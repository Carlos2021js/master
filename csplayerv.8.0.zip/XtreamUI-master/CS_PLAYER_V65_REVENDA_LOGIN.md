# CS Player v6.5 — Correção de login de Revenda

- Banco de dados: **nenhuma alteração**.
- Corrigido bloqueio indevido do grupo padrão de Revendas (grupo 4) quando uma flag legada `is_banned=1` aparece de forma inconsistente.
- O grupo realmente banido (grupo 3 / Banned) continua bloqueado.
- `reg_users.status` continua sendo respeitado.
- Bloqueios de IP, ISP e User-Agent continuam independentes.
- A mesma regra foi aplicada ao login normal, 2FA, troca de senha e validação de sessão.
- Logs agora distinguem `grupo_banido_raw` e `grupo_banido_efetivo`.

Essa correção é de compatibilidade em tempo de execução e não modifica tabela, coluna, índice ou registro do banco.

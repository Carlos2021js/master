# CS Player v6.6 — Restauração das ferramentas clássicas do Admin

Sem alterações estruturais no banco de dados.

## Restaurado/preservado em admin/reg_users.php
- Limpar filtros
- Zoom da tabela
- Atualização automática/manual no desktop e atualização manual no mobile
- Adicionar usuário registrado/revenda
- Pesquisa
- Filtro por proprietário
- Filtro Ativo/Desativado
- Quantidade de registros (10, 25, 50, 250, 500, 1000)
- Colunas clássicas: ID, usuário, proprietário, IP, tipo, status, créditos, usuários, DNS, último login e ações
- formCache e stateSave
- Paginação e ordenação server-side
- Edição
- Reset de 2FA
- Ativar/Desativar
- Banir/Desbanir (melhoria atual mantida)
- Excluir

## Administração
O administrador autenticado não perde essas ferramentas por `allowed_pages`/permissões granulares incompletas. Regras de Revenda/Sub-revenda continuam separadas.

## Responsividade
Os controles clássicos foram mantidos com ajustes de toque, quebra de toolbar e rolagem segura da tabela no smartphone.

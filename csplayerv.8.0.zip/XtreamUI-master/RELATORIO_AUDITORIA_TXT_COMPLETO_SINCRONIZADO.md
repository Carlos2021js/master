# Relatório completo — auditoria do TXT e versão sincronizada

**Projeto:** CS Player / XtreamUI  
**Escopo:** corrigir os erros presentes no TXT completo, manter a sincronização automática existente, habilitar DNS manual, revisar revenda, login, branding e Web Player.  
**Banco de dados:** não alterado.

## Resultado executivo

A auditoria encontrou seis arquivos PHP citados pelo TXT e dois grupos de problemas operacionais: warnings de tipos/arrays e um erro de sintaxe histórico em `users.php`; além de eventos HTTP 404 no teste de servidor. Os warnings do TXT correspondem a uma versão anterior ou a uma execução anterior do código, pois os arquivos atuais foram corrigidos e passaram no lint PHP. A versão entregue mantém o fluxo automático e adiciona DNS manual por sessão, sem apagar a sincronização com `streaming_servers`.

O HTTP 404 não é um erro de sintaxe do painel. Ele indica que o domínio ou porta testado respondeu, mas não disponibilizou `/player_api.php`. Agora o Web Player aceita um DNS manual, remove automaticamente o sufixo `/player_api.php` quando o usuário cola a URL completa e oferece a opção de usar somente esse DNS na sessão.

## Erros identificados no TXT completo

| Fonte do TXT | Problema identificado | Tratamento na versão atual |
|---|---|---|
| `admin/api_renew.php` | Uso histórico de constante/variável de expiração sem referência segura. | A leitura atual usa `$rRow['exp_date']` com conversão inteira e o lint passou. |
| `admin/user.php` | `Illegal string offset` nos campos MAG/E2: `parent_password`, `stb_type`, `sn`, `image_version`, `hw_version`, `device_id`, `device_id2` e `ver`. | `rMAGUser` é inicializado como array, a resposta de `getMAGUser()` é validada com `is_array()` e os acessos usam `??` e conversão segura. |
| `admin/group.php` | `in_array()` recebendo `null` em `allowed_pages`. | O JSON é decodificado e convertido para array vazio quando inválido ou ausente. |
| `admin/user_reseller.php` | Os mesmos `Illegal string offset` nos dados MAG/E2 durante edição de cliente. | `rMAGUser` possui valor padrão, é normalizado e seus campos são lidos com `??` e `htmlspecialchars((string)...)`. |
| `admin/stream_categories.php` | `foreach()` recebendo valor que não era array. | A ordenação usa uma lista vazia quando a categoria não existe ou não é array. |
| `admin/users.php` | `Parse error: unexpected end of file` na linha 847 no log histórico. | O arquivo atual passou em `php -l`, sem erro de sintaxe. |
| Logs `server_probe_failed` | HTTP 404 para `169.58.140.143`, `ppwrs.sbs` e portas 80/0 em `/player_api.php`. | Diagnóstico mantido, com entrada manual de DNS, normalização da URL e mensagem explícita. O servidor externo ainda precisa publicar o endpoint na porta correta. |

## DNS manual e sincronização

A lista automática continua sendo montada a partir dos servidores ativos de `streaming_servers`. Quando o campo DNS manual fica vazio, o comportamento anterior permanece. Quando o usuário informa um DNS, ele é validado e colocado como prioridade. A opção **Usar somente este DNS manual nesta sessão** permite ignorar temporariamente os DNS configurados e evitar novas tentativas no endereço que está retornando 404.

O usuário pode informar `http://dominio-ou-ip:porta` ou colar a URL completa terminada em `/player_api.php`; o normalizador remove o sufixo duplicável antes de montar a chamada final. O failover respeita a seleção manual e, quando permitido, continua podendo usar os demais DNS ativos.

## Revenda e criação de clientes

O atalho **Adicionar cliente** do `advanced_control_center.php` agora escolhe `user_reseller.php` para uma sessão de revenda e mantém `user.php` para uma sessão administrativa. Os menus tradicionais do header continuam preservados, incluindo clientes comuns, MAG, Enigma2, renovação, revendas e subrevendas conforme as permissões existentes.

Nenhuma permissão foi ampliada artificialmente. A correção apenas evita que uma revenda seja enviada à tela administrativa errada.

## Login administrativo e Branding Manager

A função `cs_branding_media_css()` agora coloca explicitamente `.cs-login-shell` e `.cs-login-card` acima da camada de foto/vídeo, mantendo o branding enviado pelo `branding_manager.php` como fundo e evitando que o formulário fique invisível. O cartão permanece visível, com marca CS Player centralizada e layout alinhado ao Web Player.

Foi adicionada alternância **Modo dia / Modo noite** no login administrativo. A preferência fica somente no navegador e não modifica banco ou configuração global. O Web Player já mantém a alternância de tema em `localStorage`.

## Lembrança segura do acesso

O login do Web Player salva automaticamente apenas o usuário e o DNS manual no navegador. Quando o navegador oferece `PasswordCredential` e `navigator.credentials.store`, a senha é entregue ao gerenciador de credenciais do próprio navegador. A senha não é gravada em `localStorage`, não é adicionada ao banco e não aparece nos logs.

Não é possível forçar um navegador a salvar uma senha ignorando sua política de segurança. Em aparelhos compatíveis, o gerenciador do Chrome/Android pode solicitar confirmação ou armazenar a credencial conforme as configurações do usuário.

## Arquivos alterados nesta etapa

| Arquivo | Alteração |
|---|---|
| `admin/player/bootstrap.php` | DNS manual por sessão, normalização de `/player_api.php` e lista manual/failover. |
| `admin/player/auth.php` | Recebimento, validação e persistência de DNS manual na sessão. |
| `admin/player/api.php` | Failover respeitando o DNS manual. |
| `admin/player/index.php` | Campo DNS manual, modo exclusivo, tema e lembrança segura. |
| `admin/player/assets/player.css` | Estilos do campo DNS manual, checkbox e tema claro. |
| `admin/advanced_control_center.php` | Rota correta de criação de clientes para revenda. |
| `admin/branding_helper.php` | Correção da ordem visual entre branding e formulário de login. |
| `admin/login.php` | Botão de tema dia/noite e garantia de visibilidade do cartão. |
| `admin/user.php` | Inicialização defensiva de dados MAG. |
| `admin/user_reseller.php` | Inicialização defensiva de dados MAG da revenda. |

Os arquivos `api_renew.php`, `group.php`, `stream_categories.php` e `users.php` também foram auditados e estão sintaticamente válidos; as proteções correspondentes já estavam presentes na cópia de trabalho antes desta rodada.

## Validações executadas

Foram aprovados `php -l` em todos os arquivos PHP relacionados ao TXT, incluindo `api_renew.php`, `user.php`, `user_reseller.php`, `stream_categories.php`, `users.php`, `group.php`, `bootstrap.php`, `auth.php`, `api.php`, `login.php`, `branding_helper.php` e `advanced_control_center.php`. O JavaScript do Web Player passou em `node --check`.

O teste isolado de DNS validou endereço com porta, URL terminada em `/player_api.php`, DNS manual exclusivo, DNS vazio e preservação do fallback automático. O resultado foi `manual DNS smoke test: OK`.

O SQL original continua idêntico à cópia de trabalho. SHA-256 confirmado:

```text
9b57e517257a73dcb459ee084efd5ffe66fa30e955db5743034aa159c854582e
```

## Implantação

Substitua somente os arquivos do pacote sincronizado. Não importe o SQL novamente. Após publicar, limpe o cache do navegador. No Web Player, informe o endereço base real do servidor, por exemplo `http://dominio-ou-ip:8080`, marque a opção de usar somente esse DNS e teste novamente. Se ainda houver 404, o serviço externo precisa disponibilizar `player_api.php` nessa porta; o painel não pode corrigir uma rota que não existe no servidor de origem.

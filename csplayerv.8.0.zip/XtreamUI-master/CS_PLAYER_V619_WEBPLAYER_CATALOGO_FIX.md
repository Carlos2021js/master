# CS Player v6.1.9 — Web Player / Catálogo

- Login: removida a segunda caixa visual de “Entrando…”. Agora existe apenas o estado de carregamento no botão.
- TMDB: usado somente como fallback de metadados ausentes. Não cria conteúdo, não substitui título real e não sobrescreve sinopse/imagem já presentes no catálogo.
- TMDB: busca por título agora exige correspondência forte; resultados ambíguos são descartados e registrados em log.
- TMDB: resultados marcados como adultos são recusados.
- Filmes: categorias adultas/XXX são ocultadas da navegação e seus itens não entram na listagem padrão.
- Banco de dados: nenhuma tabela, coluna ou ID alterado.

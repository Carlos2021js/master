# CS Player — melhorias e correções

## Resumo

Esta versão melhora o layout geral, corrige a aplicação dos temas claro e escuro e reforça a integração do Web Player com os servidores ativos do CS Player. O banco de dados não foi alterado: nenhuma tabela, coluna, índice ou dado do arquivo SQL foi modificado.

## Correções principais

| Área | Alteração realizada |
| --- | --- |
| Temas do painel | O cabeçalho deixou de forçar `dark`; o tema agora respeita `dark_mode` e publica `data-theme`/`data-layout-mode` coerentes. |
| CSS global | A camada Sigma e a camada de modo escuro foram escopadas ao tema escuro para não pintar o modo claro com superfícies escuras. |
| Web Player | O CSS foi reorganizado com tokens de cor, superfícies, bordas, estados de foco, responsividade, modais, cartões, busca e barra móvel. |
| Login do Player | Foi incluída alternância persistente entre claro e escuro e melhoria dos estados de senha, erro e carregamento. |
| JavaScript do Player | Foram melhorados favoritos, busca, cartões acessíveis por teclado, reconexão, failover, tratamento de erros, posição de reprodução e estados vazios. |
| DNS e portas | IPs e domínios passaram a preservar a porta configurada, inclusive `80` e `443`; IPv6 sem colchetes também é normalizado corretamente. |
| Administração | Os cartões exibem URL completa, porta HTTP, porta HTTPS e prioridade. O botão de teste mostra códigos como `HTTP 404` e o diagnóstico explica que a porta pública ou `/player_api.php` precisam estar publicados. |
| Compatibilidade | O Player oficial está centralizado em `admin/player/`; a cópia duplicada da raiz foi removida para evitar divergência. |

## Banco de dados

O arquivo `banco_xtream.sql` foi mantido fora do ciclo de edição e continua exatamente com o hash SHA-256 abaixo:

```text
9b57e517257a73dcb459ee084efd5ffe66fa30e955db5743034aa159c854582e
```

A tabela `streaming_servers` continua sendo apenas lida para sincronização dos servidores ativos. A porta usada pelo Web Player vem de `http_broadcast_port` para HTTP ou `https_broadcast_port` para HTTPS.

## Diagnóstico da captura enviada

O endereço mostrado na captura foi testado sem credenciais reais. O host respondeu, mas `player_api.php` retornou HTTP 404 em `:80`, `:25500` e `:443`. Isso demonstra que o endereço está alcançável, porém o endpoint Xtream não está publicado nessas portas. Para o login funcionar, configure no servidor uma porta pública que encaminhe para o document root que contém `player_api.php`, ou informe no cadastro de Servidores a porta pública real em `http_broadcast_port`/`https_broadcast_port`.

Depois de ajustar o servidor, utilize **Admin > Settings > Web Player Multi-DNS > Sincronizar agora** e execute o botão **Testar**. A URL exibida deverá conter a porta completa; se ainda houver erro, o botão mostrará o código HTTP ou a indicação de timeout/conexão.

## Validação executada

Foram validados 241 arquivos PHP ativos sem erros de sintaxe, os dois arquivos JavaScript do Player com verificação de sintaxe, os blocos CSS principais por balanceamento de chaves e os cenários de URL com domínio, IP, IPv6, porta explícita e portas padrão. A pré-visualização local foi revisada nos temas claro e escuro.

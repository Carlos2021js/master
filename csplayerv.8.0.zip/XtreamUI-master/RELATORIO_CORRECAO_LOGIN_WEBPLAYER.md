# Relatório técnico — Login administrativo e Web Player

**Projeto:** CS Player / XtreamUI  
**Data da análise:** 18 de agosto de 2026  
**Escopo:** corrigir o redirecionamento indevido de administradores para `user_reseller.php`, eliminar a resposta branca dessa rota e reduzir a espera percebida no login e no carregamento inicial do Web Player.  
**Restrição:** nenhuma alteração no banco de dados ou no arquivo SQL.

## Diagnóstico

A tela branca não era uma página HTML vazia causada pelo navegador. A rota `admin/user_reseller.php` era exclusiva de revendas e encerrava a execução com `exit` sempre que `$rPermissions["is_admin"]` era verdadeiro. Portanto, quando um administrador chegava nessa URL por um link antigo, por um `referrer` preservado no formulário de login ou por uma sessão/papel inconsistente, o comportamento era uma resposta sem conteúdo.

O destino do login continua sendo determinado pelo grupo persistido em `reg_users.member_group_id` e pela permissão `is_admin`; o nome do usuário, isoladamente, não define o papel. No SQL de referência, a conta `admin` está associada ao grupo 1. Se a instalação real utilizar outro `member_group_id`, esse vínculo precisa ser verificado no painel de grupos ou diretamente na instalação, sem importar o SQL novamente.

O log recebido também registrava warnings antigos de `api_renew.php`, `user.php` e `group.php`. Na cópia atual, os dois pontos mais diretamente citados já estão protegidos: `api_renew.php` acessa `exp_date` por índice de array e `group.php` normaliza `allowed_pages` para array antes de chamar `in_array`. Esses warnings antigos não foram tratados como a causa principal da tela branca atual.

A demora do Web Player tinha duas causas de código. O endpoint de autenticação consultava os DNS ativos em sequência, e a home executava seis chamadas Xtream sequenciais — três listas de categorias e três listas de conteúdo — antes de devolver qualquer resposta ao navegador. O usuário, portanto, via o envio do formulário sem feedback e aguardava uma única resposta final.

## Alterações aplicadas

| Área | Alteração | Resultado esperado |
|---|---|---|
| `admin/login.php` | O `referrer` de rotas exclusivas de revenda é descartado quando o usuário autenticado é administrador. Foi adicionado feedback de envio ao login, inclusive no fluxo reCAPTCHA v3. | O admin volta para `dashboard.php` ou para uma página administrativa válida, sem retornar a `user_reseller.php`; o botão não permite duplo envio e mostra progresso. |
| `admin/user_reseller.php` | Administradores são redirecionados para `user.php`, preservando o ID ou o modo MAG/E2 quando aplicável. | Acesso direto à rota antiga não produz mais tela branca. |
| `admin/user_reseller_edit.php` | Aplicado o mesmo redirecionamento para a tela administrativa. | A rota auxiliar também não encerra silenciosamente para admins. |
| `admin/reseller.php` | Administradores são enviados para `dashboard.php`. | Evita outra resposta vazia quando uma URL de revenda é acessada pelo papel errado. |
| `admin/player/bootstrap.php` | Criadas rotinas de requisições em lote e autenticação concorrente com `curl_multi`, mantendo fallback sequencial se cURL não existir. | Menor tempo de login e de carregamento quando há múltiplos DNS ou chamadas remotas. |
| `admin/player/auth.php` | O login usa autenticação concorrente entre DNS ativos e mantém o servidor confirmado por prioridade configurada. | DNS lento ou indisponível não bloqueia todos os outros DNS em sequência. |
| `admin/player/api.php` | As seis ações da home são disparadas por lote concorrente, preservando o mesmo formato JSON. | Categorias e conteúdo chegam em uma rodada de rede, em vez de seis rodadas sequenciais. |
| `admin/player/index.php` e `assets/player.css` | Spinner de autenticação, botão desabilitado, mensagens de progresso e versionamento do CSS. | O usuário vê imediatamente que o login está sendo processado. |
| `admin/player/home.php` e `assets/player.js` | Overlay inicial, estado de atualização de categoria, timeout de 35 segundos, mensagens de erro e versionamento dos assets. | O conteúdo mostra carregamento, termina com estado claro e não fica aguardando indefinidamente no navegador. |

## Verificações executadas

A sintaxe PHP foi validada com PHP 8.3 nos arquivos alterados de login, autorização e Web Player. A sintaxe JavaScript foi validada com `node --check`. Também foi executado um teste funcional local com um servidor HTTP simulado, confirmando autenticação concorrente e carregamento em lote das seis ações da home.

| Verificação | Resultado |
|---|---:|
| Lint PHP dos arquivos corrigidos | Aprovado |
| Sintaxe de `admin/player/assets/player.js` | Aprovado |
| Teste local de `cs_player_authenticate_dns()` | Aprovado |
| Teste local de `cs_player_api_batch()` | Aprovado |
| HTML do login do Web Player contém formulário e loading | Aprovado |
| Guard de redirecionamento admin em `user_reseller.php` | Aprovado |
| Hash do SQL original versus cópia de trabalho | Idêntico |

O SHA-256 do SQL original e da cópia preservada é `9b57e517257a73dcb459ee084efd5ffe66fa30e955db5743034aa159c854582e`. Nenhuma consulta de alteração foi executada durante esta correção.

## Observação sobre `ERR_CONNECTION_TIMED_OUT`

A mensagem `ERR_CONNECTION_TIMED_OUT` exibida na captura de tela significa que o navegador não recebeu resposta do endereço e porta do servidor. O código corrigido fornece loading e timeout quando o servidor aceita a conexão e o PHP está processando a requisição; ele não consegue corrigir, sozinho, firewall, porta fechada, serviço web parado, PHP-FPM indisponível ou indisponibilidade do próprio servidor. Se a mensagem continuar antes de a página de login abrir, deve-se verificar no servidor a porta `25500`, o serviço web/PHP-FPM e as regras de firewall.

## Implantação recomendada

Faça backup da pasta atual e substitua os arquivos pelo conteúdo de `csplayerv.3.0.1-login-webplayer-corrigido.zip`. Não importe `banco_xtream.sql` novamente. Depois da substituição, limpe o cache do navegador ou abra uma janela anônima; os assets do Web Player foram versionados como `v=20260818` para reduzir o risco de o celular reutilizar JavaScript e CSS antigos.

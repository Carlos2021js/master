# CS Player v10 — correção do Web Player

Correções aplicadas sem alteração do banco de dados:

- Caminho público corrigido para `/player/` (o diretório físico continua `admin/player/`).
- Sincronização de DNS interno passa a respeitar `http_broadcast_port` / `https_broadcast_port` de `streaming_servers`, ignorando uma porta administrativa eventualmente embutida em `domain_name`.
- Caminhos administrativos eventualmente presentes em `domain_name` não contaminam o endpoint Xtream do player.
- Identificador de DNS em `stream.php` deixa de ser convertido para inteiro, preservando IDs estáveis como `server:1` e `external:0` durante failover/reprodução.
- PHP do Web Player e JavaScript principal validados sintaticamente.

URL pública esperada quando o painel abre em `http://HOST:PORTA/dashboard.php`:

`http://HOST:PORTA/player/`

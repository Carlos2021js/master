/* CS PLAYER v6.7 — UX global, sem dependência de banco. */
(function(){
  'use strict';
  var dict={
    'Show':'Mostrar','entries':'registros','Search:':'Pesquisar:','No data available in table':'Nenhum registro encontrado',
    'No matching records found':'Nenhum registro correspondente','Showing 0 to 0 of 0 entries':'Mostrando 0 a 0 de 0 registros',
    'Previous':'Anterior','Next':'Próximo','Processing...':'Processando...','Loading...':'Carregando...'
  };
  function textNodes(root){
    var w=document.createTreeWalker(root||document.body,NodeFilter.SHOW_TEXT,{acceptNode:function(n){return n.parentNode&&/^(SCRIPT|STYLE|TEXTAREA|CODE|PRE)$/.test(n.parentNode.nodeName)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),n;
    while((n=w.nextNode())){var t=n.nodeValue,trim=t.trim();if(dict[trim])n.nodeValue=t.replace(trim,dict[trim]);
      else if(/^Showing \d+ to \d+ of \d+ entries$/.test(trim))n.nodeValue=t.replace(trim,trim.replace('Showing','Mostrando').replace(' to ',' a ').replace(' of ',' de ').replace(' entries',' registros'));
    }
  }
  function enhanceTables(root){
    (root||document).querySelectorAll('table.dataTable, table[id^="datatable"], .table.dt-responsive').forEach(function(table){
      if(table.dataset.cs67==='1')return;table.dataset.cs67='1';
      var p=table.parentElement;if(p&&!p.classList.contains('cs-datatable-shell')){var shell=document.createElement('div');shell.className='cs-datatable-shell';p.insertBefore(shell,table);shell.appendChild(table)}
    });
  }
  function clipboardFlash(){
    var el=document.querySelector('.cs-copy-flash');if(!el){el=document.createElement('div');el.className='cs-copy-flash';el.textContent='✓ Informações copiadas';document.body.appendChild(el)}
    el.classList.add('show');clearTimeout(el._t);el._t=setTimeout(function(){el.classList.remove('show')},1600);
  }
  document.addEventListener('click',function(e){
    var btn=e.target.closest('[onclick*="copy" i], .btn-copy-details, [data-copy], [title*="copiar" i]');if(btn)setTimeout(clipboardFlash,120);
    var link=e.target.closest('a[href]');if(link&&link.target!=='_blank'&&!link.href.startsWith('javascript:')&&!link.href.startsWith('#')){var bar=document.querySelector('.cs-loading-bar');if(bar)bar.classList.add('active')}
  },true);
  document.addEventListener('keydown',function(e){
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){var input=document.querySelector('input[type="search"],input[id*="search" i],input[placeholder*="pesquisar" i],input[placeholder*="search" i]');if(input){e.preventDefault();input.focus();input.select&&input.select()}}
  });
  function init(){
    var bar=document.createElement('div');bar.className='cs-loading-bar';document.body.appendChild(bar);
    textNodes(document.body);enhanceTables(document);
    var obs=new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(function(n){if(n.nodeType===1){textNodes(n);enhanceTables(n)}})})});obs.observe(document.body,{childList:true,subtree:true});
    window.addEventListener('pageshow',function(){bar.className='cs-loading-bar'});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

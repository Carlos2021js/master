<?php
include 'session.php'; include 'functions.php';
if ((int)($rPermissions['is_admin'] ?? 0) !== 1 || !hasPermissions('adv','settings')) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'Acesso restrito ao administrador.'], JSON_UNESCAPED_UNICODE);
    exit;
}
require_once __DIR__ . '/player/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function out($a,$s=200){http_response_code($s);echo json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}

function cs_admin_fixed_player_dns(): array {
    $servers = function_exists('getStreamingServers') ? getStreamingServers(true) : [];
    return cs_player_server_dns_from_rows(array_values(is_array($servers) ? $servers : []));
}

function cs_admin_probe_dns(string $url, int $timeout = 5): array {
    $url = cs_player_normalize_dns($url);
    if ($url === '') {
        cs_player_write_log('server_probe_invalid_dns', ['input' => $url], 'warning');
        return ['ok'=>false,'latency_ms'=>0,'http_code'=>0,'message'=>'DNS inválido'];
    }
    if (!function_exists('curl_init')) {
        cs_player_write_log('server_probe_curl_unavailable', ['host' => (string)(parse_url($url, PHP_URL_HOST) ?? '')], 'critical');
        return ['ok'=>false,'latency_ms'=>0,'http_code'=>0,'message'=>'cURL indisponível'];
    }
    $probe = rtrim($url,'/') . '/player_api.php?username=__csplayer_probe__&password=__csplayer_probe__';
    $ch = curl_init($probe);
    $start = microtime(true);
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_FOLLOWLOCATION=>true,
        CURLOPT_MAXREDIRS=>3,
        CURLOPT_CONNECTTIMEOUT=>min(4,$timeout),
        CURLOPT_TIMEOUT=>$timeout,
        CURLOPT_USERAGENT=>'CSPlayer-DNS-Probe/1.2',
        CURLOPT_SSL_VERIFYPEER=>false,
        CURLOPT_SSL_VERIFYHOST=>false,
    ]);
    $body=curl_exec($ch);
    $err=(string)curl_error($ch);
    $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
    $effective=(string)curl_getinfo($ch,CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    $ms=(int)round((microtime(true)-$start)*1000);
    $json=is_string($body)?json_decode($body,true):null;
    // Só é sucesso quando a rota Xtream esperada retorna JSON com HTTP 2xx.
    $endpointOk = $code >= 200 && $code < 300 && is_array($json);
    if ($endpointOk) {
        $message = 'player_api.php respondeu';
    } elseif ($code === 404) {
        $message = 'HTTP 404: /player_api.php não foi encontrado neste domínio/porta. Verifique o domínio público e a porta HTTP de transmissão.';
    } elseif ($code > 0) {
        $message = 'HTTP '.$code.' em '.$url.'; confirme a porta pública e a publicação de /player_api.php.';
    } elseif ($err !== '') {
        $message = 'Falha de conexão: '.$err.'; confirme firewall, DNS e porta pública.';
    } else {
        $message = 'Sem resposta em '.$url.'; confirme firewall, DNS e porta pública.';
    }
    if (!$endpointOk) {
        cs_player_write_log('server_probe_failed', [
            'host' => (string)(parse_url($url, PHP_URL_HOST) ?? ''),
            'port' => (int)(parse_url($url, PHP_URL_PORT) ?? 0),
            'http_code' => $code,
            'latency_ms' => $ms,
            'curl_error' => $err,
            'endpoint' => '/player_api.php',
            'message' => $message,
        ], $code === 404 ? 'error' : 'warning');
    }
    return [
        'ok'=>$endpointOk,
        'latency_ms'=>$ms,
        'http_code'=>$code,
        'effective_url'=>$effective ?: $probe,
        'message'=>$message,
    ];
}

if($_SERVER['REQUEST_METHOD']==='GET'){
    $cfg=cs_player_load_config();
    $fixed = cs_admin_fixed_player_dns();
    if(($_GET['action']??'')==='test'){
        $url=cs_player_normalize_dns((string)($_GET['url']??''));
        if(!$url) out(['ok'=>false,'message'=>'DNS inválido'],400);
        out(cs_admin_probe_dns($url, max(3,min(15,(int)($cfg['request_timeout']??8)))));
    }
    if(($_GET['action']??'')==='sync'){
        out(['ok'=>true,'fixed_dns'=>$fixed,'count'=>count($fixed),'message'=>'Servidores sincronizados em tempo real.']);
    }
    if(($_GET['action']??'')==='catalog_search'){
        $q=trim((string)($_GET['q']??''));
        if(mb_strlen($q)<2) out(['ok'=>true,'items'=>[]]);
        $db=cs_player_db(); if(!$db) out(['ok'=>false,'message'=>'Banco indisponível'],503);
        $safe=$db->real_escape_string('%'.$q.'%'); $items=[];
        $rs=@$db->query("SELECT id,stream_display_name,stream_icon,type,category_id,movie_properties FROM streams WHERE type IN (1,2) AND stream_display_name LIKE '$safe' ORDER BY stream_display_name LIMIT 35");
        if($rs) while($r=$rs->fetch_assoc()){$props=json_decode((string)($r['movie_properties']??''),true);if(!is_array($props))$props=[];$items[]=['type'=>(int)$r['type']===1?'live':'movie','id'=>(int)$r['id'],'title'=>(string)$r['stream_display_name'],'image'=>(string)($r['stream_icon']?:($props['movie_image']??'')),'synopsis'=>(string)($props['plot']??$props['description']??'')];}
        $rs=@$db->query("SELECT id,title,cover,plot FROM series WHERE title LIKE '$safe' ORDER BY title LIMIT 35");
        if($rs) while($r=$rs->fetch_assoc())$items[]=['type'=>'series','id'=>(int)$r['id'],'title'=>(string)$r['title'],'image'=>(string)($r['cover']??''),'synopsis'=>(string)($r['plot']??'')];
        out(['ok'=>true,'items'=>array_slice($items,0,60)]);
    }
    out([
        'ok'=>true,
        'config'=>$cfg,
        'fixed_dns'=>$fixed,
        'player_url'=>'player/',
        'player_public_path'=>'/player/',
        'document_root_hint'=>$_SERVER['DOCUMENT_ROOT']??'',
    ]);
}
if($_SERVER['REQUEST_METHOD']!=='POST')out(['ok'=>false],405);
$raw=json_decode((string)file_get_contents('php://input'),true);
if(!is_array($raw))out(['ok'=>false,'message'=>'JSON inválido'],400);
$cfg=cs_player_default_config();
foreach(['enabled','smart_login','dns_failover','pip_enabled','autoplay_next','remember_position'] as $k)$cfg[$k]=!empty($raw[$k]);
foreach(['brand','login_title','login_subtitle','home_title'] as $k)$cfg[$k]=mb_substr(trim((string)($raw[$k]??$cfg[$k])),0,160);
$cfg['hls_retries']=max(1,min(10,(int)($raw['hls_retries']??4)));
$cfg['stall_timeout']=max(5,min(60,(int)($raw['stall_timeout']??12)));
$cfg['request_timeout']=max(3,min(30,(int)($raw['request_timeout']??8)));
$cfg['manual_highlights']=[];
foreach(($raw['manual_highlights']??[]) as $i=>$row){
    if(!is_array($row))continue; $type=(string)($row['type']??''); $id=(int)($row['id']??0);
    if(!$id||!in_array($type,['live','movie','series'],true))continue;
    $cfg['manual_highlights'][]=['type'=>$type,'id'=>$id,'title'=>mb_substr(trim((string)($row['title']??'')),0,180),'custom_image'=>mb_substr(trim((string)($row['custom_image']??'')),0,1000),'custom_synopsis'=>mb_substr(trim((string)($row['custom_synopsis']??'')),0,2000),'enabled'=>!array_key_exists('enabled',$row)||!empty($row['enabled']),'sort'=>max(1,min(999,(int)($row['sort']??($i+1))))];
}
usort($cfg['manual_highlights'],static fn($a,$b)=>(int)$a['sort']<=>(int)$b['sort']);
$cfg['dns']=[];
foreach(($raw['dns']??[]) as $i=>$row){
    if(!is_array($row))continue;
    // DNS fixos nunca são gravados aqui; eles são lidos de streaming_servers em tempo real.
    if(!empty($row['fixed']) || (($row['source']??'')==='streaming_servers')) continue;
    $url=cs_player_normalize_dns((string)($row['url']??''));
    if(!$url)continue;
    $cfg['dns'][]=[
        'id'=>(string)($row['id']??('external_'.($i+1))),
        'name'=>mb_substr(trim((string)($row['name']??('DNS Externo '.($i+1)))),0,80),
        'url'=>$url,
        'enabled'=>!empty($row['enabled']),
        'priority'=>max(1,min(999,(int)($row['priority']??($i+1)))),
        'fixed'=>false,
        'source'=>'external',
    ];
}
if(!cs_player_save_config($cfg))out(['ok'=>false,'message'=>'Não foi possível salvar admin/player/storage/config.php'],500);
out(['ok'=>true,'message'=>'Configurações do Web Player salvas. DNS internos continuam sincronizados automaticamente.','config'=>$cfg,'fixed_dns'=>cs_admin_fixed_player_dns()]);

<?php
require __DIR__ . '/proxy_lib.php';
cs_player_require_login();
$cfg = cs_player_load_config();
$requested = isset($_GET['dns']) ? (string)$_GET['dns'] : null;
$row = cs_player_session_dns($cfg, $requested);
if (!$row) {
    cs_player_write_log('stream_dns_unavailable', ['requested_dns' => $requested], 'error');
    http_response_code(503);
    exit('DNS indisponível');
}
$type = (string)($_GET['type'] ?? 'live');
$id = (int)($_GET['id'] ?? 0);
$ext = preg_replace('/[^a-zA-Z0-9]/', '', (string)($_GET['ext'] ?? ''));
if (!$id) {
    cs_player_write_log('stream_invalid_request', ['type' => $type, 'stream_id' => $id], 'warning');
    http_response_code(400);
    exit('Stream inválido');
}
$uRaw = (string)$_SESSION['cs_player_username'];
$pRaw = (string)$_SESSION['cs_player_password'];
$u = rawurlencode($uRaw);
$p = rawurlencode($pRaw);
$base = rtrim((string)$row['url'], '/');

// Servidor interno: reproduz a origem já cadastrada no banco e não depende
// das rotas Xtream /live, /movie ou /series, que podem não existir neste painel.
if (!empty($_SESSION['cs_player_local_api'])) {
    $source = cs_player_local_stream_source($id, $uRaw, $pRaw);
    if (!$source) {
        cs_player_write_log('local_stream_source_unavailable', ['stream_type'=>$type,'stream_id'=>$id], 'error');
        http_response_code(404);
        exit('Origem do stream não encontrada');
    }
    if ($type !== 'live' && !preg_match('~\.m3u8(?:$|\?)~i', $source)) {
        cs_stream_binary($source);
    }
    [$code, $body, $ct, $effective] = cs_fetch_small($source);
    if ($code < 200 || $code >= 400) {
        cs_player_write_log('local_stream_origin_failed', ['http_code'=>$code,'content_type'=>$ct,'stream_type'=>$type,'stream_id'=>$id,'origin_host'=>(string)(parse_url($source,PHP_URL_HOST)??'')], $code===404?'error':'warning');
        http_response_code($code ?: 502);
        exit('Falha na origem do stream');
    }
    if (stripos($ct, 'mpegurl') !== false || preg_match('~\.m3u8(?:$|\?)~i', $effective)) {
        header('Content-Type: application/vnd.apple.mpegurl');
        header('Cache-Control: no-store');
        echo cs_rewrite_manifest($body, $effective);
        exit;
    }
    // Conteúdo live não-HLS: usa proxy binário para manter compatibilidade.
    cs_stream_binary($source);
}

if ($type === 'live') {
    $ext = 'm3u8';
    $url = "$base/live/$u/$p/$id.$ext";
} elseif ($type === 'movie') {
    $ext = $ext ?: 'mp4';
    $url = "$base/movie/$u/$p/$id.$ext";
} else {
    $ext = $ext ?: 'mp4';
    $url = "$base/series/$u/$p/$id.$ext";
}
if ($type !== 'live') {
    cs_stream_binary($url);
}
[$code, $body, $ct, $effective] = cs_fetch_small($url);
if ($code < 200 || $code >= 400) {
    cs_player_write_log('stream_origin_failed', [
        'host' => (string)(parse_url($base, PHP_URL_HOST) ?? ''),
        'http_code' => $code,
        'content_type' => $ct,
        'stream_type' => $type,
        'stream_id' => $id,
        'effective_url' => $effective,
    ], $code === 404 ? 'error' : 'warning');
    http_response_code($code ?: 502);
    exit('Falha no stream');
}
header('Content-Type: application/vnd.apple.mpegurl');
header('Cache-Control: no-store');
echo cs_rewrite_manifest($body, $effective);

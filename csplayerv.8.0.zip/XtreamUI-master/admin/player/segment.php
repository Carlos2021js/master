<?php
require __DIR__ . '/proxy_lib.php';
cs_player_require_login();$k=(string)($_GET['k']??'');$entry=$_SESSION['cs_player_proxy_map'][$k]??null;if(!is_array($entry)||empty($entry['url'])){http_response_code(404);exit;}$url=(string)$entry['url'];
if(preg_match('~\.m3u8(?:\?|$)~i', $url)){[$code,$body,$ct,$effective]=cs_fetch_small($url);if($code<200||$code>=400){http_response_code($code?:502);exit;}header('Content-Type: application/vnd.apple.mpegurl');echo cs_rewrite_manifest($body,$effective);exit;}
cs_stream_binary($url);

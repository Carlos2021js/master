<?php
require_once __DIR__ . '/bootstrap.php';
function cs_abs_url(string $base,string $ref): string {
    if (preg_match('~^https?://~i',$ref)) return $ref;
    $b=parse_url($base); if(!$b) return $ref; $scheme=$b['scheme']??'http'; $host=$b['host']??''; $port=isset($b['port'])?':'.$b['port']:'';
    if(isset($ref[0]) && $ref[0]==='/') return "$scheme://$host$port$ref";
    $path=$b['path']??'/'; $dir=preg_replace('~/[^/]*$~','/',$path); return "$scheme://$host$port".$dir.$ref;
}
function cs_proxy_register(string $url): string {
    if(!isset($_SESSION['cs_player_proxy_map'])||!is_array($_SESSION['cs_player_proxy_map'])) $_SESSION['cs_player_proxy_map']=[];
    $key=substr(hash('sha256',$url.session_id()),0,24); $_SESSION['cs_player_proxy_map'][$key]=['url'=>$url,'ts'=>time()];
    if(count($_SESSION['cs_player_proxy_map'])>2000){ foreach($_SESSION['cs_player_proxy_map'] as $k=>$v){if(($v['ts']??0)<time()-3600)unset($_SESSION['cs_player_proxy_map'][$k]);} }
    return $key;
}
function cs_rewrite_manifest(string $body,string $base): string {
    $lines=preg_split('/\r?\n/',$body); $out=[];
    foreach($lines as $line){
        if($line!=='' && $line[0]!=='#'){$u=cs_abs_url($base,trim($line));$line='segment.php?k='.rawurlencode(cs_proxy_register($u));}
        elseif(strpos($line,'URI="') !== false){$line=preg_replace_callback('/URI="([^"]+)"/',function($m)use($base){$u=cs_abs_url($base,$m[1]);return 'URI="segment.php?k='.rawurlencode(cs_proxy_register($u)).'"';},$line);}
        $out[]=$line;
    }
    return implode("\n",$out);
}
function cs_fetch_small(string $url): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_USERAGENT => 'CSPlayer-Web/1.0',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $ct = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $effective = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    $error = (string)curl_error($ch);
    curl_close($ch);
    if ($code < 200 || $code >= 400 || !is_string($body)) {
        cs_player_write_log('media_fetch_failed', [
            'host' => (string)(parse_url($url, PHP_URL_HOST) ?? ''),
            'http_code' => $code,
            'content_type' => $ct,
            'curl_error' => $error,
        ], $code === 404 ? 'error' : 'warning');
    }
    return [$code, is_string($body) ? $body : '', $ct, $effective ?: $url];
}
function cs_stream_binary(string $url) {
    $ch = curl_init($url);
    $headers = [];
    if (isset($_SERVER['HTTP_RANGE'])) $headers[] = 'Range: ' . $_SERVER['HTTP_RANGE'];
    curl_setopt_array($ch, [
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_USERAGENT => 'CSPlayer-Web/1.0',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HEADERFUNCTION => function($ch, $header) {
            $line = strtolower($header);
            if (strpos($line, 'content-type:') === 0 || strpos($line, 'content-length:') === 0 || strpos($line, 'content-range:') === 0 || strpos($line, 'accept-ranges:') === 0) header(trim($header));
            return strlen($header);
        },
        CURLOPT_WRITEFUNCTION => function($ch, $data) {
            echo $data;
            flush();
            return strlen($data);
        },
    ]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $error = (string)curl_error($ch);
    if ($code < 200 || $code >= 400 || $error !== '') {
        cs_player_write_log('media_stream_failed', [
            'host' => (string)(parse_url($url, PHP_URL_HOST) ?? ''),
            'http_code' => $code,
            'curl_error' => $error,
        ], $code === 404 ? 'error' : 'warning');
    }
    if (!headers_sent()) http_response_code($code ?: 200);
    curl_close($ch);
    exit;
}

<?php
if (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }
return json_decode('{"enabled":true,"brand":"CS Player","login_title":"CS Player","login_subtitle":"Entre com sua assinatura para continuar","home_title":"Início","smart_login":true,"dns_failover":true,"pip_enabled":true,"autoplay_next":false,"remember_position":true,"hls_retries":4,"stall_timeout":12,"request_timeout":8,"dns":[]}', true) ?: [];

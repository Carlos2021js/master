# CS Player v6.2.2

- Destaques manuais integrados diretamente ao `admin/settings.php` existente.
- Nenhum novo settings foi criado.
- Pesquisa canais, filmes e séries existentes no catálogo.
- Não altera tabelas, colunas ou IDs do banco.
- Configuração gravada no storage já usado pelo Web Player.
- Imagem e sinopse manuais são opcionais; catálogo/TMDB só completam campos ausentes.
- Avatar do Web Player abre menu com Minha Lista, Dia/Noite, Editar perfil e Sair.

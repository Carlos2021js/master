# CS PLAYER v6.1.6 — Web Player HTTP 500 + Tema global

Correções aplicadas em 19/08/2026.

## Web Player
- Servidor interno do CS PLAYER fixado em HTTP porta 80.
- Autenticação do servidor interno feita diretamente na tabela `users` existente.
- O servidor interno não depende mais de `/player_api.php` para o login.
- DNS externos continuam compatíveis com `player_api.php`.
- Catálogo local utiliza as tabelas existentes (`streams`, `series`, `series_episodes`, `stream_categories`, `bouquets`).
- Permissões de conteúdo seguem os bouquets vinculados ao cliente.
- Reprodução local utiliza a origem cadastrada no stream quando aplicável.
- Falhas técnicas HTTP/cURL/endpoints permanecem em `admin/logs/cs-player/web-player.log`.
- A tela de login não mostra HTTP 500, HTTP 404, player_api.php, portas ou detalhes internos; mostra apenas mensagem amigável.

## Interface
- Nome CS Player centralizado no cabeçalho do login do Web Player.
- Botão dia/noite do login do Web Player corrigido.
- Preferência de tema persistida no `localStorage` com a chave `csplayer_theme`.
- Botão dia/noite global adicionado aos layouts compartilhados de Admin/Revenda/Operador.
- Login administrativo passa a usar a mesma preferência de tema do restante do sistema.
- Tema escuro é aplicado dinamicamente por classes/atributos, sem necessidade de recarregar a página.

## Validação
- 257 arquivos PHP do diretório `admin/` verificados com `php -l`.
- 0 erros de sintaxe PHP encontrados.
- JavaScript `admin/assets/js/cs-theme-toggle.js` validado com `node --check`.

## Banco de dados
Nenhuma tabela, coluna ou ID foi criado, removido ou alterado.

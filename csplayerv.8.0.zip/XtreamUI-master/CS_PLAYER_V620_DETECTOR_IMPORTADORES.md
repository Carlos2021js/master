# CS PLAYER v6.2.0 — Detector dos Importadores

## Objetivo
Melhorar a detecção de canais, filmes, séries, temporadas, episódios e categorias sem alterar tabelas, colunas, IDs ou a arquitetura individual dos importadores.

## Playlist real analisada
Arquivo de teste: playlist_ana194812_plus.m3u
- 321.279 entradas EXTINF
- 117 categorias diferentes
- Predominância de episódios de séries/novelas em MP4
- Canais ao vivo majoritariamente com URLs sem extensão
- Filmes em MP4/MKV/AVI e coleções organizadas por group-title

## Nova ordem de decisão
1. Modo manual escolhido pelo administrador continua tendo prioridade.
2. Prefixo explícito do group-title:
   - Canais / Live / TV / Rádio -> live
   - Series / Séries / Seriados / Novelas / Doramas / Animes / Cursos -> séries/episódios
   - Filmes / Movies / VOD / Cinema -> filme
   - Coleção / Collection / Shows -> filme
3. Padrões de episódio: SxxEyy, 1x01, Season/Episode, Temporada/Episódio, Txx EPyy.
4. Extensão da mídia como fallback: m3u8/ts/mpegts -> live; mp4/mkv e formatos legados permitidos -> VOD.
5. Sem sinal confiável -> item permanece não classificado em vez de ser gravado no tipo errado.

## Regra crítica
Categorias como `Canais | Séries 24H` e `Canais | Filmes e Séries` são canais LIVE. O prefixo `Canais` tem prioridade sobre palavras posteriores do nome da categoria.

## Importadores mantidos independentes
- admin/m3u_update_nodup.php: detector interno atualizado.
- admin/m3u_update_nodup2.php: estrutura modular preservada; includes/m3u2/Classifier.php atualizado.
- admin/m3u_update_nodup3.php: estrutura modular preservada; includes/m3u3/Classifier.php atualizado.
- admin/m3u_update_nodup1.php também recebeu a correção de compatibilidade para evitar regressões em rotas legadas.

## Banco de dados
Nenhuma alteração de schema foi feita. Os tipos existentes continuam sendo usados:
- 1 = live
- 2 = movie
- 5 = series/episode

## Validação
- 279 arquivos PHP verificados com php -l.
- 0 erros de sintaxe.

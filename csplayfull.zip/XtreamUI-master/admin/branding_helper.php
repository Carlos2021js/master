<?php
/** CS Player - identidade visual e mídia, independente do banco. */
if (!function_exists('cs_branding_config')) {
    function cs_branding_config() {
        static $config = null;
        if ($config !== null) return $config;
        $file = __DIR__ . '/assets/uploads/branding/branding.json';
        $config = [];
        if (is_file($file)) {
            $decoded = json_decode((string) @file_get_contents($file), true);
            if (is_array($decoded)) $config = $decoded;
        }
        return $config;
    }
    function cs_branding_value($key, $fallback = null) {
        $c = cs_branding_config();
        return array_key_exists($key, $c) ? $c[$key] : $fallback;
    }
    function cs_branding_asset($slot, $fallback = '') {
        $config = cs_branding_config();
        if (!empty($config[$slot]) && is_string($config[$slot])) {
            $relative = ltrim(str_replace(['..', '\\'], ['', '/'], $config[$slot]), '/');
            if (is_file(__DIR__ . '/' . $relative)) return $relative . '?v=' . @filemtime(__DIR__ . '/' . $relative);
        }
        return $fallback;
    }
    function cs_branding_avatar_html($username, $size = 28) {
        $src = cs_branding_asset('admin_avatar', '');
        if ($src !== '') return '<img src="'.htmlspecialchars($src,ENT_QUOTES,'UTF-8').'" alt="Admin" style="width:'.(int)$size.'px;height:'.(int)$size.'px;border-radius:50%;object-fit:cover;margin-right:8px;vertical-align:middle">';
        return '<i class="fas fa-user-alt"></i>';
    }
    function cs_branding_background_media($context) {
        $video = cs_branding_asset($context.'_video', '');
        $image = cs_branding_asset($context.'_background', '');
        $opacity = max(0, min(100, (int)cs_branding_value($context.'_overlay', 35))) / 100;
        $muted = cs_branding_value($context.'_muted', true) ? ' muted' : '';
        $loop = cs_branding_value($context.'_loop', true) ? ' loop' : '';
        $autoplay = cs_branding_value($context.'_autoplay', true) ? ' autoplay' : '';
        $controls = cs_branding_value($context.'_controls', false) ? ' controls' : '';
        $html = '<div class="cs-media-bg" aria-hidden="true">';
        if ($video) $html .= '<video id="cs-'.$context.'-video" playsinline preload="metadata"'.$autoplay.$loop.$muted.$controls.' poster="'.htmlspecialchars($image,ENT_QUOTES,'UTF-8').'"><source src="'.htmlspecialchars($video,ENT_QUOTES,'UTF-8').'" type="video/mp4"></video>';
        elseif ($image) $html .= '<div class="cs-media-image" style="background-image:url(\''.htmlspecialchars($image,ENT_QUOTES,'UTF-8').'\')"></div>';
        $html .= '<div class="cs-media-overlay" style="background:rgba(5,10,20,'.$opacity.')"></div></div>';
        if ($video && !$muted) $html .= '<button type="button" class="cs-media-sound" onclick="csToggleMediaSound(\''.$context.'\')" title="Ativar/desativar áudio"><i class="mdi mdi-volume-high"></i></button>';
        return $html;
    }
    function cs_branding_media_css() {
        $banner = cs_branding_asset('banner_main', '');
        $css = '<style>.cs-media-bg{position:fixed;inset:0;z-index:-2;overflow:hidden;background:#07101d}.cs-media-bg video,.cs-media-bg .cs-media-image{width:100%;height:100%;object-fit:cover;background-size:cover;background-position:center}.cs-media-bg .cs-media-overlay{position:absolute;inset:0}.cs-media-sound{position:fixed;right:18px;bottom:18px;z-index:1050;width:44px;height:44px;border:0;border-radius:50%;background:rgba(0,0,0,.62);color:#fff;font-size:21px;box-shadow:0 8px 25px rgba(0,0,0,.28)}.cs-dashboard-surface{position:relative;z-index:1}.cs-dashboard-transparent .card,.cs-dashboard-transparent .card-box{backdrop-filter:blur(8px);background-color:rgba(255,255,255,.88)!important}';
        if ($banner) {
            $css .= '.nav-user{background-image:url("'.htmlspecialchars($banner,ENT_QUOTES,'UTF-8').'")!important;background-size:cover;background-position:center}';
        }
        $css .= '</style><script>function csToggleMediaSound(c){var v=document.getElementById("cs-"+c+"-video");if(!v)return;v.muted=!v.muted;if(v.paused)v.play().catch(function(){});}document.addEventListener("click",function(){document.querySelectorAll(".cs-media-bg video[autoplay]").forEach(function(v){if(v.paused)v.play().catch(function(){});});},{once:true});</script>';
        return $css;
    }
}

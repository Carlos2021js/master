<?php
/**
 * CS PLAYER — M3U/M3U Plus endpoint Ultra Fast
 * Ubuntu 24.04 | PHP 8.3/8.4 | Xtream-compatible database
 *
 * Supported:
 *   ?username=USER&password=PASS&type=m3u_plus&output=mpegts
 *   ?username=USER&password=PASS&type=m3u_plus&output=ts
 *   ?username=USER&password=PASS&type=m3u_plus&output=hls
 *   ?username=USER&password=PASS&type=m3u_plus&output=m3u8
 *
 * Browser requests receive a downloadable .m3u file.
 */
declare(strict_types=1);

@ini_set('display_errors', '1');
@ini_set('log_errors', '1');
@ini_set('zlib.output_compression', '0');
@ini_set('output_buffering', '0');
@set_time_limit(0);
@ignore_user_abort(true);
error_reporting(E_ALL);

const CS_GET_VERSION = '4.0.7-ultra-fast-2';
const CS_GET_SQL_CHUNK = 900;
const CS_GET_FLUSH_EVERY = 1000;

function cs_get_fail(int $status, string $message): never {
    while (ob_get_level() > 0) { @ob_end_clean(); }
    http_response_code($status);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    header('X-Content-Type-Options: nosniff');
    echo $message;
    exit;
}

function cs_get_bootstrap(): void {
    foreach ([
        __DIR__ . '/player/bootstrap.php',
        dirname(__DIR__) . '/admin/player/bootstrap.php',
        '/home/xtreamcodes/iptv_xtream_codes/admin/player/bootstrap.php',
    ] as $file) {
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
    cs_get_fail(500, 'CS PLAYER: serviço M3U temporariamente indisponível.');
}

function cs_m3u_text(string $value): string {
    $value = str_replace(["\r", "\n", "\0"], [' ', ' ', ''], $value);
    $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value) ?? $value;
    if (function_exists('mb_check_encoding') && !mb_check_encoding($value, 'UTF-8')) {
        $value = mb_convert_encoding($value, 'UTF-8', 'UTF-8');
    }
    return trim($value);
}

function cs_m3u_attr(string $value): string {
    return str_replace('"', "'", cs_m3u_text($value));
}

function cs_get_base_url(): string {
    $forwarded = strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')));
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') || $forwarded === 'https';
    $scheme = $https ? 'https' : 'http';
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '' || !preg_match('/^[A-Za-z0-9.\-:\[\]]+$/D', $host)) {
        $host = trim((string)($_SERVER['SERVER_ADDR'] ?? '127.0.0.1'));
        $port = (int)($_SERVER['SERVER_PORT'] ?? ($https ? 443 : 80));
        if (($scheme === 'http' && $port !== 80) || ($scheme === 'https' && $port !== 443)) {
            $host .= ':' . $port;
        }
    }
    return $scheme . '://' . $host;
}

function cs_get_flush(): void {
    if (function_exists('ob_flush')) { @ob_flush(); }
    @flush();
}

function cs_get_ids(mixed $value): array {
    $out = [];
    foreach ((array)$value as $id) {
        $id = (int)$id;
        if ($id > 0) $out[$id] = $id;
    }
    return array_values($out);
}

function cs_get_table_columns(mysqli $db, string $table): array {
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    if (!preg_match('/^[A-Za-z0-9_]+$/D', $table)) return [];
    $cols = [];
    $res = @$db->query('SHOW COLUMNS FROM `' . $table . '`');
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $name = (string)($row['Field'] ?? '');
            if ($name !== '') $cols[$name] = true;
        }
        $res->free();
    }
    return $cache[$table] = $cols;
}

function cs_get_col(array $cols, string $name, string $fallback = "''"): string {
    return isset($cols[$name]) ? '`' . $name . '`' : $fallback . ' AS `' . $name . '`';
}

function cs_get_chunks(array $ids): iterable {
    $count = count($ids);
    for ($i = 0; $i < $count; $i += CS_GET_SQL_CHUNK) {
        yield array_slice($ids, $i, CS_GET_SQL_CHUNK);
    }
}

function cs_get_log(string $event, array $context, string $level = 'info'): void {
    if (function_exists('cs_player_write_log')) {
        try { cs_player_write_log($event, $context, $level); } catch (Throwable) {}
    }
}

cs_get_bootstrap();

if (!function_exists('cs_player_local_user') || !function_exists('cs_player_local_permissions') || !function_exists('cs_player_db')) {
    cs_get_fail(500, 'CS PLAYER: componentes de autenticação M3U indisponíveis.');
}

if (session_status() === PHP_SESSION_ACTIVE) @session_write_close();

$started = microtime(true);
try {
    $username = trim((string)($_GET['username'] ?? $_POST['username'] ?? ''));
    $password = (string)($_GET['password'] ?? $_POST['password'] ?? '');
    $type = strtolower(trim((string)($_GET['type'] ?? 'm3u_plus')));
    $requestedOutput = strtolower(trim((string)($_GET['output'] ?? 'mpegts')));

    if ($username === '' || $password === '') cs_get_fail(401, 'CS PLAYER: usuário e senha são obrigatórios.');
    if (!in_array($type, ['m3u', 'm3u_plus'], true)) $type = 'm3u_plus';

    $output = match ($requestedOutput) {
        'hls', 'm3u8' => 'hls',
        'ts', 'mpegts', 'mpeg-ts' => 'mpegts',
        default => 'mpegts',
    };

    $user = cs_player_local_user($username, $password);
    if (!is_array($user)) {
        cs_get_log('get_auth_failed', ['username_hash'=>substr(hash('sha256', $username),0,12)], 'warning');
        cs_get_fail(401, 'CS PLAYER: credenciais inválidas ou assinatura indisponível.');
    }

    $permissions = cs_player_local_permissions($user);
    $channelIds = cs_get_ids($permissions['channels'] ?? []);
    $seriesIds = cs_get_ids($permissions['series'] ?? []);

    $db = cs_player_db();
    if (!$db instanceof mysqli) cs_get_fail(503, 'CS PLAYER: banco de dados temporariamente indisponível.');

    // Evita espera excessiva por locks sem alterar a configuração global do MariaDB.
    @$db->query("SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED");
    @$db->query("SET SESSION lock_wait_timeout=5");

    $streamCols = cs_get_table_columns($db, 'streams');
    $seriesCols = cs_get_table_columns($db, 'series');
    $episodeCols = cs_get_table_columns($db, 'series_episodes');
    if (!isset($streamCols['id'], $streamCols['type'], $streamCols['stream_display_name'])) {
        throw new RuntimeException('Estrutura da tabela streams incompatível.');
    }

    $categories = [];
    if ($res = @$db->query('SELECT `id`,`category_name` FROM `stream_categories`', MYSQLI_USE_RESULT)) {
        while ($row = $res->fetch_assoc()) $categories[(int)$row['id']] = (string)$row['category_name'];
        $res->free();
    }

    $base = cs_get_base_url();
    $u = rawurlencode($username);
    $p = rawurlencode($password);
    $liveExt = $output === 'hls' ? 'm3u8' : 'ts';
    $safeName = preg_replace('/[^A-Za-z0-9._-]+/', '_', $username) ?: 'playlist';

    while (ob_get_level() > 0) @ob_end_clean();
    http_response_code(200);
    header('Content-Type: audio/x-mpegurl; charset=utf-8');
    header('Content-Disposition: attachment; filename="CSPLAYER_' . $safeName . '.m3u"; filename*=UTF-8\'\'CSPLAYER_' . rawurlencode($safeName) . '.m3u');
    header('Content-Transfer-Encoding: binary');
    header('X-Content-Type-Options: nosniff');
    header('X-Accel-Buffering: no');
    header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('X-CS-Player-M3U: ' . CS_GET_VERSION);

    // HEAD valida autenticação/endpoint sem construir toda a playlist.
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'HEAD') exit;

    echo "#EXTM3U\n";
    $written = 0;

    $emit = static function (int $id, string $name, string $logo, string $group, string $url, array $extra = []) use ($type, &$written): void {
        if ($id <= 0 || $url === '') return;
        $name = cs_m3u_text($name !== '' ? $name : ('CS PLAYER ' . $id));
        if ($type === 'm3u_plus') {
            $attrs = ' tvg-id="' . cs_m3u_attr((string)($extra['tvg_id'] ?? '')) . '"'
                . ' tvg-name="' . cs_m3u_attr($name) . '"'
                . ' tvg-logo="' . cs_m3u_attr($logo) . '"'
                . ' group-title="' . cs_m3u_attr($group) . '"';
            if (!empty($extra['catchup'])) $attrs .= ' catchup="default"';
            echo '#EXTINF:-1' . $attrs . ',' . $name . "\n";
        } else {
            echo '#EXTINF:-1,' . $name . "\n";
        }
        echo $url . "\n";
        if ((++$written % CS_GET_FLUSH_EVERY) === 0) cs_get_flush();
    };

    // Consulta em blocos: evita IN gigantes, sort temporário e max_allowed_packet em listas grandes.
    $selectStreams = [
        '`id`', '`type`', '`stream_display_name`',
        cs_get_col($streamCols, 'stream_icon'),
        cs_get_col($streamCols, 'category_id', '0'),
        cs_get_col($streamCols, 'epg_id'),
        cs_get_col($streamCols, 'target_container', "'mp4'"),
        cs_get_col($streamCols, 'tv_archive_duration', '0'),
    ];
    foreach (cs_get_chunks($channelIds) as $chunk) {
        if (!$chunk) continue;
        $in = implode(',', $chunk);
        $sql = 'SELECT ' . implode(',', $selectStreams) . ' FROM `streams` WHERE `id` IN (' . $in . ') AND `type` IN (1,2)';
        $res = @$db->query($sql, MYSQLI_USE_RESULT);
        if (!$res) {
            cs_get_log('get_stream_query_failed', ['errno'=>$db->errno,'chunk_size'=>count($chunk)], 'error');
            continue; // uma falha de bloco não derruba toda a playlist
        }
        while ($row = $res->fetch_assoc()) {
            $id = (int)$row['id']; $streamType = (int)$row['type'];
            $group = $categories[(int)($row['category_id'] ?? 0)] ?? ($streamType === 1 ? 'Canais' : 'Filmes');
            if ($streamType === 1) {
                $emit($id, (string)$row['stream_display_name'], (string)($row['stream_icon'] ?? ''), $group,
                    "$base/live/$u/$p/$id.$liveExt", [
                        'tvg_id'=>(string)($row['epg_id'] ?? ''),
                        'catchup'=>(int)($row['tv_archive_duration'] ?? 0) > 0,
                    ]);
            } else {
                $ext = strtolower(trim((string)($row['target_container'] ?? 'mp4')));
                if (!preg_match('/^[a-z0-9]{2,8}$/D', $ext)) $ext = 'mp4';
                $emit($id, (string)$row['stream_display_name'], (string)($row['stream_icon'] ?? ''), $group,
                    "$base/movie/$u/$p/$id.$ext");
            }
        }
        $res->free();
    }

    // Séries/episódios também em blocos, sem ORDER BY global caro.
    if ($seriesIds && isset($episodeCols['series_id'], $episodeCols['stream_id']) && isset($seriesCols['id'])) {
        $seasonExpr = isset($episodeCols['season_num']) ? 'se.`season_num`' : '0';
        $sortExpr = isset($episodeCols['sort']) ? 'se.`sort`' : '0';
        $seriesTitleExpr = isset($seriesCols['title']) ? 'sr.`title`' : "''";
        $seriesCategoryExpr = isset($seriesCols['category_id']) ? 'sr.`category_id`' : '0';
        $iconExpr = isset($streamCols['stream_icon']) ? 's.`stream_icon`' : "''";
        $containerExpr = isset($streamCols['target_container']) ? 's.`target_container`' : "'mp4'";

        foreach (cs_get_chunks($seriesIds) as $chunk) {
            if (!$chunk) continue;
            $in = implode(',', $chunk);
            $sql = "SELECT se.`series_id`,$seasonExpr AS `season_num`,$sortExpr AS `sort`,"
                 . "s.`id`,s.`stream_display_name`,$iconExpr AS `stream_icon`,$containerExpr AS `target_container`,"
                 . "$seriesTitleExpr AS `title`,$seriesCategoryExpr AS `category_id` "
                 . "FROM `series_episodes` se INNER JOIN `streams` s ON s.`id`=se.`stream_id` "
                 . "INNER JOIN `series` sr ON sr.`id`=se.`series_id` WHERE se.`series_id` IN ($in)";
            $res = @$db->query($sql, MYSQLI_USE_RESULT);
            if (!$res) {
                cs_get_log('get_episode_query_failed', ['errno'=>$db->errno,'chunk_size'=>count($chunk)], 'error');
                continue;
            }
            while ($row = $res->fetch_assoc()) {
                $id=(int)$row['id'];
                $ext=strtolower(trim((string)($row['target_container'] ?? 'mp4')));
                if (!preg_match('/^[a-z0-9]{2,8}$/D',$ext)) $ext='mp4';
                $season=max(0,(int)($row['season_num']??0)); $episode=max(0,(int)($row['sort']??0));
                $seriesTitle=cs_m3u_text((string)($row['title']??'Série')) ?: 'Série';
                $episodeTitle=cs_m3u_text((string)($row['stream_display_name']??''));
                if ($episodeTitle==='') $episodeTitle=sprintf('%s S%02dE%02d',$seriesTitle,$season,$episode);
                $category=$categories[(int)($row['category_id']??0)] ?? 'Séries';
                $emit($id,$episodeTitle,(string)($row['stream_icon']??''),$category.' | '.$seriesTitle,
                    "$base/series/$u/$p/$id.$ext");
            }
            $res->free();
        }
    }

    cs_get_flush();
    cs_get_log('get_playlist_generated', [
        'username_hash'=>substr(hash('sha256',$username),0,12),
        'output'=>$output,'type'=>$type,'items'=>$written,
        'elapsed_ms'=>(int)round((microtime(true)-$started)*1000),
        'version'=>CS_GET_VERSION,
    ], 'info');
    exit;

} catch (Throwable $e) {
    cs_get_log('get_playlist_fatal', [
        'class'=>get_class($e),
        'errno'=>($e instanceof mysqli_sql_exception ? $e->getCode() : 0),
        'message_hash'=>substr(hash('sha256',$e->getMessage()),0,12),
        'line'=>$e->getLine(),
        'version'=>CS_GET_VERSION,
    ], 'error');
    cs_get_fail(500, 'CS PLAYER: falha ao gerar a playlist. Consulte Logs e erros do sistema.');
}

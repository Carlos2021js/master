<?php
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/cs_admin_access.php';

if (empty($rPermissions['is_admin']) || !hasPermissions('adv', 'mass_delete')) {
    http_response_code(403);
    exit('Acesso negado. Esta ferramenta exige permissão administrativa de exclusão em massa.');
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
if (empty($_SESSION['m3u_cleanup_token'])) {
    $_SESSION['m3u_cleanup_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['m3u_cleanup_token'];
$isAjaxCleanup = ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cleanup_ajax']));

$scopes = [
    'all'        => 'Tudo do conteúdo M3U: canais, filmes, séries, episódios e categorias vazias',
    'channels'   => 'Somente canais / Live TV',
    'movies'     => 'Somente filmes / VOD',
    'series'     => 'Séries, episódios e streams de episódios',
    'episodes'   => 'Somente episódios, mantendo as séries',
    'categories' => 'Somente categorias vazias',
];
$message = '';
$messageType = 'info';
$result = [];

function cleanupTableExists(mysqli $db, $table) {
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $check = $db->query("SHOW TABLES LIKE '" . $db->real_escape_string($safe) . "'");
    return $check && $check->num_rows > 0;
}
function cleanupDeleteIds(mysqli $db, $table, $column, array $ids) {
    if (!$ids || !cleanupTableExists($db, $table)) return 0;
    $safeTable = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $safeColumn = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    $list = implode(',', array_map('intval', $ids));
    $db->query("DELETE FROM `{$safeTable}` WHERE `{$safeColumn}` IN ({$list})");
    return $db->affected_rows;
}
function cleanupBouquets(mysqli $db, array $streamIds, array $seriesIds, $clearAll = false) {
    $changed = 0;
    if (!cleanupTableExists($db, 'bouquets')) return 0;
    $res = $db->query('SELECT id, bouquet_channels, bouquet_series FROM bouquets');
    while ($row = $res->fetch_assoc()) {
        $channels = json_decode((string)$row['bouquet_channels'], true);
        $series = json_decode((string)$row['bouquet_series'], true);
        $channels = is_array($channels) ? array_values(array_unique(array_map('intval', $channels))) : [];
        $series = is_array($series) ? array_values(array_unique(array_map('intval', $series))) : [];
        $newChannels = $clearAll ? [] : array_values(array_diff($channels, array_map('intval', $streamIds)));
        $newSeries = $clearAll ? [] : array_values(array_diff($series, array_map('intval', $seriesIds)));
        if ($newChannels !== $channels || $newSeries !== $series) {
            $stmt = $db->prepare('UPDATE bouquets SET bouquet_channels = ?, bouquet_series = ? WHERE id = ?');
            $channelsJson = json_encode($newChannels);
            $seriesJson = json_encode($newSeries);
            $id = (int)$row['id'];
            $stmt->bind_param('ssi', $channelsJson, $seriesJson, $id);
            $stmt->execute();
            $changed++;
        }
    }
    return $changed;
}
function cleanupEmptyCategories(mysqli $db) {
    $deleted = 0;
    if (!cleanupTableExists($db, 'stream_categories')) return 0;
    $res = $db->query('SELECT id, category_type FROM stream_categories');
    while ($row = $res->fetch_assoc()) {
        $id = (int)$row['id'];
        $type = strtolower((string)$row['category_type']);
        $streamCount = 0;
        $seriesCount = 0;
        if ($type === 'live') {
            $q = $db->query("SELECT COUNT(*) c FROM streams WHERE category_id = {$id}");
            $streamCount = (int)$q->fetch_assoc()['c'];
        } elseif ($type === 'movie') {
            $q = $db->query("SELECT COUNT(*) c FROM streams WHERE category_id = {$id}");
            $streamCount = (int)$q->fetch_assoc()['c'];
        } elseif ($type === 'series') {
            $q = $db->query("SELECT COUNT(*) c FROM series WHERE category_id = {$id}");
            $seriesCount = (int)$q->fetch_assoc()['c'];
            $q = $db->query("SELECT COUNT(*) c FROM streams WHERE category_id = {$id}");
            $streamCount = (int)$q->fetch_assoc()['c'];
        }
        if ($streamCount === 0 && $seriesCount === 0) {
            $db->query("DELETE FROM stream_categories WHERE id = {$id}");
            $deleted += $db->affected_rows;
        }
    }
    return $deleted;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['cleanup_submit']) || $isAjaxCleanup)) {
    try {
        if (!hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
            throw new RuntimeException('Token de segurança inválido. Recarregue a página e tente novamente.');
        }
        $scope = (string)($_POST['scope'] ?? '');
        if (!isset($scopes[$scope])) throw new RuntimeException('Escopo de limpeza inválido.');
        if (($_POST['confirm_text'] ?? '') !== 'LIMPAR') {
            throw new RuntimeException('Digite LIMPAR para confirmar a operação.');
        }
        if (empty($_POST['confirm_danger'])) {
            throw new RuntimeException('Marque a confirmação de exclusão permanente.');
        }
        if (!isset($db) || !($db instanceof mysqli)) throw new RuntimeException('Conexão com o banco indisponível.');
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        set_time_limit(0);
        $streamIds = [];
        $seriesIds = [];
        $streamTypes = [];
        if ($scope === 'all' || $scope === 'channels') $streamTypes[] = 1;
        if ($scope === 'all' || $scope === 'movies') $streamTypes[] = 2;
        if ($scope === 'all' || $scope === 'series') $streamTypes[] = 5;
        if ($streamTypes) {
            $typeList = implode(',', array_map('intval', $streamTypes));
            $res = $db->query("SELECT id FROM streams WHERE type IN ({$typeList})");
            while ($row = $res->fetch_assoc()) $streamIds[] = (int)$row['id'];
        }
        if ($scope === 'all' || $scope === 'series') {
            $res = $db->query('SELECT id FROM series');
            while ($row = $res->fetch_assoc()) $seriesIds[] = (int)$row['id'];
        }
        if ($scope === 'all' || $scope === 'episodes') {
            if ($scope === 'episodes') {
                $res = $db->query('SELECT stream_id FROM series_episodes');
                while ($row = $res->fetch_assoc()) $streamIds[] = (int)$row['stream_id'];
            }
        }
        $streamIds = array_values(array_unique(array_filter($streamIds)));
        $seriesIds = array_values(array_unique(array_filter($seriesIds)));
        $db->begin_transaction();
        $deleted = ['streams_sys' => 0, 'series_episodes' => 0, 'streams' => 0, 'series' => 0, 'categories' => 0, 'bouquets' => 0];
        if ($scope === 'categories') {
            $deleted['categories'] = cleanupEmptyCategories($db);
        } else {
            $deleted['series_episodes'] = cleanupDeleteIds($db, 'series_episodes', 'stream_id', $streamIds);
            if ($scope === 'all' || $scope === 'series') {
                $deleted['series_episodes'] += cleanupDeleteIds($db, 'series_episodes', 'series_id', $seriesIds);
            }
            $deleted['streams_sys'] = cleanupDeleteIds($db, 'streams_sys', 'stream_id', $streamIds);
            $deleted['streams'] = cleanupDeleteIds($db, 'streams', 'id', $streamIds);
            if ($scope === 'all' || $scope === 'series') {
                $deleted['series'] = cleanupDeleteIds($db, 'series', 'id', $seriesIds);
            }
            $deleted['bouquets'] = cleanupBouquets($db, $streamIds, $seriesIds, $scope === 'all');
            if ($scope === 'all' || $scope === 'categories') $deleted['categories'] = cleanupEmptyCategories($db);
        }
        $db->commit();
        $result = $deleted;
        $message = 'Limpeza concluída com sucesso. Os registros excluídos não podem ser recuperados por esta tela.';
        $messageType = 'success';
    } catch (Throwable $e) {
        if (isset($db) && $db instanceof mysqli) { try { $db->rollback(); } catch (Throwable $ignored) {} }
        $message = $e->getMessage();
        $messageType = 'danger';
    }
}


if ($isAjaxCleanup) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    $ok = ($messageType === 'success');
    echo json_encode([
        'ok' => $ok,
        'message' => $message,
        'result' => $result,
        'percent' => $ok ? 100 : 0,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$rSidebar = !empty($rSettings['sidebar']);
include ($rSidebar ? 'header_sidebar.php' : 'header.php');
?>
<div class="<?= $rSidebar ? 'content-page' : 'wrapper' ?> boxed-layout-ext">
    <div class="container-fluid">
        <div class="page-title-box"><h4 class="page-title"><i class="mdi mdi-delete-sweep text-danger"></i> Limpeza do conteúdo M3U</h4></div>
        <?php if ($message): ?><div class="alert alert-<?= htmlspecialchars($messageType) ?>"><strong><?= htmlspecialchars($message) ?></strong></div><?php endif; ?>
        <?php if ($result): ?><div class="alert alert-info"><strong>Resumo da operação:</strong> Streams: <?= (int)$result['streams'] ?>; episódios: <?= (int)$result['series_episodes'] ?>; séries: <?= (int)$result['series'] ?>; vínculos de servidor: <?= (int)$result['streams_sys'] ?>; buquês atualizados: <?= (int)$result['bouquets'] ?>; categorias vazias: <?= (int)$result['categories'] ?>.</div><?php endif; ?>
        <div class="card border-danger"><div class="card-body">
            <div class="alert alert-warning"><strong>Atenção:</strong> esta operação é permanente. O banco atual não possui um marcador que diferencie automaticamente registros importados pelo M3U de registros criados manualmente. Os escopos abaixo trabalham por tipo de conteúdo.</div>
            <form method="post" id="m3u-cleanup-form" novalidate>
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                <input type="hidden" name="cleanup_ajax" value="1">
                <div class="form-group"><label class="font-weight-bold">O que deseja limpar?</label><select name="scope" class="form-control" required><?php foreach ($scopes as $key => $label): ?><option value="<?= htmlspecialchars($key) ?>"><?= htmlspecialchars($label) ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Digite <strong>LIMPAR</strong> para confirmar</label><input name="confirm_text" class="form-control" autocomplete="off" required></div>
                <div class="custom-control custom-checkbox mb-3"><input type="checkbox" class="custom-control-input" id="confirm_danger" name="confirm_danger" value="1" required><label class="custom-control-label" for="confirm_danger">Confirmo que compreendo que a exclusão é permanente.</label></div>

                <div id="cleanup-progress-card" class="cleanup-progress-card" hidden aria-live="polite">
                    <div class="cleanup-progress-head">
                        <strong id="cleanup-progress-title">Preparando limpeza...</strong>
                        <strong id="cleanup-progress-percent">0%</strong>
                    </div>
                    <div class="progress cleanup-progress-track">
                        <div id="cleanup-progress-bar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width:0%" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"></div>
                    </div>
                    <div id="cleanup-progress-text" class="cleanup-progress-text">A interface continua disponível durante o processo. Você pode usar o menu normalmente.</div>
                </div>

                <div id="cleanup-result" class="mt-3" hidden></div>

                <button type="submit" id="cleanup-submit" class="btn btn-danger"><i class="mdi mdi-delete-sweep"></i> Executar limpeza</button>
                <a href="./m3u_update_nodup.php" class="btn btn-secondary">Voltar para importação M3U</a>
            </form>
        </div></div>
    </div>
</div>
<style>
.cleanup-progress-card{margin:18px 0;padding:16px;border:1px solid rgba(76,139,245,.35);border-radius:12px;background:rgba(16,23,35,.55)}
.cleanup-progress-head{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:10px}
.cleanup-progress-track{height:18px;border-radius:999px;overflow:hidden;background:rgba(255,255,255,.12)}
.cleanup-progress-track .progress-bar{transition:width .45s ease}
.cleanup-progress-text{margin-top:10px;opacity:.82}
#m3u-cleanup-form.is-running .form-control,#m3u-cleanup-form.is-running .custom-control-input,#m3u-cleanup-form.is-running #cleanup-submit{pointer-events:none;opacity:.72}
@media (max-width:767.98px){.cleanup-progress-head{font-size:14px}.cleanup-progress-card{padding:13px}.card-body{overflow:visible!important}}
</style>
<script>
(function(){
    var form = document.getElementById('m3u-cleanup-form');
    if (!form || !window.fetch) return;
    var card = document.getElementById('cleanup-progress-card');
    var bar = document.getElementById('cleanup-progress-bar');
    var pct = document.getElementById('cleanup-progress-percent');
    var title = document.getElementById('cleanup-progress-title');
    var text = document.getElementById('cleanup-progress-text');
    var result = document.getElementById('cleanup-result');
    var submit = document.getElementById('cleanup-submit');
    var timer = null;
    var progress = 0;

    function setProgress(value, label, detail) {
        progress = Math.max(0, Math.min(100, value));
        bar.style.width = progress + '%';
        bar.setAttribute('aria-valuenow', String(progress));
        pct.textContent = progress + '%';
        if (label) title.textContent = label;
        if (detail) text.textContent = detail;
    }

    form.addEventListener('submit', function(ev){
        ev.preventDefault();
        if (!form.reportValidity()) return;
        var confirmText = form.querySelector('[name="confirm_text"]').value;
        var confirmDanger = form.querySelector('[name="confirm_danger"]').checked;
        if (confirmText !== 'LIMPAR' || !confirmDanger) {
            alert('Digite LIMPAR e marque a confirmação para continuar.');
            return;
        }
        if (!confirm('Esta operação excluirá dados permanentemente. Confirma continuar?')) return;

        card.hidden = false;
        result.hidden = true;
        result.innerHTML = '';
        form.classList.add('is-running');
        submit.disabled = true;
        setProgress(3, 'Preparando limpeza', 'Validando permissões e escopo selecionado...');

        var stages = [
            [12, 'Analisando conteúdo', 'Identificando canais, filmes, séries, episódios e vínculos relacionados...'],
            [28, 'Preparando exclusão', 'Organizando dependências para evitar registros órfãos...'],
            [48, 'Limpando vínculos', 'Removendo relações de episódios, servidores e buquês...'],
            [68, 'Limpando conteúdo', 'Processando os registros selecionados no banco...'],
            [84, 'Otimizando resultado', 'Removendo categorias vazias e finalizando a transação...'],
            [94, 'Finalizando', 'Confirmando alterações e preparando o resumo...']
        ];
        var idx = 0;
        timer = setInterval(function(){
            if (idx < stages.length) {
                var st = stages[idx++];
                setProgress(st[0], st[1], st[2]);
            }
        }, 850);

        var body = new FormData(form);
        fetch(window.location.href, {method:'POST', body:body, credentials:'same-origin', headers:{'X-Requested-With':'XMLHttpRequest'}})
            .then(function(resp){
                return resp.text().then(function(raw){
                    var data;
                    try { data = JSON.parse(raw); } catch(e) { throw new Error('Resposta inválida do servidor (HTTP ' + resp.status + ').'); }
                    if (!resp.ok || !data.ok) throw new Error(data.message || ('HTTP ' + resp.status));
                    return data;
                });
            })
            .then(function(data){
                clearInterval(timer);
                setProgress(100, 'Limpeza concluída', 'Processo finalizado com sucesso.');
                var r = data.result || {};
                result.className = 'alert alert-success mt-3';
                result.innerHTML = '<strong>' + escapeHtml(data.message || 'Limpeza concluída.') + '</strong><br>' +
                    'Streams: ' + (r.streams || 0) + '; episódios: ' + (r.series_episodes || 0) + '; séries: ' + (r.series || 0) +
                    '; vínculos de servidor: ' + (r.streams_sys || 0) + '; buquês atualizados: ' + (r.bouquets || 0) +
                    '; categorias vazias: ' + (r.categories || 0) + '.';
                result.hidden = false;
            })
            .catch(function(err){
                clearInterval(timer);
                setProgress(progress < 10 ? 10 : progress, 'Falha na limpeza', 'A operação foi interrompida com segurança.');
                bar.classList.remove('progress-bar-animated');
                result.className = 'alert alert-danger mt-3';
                result.innerHTML = '<strong>Erro:</strong> ' + escapeHtml(err && err.message ? err.message : 'Falha desconhecida.');
                result.hidden = false;
            })
            .finally(function(){
                form.classList.remove('is-running');
                submit.disabled = false;
            });
    });

    function escapeHtml(value) {
        var div = document.createElement('div');
        div.textContent = String(value == null ? '' : value);
        return div.innerHTML;
    }
})();
</script>
</body></html>
<?php exit; ?>

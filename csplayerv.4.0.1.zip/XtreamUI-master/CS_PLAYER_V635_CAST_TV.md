# CS PLAYER v6.3.5 — Transmitir para TV

## Implementado
- Botão **TV** dentro do modal do player, ao lado de PiP, tela cheia e reconexão.
- Google Cast Web Sender Framework com Default Media Receiver.
- Seleção de Chromecast / Google TV compatível pelo diálogo oficial do Cast.
- Transmissão iniciando na posição atual para filmes e episódios.
- Conteúdo ao vivo marcado como stream LIVE.
- Status visual de TV conectada dentro do player.
- Fallback para `HTMLMediaElement.remote.prompt()` quando o navegador oferece Remote Playback.
- Token temporário aleatório para a TV acessar a mídia sem receber usuário/senha do cliente.
- Tokens expiram em 2 horas e são armazenados fora do banco em `admin/player/storage/cast/`.
- Proxy HLS específico para Cast, incluindo manifests/segmentos assinados e cabeçalhos CORS.
- Nenhuma tabela, coluna ou ID do banco foi alterado.

## Arquivos novos
- `admin/player/cast_token.php`
- `admin/player/cast_lib.php`
- `admin/player/cast_stream.php`
- `admin/player/cast_segment.php`

## Arquivos alterados
- `admin/player/home.php`
- `admin/player/assets/player.js`
- `admin/player/assets/player.css`

## HTTPS
O Google Cast Web Sender deve ser servido em contexto HTTPS para a experiência oficial de descoberta e conexão no navegador. O CS Player detecta acesso HTTP e tenta primeiro o Remote Playback nativo quando disponível; caso contrário informa que o Web Player precisa ser aberto por HTTPS para usar Google Cast.

## Compatibilidade de mídia
A TV precisa conseguir alcançar a URL pública do CS Player. HLS é retransmitido pelo proxy Cast com CORS. Formatos/codecs ainda dependem do suporte do dispositivo Cast/TV.

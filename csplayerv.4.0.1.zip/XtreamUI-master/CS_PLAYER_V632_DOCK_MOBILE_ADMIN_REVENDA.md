# CS PLAYER v6.3.2 — Dock móvel Admin / Revenda

- Web Player preservado sem alterações de layout.
- Desktop preserva o cabeçalho superior existente e o Branding Manager.
- Smartphone usa navegação inferior fixa em dark mode, inspirada na referência enviada.
- Removida apenas a referência funcional "Teste Rápido" do dock móvel; nenhuma página/recurso do projeto foi apagado.
- Dock móvel: Notificações, Clientes, Revendas (somente Admin), Conta e Menu.
- O botão Menu continua abrindo o menu principal legado completo, portanto nenhuma opção administrativa é removida.
- Revendas continua respeitando permissões/roles.
- Conteúdo recebe espaço inferior para não ficar escondido atrás do dock.
- Botão voltar ao topo foi deslocado para cima do dock no smartphone.
- Banco de dados não foi alterado.

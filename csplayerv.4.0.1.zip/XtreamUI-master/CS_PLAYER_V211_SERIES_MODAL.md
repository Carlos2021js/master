# CS PLAYER 2.0.11 — Séries Inteligentes

- Modal exclusivo para Séries.
- Temporadas organizadas automaticamente de acordo com o servidor.
- Episódios selecionáveis sem alterar Filmes/Canais.
- Memória local do último episódio escolhido.
- Compatível com smartphone, desktop e Smart TV/controle remoto.
- Mantém player universal HTTP da 2.0.10.

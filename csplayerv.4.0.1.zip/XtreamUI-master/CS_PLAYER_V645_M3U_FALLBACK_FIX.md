# CS Player v6.4.5 — correção de DNS/M3U universal

- Corrigido o salvamento das configurações do Web Player que desligava silenciosamente o fallback M3U Plus.
- Modo **Auto** agora sempre tenta `player_api.php`, `panel_api.php` e, se necessário, `get.php` M3U Plus.
- Modo **M3U Plus** não depende mais de uma flag global para autenticar.
- O botão **Testar** considera o modo selecionado no DNS e consegue identificar rota M3U, sem marcar o servidor como inválido apenas porque `player_api.php` retorna 404.
- A validação definitiva do M3U continua sendo feita no login real, com usuário e senha, exigindo uma playlist `#EXTM3U`.
- Nenhuma tabela, coluna ou ID do banco de dados foi alterado.

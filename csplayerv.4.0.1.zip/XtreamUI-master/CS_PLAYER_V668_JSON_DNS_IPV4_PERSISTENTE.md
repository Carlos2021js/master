# CS PLAYER v6.6.8

- DNS manuais são persistidos no JSON mesmo quando offline, 404 ou com autenticação inválida.
- Estado enabled é salvo separadamente; DNS desativado permanece no JSON, mas não é usado no login.
- Domínios externos HTTP porta 80 em modo Auto recebem preferência efetiva IPv4 no motor JSON.
- A escolha original do painel é preservada em `serverN_ip_mode_configured`.
- Layout e Configurações Avançadas do Web Player não foram alterados.
- Banco de dados não foi alterado.

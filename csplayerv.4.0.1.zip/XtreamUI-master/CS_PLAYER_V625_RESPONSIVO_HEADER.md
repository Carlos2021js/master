# CS PLAYER v6.2.5 — Responsividade Smartphone/Desktop

Correção incremental sobre a v6.2.4, sem alteração do banco de dados.

## Ajustes
- Cabeçalho mobile reorganizado em áreas independentes para marca, perfil, menu e notificações.
- Removido conflito entre posicionamento absoluto e flex das regras antigas.
- Menu e notificações possuem hit-area própria e espaçamento consistente.
- Dropdown de notificações limitado à viewport do smartphone.
- Perfil reduzido ao avatar em telas pequenas para evitar colisão.
- Layout adaptado para 320px, 360px, 375px, 390px, 412px, tablet e desktop.
- Tabelas, formulários, modais e conteúdo continuam com rolagem/adaptação responsiva global.
- Cache-busting atualizado nos dois headers para forçar navegador a carregar o CSS corrigido.

## Banco
Nenhuma tabela, coluna, índice ou ID foi alterado.

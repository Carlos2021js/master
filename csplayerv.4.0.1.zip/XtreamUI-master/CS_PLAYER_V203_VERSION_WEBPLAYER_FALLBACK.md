# CS PLAYER 2.0.3 build 203

- Informações modernas de versão no card legado de Settings.
- Versão instalada, disponível, build, canal, publicação e changelog.
- Web Player mantém os dois DNS JSON.
- Fallback HTTP clássico compatível com o projeto Web Player de referência.
- Fallback local pelo banco CS PLAYER quando APIs externas respondem 404/incompatível.
- Nenhuma alteração de schema/banco.

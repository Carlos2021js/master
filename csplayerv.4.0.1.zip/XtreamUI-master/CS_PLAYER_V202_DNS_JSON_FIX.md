# CS PLAYER 2.0.2

- Mantém no JSON os DNS `http://169.58.140.143:80` e `http://power08121562.shop:80`.
- Repara formatos legados/malformados como `http://[169.58.140.143:]:80`.
- Sincroniza o JSON antes da autenticação sem remover DNS adicionais do administrador.
- Não altera o banco de dados.

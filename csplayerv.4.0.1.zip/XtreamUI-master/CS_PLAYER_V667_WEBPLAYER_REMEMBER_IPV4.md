# CS PLAYER v6.6.7

## Web Player
- Mantém o layout e o design existentes.
- Salva usuário e senha no armazenamento local do navegador antes da autenticação, inclusive quando o login falha.
- O salvamento não autentica nem libera acesso com credenciais inválidas.
- O Password Credential API continua sendo usado quando disponível.

## DNS JSON
- Espelho JSON preservado.
- Em modo IP Auto, o motor JSON tenta IPv4 primeiro.
- A família IP usada na autenticação permanece na sessão e é reutilizada no catálogo.
- Eventos: `json_dns_ipv4_fallback_selected`, `json_dns_auth_selected`, `json_dns_auth_failed`.

## Atualizações
- Dropbox: manifesto principal.
- GitHub: fallback.

## Banco
Nenhuma alteração de banco de dados.

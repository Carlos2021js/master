# CS PLAYER v6.4.1 — Compatibilidade de DNS Externo

Correções aplicadas sem alteração de banco de dados:

- DNS externo HTTP sem porta continua usando porta 80; `http://host` e `http://host:80` são aceitos.
- Autenticação externa testa endpoints compatíveis `player_api.php` e `panel_api.php`.
- Respostas Xtream com pequenas diferenças estruturais são normalizadas antes da validação.
- O endpoint aceito é preservado na sessão e reutilizado nas chamadas seguintes.
- Novo log `external_dns_auth_selected` registra host, porta e endpoint selecionado sem credenciais.
- O catálogo externo guarda `direct_source` e `container_extension` quando fornecidos pelo servidor.
- A reprodução externa prioriza `direct_source` quando válido.
- Canais Live com falha de manifesto HLS/404 tentam automaticamente o formato TS como fallback.
- O fallback é automático e não adiciona botão de reconexão.
- Cache-busting do JavaScript do player atualizado para v6.4.1.

Observação: se o log indicar cURL errno 6 / resolução de host, o problema está no DNS do sistema da VPS; nesse caso outro Web Player rodando diretamente no aparelho pode funcionar enquanto o CS PLAYER, que autentica/proxy pelo servidor, não consegue resolver o domínio.

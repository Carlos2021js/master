# CS PLAYER 2.0.8 — Proxy HLS / HTTP / Anti-travamento

- Mantém HTTP de ponta a ponta; não força HTTPS.
- HLS passa pelo proxy same-origin do Web Player, evitando mixed-content e CORS no navegador.
- Manifestos HLS são reescritos para segmentos internos e respeitam DNS/IP selecionado na sessão.
- Retries progressivos para manifesto, níveis e fragmentos.
- Recuperação suave de erros de rede e mídia do hls.js antes de reiniciar o stream.
- Circuit breaker evita loops rápidos de reconexão, mantendo tentativas automáticas em segundo plano.
- Fallback automático HLS -> MPEG-TS quando a playlist não existe.
- VOD via proxy preserva Range/Content-Range para seek em MP4 e outros contêineres suportados pelo navegador.
- TCP keepalive, low-speed detection e timeouts ajustados para redes móveis/TV.
- Reconexão automática quando o dispositivo volta a ficar online.
- Logs do proxy em admin/logs/cs-player/web-player-proxy.log sem registrar credenciais.
- Banco de dados não alterado.

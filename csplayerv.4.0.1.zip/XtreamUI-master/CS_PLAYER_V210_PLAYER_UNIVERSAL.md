# CS PLAYER 2.0.10 — Player Universal

- Layout do player inspirado em controles clássicos: play/pause central, tempo, volume, tela cheia e menu de três pontos.
- Removidos controles de velocidade.
- Cast/Remote Playback aparece somente quando há suporte/dispositivo disponível.
- HTTP preservado sem forçar HTTPS.
- HLS/M3U8 via HLS.js + proxy de manifesto/segmentos.
- TS/MPEG-TS via mpegts.js + proxy same-origin.
- MP4 via HTML5/proxy com Range.
- MKV com fallback de remux FFmpeg para MP4 fragmentado quando disponível.
- URL original do catálogo/M3U tem prioridade absoluta.
- Compatibilidade LIVE com /usuario/senha/id.ts e /live/usuario/senha/id.ts.
- Detecção de origem por candidatos quando direct_source não existe.
- Retry progressivo, stall watchdog, circuit breaker e failover mantidos.
- Sem alteração do banco de dados.

# CS Player v6.5.4 — Bootstrap PHP 7.4 Safe

- Web Player compatível com PHP interno Xtream 7.4.33 até PHP 8.4.
- `bootstrap.php` não usa `match`, union types, `str_starts_with` ou `str_contains`.
- Marcador interno: `CS_PLAYER_WEBPLAYER_BOOTSTRAP_VERSION: 6.5.4-php74-safe`.
- `check_install.php` informa se o bootstrap instalado é a revisão correta.
- Banco de dados não alterado.

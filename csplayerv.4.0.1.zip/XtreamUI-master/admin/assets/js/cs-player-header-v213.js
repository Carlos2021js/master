(function(){
  'use strict';
  var body=document.body;
  if(!body || body.classList.contains('cs-web-player')) return;

  function header(){ return document.querySelector('.navbar-custom'); }
  function dropdownRoots(){ return Array.prototype.slice.call(document.querySelectorAll('.navbar-custom li.dropdown')); }
  function isHeaderDropdown(node){ return !!(node && node.closest && node.closest('.navbar-custom')); }
  function removeBackdrop(){
    document.querySelectorAll('.cs213-header-backdrop').forEach(function(el){el.remove();});
    body.classList.remove('cs213-header-menu-open');
  }
  function addBackdrop(){
    removeBackdrop();
    var el=document.createElement('div');
    el.className='cs213-header-backdrop';
    el.setAttribute('aria-hidden','true');
    el.addEventListener('click',function(){ closeHeaderDropdowns(); });
    body.appendChild(el);
    body.classList.add('cs213-header-menu-open');
  }
  function closeMainMenu(){
    var nav=document.getElementById('navigation');
    if(nav){nav.classList.remove('menu-open');nav.setAttribute('aria-hidden','true'); if(window.innerWidth<992) nav.style.display='none';}
    document.querySelectorAll('.navbar-toggle').forEach(function(btn){btn.classList.remove('open');btn.setAttribute('aria-expanded','false');});
    if(window.innerWidth<992){
      body.classList.remove('sidebar-enable');
      document.querySelectorAll('.button-menu-mobile').forEach(function(btn){btn.classList.remove('open');btn.setAttribute('aria-expanded','false');});
    }
  }
  function closeHeaderDropdowns(except){
    dropdownRoots().forEach(function(li){
      if(li===except) return;
      li.classList.remove('show');
      var a=li.querySelector(':scope > [data-toggle="dropdown"]');
      var m=li.querySelector(':scope > .dropdown-menu');
      if(a){a.setAttribute('aria-expanded','false');}
      if(m){m.classList.remove('show');}
      if(window.jQuery && window.jQuery.fn && window.jQuery.fn.dropdown && a){
        try{ window.jQuery(a).dropdown('hide'); }catch(e){}
      }
    });
    if(!except) removeBackdrop();
  }

  // Identifica semanticamente o menu de perfil para CSS/diagnóstico sem mudar PHP legado.
  document.querySelectorAll('.navbar-custom .nav-user').forEach(function(a){
    var li=a.closest('li.dropdown'); if(li) li.classList.add('cs213-profile-root');
  });
  document.querySelectorAll('.navbar-custom .cs-notification-bell').forEach(function(li){li.classList.add('cs213-notification-root');});

  // Bootstrap 4/jQuery: garante exclusividade entre perfil e notificações.
  if(window.jQuery){
    window.jQuery(document).on('show.bs.dropdown','.navbar-custom li.dropdown',function(){
      var current=this;
      closeMainMenu();
      dropdownRoots().forEach(function(li){
        if(li!==current){
          var a=li.querySelector(':scope > [data-toggle="dropdown"]');
          if(a){try{window.jQuery(a).dropdown('hide');}catch(e){}}
        }
      });
      addBackdrop();
    });
    window.jQuery(document).on('hidden.bs.dropdown','.navbar-custom li.dropdown',function(){
      setTimeout(function(){
        if(!document.querySelector('.navbar-custom li.dropdown.show,.navbar-custom .dropdown-menu.show')) removeBackdrop();
      },0);
    });
  }

  // Quando abre o menu principal/lateral, fecha perfil/notificações primeiro.
  document.addEventListener('click',function(e){
    var main=e.target.closest && e.target.closest('.navbar-toggle,.button-menu-mobile,[data-cs-menu-trigger="true"]');
    if(main){ closeHeaderDropdowns(); return; }
    var toggle=e.target.closest && e.target.closest('.navbar-custom [data-toggle="dropdown"]');
    if(toggle){
      var li=toggle.closest('li.dropdown');
      dropdownRoots().forEach(function(other){
        if(other!==li){
          other.classList.remove('show');
          var om=other.querySelector(':scope > .dropdown-menu'); if(om)om.classList.remove('show');
          var oa=other.querySelector(':scope > [data-toggle="dropdown"]'); if(oa)oa.setAttribute('aria-expanded','false');
        }
      });
    }
  },true);

  // ESC fecha somente camadas do cabeçalho sem navegar ou alterar a página.
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){
      closeHeaderDropdowns();
      closeMainMenu();
    }
  });

  // Recalcula o estado após rotação/redimensionamento e elimina transforms antigos.
  window.addEventListener('resize',function(){
    document.querySelectorAll('.navbar-custom .dropdown-menu.show').forEach(function(menu){ menu.style.transform=''; });
    if(window.innerWidth>=992) removeBackdrop();
  },{passive:true});
})();

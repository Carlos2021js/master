/* CS PLAYER — Sigma interaction layer. Preserva eventos legados e só adiciona aprimoramentos progressivos. */
(function (window, document) {
    'use strict';

    function currentFile() {
        var path = window.location.pathname || '';
        return path.split('/').pop() || 'dashboard.php';
    }

    function markActiveBottomNav() {
        var file = currentFile();
        var role = document.body && document.body.getAttribute('data-cs-role');
        var links = document.querySelectorAll('.cs-sigma-bottom-nav a');
        Array.prototype.forEach.call(links, function (link) {
            var matches = (link.getAttribute('data-match') || '').split(',');
            var isAdminOnly = link.getAttribute('data-role') === 'admin';
            if (isAdminOnly && role !== 'admin') {
                link.hidden = true;
                return;
            }
            link.hidden = false;
            var active = matches.indexOf(file) !== -1;
            link.classList.toggle('active', active);
            if (active) link.setAttribute('aria-current', 'page');
            else link.removeAttribute('aria-current');
        });
    }

    function connectMenuTrigger() {
        var triggers = document.querySelectorAll('[data-cs-menu-trigger="true"]');
        Array.prototype.forEach.call(triggers, function (trigger) {
            trigger.addEventListener('click', function (event) {
                event.preventDefault();
                var menuButton = document.querySelector('.navbar-toggle, .button-menu-mobile');
                if (menuButton) {
                    menuButton.click();
                    return;
                }
                var nav = document.querySelector('#topnav .navigation-menu');
                if (nav) {
                    nav.classList.toggle('show');
                    nav.removeAttribute('aria-hidden');
                }
            });
        });
    }

    function flashCopyState(button, success) {
        if (!button) return;
        var original = button.getAttribute('data-copy-original-label');
        if (!original) {
            original = button.innerHTML;
            button.setAttribute('data-copy-original-label', original);
        }
        button.setAttribute('data-copy-state', success ? 'success' : 'error');
        button.classList.toggle('copy-success', success);
        button.classList.toggle('copy-error', !success);
        if (success) {
            button.innerHTML = '<i class="mdi mdi-check"></i> Copiado';
            window.setTimeout(function () {
                button.innerHTML = original;
                button.removeAttribute('data-copy-state');
                button.classList.remove('copy-success', 'copy-error');
            }, 1700);
        } else {
            window.setTimeout(function () {
                button.innerHTML = original;
                button.removeAttribute('data-copy-state');
                button.classList.remove('copy-success', 'copy-error');
            }, 1900);
        }
    }

    function fallbackCopy(text) {
        var area = document.createElement('textarea');
        area.value = text;
        area.setAttribute('readonly', '');
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        var result = false;
        try { result = document.execCommand('copy'); } catch (error) { result = false; }
        document.body.removeChild(area);
        return result;
    }

    function copyText(text, button) {
        if (!text) return;
        var done = function () { flashCopyState(button, true); };
        var failed = function () { flashCopyState(button, false); };
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(done).catch(function () {
                if (fallbackCopy(text)) done(); else failed();
            });
        } else if (fallbackCopy(text)) {
            done();
        } else {
            failed();
        }
    }

    function resolveCopyText(button) {
        var target = button.getAttribute('data-copy-target');
        if (target) {
            var element = document.querySelector(target);
            if (element) return element.value !== undefined ? element.value : element.innerText;
        }
        var value = button.getAttribute('data-copy');
        if (value) return value;
        var sibling = button.closest('.copy-wrap, .copy-group, .client-delivery, .delivery-box, .copy-panel, .user-details-box');
        if (sibling) return sibling.innerText;
        return '';
    }

    function connectCopyActions() {
        document.addEventListener('click', function (event) {
            var button = event.target.closest('[data-copy], [data-copy-target], .copy-to-clipboard, .btn-copy');
            if (!button || button.getAttribute('data-copy-native') === 'false') return;
            var text = resolveCopyText(button);
            if (text) {
                event.preventDefault();
                copyText(text.trim(), button);
            }
        });
    }

    function improveAccessibleStates() {
        Array.prototype.forEach.call(document.querySelectorAll('input, select, textarea'), function (input) {
            if (!input.id) return;
            var label = document.querySelector('label[for="' + CSS.escape(input.id) + '"]');
            if (label && !input.getAttribute('aria-label')) input.setAttribute('aria-label', label.innerText.trim());
        });
    }

    function boot() {
        markActiveBottomNav();
        connectMenuTrigger();
        connectCopyActions();
        improveAccessibleStates();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
    else boot();
})(window, document);

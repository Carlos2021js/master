(function () {
  'use strict';

  /* Um único loader compartilhado por Admin e Revenda. */
  var loader = document.querySelector('.csplay-page-loader');
  if (!loader) {
    loader = document.createElement('div');
    loader.className = 'csplay-page-loader';
    loader.setAttribute('aria-hidden', 'true');
    loader.innerHTML = '<div class="csplay-spinner" role="status" aria-label="Carregando"></div>';
    if (document.body) {
      document.body.insertBefore(loader, document.body.firstChild);
    }
  }

  var hidden = false;
  function hideLoader() {
    if (!loader) return;
    hidden = true;
    loader.classList.add('hide');
    loader.setAttribute('aria-hidden', 'true');
  }
  function showLoader() {
    if (!loader) return;
    hidden = false;
    loader.classList.remove('hide');
    loader.setAttribute('aria-hidden', 'false');
  }

  if (document.readyState === 'complete') {
    window.requestAnimationFrame(hideLoader);
  } else {
    window.addEventListener('load', hideLoader, { once: true });
  }
  /* Nunca deixar o painel preso no overlay por recurso externo lento. */
  window.setTimeout(hideLoader, 6500);

  document.addEventListener('click', function (event) {
    var target = event.target;
    var link = target && target.closest ? target.closest('a[href]') : null;
    if (!link) return;

    var href = link.getAttribute('href') || '';
    if (!href || href === '#' || href.charAt(0) === '#') return;
    if (/^\s*javascript:/i.test(href)) return;
    if (link.target === '_blank' || link.hasAttribute('download')) return;
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    if (link.getAttribute('data-toggle') === 'dropdown' ||
        link.getAttribute('data-bs-toggle') === 'dropdown' ||
        link.getAttribute('data-toggle') === 'collapse' ||
        link.getAttribute('data-bs-toggle') === 'collapse') return;

    var absolute;
    try { absolute = new URL(link.href, window.location.href); } catch (e) { return; }
    if (absolute.origin !== window.location.origin) return;

    showLoader();
  }, true);

  /* Formulários que realmente navegam também usam a mesma transição. */
  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (!form || form.getAttribute('target') === '_blank') return;
    showLoader();
  }, true);

  /* Ao voltar pelo histórico, nunca manter overlay congelado. */
  window.addEventListener('pageshow', function () {
    hideLoader();
  });

  /* Fecha dropdowns irmãos para impedir menus sobrepostos no topo. */
  document.addEventListener('show.bs.dropdown', function (event) {
    var current = event.target;
    document.querySelectorAll('.navbar-custom .dropdown.show').forEach(function (item) {
      if (item !== current) item.classList.remove('show');
    });
  });
}());

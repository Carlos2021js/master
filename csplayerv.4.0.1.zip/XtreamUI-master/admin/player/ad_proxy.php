<?php
require __DIR__ . '/proxy_lib.php'; cs_player_require_login(); $cfg=cs_player_load_config(); $type=(string)($_GET['type']??''); $id=(int)($_GET['id']??0); $url=trim((string)($cfg['ads_preroll_url']??''));
if($type!==''&&$id>0){foreach((array)($cfg['manual_highlights']??[]) as $h){if(is_array($h)&&(string)($h['type']??'')===$type&&(int)($h['id']??0)===$id&&trim((string)($h['ad_url']??''))!==''){$url=trim((string)$h['ad_url']);break;}}}
if($url===''||!preg_match('~^https?://~i',$url)){http_response_code(404);exit('Anúncio indisponível');}
cs_proxy_log('player_ad_started',['origin_host'=>(string)(parse_url($url,PHP_URL_HOST)??''),'content_type'=>$type,'content_id'=>$id]); cs_stream_binary($url);

<?php
require __DIR__ . '/proxy_lib.php';
cs_player_require_login();
cs_proxy_media_headers();

$cfg = cs_player_load_config();
$requested = isset($_GET['dns']) ? (string)$_GET['dns'] : null;
$row = cs_player_session_dns($cfg, $requested);
if (!$row) {
    cs_player_write_log('stream_dns_unavailable', ['requested_dns' => $requested], 'error');
    http_response_code(503);
    exit('DNS indisponível');
}

$type = (string)($_GET['type'] ?? 'live');
if (!in_array($type, ['live','movie','series'], true)) $type = 'live';
$id = (int)($_GET['id'] ?? 0);
$ext = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string)($_GET['ext'] ?? '')));
$requestedFormat = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string)($_GET['format'] ?? '')));
if (!$id) {
    cs_player_write_log('stream_invalid_request', ['type' => $type, 'stream_id' => $id], 'warning');
    http_response_code(400);
    exit('Stream inválido');
}

$uRaw = (string)($_SESSION['cs_player_username'] ?? '');
$pRaw = (string)($_SESSION['cs_player_password'] ?? '');
$u = rawurlencode($uRaw);
$p = rawurlencode($pRaw);
$base = rtrim((string)$row['url'], '/');
$deliveryRequest = strtolower((string)($_GET['delivery'] ?? '')); $validDelivery = ['auto','direct','proxy','proxy_hls']; if (!in_array($deliveryRequest,$validDelivery,true)) $deliveryRequest = 'auto';
$useProxy = cs_proxy_should_use($type, $cfg);
$externalMeta = [];
if (empty($_SESSION['cs_player_local_api']) && isset($_SESSION['cs_player_external_sources'][$type.':'.$id]) && is_array($_SESSION['cs_player_external_sources'][$type.':'.$id])) {
    $externalMeta = $_SESSION['cs_player_external_sources'][$type.':'.$id];
}
$directExternal = trim((string)($externalMeta['direct_source'] ?? ''));
if ($directExternal !== '' && !preg_match('~^https?://~i', $directExternal)) $directExternal = '';
if ($ext === '') $ext = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string)($externalMeta['container_extension'] ?? '')));

function cs_stream_is_hls(string $url, string $contentType = ''): bool {
    return stripos($contentType, 'mpegurl') !== false || (bool)preg_match('~\.m3u8(?:$|\?)~i', $url);
}
function cs_stream_extension(string $url): string {
    $path = (string)(parse_url($url, PHP_URL_PATH) ?? '');
    return strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
}
function cs_stream_choose_candidate(array $candidates): array {
    $seen = [];
    $last = ['url'=>'','probe'=>['ok'=>false,'code'=>0,'content_type'=>'','effective'=>'','error'=>''],'pattern'=>''];
    foreach ($candidates as $candidate) {
        if (!is_array($candidate)) continue;
        $url = trim((string)($candidate['url'] ?? ''));
        if ($url === '' || !preg_match('~^https?://~i', $url)) continue;
        $key = strtolower($url);
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $probe = cs_probe_stream_url($url, 6);
        $last = ['url'=>$url,'probe'=>$probe,'pattern'=>(string)($candidate['pattern'] ?? 'candidate')];
        if (!empty($probe['ok'])) {
            cs_proxy_log('proxy_origin_selected', [
                'origin_host'=>(string)(parse_url($url, PHP_URL_HOST) ?? ''),
                'pattern'=>$last['pattern'],
                'http_code'=>(int)($probe['code'] ?? 0),
            ]);
            return $last;
        }
    }
    return $last;
}
function cs_stream_deliver(string $url, string $type, int $id, bool $useProxy, string $requestedFormat = '', string $knownCt = '', string $deliveryRequest = 'auto'): void {
    $cfgLocal = cs_player_load_config(); $extLocal = cs_stream_extension($url); $mode = in_array($deliveryRequest,['auto','direct','proxy','proxy_hls'],true) ? $deliveryRequest : 'auto';
    if ($mode === 'auto') { $formatKey = ($extLocal === 'm3u8') ? 'delivery_hls' : (($extLocal === 'ts' || $extLocal === 'mpegts') ? 'delivery_ts' : ($extLocal === 'mkv' ? 'delivery_mkv' : ($extLocal === 'mp4' ? 'delivery_mp4' : 'stream_delivery_mode'))); $mode = (string)($cfgLocal[$formatKey] ?? $cfgLocal['stream_delivery_mode'] ?? 'auto'); if ($mode === 'auto') $mode = $useProxy ? 'proxy' : 'direct'; }
    if ($mode === 'direct') cs_proxy_direct_redirect($url); $useProxy = true;
    $originHost = (string)(parse_url($url, PHP_URL_HOST) ?? '');
    $extension = cs_stream_extension($url);
    cs_proxy_log('proxy_stream_started', ['origin_host'=>$originHost,'stream_type'=>$type,'stream_id'=>$id,'format'=>$extension ?: $requestedFormat]);

    if ($requestedFormat === 'remux' || $extension === 'mkv') {
        cs_stream_mkv_remux($url);
    }
    if ($extension === 'ts' || $extension === 'mpegts' || ($type === 'live' && $requestedFormat === 'ts')) {
        cs_stream_binary($url);
    }
    if ($type !== 'live' && $extension !== 'm3u8') {
        cs_stream_binary($url);
    }

    [$code, $body, $ct, $effective] = cs_fetch_small($url);
    if ($code < 200 || $code >= 400) {
        cs_player_write_log('stream_origin_failed', [
            'host'=>$originHost,'http_code'=>$code,'content_type'=>$ct,
            'stream_type'=>$type,'stream_id'=>$id,'requested_format'=>$requestedFormat ?: $extension,
        ], $code === 404 ? 'error' : 'warning');
        http_response_code($code ?: 502);
        exit('Falha no stream');
    }
    if (cs_stream_is_hls($effective, $ct ?: $knownCt)) {
        header('Content-Type: application/vnd.apple.mpegurl');
        header('Cache-Control: no-store');
        echo cs_rewrite_manifest($body, $effective);
        exit;
    }
    // Origem respondeu binário sem extensão clara.
    cs_stream_binary($effective ?: $url);
}

// Servidor interno: sempre prioriza a URL original armazenada no banco.
if (!empty($_SESSION['cs_player_local_api'])) {
    $source = cs_player_local_stream_source($id, $uRaw, $pRaw);
    if (!$source) {
        cs_player_write_log('local_stream_source_unavailable', ['stream_type'=>$type,'stream_id'=>$id], 'error');
        http_response_code(404);
        exit('Origem do stream não encontrada');
    }
    cs_proxy_log('proxy_original_source_selected', ['origin_host'=>(string)(parse_url($source,PHP_URL_HOST)??''),'stream_type'=>$type,'stream_id'=>$id]);
    cs_stream_deliver($source, $type, $id, $useProxy, $requestedFormat, '', $deliveryRequest);
}

// Catálogo externo: se a API/M3U informou a URL completa, ela tem prioridade absoluta.
if ($directExternal !== '') {
    cs_proxy_log('proxy_original_source_selected', ['origin_host'=>(string)(parse_url($directExternal,PHP_URL_HOST)??''),'stream_type'=>$type,'stream_id'=>$id]);
    cs_stream_deliver($directExternal, $type, $id, $useProxy, $requestedFormat, '', $deliveryRequest);
}

// Compatibilidade com servidores que não retornam direct_source.
$candidates = [];
if ($type === 'live') {
    $preferred = $requestedFormat === 'ts' ? 'ts' : ($ext ?: 'm3u8');
    if (!in_array($preferred, ['m3u8','ts','mpegts'], true)) $preferred = 'm3u8';
    $alternate = $preferred === 'm3u8' ? 'ts' : 'm3u8';
    // Muitos painéis entregam LIVE sem /live/: http://dns/user/pass/id.ts
    $candidates[] = ['url'=>"$base/$u/$p/$id.$preferred", 'pattern'=>'root_credentials_'.$preferred];
    $candidates[] = ['url'=>"$base/live/$u/$p/$id.$preferred", 'pattern'=>'live_prefix_'.$preferred];
    $candidates[] = ['url'=>"$base/$u/$p/$id.$alternate", 'pattern'=>'root_credentials_'.$alternate];
    $candidates[] = ['url'=>"$base/live/$u/$p/$id.$alternate", 'pattern'=>'live_prefix_'.$alternate];
} elseif ($type === 'movie') {
    $formats = array_values(array_unique(array_filter([$ext, 'mp4', 'mkv', 'm3u8', 'ts'])));
    foreach ($formats as $format) {
        $candidates[] = ['url'=>"$base/movie/$u/$p/$id.$format", 'pattern'=>'movie_'.$format];
        $candidates[] = ['url'=>"$base/$u/$p/$id.$format", 'pattern'=>'root_movie_'.$format];
    }
} else {
    $formats = array_values(array_unique(array_filter([$ext, 'mp4', 'mkv', 'm3u8', 'ts'])));
    foreach ($formats as $format) {
        $candidates[] = ['url'=>"$base/series/$u/$p/$id.$format", 'pattern'=>'series_'.$format];
        $candidates[] = ['url'=>"$base/$u/$p/$id.$format", 'pattern'=>'root_series_'.$format];
    }
}

$selected = cs_stream_choose_candidate($candidates);
$url = (string)($selected['url'] ?? '');
$probe = (array)($selected['probe'] ?? []);
if ($url === '' || empty($probe['ok'])) {
    $code = (int)($probe['code'] ?? 0);
    cs_player_write_log('stream_candidates_exhausted', [
        'host'=>(string)(parse_url($base,PHP_URL_HOST)??''),'http_code'=>$code,
        'stream_type'=>$type,'stream_id'=>$id,'candidate_count'=>count($candidates),
    ], $code === 404 ? 'error' : 'warning');
    http_response_code($code ?: 502);
    exit('Nenhuma origem compatível encontrada');
}
cs_stream_deliver($url, $type, $id, $useProxy, $requestedFormat, (string)($probe['content_type'] ?? ''), $deliveryRequest);

# CS PLAYER v6.6.2 — Web Player nas Configurações + Atualização GitHub

## Web Player dentro das opções
O Web Player passa a ter uma aba própria no mesmo wizard de `admin/settings.php` onde ficam Geral, CS PLAYER, Revenda, Streaming, MAG e Atualizações.

O bloco existente não foi duplicado e continua usando `player_admin_api.php`, a configuração persistente e o mesmo banco sem alterações.

## Estrutura de instalação preservada
O ZIP continua obrigatoriamente com a pasta raiz:

`XtreamUI-master/`

Isso preserva compatibilidade com o instalador por comando e com `pytools/fsremake.py`.

## Atualização remota pelo GitHub
Envie o ZIP da nova versão para um repositório GitHub e use o link RAW/direto do arquivo.

No servidor:

```bash
cd /home/xtreamcodes/iptv_xtream_codes
chmod +x cs-player-update-github.sh
./cs-player-update-github.sh "https://github.com/USUARIO/REPOSITORIO/raw/refs/heads/main/csplayer-versao.zip"
```

O atualizador:
1. aceita apenas HTTPS do GitHub;
2. testa a integridade do ZIP;
3. exige `XtreamUI-master/` na raiz;
4. valida os PHP com o PHP interno do CS PLAYER quando disponível;
5. cria backup da pasta Admin;
6. preserva `config` e configurações persistentes do Web Player;
7. copia os arquivos;
8. executa `check_install.php` após atualizar;
9. não executa SQL e não altera o banco.

## Link direto GitHub
Se a página do GitHub for:

`https://github.com/USUARIO/REPOSITORIO/blob/main/csplayer.zip`

use como URL de atualização:

`https://github.com/USUARIO/REPOSITORIO/raw/refs/heads/main/csplayer.zip`


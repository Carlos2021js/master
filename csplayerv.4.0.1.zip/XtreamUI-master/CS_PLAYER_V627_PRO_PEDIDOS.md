# CS Player v6.2.7 — Interface profissional + Pedidos no Web Player

## Objetivo
Melhorar a apresentação de Admin, Revenda e Web Player preservando a arquitetura existente, o Branding Manager e o banco de dados.

## Banco de dados
Nenhuma tabela, coluna, índice ou ID foi criado, removido ou alterado.

## Admin / Revenda
- Nova camada visual `admin/assets/css/cs-player-pro-v627.css` carregada após os estilos existentes.
- Mantém logo, cores, avatar e identidade coordenados por `branding_manager.php` / `branding_helper.php`.
- Melhora cards, formulários, botões, dropdowns, tabelas, modais, páginas de título e comportamento responsivo.
- Smartphone: formulários empilham, tabelas ganham rolagem horizontal e modais respeitam a viewport.
- Desktop: preserva a geometria dos menus e amplia consistência visual.

## Pedidos no Web Player
- Nova opção `Conta > Pedidos`.
- O cliente pode solicitar Filme, Série, Canal ou Outro.
- Pode acompanhar o status, ler respostas do atendimento e responder novamente.
- Os pedidos usam as tabelas já existentes `tickets` e `tickets_replies`.
- O ticket é direcionado ao responsável da conta do cliente (`users.member_id`).
- Admin/Revenda continuam respondendo pelas páginas existentes `tickets.php`, `ticket.php` e `ticket_view.php`.
- Tickets criados pelo Web Player recebem o selo visual `WEB PLAYER` em `tickets.php`.
- O vínculo entre `ticket_id` e cliente é mantido fora do banco em `admin/player/storage/webplayer_ticket_links.php`, arquivo PHP sem saída direta.
- Requisições POST usam token CSRF da sessão.
- O Web Player só permite ao cliente ler/responder tickets ligados ao próprio ID.

## Arquivos principais alterados
- `admin/header.php`
- `admin/header_sidebar.php`
- `admin/assets/css/cs-player-pro-v627.css`
- `admin/tickets.php`
- `admin/player/home.php`
- `admin/player/index.php`
- `admin/player/profile.php`
- `admin/player/assets/player.css`
- `admin/player/assets/requests.js`
- `admin/player/requests.php`
- `admin/player/requests_api.php`

## Validação
- PHP 8.3: todos os arquivos PHP do projeto validados com `php -l`.
- JavaScript próprio validado com `node --check`.
- Nenhuma migração SQL adicionada.

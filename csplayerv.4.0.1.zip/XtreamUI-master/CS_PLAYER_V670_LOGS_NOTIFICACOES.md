# CS PLAYER 6.7.0

- Central de mensagens não expõe SQL, JSON de infraestrutura ou mensagens internas de banco.
- Notificações antigas de panel_error também são sanitizadas na renderização, sem apagar registros.
- system_logs.php com resumo de saúde, filtros de período, severidade e busca.
- Erros históricos permanecem consultáveis, mas não são apresentados como estado atual.
- Layout responsivo da Central de mensagens melhorado para smartphone.
- Banco de dados não alterado por esta revisão.

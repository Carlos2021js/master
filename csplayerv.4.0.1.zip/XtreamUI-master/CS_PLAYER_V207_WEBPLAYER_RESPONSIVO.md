# CS PLAYER 2.0.7 / build 207

- Mantém integralmente o player de Destaques e sua rotação automática/manual.
- Remove somente o botão duplicado "Verificar atualização" do cartão superior de informações da versão; o atualizador principal permanece.
- Remove a referência visual a TMDB no rodapé do Web Player. O catálogo e a organização visual usam os dados recebidos do servidor.
- Filmes e séries ganham fileiras automáticas por ano: Lançamentos 2026, 2025, 2024... conforme o ano existente nos itens do servidor.
- Categorias originais do servidor continuam disponíveis depois das fileiras por ano.
- Início preserva Continue assistindo, Destaques, Top 10, canais e categorias.
- Responsividade ampliada para smartphone, desktop, tablet e Smart TV/4K, com foco visível para navegação por controle remoto/teclado.
- Nenhuma alteração de schema de banco de dados.

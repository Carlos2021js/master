# CS Player v6.5.0 — Web Player / DNS Inteligente

- DNS continuam 100% manuais e sem alteração do banco.
- Estratégia Inteligente ou Prioridade fixa.
- Saúde por DNS em arquivo de runtime: latência média, sucessos, falhas consecutivas e cooldown.
- Circuit breaker: DNS com falhas repetidas é temporariamente rebaixado.
- Último DNS saudável recebe pequena preferência sem ignorar a prioridade administrativa.
- Failover do player reutiliza a mesma ordenação inteligente.
- Modo por DNS: Auto / Smart / XC / M3U Plus.
- Perfil HTTP por DNS e seleção Auto / IPv4 / IPv6.
- Probe M3U interrompe amostragem de lista grande de forma controlada sem tratar o limite como erro cURL.
- Configuração persistente e estado de saúde ficam fora do banco.
- Proxy, Cast, TMDB, destaques, pedidos, player estilo YouTube e reconexão automática preservados.

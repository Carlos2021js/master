# CS PLAYER v6.4.7 — Smart Extremo

- DNS permanece 100% manual.
- Modos Auto / Smart / XC / M3U Plus preservados.
- Smart testa perfis HTTP compatíveis (IPTV Smarters, XCIPTV, VLC e Browser).
- Requisições usam HTTP/1.1, redirects e compressão compatível.
- Diagnóstico registra IP remoto, redirects, tamanho da resposta e host efetivo sem credenciais.
- Teste administrativo separa servidor online de rota API incompatível.
- Settings mobile reorganizado em cards rotulados, sem campos anônimos.
- Caminho M3U configurável por DNS.
- Login não menciona mais sincronização automática de servidores.
- Banco de dados não foi alterado.

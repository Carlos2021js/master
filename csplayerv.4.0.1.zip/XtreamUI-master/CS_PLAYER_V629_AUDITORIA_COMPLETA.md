# CS Player v6.2.9 — Auditoria completa

Base auditada: CS Player v6.2.8.

## Escopo verificado
- Admin, Revenda e páginas compartilhadas.
- Web Player: login local, usuário/e-mail, sessão persistente, catálogo, categorias, TMDB, reprodução, destaques automáticos/manuais e pedidos.
- Branding Manager e cabeçalhos responsivos.
- Três importadores M3U e classificadores independentes.
- Rotas PHP, includes locais do Web Player e assets locais.
- Compatibilidade sintática com PHP 8.3 do ambiente atual.
- JavaScript próprio do Web Player e camada responsiva.

## Correções adicionais aplicadas
### stream.php e radio.php
O campo `auto_restart` podia conter JSON vazio ou inválido. O código legado atribuía diretamente o resultado de `json_decode()` e em seguida acessava índices como `days`/`at`, o que pode produzir warnings/TypeError no PHP 8.x quando o resultado é `null`.

Agora o valor decodificado só substitui os padrões quando for realmente um array. `days` é sempre normalizado para array e `at` para `06:00` quando ausente/inválido.

## Banco de dados
Nenhuma tabela, coluna, índice ou ID foi alterado. Não existe migração SQL nesta versão.

## Validação
- 282 arquivos PHP: 0 erros de sintaxe.
- JavaScript próprio validado com `node --check`: 0 erros.
- Referências de assets locais do Web Player verificadas: 0 ausentes.
- ZIP final testado com `unzip -t`.

## Observação sobre logs do sistema
Mensagens como `/var/log/php8.3-fpm.log`, `/var/log/syslog` ou `/var/log/auth.log` ausente/sem permissão dependem das permissões e configuração de logs da VPS. Não indicam erro de sintaxe do projeto.

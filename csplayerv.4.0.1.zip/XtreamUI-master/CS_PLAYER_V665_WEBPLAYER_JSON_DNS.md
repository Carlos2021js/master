# CS PLAYER v6.6.5 — Web Player JSON DNS Compatibility

## Objetivo
Esta versão preserva integralmente o layout/design e as Configurações Avançadas do Web Player. A alteração é apenas na camada de conexão/autenticação DNS.

## Motor JSON clássico
Os DNS manuais ativos do Settings são espelhados em runtime em `admin/logs/cs-player/web-player-dns.json`, no padrão `server1_name`, `server1`, `server2_name`, `server2` etc. O arquivo não é distribuído preenchido no ZIP.

No login, o CS PLAYER tenta primeiro o mesmo fluxo simples observado no Web Player funcional de referência: `player_api.php`, requisição HTTP direta pelo stream wrapper do PHP e User-Agent de navegador. Ao autenticar, o DNS selecionado fica na sessão e as consultas do catálogo usam o mesmo motor JSON.

Se essa compatibilidade não autenticar, o motor avançado atual continua funcionando como fallback: Smart / XC / M3U Plus, perfis HTTP, failover e saúde de DNS. Nenhuma função foi removida.

## Persistência
Ao salvar o Web Player, a lista manual também é sincronizada com o JSON persistente. Se o arquivo não existir, ele é recriado automaticamente a partir da configuração atual.

## Compatibilidade
- PHP interno CS PLAYER 7.4.33: suportado.
- PHP Ubuntu 8.x: suportado.
- Banco de dados: nenhuma alteração.
- `XtreamUI-master/`: preservado para instalação por comando.

## Logs novos
- `json_dns_auth_selected`: autenticação realizada pelo motor JSON.
- `json_dns_auth_failed`: nenhum DNS JSON autenticou; o motor avançado continuará tentando.
- `json_dns_mirror_save_failed`: configuração principal foi salva, mas o espelho JSON não pôde ser persistido.

# CS PLAYER v6.6.6 — Atualizador GitHub oficial

- Manifesto principal: `https://raw.githubusercontent.com/Carlos2021js/master/main/update.json`
- Fallback: manifesto Dropbox anteriormente configurado.
- Estrutura `XtreamUI-master/` preservada.
- Atualizador não executa SQL nem altera banco de dados.
- Mantidos Web Player JSON DNS, modos Smart/XC/M3U Plus, proxy, Cast, TMDB, destaques, tickets e demais recursos existentes.
- Compatibilidade alvo: PHP interno 7.4.33 até PHP 8.4.

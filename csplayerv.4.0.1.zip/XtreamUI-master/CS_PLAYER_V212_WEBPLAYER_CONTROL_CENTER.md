# CS PLAYER 2.0.12 build 212
Central Web Player no settings.php; HTTP, HLS/M3U8, TS/MPEG-TS, MP4, MKV; direto/proxy/proxy HLS; anúncios globais e por Destaque; sem alteração de banco.

# CS Player v6.4.4 — Compatibilidade universal do Web Player

- DNS manual preservado.
- Modo por DNS: Auto, Xtream ou M3U Plus.
- Auto tenta player_api.php/panel_api.php e depois get.php M3U Plus.
- Caminho base do DNS é preservado.
- Saída M3U configurável entre MPEG-TS e HLS.
- User-Agent compatível com apps IPTV.
- Catálogo M3U é montado em cache local fora do banco, com classificação de live/filmes/séries e episódios.
- Nenhuma tabela/coluna/ID do banco é alterada.
- Proxy, Cast, PiP, player estilo YouTube e reconexão automática são preservados.

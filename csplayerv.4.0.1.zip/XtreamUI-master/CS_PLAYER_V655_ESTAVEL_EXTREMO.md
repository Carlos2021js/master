# CS Player v6.5.5 — Estável Extremo

Esta revisão preserva banco, rotas, permissões e funcionalidades existentes.

## Melhorias

- Bootstrap marcado como `6.5.5-stable-extreme`.
- Compatibilidade do Web Player mantida para PHP 7.4–8.4.
- `check_install.php` passa a usar automaticamente `/php/bin/php` do Xtream quando disponível, evitando falso positivo quando o Ubuntu usa PHP 8.3 e o painel usa PHP 7.4.
- Varredura adicional contra construções PHP 8 exclusivas dentro de `admin/player/`.
- Autodiagnóstico do Settings considera PHP 7.4 compatível e mostra o runtime real.
- Autodiagnóstico detecta construções PHP 8 exclusivas antes de virarem HTTP 500.
- DNS manuais ganham botão **Diagnosticar todos**.
- Cards DNS exibem saúde resumida (latência, falhas e cooldown) sem alterar banco.
- Após carregar/salvar Settings, o estado de saúde é atualizado automaticamente.

## Banco de dados

Nenhuma tabela, coluna, índice ou ID foi alterado.

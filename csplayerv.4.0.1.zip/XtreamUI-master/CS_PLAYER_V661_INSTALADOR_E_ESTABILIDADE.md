# CS PLAYER v6.6.1 — Instalador e Estabilidade

Esta revisão preserva integralmente a estrutura técnica `XtreamUI-master`, necessária para o atualizador por comando do projeto.

## Regras desta versão

- Identidade visível do produto: **CS PLAYER**.
- Estrutura técnica de atualização: **XtreamUI-master** preservada.
- Caminho instalado `/home/xtreamcodes/iptv_xtream_codes/` preservado.
- Nenhuma alteração de banco de dados, tabelas, colunas ou IDs.
- Web Player compatível com PHP 7.4–8.4.
- `check_install.php` valida também a referência `XtreamUI-master` usada pelo atualizador.
- Arquivos críticos de instalação e integração são verificados.

## Instalação

O ZIP contém uma única pasta principal `XtreamUI-master/`, permitindo que os scripts legados que esperam `/tmp/update/XtreamUI-master/*` continuem funcionando.

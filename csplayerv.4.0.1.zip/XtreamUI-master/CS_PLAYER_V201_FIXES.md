# CS PLAYER 2.0.1

Correção incremental baseada no pacote 2.0.0 enviado pelo usuário.

## Alterações

- `admin/login.php`: persistência local de usuário e senha antes da autenticação, inclusive quando a tentativa falha. O recurso apenas preenche os campos; não cria sessão nem contorna a autenticação.
- `admin/player/bootstrap.php`: normalização robusta de IPv4, domínio, porta e IPv6.
- `admin/player/json_dns_compat.php`: leitura defensiva de `response_bytes`.
- `admin/system_logs.php`: limpeza de logs com CSRF, whitelist, truncamento sem exclusão do arquivo, confirmação e registro de auditoria.
- `CS_PLAYER_UPDATE_VERSION.json`: versão 2.0.1 build 201.

Nenhuma alteração de schema ou conteúdo do banco de dados foi incluída.

# CS PLAYER v6.6.3 — Atualização automática por JSON/GitHub

- Manifesto oficial: https://raw.githubusercontent.com/Carlos2021js/master/main/update.json
- A aba Atualizações do settings.php consulta o manifesto e compara versão/build.
- Botão Atualizar agora baixa o ZIP, verifica SHA-256 quando informado, exige XtreamUI-master/, valida PHP com o runtime interno quando disponível, cria backup e preserva configurações persistentes.
- Nenhuma migração SQL é executada.
- A versão inicial do canal remoto nesta build é 1.0.1 / build 101, gravada em CS_PLAYER_UPDATE_VERSION.json.
- Após uma atualização bem-sucedida, a versão instalada é persistida em admin/logs/cs-player/update-state.json.

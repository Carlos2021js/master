# CS PLAYER v6.6.9 — Atualizador + Web Player Extremo

- Atualizador aceita ZipArchive **ou** `/usr/bin/unzip`.
- Lock contra atualizações simultâneas.
- SHA-256, validação de estrutura, lint pré/pós-instalação.
- Backup transacional dos arquivos substituídos e rollback automático em falha.
- Preserva configuração, DNS JSON, saúde dos DNS e estado local.
- Dropbox principal e GitHub reserva.
- Transporte HTTP unificado no Web Player.
- IPv4 primeiro em modo Auto, com persistência da família IP da sessão.
- O mesmo DNS/motor autenticado é usado no catálogo.
- Logs de transporte sem credenciais.
- Banco de dados não é alterado.

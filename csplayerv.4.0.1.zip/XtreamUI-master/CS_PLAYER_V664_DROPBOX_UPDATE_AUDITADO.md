# CS PLAYER v6.6.4 — Dropbox Update Auditado

- Manifesto principal: Dropbox `update.json` informado pelo administrador.
- Manifesto reserva: GitHub `update.json`.
- Downloads permitidos somente por HTTPS dos hosts Dropbox/GitHub autorizados.
- Estrutura técnica `XtreamUI-master/` preservada.
- Banco de dados não é alterado pelo atualizador.
- Atualização é bloqueada se o manifesto declarar `database_changes: true`.
- SHA-256 é validado quando presente no manifesto.
- Backup dos arquivos administrativos antes da cópia.
- Configurações persistentes do Web Player e configuração principal são preservadas.
- Compatibilidade de código do Web Player mantida para PHP 7.4–8.4.
- Script legado `cs-player-update-github.sh` foi preservado por compatibilidade e agora aceita Dropbox/GitHub.
- Novo alias neutro: `cs-player-update-remote.sh`.

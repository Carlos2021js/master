# Correção do HTTP 500 na autenticação do Web Player

## Diagnóstico

Os logs mostram que o Web Player recebeu HTTP 500 sem JSON do host `169.58.140.143`. A consulta externa com credenciais fictícias confirmou que a origem/porta configurada não está entregando uma resposta Xtream válida. O HTTP 500 é produzido pelo serviço remoto ou pela configuração do endpoint; não é uma alteração ou falha do banco local do painel.

## Correções aplicadas

O arquivo `admin/player/bootstrap.php` agora registra, sem senha ou token, o host, código HTTP, tipo de conteúdo, código de erro cURL, tamanho temporal da requisição e tempo total. A requisição envia `Accept: application/json`, desativa cache, aceita compressão e utiliza HTTP/1.1 para aumentar a compatibilidade com instalações Nginx/PHP legadas.

Quando o cURL multi está indisponível, o fallback sequencial também devolve diagnósticos estruturados em vez de retornar um erro indistinguível de usuário inexistente. Quando há mais de um servidor sincronizado, o primeiro que devolver uma resposta Xtream válida continua sendo escolhido; um servidor que retorna 500 não impede o failover automático.

A mensagem do login continua diferenciando HTTP 500, HTTP 404, outros códigos e ausência de resposta. A senha, o corpo da resposta e tokens não são registrados.

## Resultado do log recebido

O registro:

```json
{"event":"auth_request_failed","context":{"host":"169.58.140.143","http_code":500,"json":false}}
```

significa que `player_api.php` respondeu com erro interno e não retornou JSON. A mensagem correta para o usuário é verificar o serviço Xtream, o PHP-FPM/Nginx e a publicação de `player_api.php` na porta de broadcast cadastrada em **Servidores**. Não se deve resolver esse problema trocando usuário, senha ou importando o SQL.

## Testes

Foram aprovados o lint PHP de `bootstrap.php`, `auth.php`, `api.php` e `index.php`, a sintaxe JavaScript do Web Player e um teste local com dois servidores simulados: o primeiro retornou HTTP 500 e o segundo retornou JSON Xtream válido; o failover escolheu corretamente o segundo servidor.

A tela de login continua sem DNS manual e mantém a sincronização automática. A comparação byte a byte do SQL original com a cópia de trabalho permaneceu idêntica:

```text
9b57e517257a73dcb459ee084efd5ffe66fa30e955db5743034aa159c854582e
```

Nenhuma tabela, coluna, registro, usuário, senha, grupo, porta ou configuração do banco foi alterada. Nenhuma importação ou migração foi executada.

## Verificação necessária no servidor de origem

No próprio servidor que hospeda o Xtream, verifique os logs do Nginx/Apache e do PHP-FPM no instante `2026-08-18T23:55:18+00:00`. Confirme se a porta HTTP de transmissão configurada para o servidor ativo aponta para o serviço que publica `player_api.php`, se o PHP-FPM está em execução, se o arquivo/rota não está devolvendo erro fatal e se o firewall/proxy não está encaminhando para o painel administrativo. O código do painel pode diagnosticar e fazer failover, mas não consegue reparar um HTTP 500 gerado pelo serviço remoto.

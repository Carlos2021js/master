# CS Player v6.3.0 — Destaques: rotação automática + escolha manual

- Corrigida a rotação que podia ficar pausada indefinidamente ao manter o cursor sobre o hero.
- A rotação automática inicia após o carregamento da Home e reinicia após cada troca.
- Interação manual pausa por 8 segundos e depois retoma automaticamente.
- Setas anterior/próximo agora funcionam também no smartphone.
- Swipe horizontal no hero em dispositivos touch.
- Novo seletor “Escolher destaque” lista todos os destaques ativos, inclusive quando houver mais de 20.
- Indicadores visuais ficam compactos, enquanto o seletor oferece acesso a até 100 destaques.
- Timer pausa apenas quando a página fica em segundo plano, retomando ao voltar.
- Banco de dados não alterado.

# CS PLAYER v6.6.0 — Profissional Extremo

- Banco de dados preservado: nenhuma tabela, coluna, índice ou ID alterado.
- Compatibilidade do Web Player mantida para PHP 7.4–8.4.
- Bootstrap marcado como `6.6.0-professional-stable`.
- Logs do Web Player recebem rotação automática em ~5 MB, preservando `.1`.
- Configuração persistente passa por leitura de validação após a gravação; arquivo inválido não é considerado salvo.
- `check_install.php` também verifica compatibilidade PHP 7.4 em `player_admin_api.php` e `settings.php`.
- Settings ganhou resumo de runtime CS PLAYER / PHP / DNS / Proxy.
- Mensagens visíveis foram neutralizadas para identidade CS PLAYER; XC permanece apenas como protocolo de compatibilidade.
- Admin, Revenda, Web Player, proxy, Cast, TMDB, destaques, tickets/pedidos e 3 importadores preservados.

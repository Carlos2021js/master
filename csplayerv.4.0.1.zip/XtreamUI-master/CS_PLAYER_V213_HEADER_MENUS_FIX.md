# CS PLAYER 2.0.13 build 213

Correção dos dois menus do cabeçalho (horizontal e sidebar), perfil e notificações.
- menus separados e sem colisão;
- dropdown exclusivo por vez;
- viewport segura em smartphone;
- menu principal fecha ao abrir perfil/notificações e vice-versa;
- ESC/backdrop fecha camadas;
- desktop, smartphone e tablet;
- sem alteração do banco ou do Web Player.

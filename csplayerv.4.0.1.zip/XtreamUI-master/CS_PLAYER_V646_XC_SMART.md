# CS Player v6.4.6 — Modos XC e Smart

## Modos de conexão

- **Auto**: tenta API Xtream (`player_api.php` / `panel_api.php`) e, se necessário, M3U Plus (`get.php`).
- **Smart**: detecção automática orientada ao Web Player. Testa API XC/Xtream primeiro e faz fallback transparente para M3U Plus, registrando o provedor selecionado nos logs.
- **XC**: força compatibilidade Xtream Codes/XC via API; não cai para M3U. Útil quando o servidor publica `player_api.php` ou `panel_api.php`.
- **M3U Plus**: usa `get.php?type=m3u_plus`, com saída MPEG-TS ou HLS.

## Compatibilidade

A opção antiga `xtream` continua sendo aceita internamente para preservar configurações existentes. Nenhuma tabela, coluna ou ID do banco de dados foi alterado.

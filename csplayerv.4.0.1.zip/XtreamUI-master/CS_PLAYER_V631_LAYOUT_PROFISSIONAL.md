# CS PLAYER v6.3.1 — Layout profissional e responsivo

- Corrige contraste da timeline de tickets no modo escuro.
- Corrige assunto longo e botões da tela de ticket em smartphones.
- Mensagens de ticket usam cards compatíveis com tema/Branding Manager.
- Mobile usa timeline em largura total, sem colunas comprimidas.
- Melhora proteção contra overflow em títulos, cards, modais, mídia e textos longos.
- Mantém cabeçalho e branding existentes; a nova camada CSS não redefine logo ou cores da marca.
- Mantém Admin, Revenda, Web Player, tickets/pedidos, destaques, TMDB e importadores existentes.
- Nenhuma alteração de tabela, coluna, índice ou ID do banco de dados.

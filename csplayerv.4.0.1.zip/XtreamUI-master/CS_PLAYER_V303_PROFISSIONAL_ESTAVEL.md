# CS PLAYER 3.0.3 build 303

Esta versão foi gerada diretamente sobre o ZIP 3.0.1 confirmado como funcional.

## Melhorias
- preserva integralmente a estrutura XtreamUI-master necessária ao instalador;
- conexão MariaDB mantém a configuração original como prioridade e possui recuperação local controlada;
- login não executa bind_param/execute em statement inválido;
- indisponibilidade de login_flood não derruba o login;
- atualização remota não dispara migração automática de schema;
- notificações não criam tabela automaticamente quando cs_notifications não existe;
- resellersmarters não cria reseller_credentials automaticamente;
- HSTS é enviado apenas quando a página realmente está em HTTPS;
- identificação interna corrigida para 3.0.3 build 303;
- banco não foi aberto nem modificado durante a geração.

Nenhuma funcionalidade existente foi removida.

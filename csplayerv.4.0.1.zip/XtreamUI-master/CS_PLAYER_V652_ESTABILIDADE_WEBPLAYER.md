# CS Player v6.5.2 — Estabilidade extrema do Web Player

- Mantém todas as funções existentes e não altera o banco.
- DNS health isolado em `admin/player/dns_health.php`, reduzindo o tamanho/risco do bootstrap principal.
- Configuração persistente ganhou backup automático da última versão principal antes de salvar.
- Carregamento da configuração considera o backup antes dos fallbacks.
- `player_admin_api.php?action=preflight` verifica PHP, extensões, arquivos essenciais, persistência, DNS ativos e proxy.
- Settings recebeu painel **Autodiagnóstico do Web Player**.
- Adicionado `admin/player/check_install.php` para executar `php -l` em toda a instalação via CLI.
- Nenhuma tabela, coluna, índice ou ID foi alterado.

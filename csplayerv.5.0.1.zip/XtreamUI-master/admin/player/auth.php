<?php
require __DIR__ . '/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
$cfg = cs_player_load_config();
$username = trim((string)($_POST['username'] ?? ''));
$password = (string)($_POST['password'] ?? '');
if ($username === '' || $password === '') { $_SESSION['cs_player_error'] = 'Informe usuário e senha.'; header('Location: index.php'); exit; }
$dnsList = cs_player_active_dns($cfg);
if (!$dnsList) { $_SESSION['cs_player_error'] = 'Nenhum DNS do Web Player foi configurado pelo administrador.'; header('Location: index.php'); exit; }
    $authenticated = cs_player_authenticate_dns($dnsList, $username, $password);
    if (is_array($authenticated) && isset($authenticated['row'], $authenticated['data'])) {
        $row = $authenticated['row'];
        $data = $authenticated['data'];
        session_regenerate_id(true);
        $_SESSION['cs_player_auth'] = true;
        $_SESSION['cs_player_username'] = $username;
        $_SESSION['cs_player_password'] = $password;
        $_SESSION['cs_player_dns_index'] = (string)$row['_index'];
        $_SESSION['cs_player_dns_name'] = (string)($row['name'] ?? 'Servidor');
        $_SESSION['cs_player_user_info'] = $data['user_info'] ?? [];
        header('Location: home.php'); exit;
    }

cs_player_write_log('web_player_auth_failed', [
    'username_hash' => substr(hash('sha256', $username), 0, 12),
    'dns_count' => count($dnsList),
], 'warning');
$_SESSION['cs_player_error'] = 'Usuário não localizado nos DNS ativos ou assinatura sem acesso.';
header('Location: index.php');

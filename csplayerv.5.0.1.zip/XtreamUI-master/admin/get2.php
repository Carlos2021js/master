<?php
/**
 * CS PLAYER - Xtream compatible M3U endpoint
 * PHP 8.3/8.4 | Ubuntu 24.04
 *
 * Examples:
 * /get.php?username=USER&password=PASS&type=m3u_plus&output=mpegts
 * /get.php?username=USER&password=PASS&type=m3u_plus&output=hls
 */
declare(strict_types=1);

@ini_set('display_errors', '1');
@ini_set('log_errors', '1');
@ini_set('zlib.output_compression', '0');
error_reporting(E_ALL);
@set_time_limit(0);
@ignore_user_abort(true);

function cs_get_fail(int $status, string $message): never {
    while (ob_get_level() > 0) { @ob_end_clean(); }
    http_response_code($status);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    echo $message;
    exit;
}

function cs_get_load_bootstrap(): void {
    $candidates = [
        __DIR__ . '/player/bootstrap.php',
        dirname(__DIR__) . '/admin/player/bootstrap.php',
        '/home/xtreamcodes/iptv_xtream_codes/admin/player/bootstrap.php',
    ];
    foreach ($candidates as $file) {
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
    cs_get_fail(500, 'CS PLAYER: serviço temporariamente indisponível.');
}

function cs_get_safe_attr(string $value): string {
    $value = str_replace(["\r", "\n", '"'], [' ', ' ', "'"], $value);
    return htmlspecialchars(trim($value), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function cs_get_request_base(): string {
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
    $scheme = $https ? 'https' : 'http';
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '') {
        $host = trim((string)($_SERVER['SERVER_ADDR'] ?? '127.0.0.1'));
        $port = (int)($_SERVER['SERVER_PORT'] ?? 80);
        if (($scheme === 'http' && $port !== 80) || ($scheme === 'https' && $port !== 443)) {
            $host .= ':' . $port;
        }
    }
    // evita header injection / host inválido
    if (!preg_match('/^[A-Za-z0-9.\-:\[\]]+$/', $host)) {
        $host = '127.0.0.1';
    }
    return $scheme . '://' . $host;
}

function cs_get_url_segment(string $value): string {
    return rawurlencode($value);
}

function cs_get_flush(): void {
    if (function_exists('ob_flush')) @ob_flush();
    @flush();
}

cs_get_load_bootstrap();
if (!function_exists('cs_player_local_user') || !function_exists('cs_player_local_permissions') || !function_exists('cs_player_db')) {
    cs_get_fail(500, 'CS PLAYER: componentes da API indisponíveis.');
}

if (session_status() === PHP_SESSION_ACTIVE) {
    @session_write_close();
}

try {
    $username = trim((string)($_GET['username'] ?? $_POST['username'] ?? ''));
    $password = (string)($_GET['password'] ?? $_POST['password'] ?? '');
    $type = strtolower(trim((string)($_GET['type'] ?? 'm3u_plus')));
    $requestedOutput = strtolower(trim((string)($_GET['output'] ?? 'mpegts')));

    if ($username === '' || $password === '') {
        cs_get_fail(401, 'CS PLAYER: usuário e senha são obrigatórios.');
    }

    if (!in_array($type, ['m3u', 'm3u_plus'], true)) {
        $type = 'm3u_plus';
    }

    $output = match ($requestedOutput) {
        'hls', 'm3u8' => 'hls',
        'ts', 'mpegts', 'mpeg-ts' => 'mpegts',
        default => 'mpegts',
    };

    $user = cs_player_local_user($username, $password);
    if (!is_array($user)) {
        if (function_exists('cs_player_write_log')) {
            cs_player_write_log('get_auth_failed', ['username_hash' => substr(hash('sha256', $username), 0, 12)], 'warning');
        }
        cs_get_fail(401, 'CS PLAYER: credenciais inválidas ou assinatura indisponível.');
    }

    $permissions = cs_player_local_permissions($user);
    $channelIds = array_values(array_unique(array_filter(array_map('intval', (array)($permissions['channels'] ?? [])), static fn(int $id): bool => $id > 0)));
    $seriesIds = array_values(array_unique(array_filter(array_map('intval', (array)($permissions['series'] ?? [])), static fn(int $id): bool => $id > 0)));

    $db = cs_player_db();
    if (!$db instanceof mysqli) {
        cs_get_fail(503, 'CS PLAYER: banco de dados temporariamente indisponível.');
    }

    // Mapa de categorias em uma única consulta.
    $categories = [];
    if ($res = @$db->query('SELECT `id`,`category_name` FROM `stream_categories`')) {
        while ($row = $res->fetch_assoc()) {
            $categories[(int)$row['id']] = (string)$row['category_name'];
        }
        $res->free();
    }

    // O próprio endpoint gera URLs Xtream do servidor. Não altera/extende URL de origem.
    $base = cs_get_request_base();
    $u = cs_get_url_segment($username);
    $p = cs_get_url_segment($password);
    $liveExt = $output === 'hls' ? 'm3u8' : 'ts';

    // Download explícito no navegador. Apps IPTV continuam lendo normalmente.
    $safeName = preg_replace('/[^A-Za-z0-9._-]+/', '_', $username) ?: 'playlist';
    while (ob_get_level() > 0) { @ob_end_clean(); }
    http_response_code(200);
    header('Content-Type: audio/x-mpegurl; charset=utf-8');
    header('Content-Disposition: attachment; filename="CSPLAYER_' . $safeName . '.m3u"');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('X-Accel-Buffering: no');

    echo "#EXTM3U\n";
    $written = 0;

    $emit = static function (int $id, string $name, string $logo, string $group, string $url, array $extra = []) use ($type, &$written): void {
        if ($id <= 0 || $url === '') return;
        $name = cs_get_safe_attr($name !== '' ? $name : ('CS PLAYER ' . $id));
        if ($type === 'm3u_plus') {
            $attrs = ' tvg-id="' . cs_get_safe_attr((string)($extra['tvg_id'] ?? '')) . '"'
                . ' tvg-name="' . $name . '"'
                . ' tvg-logo="' . cs_get_safe_attr($logo) . '"'
                . ' group-title="' . cs_get_safe_attr($group) . '"';
            if (isset($extra['catchup']) && $extra['catchup'] !== '') {
                $attrs .= ' catchup="' . cs_get_safe_attr((string)$extra['catchup']) . '"';
            }
            echo '#EXTINF:-1' . $attrs . ',' . $name . "\n";
        } else {
            echo '#EXTINF:-1,' . $name . "\n";
        }
        echo $url . "\n";
        $written++;
        if (($written % 500) === 0) cs_get_flush();
    };

    // Canais + filmes numa consulta, sem limite artificial de 5000 e sem N+1.
    if ($channelIds) {
        $in = implode(',', $channelIds);
        $sql = "SELECT `id`,`type`,`stream_display_name`,`stream_icon`,`category_id`,`epg_id`,`target_container`,`tv_archive_duration`\n"
             . "FROM `streams` WHERE `id` IN ($in) AND `type` IN (1,2) ORDER BY `type`,`category_id`,`stream_display_name`";
        if ($res = @$db->query($sql, MYSQLI_USE_RESULT)) {
            while ($row = $res->fetch_assoc()) {
                $id = (int)$row['id'];
                $streamType = (int)$row['type'];
                $name = (string)($row['stream_display_name'] ?? '');
                $logo = (string)($row['stream_icon'] ?? '');
                $categoryId = (int)($row['category_id'] ?? 0);
                $group = $categories[$categoryId] ?? ($streamType === 1 ? 'Canais' : 'Filmes');

                if ($streamType === 1) {
                    $url = "$base/live/$u/$p/$id.$liveExt";
                    $emit($id, $name, $logo, $group, $url, [
                        'tvg_id' => (string)($row['epg_id'] ?? ''),
                        'catchup' => ((int)($row['tv_archive_duration'] ?? 0) > 0) ? 'default' : '',
                    ]);
                } else {
                    $ext = strtolower(trim((string)($row['target_container'] ?? 'mp4')));
                    if (!preg_match('/^[a-z0-9]{2,8}$/', $ext)) $ext = 'mp4';
                    $url = "$base/movie/$u/$p/$id.$ext";
                    $emit($id, $name, $logo, $group, $url);
                }
            }
            $res->free();
        } else {
            throw new RuntimeException('Falha ao consultar canais e filmes.');
        }
    }

    // Episódios em uma única consulta. Evita consultar cada série individualmente.
    if ($seriesIds) {
        $inSeries = implode(',', $seriesIds);
        $sql = "SELECT se.`series_id`,se.`season_num`,se.`sort`,s.`id`,s.`stream_display_name`,s.`stream_icon`,s.`target_container`,sr.`title`,sr.`category_id`\n"
             . "FROM `series_episodes` se\n"
             . "INNER JOIN `streams` s ON s.`id`=se.`stream_id`\n"
             . "INNER JOIN `series` sr ON sr.`id`=se.`series_id`\n"
             . "WHERE se.`series_id` IN ($inSeries)\n"
             . "ORDER BY sr.`category_id`,sr.`title`,se.`season_num`,se.`sort`";
        if ($res = @$db->query($sql, MYSQLI_USE_RESULT)) {
            while ($row = $res->fetch_assoc()) {
                $id = (int)$row['id'];
                $ext = strtolower(trim((string)($row['target_container'] ?? 'mp4')));
                if (!preg_match('/^[a-z0-9]{2,8}$/', $ext)) $ext = 'mp4';
                $season = max(0, (int)($row['season_num'] ?? 0));
                $episode = max(0, (int)($row['sort'] ?? 0));
                $seriesTitle = trim((string)($row['title'] ?? 'Série'));
                $episodeTitle = trim((string)($row['stream_display_name'] ?? ''));
                if ($episodeTitle === '') {
                    $episodeTitle = sprintf('%s S%02dE%02d', $seriesTitle, $season, $episode);
                }
                $categoryId = (int)($row['category_id'] ?? 0);
                $categoryName = $categories[$categoryId] ?? 'Séries';
                $group = $categoryName . ' | ' . $seriesTitle;
                $url = "$base/series/$u/$p/$id.$ext";
                $emit($id, $episodeTitle, (string)($row['stream_icon'] ?? ''), $group, $url);
            }
            $res->free();
        } else {
            throw new RuntimeException('Falha ao consultar episódios.');
        }
    }

    cs_get_flush();
    if (function_exists('cs_player_write_log')) {
        cs_player_write_log('get_playlist_generated', [
            'username_hash' => substr(hash('sha256', $username), 0, 12),
            'output' => $output,
            'type' => $type,
            'items' => $written,
        ], 'info');
    }
    exit;

} catch (Throwable $e) {
    if (function_exists('cs_player_write_log')) {
        cs_player_write_log('get_php_fatal', [
            'class' => get_class($e),
            'message_hash' => substr(hash('sha256', $e->getMessage()), 0, 12),
            'line' => $e->getLine(),
        ], 'error');
    }
    cs_get_fail(500, 'CS PLAYER: falha ao gerar a playlist. Consulte os logs administrativos.');
}

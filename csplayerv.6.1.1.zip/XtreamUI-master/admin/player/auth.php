<?php
require __DIR__ . '/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
$cfg = cs_player_load_config();
$username = trim((string)($_POST['username'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$manualDns = trim((string)($_POST['manual_dns'] ?? ''));
$manualOnly = $manualDns !== '' && !empty($_POST['manual_only']);
if ($username === '' || $password === '') { $_SESSION['cs_player_error'] = 'Informe usuário e senha.'; header('Location: index.php'); exit; }
if ($manualDns !== '' && !cs_player_manual_dns_row($manualDns)) {
    $_SESSION['cs_player_error'] = 'DNS manual inválido. Use um domínio ou IP com http:// ou https:// e porta opcional.';
    header('Location: index.php'); exit;
}
$dnsList = cs_player_session_dns_list($cfg, $manualDns, $manualOnly);
if (!$dnsList) { $_SESSION['cs_player_error'] = 'Informe um DNS manual ou aguarde o administrador configurar um servidor ativo.'; header('Location: index.php'); exit; }
    $authenticated = cs_player_authenticate_dns($dnsList, $username, $password);
    if (is_array($authenticated) && isset($authenticated['row'], $authenticated['data'])) {
        $row = $authenticated['row'];
        $data = $authenticated['data'];
        session_regenerate_id(true);
        $_SESSION['cs_player_auth'] = true;
        $_SESSION['cs_player_username'] = $username;
        $_SESSION['cs_player_password'] = $password;
        $_SESSION['cs_player_dns_index'] = (string)$row['_index'];
        $_SESSION['cs_player_dns_name'] = (string)($row['name'] ?? 'Servidor');
        $_SESSION['cs_player_manual_dns'] = $manualDns !== '' ? (string)$row['url'] : '';
        $_SESSION['cs_player_manual_only'] = $manualDns !== '' && $manualOnly;
        $_SESSION['cs_player_user_info'] = $data['user_info'] ?? [];
        header('Location: home.php'); exit;
    }

cs_player_write_log('web_player_auth_failed', [
    'username_hash' => substr(hash('sha256', $username), 0, 12),
    'dns_count' => count($dnsList),
    'manual_dns' => $manualDns !== '' ? (string)(parse_url($manualDns, PHP_URL_HOST) ?? '') : '',
], 'warning');
$_SESSION['cs_player_error'] = 'Usuário não localizado nos DNS ativos ou assinatura sem acesso.';
header('Location: index.php');

<?php
include "session.php";
include "functions.php";

if (empty($rPermissions["is_admin"])) { exit; }

set_time_limit(0);
ini_set('max_execution_time', '0');

function cs_table_exists($db, $table) {
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $r = $db->query("SHOW TABLES LIKE '" . $db->real_escape_string($table) . "'");
    return $r && $r->num_rows > 0;
}
function cs_count($db, $sql) {
    $r = $db->query($sql);
    if (!$r) return 0;
    $row = $r->fetch_row();
    return (int)($row[0] ?? 0);
}
function cs_exec($db, $sql, &$log) {
    if (!$db->query($sql)) throw new RuntimeException($db->error . ' | SQL: ' . $sql);
    $log[] = $sql;
}
function cs_stream_ids_by_type($db, array $types) {
    $types = array_values(array_unique(array_map('intval', $types)));
    if (!$types) return [];
    $ids = [];
    $r = $db->query("SELECT id FROM streams WHERE type IN (" . implode(',', $types) . ")");
    if ($r) while ($row = $r->fetch_assoc()) $ids[] = (int)$row['id'];
    return $ids;
}
function cs_delete_stream_ids($db, array $ids, &$log) {
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
    if (!$ids) return;
    foreach (array_chunk($ids, 1000) as $chunk) {
        $in = implode(',', $chunk);
        if (cs_table_exists($db, 'series_episodes')) cs_exec($db, "DELETE FROM series_episodes WHERE stream_id IN ($in)", $log);
        if (cs_table_exists($db, 'streams_sys')) cs_exec($db, "DELETE FROM streams_sys WHERE stream_id IN ($in)", $log);
        cs_exec($db, "DELETE FROM streams WHERE id IN ($in)", $log);
    }
}

$counts = [
    'live' => cs_count($db, "SELECT COUNT(*) FROM streams WHERE type=1"),
    'movies' => cs_count($db, "SELECT COUNT(*) FROM streams WHERE type=2"),
    'episode_streams' => cs_count($db, "SELECT COUNT(*) FROM streams WHERE type=5"),
    'series' => cs_table_exists($db, 'series') ? cs_count($db, "SELECT COUNT(*) FROM series") : 0,
    'episodes' => cs_table_exists($db, 'series_episodes') ? cs_count($db, "SELECT COUNT(*) FROM series_episodes") : 0,
    'categories' => cs_table_exists($db, 'stream_categories') ? cs_count($db, "SELECT COUNT(*) FROM stream_categories WHERE category_type IN ('live','movie','series')") : 0,
];

$message = '';
$error = '';
$executed = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['execute_cleanup'])) {
    $token = isset($_POST['confirm_text']) ? trim((string)$_POST['confirm_text']) : '';
    $selected = isset($_POST['cleanup']) && is_array($_POST['cleanup']) ? array_values($_POST['cleanup']) : [];
    $allowed = ['live','movies','series','episodes','categories','all'];
    $selected = array_values(array_intersect($selected, $allowed));

    if ($token !== 'LIMPAR') {
        $error = 'Digite LIMPAR no campo de confirmação.';
    } elseif (!$selected) {
        $error = 'Selecione pelo menos um item para limpeza.';
    } else {
        if (in_array('all', $selected, true)) $selected = ['live','movies','series','episodes','categories'];
        try {
            $db->begin_transaction();

            // Séries: remove episódios, streams de episódios e cadastros de séries.
            if (in_array('series', $selected, true)) {
                $episodeStreamIds = [];
                if (cs_table_exists($db, 'series_episodes')) {
                    $r = $db->query("SELECT DISTINCT stream_id FROM series_episodes WHERE stream_id > 0");
                    if ($r) while ($row = $r->fetch_assoc()) $episodeStreamIds[] = (int)$row['stream_id'];
                    cs_exec($db, "DELETE FROM series_episodes", $executed);
                }
                cs_delete_stream_ids($db, $episodeStreamIds, $executed);
                // Também limpa streams tipo 5 eventualmente não vinculados em series_episodes.
                cs_delete_stream_ids($db, cs_stream_ids_by_type($db, [5]), $executed);
                if (cs_table_exists($db, 'series')) cs_exec($db, "DELETE FROM series", $executed);
            } elseif (in_array('episodes', $selected, true)) {
                $episodeStreamIds = [];
                if (cs_table_exists($db, 'series_episodes')) {
                    $r = $db->query("SELECT DISTINCT stream_id FROM series_episodes WHERE stream_id > 0");
                    if ($r) while ($row = $r->fetch_assoc()) $episodeStreamIds[] = (int)$row['stream_id'];
                    cs_exec($db, "DELETE FROM series_episodes", $executed);
                }
                cs_delete_stream_ids($db, $episodeStreamIds, $executed);
                cs_delete_stream_ids($db, cs_stream_ids_by_type($db, [5]), $executed);
                if (cs_table_exists($db, 'series')) cs_exec($db, "UPDATE series SET seasons='[]', last_modified=" . time(), $executed);
            }

            if (in_array('live', $selected, true)) cs_delete_stream_ids($db, cs_stream_ids_by_type($db, [1]), $executed);
            if (in_array('movies', $selected, true)) cs_delete_stream_ids($db, cs_stream_ids_by_type($db, [2]), $executed);

            if (in_array('categories', $selected, true) && cs_table_exists($db, 'stream_categories')) {
                // Evita referências para categorias removidas quando a mídia correspondente não foi selecionada.
                cs_exec($db, "UPDATE streams SET category_id=0 WHERE category_id IN (SELECT id FROM stream_categories WHERE category_type IN ('live','movie','series'))", $executed);
                if (cs_table_exists($db, 'series')) cs_exec($db, "UPDATE series SET category_id=0 WHERE category_id IN (SELECT id FROM stream_categories WHERE category_type='series')", $executed);
                cs_exec($db, "DELETE FROM stream_categories WHERE category_type IN ('live','movie','series')", $executed);
            }

            $db->commit();
            if (function_exists('scanBouquets')) { @scanBouquets(); }
            $message = 'Limpeza concluída com sucesso. O importador m3u_update_nodup.php não foi alterado.';
            $counts = [
                'live' => cs_count($db, "SELECT COUNT(*) FROM streams WHERE type=1"),
                'movies' => cs_count($db, "SELECT COUNT(*) FROM streams WHERE type=2"),
                'episode_streams' => cs_count($db, "SELECT COUNT(*) FROM streams WHERE type=5"),
                'series' => cs_table_exists($db, 'series') ? cs_count($db, "SELECT COUNT(*) FROM series") : 0,
                'episodes' => cs_table_exists($db, 'series_episodes') ? cs_count($db, "SELECT COUNT(*) FROM series_episodes") : 0,
                'categories' => cs_table_exists($db, 'stream_categories') ? cs_count($db, "SELECT COUNT(*) FROM stream_categories WHERE category_type IN ('live','movie','series')") : 0,
            ];
        } catch (Throwable $e) {
            @$db->rollback();
            $error = 'A limpeza foi cancelada e revertida: ' . $e->getMessage();
        }
    }
}

if ($rSettings["sidebar"]) include "header_sidebar.php"; else include "header.php";
?>
<?php if ($rSettings["sidebar"]) { ?><div class="content-page"><div class="content boxed-layout-ext"><div class="container-fluid"><?php } else { ?><div class="wrapper boxed-layout-ext"><div class="container-fluid"><?php } ?>
<div class="row"><div class="col-12"><div class="page-title-box"><h4 class="page-title"><span class="mdi mdi-broom"></span> Limpeza completa do conteúdo M3U</h4></div></div></div>
<?php if ($message) { ?><div class="alert alert-success"><?=htmlspecialchars($message)?></div><?php } ?>
<?php if ($error) { ?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php } ?>
<div class="row">
<div class="col-xl-4 col-md-6"><div class="card"><div class="card-body"><h5>Canais</h5><h2><?=number_format($counts['live'],0,',','.')?></h2><small>streams tipo LIVE</small></div></div></div>
<div class="col-xl-4 col-md-6"><div class="card"><div class="card-body"><h5>Filmes</h5><h2><?=number_format($counts['movies'],0,',','.')?></h2><small>streams tipo MOVIE</small></div></div></div>
<div class="col-xl-4 col-md-6"><div class="card"><div class="card-body"><h5>Séries / episódios</h5><h2><?=number_format($counts['series'],0,',','.')?> / <?=number_format($counts['episodes'],0,',','.')?></h2><small><?=number_format($counts['episode_streams'],0,',','.')?> streams de episódios</small></div></div></div>
</div>
<div class="card"><div class="card-body">
<h4 class="header-title mb-3">Selecione o que deseja limpar</h4>
<div class="alert alert-warning"><strong>Atenção:</strong> esta ação apaga registros do banco. Ela não altera <code>m3u_update_nodup.php</code>. Para segurança, a operação usa transação e exige confirmação manual.</div>
<form method="post" id="cleanupForm">
<div class="row">
<?php $opts=['live'=>'Canais (LIVE)','movies'=>'Filmes','series'=>'Séries completas + episódios','episodes'=>'Somente episódios','categories'=>'Categorias LIVE / MOVIE / SERIES','all'=>'TUDO importado pelo M3U']; foreach($opts as $k=>$v){ ?>
<div class="col-lg-4 col-md-6 mb-2"><div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" name="cleanup[]" value="<?=$k?>" id="c_<?=$k?>"><label class="custom-control-label" for="c_<?=$k?>"><?=$v?></label></div></div>
<?php } ?>
</div><hr>
<div class="form-group"><label>Para confirmar, digite <strong>LIMPAR</strong></label><input type="text" class="form-control" name="confirm_text" autocomplete="off" placeholder="LIMPAR" required></div>
<button type="submit" name="execute_cleanup" value="1" class="btn btn-danger"><span class="mdi mdi-delete-forever"></span> Executar limpeza selecionada</button>
</form>
</div></div>
</div></div></div>
<script>
document.getElementById('cleanupForm').addEventListener('submit', function(e){
 if(!confirm('Confirma a limpeza definitiva dos itens selecionados?')) e.preventDefault();
});
document.getElementById('c_all').addEventListener('change', function(){
 document.querySelectorAll('input[name="cleanup[]"]').forEach(function(el){ if(el.id !== 'c_all') el.checked = document.getElementById('c_all').checked; });
});
</script>
<?php include "footer.php"; ?>

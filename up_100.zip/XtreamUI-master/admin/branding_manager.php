<?php
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
cs_admin_only('a identidade visual, imagens e vídeos');
if ((!hasPermissions('adv', 'settings')) && (!hasPermissions('adv', 'database'))) exit;
require_once __DIR__ . '/branding_helper.php';
require_once __DIR__ . '/cs_audit.php';

$baseDir = __DIR__ . '/assets/uploads/branding';
$backupDir = $baseDir . '/backups';
$configFile = $baseDir . '/branding.json';
@mkdir($backupDir, 0755, true);
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
if (empty($_SESSION['cs_branding_csrf'])) $_SESSION['cs_branding_csrf'] = bin2hex(random_bytes(24));
$csrf = $_SESSION['cs_branding_csrf'];
$message = ''; $messageType = 'success';
$slots = [
    'logo_main' => ['label'=>'Logo principal', 'fallback'=>($rSettings['logo_url'] ?? 'assets/images/logo.png'), 'accept'=>'PNG, JPG ou WebP'],
    'logo_compact' => ['label'=>'Logo compacto/lateral', 'fallback'=>($rSettings['logo_url_sidebar'] ?? 'assets/images/logo-back.png'), 'accept'=>'PNG, JPG ou WebP'],
    'favicon' => ['label'=>'Favicon', 'fallback'=>'assets/images/favicon.ico', 'accept'=>'PNG, JPG, WebP ou ICO'],
    'login_background' => ['label'=>'Fundo da tela de login', 'fallback'=>'assets/images/bg1.png', 'accept'=>'PNG, JPG ou WebP'],
    'dashboard_background' => ['label'=>'Fundo do Dashboard', 'fallback'=>'', 'accept'=>'PNG, JPG ou WebP'],
    'login_video' => ['label'=>'Vídeo do login', 'fallback'=>'', 'accept'=>'MP4 com ou sem áudio'],
    'dashboard_video' => ['label'=>'Vídeo do Dashboard', 'fallback'=>'', 'accept'=>'MP4 com ou sem áudio'],
    'admin_avatar' => ['label'=>'Imagem do administrador', 'fallback'=>'', 'accept'=>'PNG, JPG ou WebP']
];

function cs_branding_load_config($file) {
    if (!is_file($file)) return [];
    $data = json_decode((string)@file_get_contents($file), true);
    return is_array($data) ? $data : [];
}
function cs_branding_save_config($file, array $data) {
    $tmp = $file . '.tmp';
    $json = json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    @chmod($tmp, 0644);
    return @rename($tmp, $file);
}
function cs_validate_upload($file, $allowIco = false, $allowVideo = false) {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) return [false, 'Falha no envio. Verifique também upload_max_filesize, post_max_size e client_max_body_size.'];
    $limit = $allowVideo ? 300 * 1024 * 1024 : 15 * 1024 * 1024;
    if ($file['size'] < 1 || $file['size'] > $limit) return [false, $allowVideo ? 'O vídeo deve ter no máximo 300 MB.' : 'A imagem deve ter no máximo 15 MB.'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($allowVideo) {
        if ($ext !== 'mp4') return [false, 'Envie um vídeo MP4.'];
        $finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : false;
        $mime = $finfo ? finfo_file($finfo, $file['tmp_name']) : '';
        if ($finfo) finfo_close($finfo);
        if ($mime && !in_array($mime, ['video/mp4','application/mp4','application/octet-stream'], true)) return [false, 'O arquivo não foi reconhecido como MP4 válido.'];
        return [true, 'mp4'];
    }
    $allowed = $allowIco ? ['png','jpg','jpeg','webp','ico'] : ['png','jpg','jpeg','webp'];
    if (!in_array($ext, $allowed, true)) return [false, 'Formato não permitido.'];
    if ($ext !== 'ico') {
        $info = @getimagesize($file['tmp_name']);
        if (!$info || !in_array($info[2], [IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_WEBP], true)) return [false, 'O arquivo não é uma imagem válida.'];
        if ($info[0] > 12000 || $info[1] > 12000) return [false, 'Dimensões máximas: 12000 × 12000 px.'];
    }
    return [true, $ext === 'jpeg' ? 'jpg' : $ext];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) { $message='Sessão expirada. Recarregue a página.'; $messageType='danger'; }
    else {
        $config = cs_branding_load_config($configFile);
        $action = $_POST['action'] ?? '';
        if ($action === 'upload_slot') {
            $slot = (string)($_POST['slot'] ?? '');
            if (!isset($slots[$slot])) { $message='Tipo de imagem inválido.'; $messageType='danger'; }
            else {
                [$ok,$result] = cs_validate_upload($_FILES['image'] ?? [], $slot === 'favicon', in_array($slot, ['login_video','dashboard_video'], true));
                if (!$ok) { $message=$result; $messageType='danger'; }
                else {
                    $name = $slot . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $result;
                    $target = $baseDir . '/' . $name;
                    if (@move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                        @chmod($target, 0644);
                        if (!empty($config[$slot]) && is_file(__DIR__ . '/' . $config[$slot])) @copy(__DIR__ . '/' . $config[$slot], $backupDir . '/' . basename($config[$slot]));
                        $config[$slot] = 'assets/uploads/branding/' . $name;
                        if (cs_branding_save_config($configFile, $config)) { $message='Imagem atualizada com sucesso.'; cs_audit_log('branding.upload', ['slot'=>$slot,'file'=>$name,'size'=>(int)($_FILES['image']['size'] ?? 0)]); }
                        else { @unlink($target); $message='Não foi possível salvar a configuração.'; $messageType='danger'; }
                    } else { $message='A pasta de branding não possui permissão de escrita.'; $messageType='danger'; }
                }
            }
        } elseif ($action === 'save_media_settings') {
            foreach (['login','dashboard'] as $ctx) {
                foreach (['muted','loop','autoplay','controls'] as $flag) $config[$ctx.'_'.$flag] = !empty($_POST[$ctx.'_'.$flag]);
                $config[$ctx.'_overlay'] = max(0, min(100, (int)($_POST[$ctx.'_overlay'] ?? 35)));
            }
            if (cs_branding_save_config($configFile, $config)) { $message='Preferências de vídeo e fundo atualizadas.'; cs_audit_log('branding.settings_update'); }
            else { $message='Não foi possível salvar as preferências.'; $messageType='danger'; }
        } elseif ($action === 'restore_slot') {
            $slot = (string)($_POST['slot'] ?? '');
            if (isset($slots[$slot])) {
                if (!empty($config[$slot])) @unlink(__DIR__ . '/' . $config[$slot]);
                unset($config[$slot]);
                cs_branding_save_config($configFile, $config);
                $message='Imagem restaurada para o padrão.'; cs_audit_log('branding.restore', ['slot'=>$slot]);
            }
        } elseif ($action === 'replace_project_image') {
            $relative = str_replace('\\','/', (string)($_POST['project_image'] ?? ''));
            $allowedBases = array_filter([realpath(__DIR__ . '/assets/images'), realpath(__DIR__ . '/icons')]);
            $target = realpath(__DIR__ . '/' . $relative);
            $inside = false; foreach ($allowedBases as $realBase) if ($target && ($target === $realBase || strpos($target, $realBase . DIRECTORY_SEPARATOR) === 0)) { $inside = true; break; }
            if (!$inside || !is_file($target)) { $message='Imagem do projeto inválida.'; $messageType='danger'; }
            else {
                [$ok,$ext] = cs_validate_upload($_FILES['image'] ?? [], strtolower(pathinfo($target, PATHINFO_EXTENSION)) === 'ico');
                if (!$ok) { $message=$ext; $messageType='danger'; }
                else {
                    $targetExt = strtolower(pathinfo($target, PATHINFO_EXTENSION));
                    if (($targetExt === 'ico') !== ($ext === 'ico')) { $message='Para favicon ICO, envie outro arquivo ICO.'; $messageType='danger'; }
                    else {
                        $backup = $backupDir . '/project-' . date('Ymd-His') . '-' . basename($target);
                        @copy($target, $backup);
                        if (@move_uploaded_file($_FILES['image']['tmp_name'], $target)) { @chmod($target,0644); $message='Imagem do projeto substituída; backup criado.'; cs_audit_log('branding.project_replace', ['file'=>$relative]); }
                        else { @copy($backup,$target); $message='Não foi possível substituir a imagem.'; $messageType='danger'; }
                    }
                }
            }
        }
    }
}
$config = cs_branding_load_config($configFile);
$projectImages = [];
$scanRoots = [__DIR__ . '/assets/images', __DIR__ . '/icons'];
foreach ($scanRoots as $scanRoot) if (is_dir($scanRoot)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($scanRoot, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $img) if ($img->isFile() && preg_match('/\.(png|jpe?g|webp|gif|ico)$/i', $img->getFilename())) {
        $projectImages[] = str_replace('\\','/', substr($img->getPathname(), strlen(__DIR__) + 1));
    }
}
sort($projectImages);
include $rSettings['sidebar'] ? 'header_sidebar.php' : 'header.php';
?>
<div class="wrapper"><div class="container-fluid">
<div class="row"><div class="col-12"><div class="page-title-box"><h4 class="page-title"><i class="mdi mdi-image-multiple"></i> Identidade visual e imagens</h4></div></div></div>
<?php if ($message): ?><div class="alert alert-<?=$messageType?> alert-dismissible fade show"><?=htmlspecialchars($message)?><button type="button" class="close" data-dismiss="alert">&times;</button></div><?php endif; ?>
<div class="alert alert-info"><strong>Gerenciamento não destrutivo:</strong> as imagens personalizadas ficam separadas dos arquivos originais. A restauração volta ao padrão, e substituições avançadas geram backup automático.</div>
<div class="row">
<?php foreach ($slots as $key=>$slot): $current = !empty($config[$key]) ? $config[$key] : $slot['fallback']; ?>
<div class="col-xl-4 col-md-6"><div class="card"><div class="card-body">
<h4 class="header-title mb-3"><?=htmlspecialchars($slot['label'])?></h4>
<div class="text-center bg-light rounded p-3 mb-3" style="min-height:150px;display:flex;align-items:center;justify-content:center">
<?php if ($current && in_array($key,['login_video','dashboard_video'],true)): ?><video src="<?=htmlspecialchars($current)?>?v=<?=time()?>" controls muted style="max-width:100%;max-height:180px"></video><?php elseif ($current): ?><img src="<?=htmlspecialchars($current)?>?v=<?=time()?>" alt="" style="max-width:100%;max-height:125px;object-fit:contain"><?php else: ?><div><i class="fas fa-user-circle fa-5x text-muted"></i><br><small>Imagem padrão</small></div><?php endif; ?>
</div>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="upload_slot"><input type="hidden" name="slot" value="<?=htmlspecialchars($key)?>">
<div class="custom-file mb-2"><input class="custom-file-input" id="img-<?=$key?>" type="file" name="image" accept="<?=in_array($key,['login_video','dashboard_video'],true)?'.mp4':'.png,.jpg,.jpeg,.webp'.($key==='favicon'?',.ico':'')?>" required><label class="custom-file-label" for="img-<?=$key?>">Selecionar imagem</label></div>
<small class="text-muted d-block mb-2"><?=htmlspecialchars($slot['accept'])?> · <?=in_array($key,['login_video','dashboard_video'],true)?'máximo 300 MB':'máximo 15 MB'?></small><button class="btn btn-primary btn-sm" type="submit"><i class="mdi mdi-upload"></i> Substituir</button></form>
<?php if (!empty($config[$key])): ?><form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="restore_slot"><input type="hidden" name="slot" value="<?=htmlspecialchars($key)?>"><button class="btn btn-outline-secondary btn-sm mt-2" onclick="return confirm('Restaurar imagem padrão?')"><i class="mdi mdi-backup-restore"></i> Restaurar padrão</button></form><?php endif; ?>
</div></div></div>
<?php endforeach; ?>
</div>
<div class="card"><div class="card-body"><h4 class="header-title">Comportamento dos vídeos e fundos</h4><p class="text-muted">Navegadores podem bloquear reprodução automática com áudio. Quando isso ocorrer, o botão flutuante permite iniciar e ativar o som após a primeira interação.</p>
<form method="post"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="save_media_settings"><div class="row">
<?php foreach(['login'=>'Login','dashboard'=>'Dashboard'] as $ctx=>$title): ?><div class="col-lg-6"><div class="border rounded p-3 mb-3"><h5><?=$title?></h5>
<?php foreach(['autoplay'=>'Reprodução automática','loop'=>'Repetir continuamente','muted'=>'Iniciar sem áudio','controls'=>'Mostrar controles do vídeo'] as $flag=>$label): ?><div class="custom-control custom-switch mb-2"><input type="checkbox" class="custom-control-input" id="<?=$ctx?>_<?=$flag?>" name="<?=$ctx?>_<?=$flag?>" <?=cs_branding_value($ctx.'_'.$flag, $flag!=='controls')?'checked':''?>><label class="custom-control-label" for="<?=$ctx?>_<?=$flag?>"><?=$label?></label></div><?php endforeach; ?>
<label class="mt-2">Escurecimento/sobreposição: <strong id="<?=$ctx?>OverlayValue"><?=(int)cs_branding_value($ctx.'_overlay',35)?>%</strong></label><input type="range" class="custom-range" min="0" max="90" name="<?=$ctx?>_overlay" value="<?=(int)cs_branding_value($ctx.'_overlay',35)?>" oninput="document.getElementById('<?=$ctx?>OverlayValue').textContent=this.value+'%'">
</div></div><?php endforeach; ?></div><button class="btn btn-success"><i class="mdi mdi-content-save"></i> Salvar comportamento</button></form></div></div>
<div class="card"><div class="card-body"><h4 class="header-title">Biblioteca avançada de imagens do projeto</h4><p class="text-muted">Substitua uma imagem existente mantendo o mesmo caminho. Um backup datado será criado antes da alteração.</p>
<form method="post" enctype="multipart/form-data" class="row align-items-end"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="replace_project_image">
<div class="col-md-5"><label>Imagem existente</label><select name="project_image" class="form-control select2" required><?php foreach($projectImages as $img): ?><option value="<?=htmlspecialchars($img)?>"><?=htmlspecialchars($img)?></option><?php endforeach; ?></select></div>
<div class="col-md-5"><label>Nova imagem</label><input type="file" name="image" class="form-control" accept=".png,.jpg,.jpeg,.webp,.ico" required></div><div class="col-md-2"><button class="btn btn-warning btn-block" onclick="return confirm('Substituir esta imagem do projeto?')"><i class="mdi mdi-image-edit"></i> Substituir</button></div></form>
</div></div>
</div></div>
<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-md-12 copyright text-center"><?=getFooter()?></div></div></div></footer>
<script src="assets/js/vendor.min.js"></script><script src="assets/libs/select2/select2.min.js"></script><script src="assets/js/app.min.js"></script>
<script>$(function(){ $('.select2').select2({width:'100%'}); $('.custom-file-input').on('change',function(){var n=this.files[0]?this.files[0].name:'Selecionar imagem';$(this).next('.custom-file-label').text(n);});});</script>
</body></html>

# CS Player — melhorias aplicadas

Esta atualização é incremental e preserva todos os módulos e integrações existentes.

- Camada de compatibilidade `admin/cs_player.php` para PHP moderno.
- Cache em arquivo com escrita atômica, TTL e fallback para dados antigos.
- Cliente HTTP resiliente com cURL e fallback por stream.
- reCAPTCHA v3 opcional: somente é carregado e validado quando habilitado e quando site key + secret key estão preenchidas.
- Validação de ação e score do reCAPTCHA v3, com timeout e tratamento de indisponibilidade.
- Identidade do autenticador 2FA atualizada para **CS Player**.
- Login responsivo refinado, sem remoção dos fluxos existentes de login, 2FA, troca de senha ou reCAPTCHA v2.
- Detector auxiliar de fontes Xtream API, M3U, HLS e Stalker, pronto para reaproveitamento pelos módulos atuais.

## Cache

Por padrão, o cache tenta usar `admin/cache/cs-player` e recorre ao diretório temporário do sistema. É possível definir outro local com `CS_PLAYER_CACHE_DIR`.

## Ubuntu 24.04

Recomendado: PHP 8.1+ com extensões `curl`, `mysqli`, `mbstring`, `json`, `xml`, `zip` e OPcache. O código modificado foi validado sintaticamente com PHP 8.4.

## Importador M3U inteligente para arquivos grandes
- Upload fragmentado em blocos de 512 KB para evitar `413 Request Entity Too Large`.
- Análise obrigatória antes da importação.
- Parser incremental para playlists com centenas de MB.
- Separação por canais, filmes, séries, temporadas, episódios e categorias.
- Detecção combinada por grupo, extensão e padrões SxxExx/TxxExx/1x01.
- Contagem de duplicidades internas antes de gravar no banco.
- Importação transacional em lotes de 500 itens.
- Atualização consolidada das temporadas, evitando uma consulta pesada por episódio.
- Download remoto por streaming para arquivo temporário.
- Configurações recomendadas para Nginx e PHP-FPM no Ubuntu 24.04.

## Gerenciador de identidade visual
- Nova opção **Identidade visual** no menu administrativo.
- Troca não destrutiva de logo principal, logo compacto, favicon, fundo do login e imagem do administrador.
- Biblioteca avançada para substituir imagens existentes em `admin/assets/images`.
- Validação real de formato, tamanho máximo de 10 MB e dimensões máximas de 8000 × 8000 px.
- Proteção CSRF, nomes aleatórios, escrita atômica da configuração e backups automáticos.
- Restauração individual para os recursos visuais padrão.
- Arquivos personalizados isolados em `admin/assets/uploads/branding`.

- Gerenciamento ampliado de todas as imagens visuais, vídeo MP4 no login e Dashboard, áudio, autoplay, loop, controles, overlay e fallback.

## Revisão profissional e diagnóstico inteligente
- Nova opção **Saúde do sistema** no menu administrativo.
- Verificações automáticas de PHP, extensões, limites de upload, memória, tempo de execução, permissões, cache, mídias e espaço em disco.
- Índice visual de saúde para priorizar ajustes do servidor.
- Auditoria leve em JSON Lines para alterações de identidade visual, sem registrar senhas, tokens, cookies, chaves ou segredos.
- Proteção adicional dos diretórios de cache, logs e uploads contra listagem e execução de scripts.
- Medição de uso de armazenamento para mídia e cache.
- Implementação incremental: nenhum módulo, rota ou funcionalidade existente foi removido.

## Controle administrativo exclusivo

- Centralizado o bloqueio das funcionalidades personalizadas em `admin/cs_admin_access.php`.
- Identidade visual, vídeos, saúde do sistema e importador inteligente M3U agora exigem administrador no servidor.
- Links dessas funções são exibidos exclusivamente para administradores.
- Revendedores e demais perfis continuam vendo o resultado das alterações, mas não podem editá-las.
- Tentativas diretas retornam HTTP 403 e não executam ações POST/AJAX.

## Correção import_stream — acesso exclusivo do administrador
- Corrigido o bloqueio incorreto que exigia `add_stream`/`edit_stream` antes de abrir o modo de importação.
- O modo `stream.php?import` agora valida corretamente `import_streams`.
- Revendedores e demais perfis não visualizam o item Importar Streams.
- Acesso direto, upload M3U e endpoint de listagem retornam HTTP 403 para não administradores.
- A proteção é aplicada no servidor, além da ocultação no menu.

## Auditoria profissional de estabilidade e segurança

- Auditoria integral dos 185 arquivos PHP com PHP 8.4.
- Proteção das chamadas FFprobe contra injeção de comandos e entradas de controle.
- Validação de URL/fonte com limite seguro antes da análise de mídia.
- Otimização da deduplicação no importador legado de streams usando mapa indexado.
- Tratamento de campos M3U opcionais sem avisos de índice indefinido no PHP 8+.
- Validação numérica de PID antes de encerrar o processo do monitor de pastas.
- Isolamento seguro do endereço IP enviado ao iptables.
- Atualizações remotas com tratamento de indisponibilidade, validação de versão e argumentos isolados.
- Preservação das permissões: recursos personalizados e importações continuam exclusivos do administrador.
- Nenhuma funcionalidade, página, integração ou estrutura de banco removida.

## Auditoria final de estabilidade e compatibilidade

- reCAPTCHA v3 opcional validado com chaves vazias e incompletas.
- tratamento global seguro de exceções e erros fatais.
- autenticação e permissões migradas para prepared statements.
- cache por requisição para configurações, categorias e permissões.
- limpeza automática e limite de crescimento do cache em disco.
- identidade visual antiga removida dos textos, traduções e comentários.
- testes de detecção para Xtream API, M3U, HLS e Stalker.
- auditoria SQL detalhada e análise de desempenho/memória adicionadas em `docs/`.


## Escopo administrativo e importação grande
- Todos os componentes adicionados foram consolidados dentro de `admin/`.
- Importação M3U Inteligente movida para Gestão > Ferramentas.
- Upload fragmentado adaptativo de 16 MB até 512 KB, com fallback automático ao erro 413.
- Sem limite artificial de tamanho no aplicativo; validação baseada em espaço livre real.
- Verificação de ordem, tamanho final e integridade básica dos blocos.
- Armazenamento temporário protegido em `admin/storage/m3u_uploads/`.

## Servidor SSH
- Nova aba `Servidor SSH` integrada ao menu administrativo existente.
- Acesso exclusivo do administrador principal, com bloqueio HTTP no servidor.
- Diagnóstico de SSH, Nginx, PHP-FPM, carga, memória e disco.
- Reinício da VPS, reload seguro do Nginx, restart do PHP-FPM, limpeza de cache e perfis PHP controlados.
- Nenhuma senha root ou senha SSH é armazenada pelo painel.
- Execução privilegiada limitada ao helper `/usr/local/sbin/cs-player-adminctl` com lista fechada de ações.

## Auditoria Servidor SSH
- Verificador de atualização desacoplado de repositórios antigos.
- Helper compatível com PHP-FPM 8.2, 8.3 e 8.4.
- Backup e rollback de configuração PHP.
- Bloqueio de manutenções concorrentes.
- Limpeza de disco conservadora, sem remoção automática de pacotes.
- Rota duplicada do gerenciador consolidada.
- Proteção contra ações administrativas repetidas.

## Diagnóstico e persistência real do importador
- Corrigida confirmação silenciosa de consultas SQL do importador.
- O arquivo M3U temporário só é excluído após gravação confirmada no banco.
- Adicionado diagnóstico em tempo real com status, memória, lotes, SQL, sucessos, avisos e erros.
- Adicionado histórico persistente sem alterar o banco.
- Erros isolados de canais não cancelam os demais itens.
- Adicionada verificação explícita das permissões de storage.

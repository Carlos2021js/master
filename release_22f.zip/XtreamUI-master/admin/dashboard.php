<?php
include "session.php"; include "functions.php";
if (!$rPermissions["is_admin"]) { header("Location: ./reseller.php"); }

if ($rAdminSettings["dark_mode"]) {
	$rColours = Array(1 => Array("secondary", "#7e8e9d"), 2 => Array("secondary", "#7e8e9d"), 3 => Array("secondary", "#7e8e9d"), 4 => Array("secondary", "#7e8e9d"));
} else {
	$rColours = Array(1 => Array("purple", "#675db7"), 2 => Array("success", "#23b397"), 3 => Array("pink", "#e36498"), 4 => Array("info", "#56C3D6"));
}
	$query = $db->query("SELECT * from users where is_mag = 1;");
	$devicesmag = mysqli_num_rows($query);
	
	$query = $db->query("SELECT * from users where is_e2 = 1;");
	$enigma2 = $query->num_rows;
	
	$query = $db->query("SELECT * from users where is_mag = 0;");
	$smarttv = $query->num_rows;
	
	$query = $db->query("SELECT * from streams where type = 1;");
	$channels = $query->num_rows;
	
	$query = $db->query("SELECT * from streams where type = 2;");
	$vod = $query->num_rows;
	
	$query = $db->query("SELECT * from series;");
	$series = $query->num_rows;
	
	$query = $db->query("SELECT * from bouquets;");
	$bouquets = $query->num_rows;
	
	$query = $db->query("SELECT * from streams where type = 4;");
	$radio = $query->num_rows;
	
	$query = $db->query("SELECT * from streaming_servers;");
	$server = $query->num_rows;
	
	$query = $db->query("SELECT * from streaming_servers where status = 2;");
	$off_server = $query->num_rows;
	
	$query = $db->query("SELECT * from reg_users;");
	$reseller = $query->num_rows;
	
	$query = $db->query("SELECT * from series_episodes;");
    $episodes = $query->num_rows;

	$query = $db->query("SELECT * from streams_providers;");
    $name = $query->num_rows;
	
if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper"><div class="container-fluid">
        <?php } ?>
				<?php if (hasPermissions("adv", "index")) { ?>
                <!-- start page title -->
                <br>
				<?php if (($rServerError) && ($rPermissions["is_admin"]) && (hasPermissions("adv", "servers"))) { 
				foreach ($rServers as $rServer) { 
				$show_offline=false
				?>
				<?php 
				if (((time() - $rServer["last_check_ago"]) > 360) AND ($rServer["can_delete"] == 1) AND ($rServer["status"] <> 3)) { $rServer["status"] = 2; }
				if ($rServer["status"] == 2) {
					$show_offline=true;
					if ($rServer["last_check_ago"] > 0) {
					    $rServerOff = $rServer["server_name"] . " offline for ".intval((time() - $rServer["last_check_ago"])/60)." minutes";
					} else {
					    $rServerOff = $rServer["server_name"] . " Offline";
					}	
                }
				?>
                    <div class="alert alert-dark alert-dismissible fade show" role="alert" <?php if ($show_offline===false){?>style="display:none"<?php } ?>>
                        <button type="button" class="close" data-dismiss="alert" aria-label="<?=$_["close"]?>">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <a href="./servers.php">
                            <i class="fas fa-square text-danger"></i>
                        </a>
						<?php echo $rServerOff; ?>
                    </div>
                <?php } }?>
                <!-- end page title --> 
                <div class="tab-content">
                    <div class="tab-pane show active" id="server-home">
                        <div class="row">
						
							<div class="col-6-md col-xl-3">
							    <div class="card-bg online-users bg-info1">
								<?php if (hasPermissions("adv", "live_connections")) { ?>
								<a href="./live_connections.php">
								<?php } ?>
									<div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between cta-box">
									<?php if ($rAdminSettings["dark_mode"]) { ?>
										<div class="avatar-md">
											<i class="fe-users avatar-title font-24 text-white"></i>
										</div>
										<?php } else { ?>
										<div class="avatar-md">
											<i class="fe-users avatar-title font-24 text-white"></i>
										</div>
										<?php } ?>
									</div>
									<div class="col-md" align="right">
										<h3 class="text-white mb-1"><span data-plugin="counterup" class="entry">0</span></h3>
										<p class="text-white mb-1 text-truncate"><?=$_["online_users"]?></p>
									</div>
								</div><br> <!-- end card-box-->
                            </div> <!-- end col -->
                            
                            <div class="col-6-md col-xl-3">
							    <div class="card-bg active-connections bg-success1">
								<?php if (hasPermissions("adv", "live_connections")) { ?>
								<a href="./live_connections.php">
								<?php } ?>
									        <div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between cta-box">
												<?php if ($rAdminSettings["dark_mode"]) { ?>
												<div class="avatar-md">
													<i class="fe-box avatar-title font-24 text-white"></i><br><br>
												</div>
												<?php } else { ?>
												<div class="avatar-md">
													<i class="fe-box avatar-title font-24 text-white"></i><br><br>
												</div>
												<?php } ?>
											</div>
											<div class="col-md" align="right">
												<h3 class="text-white mb-1"><span data-plugin="counterup" class="entry">0</span></h3>
												<p class="text-white mb-1 text-truncate"><?=$_["open_connections"]?></p>
											</div>
								</div><br> <!-- end card-box-->
                            </div> <!-- end col -->

                            <div class="col-6-md col-xl-3">
								<?php if (hasPermissions("adv", "live_connections")) { ?>
								<a href="./live_connections.php">
								<?php } ?>
									<div class="card-bg bg-pink1">
								        <div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between cta-box">
										    <?php if ($rAdminSettings["dark_mode"]) { ?>
										    <div class="avatar-md">
											    <i class="fe-download avatar-title font-24 text-white"></i>
										    </div>
										    <?php } else { ?>
										    <div class="avatar-md">
											    <i class="fe-download avatar-title font-24 text-white"></i>
										    </div>
										    <?php } ?>
										    <div class="col" align="right">
											    <h3 class="text-white my-1 input-flow"><span data-plugin="counterup" class="entry">0</span><small> Mbps</small></h3>
											    <p class="text-white my-1 text-truncate"><?=$_["total_input"]?></p>
										    </div>
									    </div>
									    <div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-md">
												<i class="fe-upload avatar-title font-24 text-white"></i>
											</div>
											<?php } else { ?>
											<div class="avatar-md">
												<i class="fe-upload avatar-title font-24 text-white"></i>
											</div>
											<?php } ?>
											<div class="col" align="right">
												<h3 class="text-white my-1 output-flow"><span data-plugin="counterup" class="entry">0</span><small> Mbps</small></h3>
												<p class="text-white my-1 text-truncate"><?=$_["total_output"]?></p>
											</div>
										</div>
									</div><br>
                            </div> <!-- end col -->
							
							<div class="col-6-md col-xl-3">
								<?php if (hasPermissions("adv", "live_connections")) { ?>
								<a href="./streams.php?filter=1">
								<?php } ?>
									<div class="card-bg bg-secondary1">
									    <div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between cta-box">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-md">
												<i class="fe-video avatar-title font-24 text-white"></i>
											</div>
											<?php } else { ?>
											<div class="avatar-md">
												<i class="fe-video avatar-title font-24 text-white"></i>
											</div>
											<?php } ?>
											<div class="col" align="right">
												<h3 class="text-white my-1 active-streams"><span data-plugin="counterup" class="entry">0</span></h3>
												<p class="text-white my-1 text-truncate"><?=$_["online_streams"]?></p>
											</div>
										</div>
										<?php if (hasPermissions("adv", "live_connections")) { ?>
								        <a href="./streams.php?filter=2">
								        <?php } ?>
									    <div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between">
											 <?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-md">
												 <i class="fe-video-off avatar-title font-24 text-white"></i>
											</div>
											<?php } else { ?>
											<div class="avatar-md">
												<i class="fe-video-off avatar-title font-24 text-white"></i>
											</div>
											<?php } ?>
											<div class="col" align="right">
												<h3 class="text-white my-1 offline-streams"><span data-plugin="counterup" class="entry">0</span></h3>
												<p class="text-white my-1 text-truncate"><?=$_["offline_streams"]?></p>
											</div>
										</div>
									</div><br>
                            </div><!-- end col -->
							
							<?php if (($rSettings["save_closed_connection"]) && ($rAdminSettings["dashboard_stats"])) { ?>
							<div class="col-xl-12">
								<!-- Portlet card -->
								<div class="card">
									<div class="card-body border">
										<div class="card-widgets">
											<a href="javascript: setPeriod('week');">
												<button type="button" class="btn btn-info waves-effect waves-light btn-xs"><?=$_["week"]?></button>
											</a>
											<a href="javascript: setPeriod('day');">
												<button type="button" class="btn btn-info waves-effect waves-light btn-xs"><?=$_["day"]?></button>
											</a>
											<a href="javascript: setPeriod('hour');">
												<button type="button" class="btn btn-info waves-effect waves-light btn-xs"><?=$_["hour"]?></button>
											</a>
										</div>
										<h4 class="header-title mb-0"><?=$_["connections"]?></h4>
										<div id="statistics-collapse" class="collapse pt-3 show" dir="ltr">
											<div id="statistics" class="apex-charts"></div>
										</div> <!-- collapsed end -->
									</div> <!-- end card-bg -->
								</div> <!-- end card-->
							</div> <!-- end col-->
							<?php }
							$i = 0; foreach ($rServers as $rServer) { $i ++; if ($i == 5) { $i = 1; } ?>
							<div class="col-xl-4 col-md-6"><!-- ancien largeur col-xl-3 col-md-6"> col-->
							    <div class="card-header bg-dark text-white">
							        <?php if (hasPermissions("adv", "live_connections")) { ?>
									<div class="float-right">
								        <a href="./server.php?id=<?=$rServer["id"]?>" class="arrow-none card-drop">
                                            <i class="mdi mdi-pencil-outline"></i>
							            </a>
									    <a href="./process_monitor.php?server=<?=$rServer["id"]?>" class="arrow-none card-drop">
                                            <i class="mdi mdi-chart-line"></i>
							            </a>
                                    </div>
									<?php } ?>
									<font size="2" class="card-title mb-0 text-white mdi mdi-server"> <?=$rServer["server_name"]?> - <?=$rServer["server_ip"]?> - <span id="s_<?=$rServer["id"]?>_uptime">0d 0h</font>
								</div>
                            <div class="card-header text-white bg-white border"><p>
					            <div class="row">
                                    <div class="col-md-2 col-2">
                                        <h4 class="header-title"><?=$_["conns"]?></h4>
                                    </div>
                                    <div class="col-md-2 col-2">
                                        <a href="./live_connections.php?server_id=<?=$rServer["id"]?>"><button id="s_<?=$rServer["id"]?>_conns" type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min">0</button></a>
                                    </div>
                                    <div class="col-md-2 col-2">
                                        <h4 class="header-title"><?=$_["users"]?></h4>
                                    </div>
                                    <div class="col-md-2 col-2">
                                        <a href="./live_connections.php?server_id=<?=$rServer["id"]?>"><button id="s_<?=$rServer["id"]?>_users" type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min">0</button></a>
                                    </div>
									<div class="col-md-4 col-4">
                                        <div class="progress-w-left">
                                            <!--<h4 class="progress-value header-title mdi mdi-fan font-18"></h4>-->
                                            <div class="progress progress-lg">
                                                <div class="progress-bar " id="s_<?=$rServer["id"]?>_cpu" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                         </div>
                                    </div>
                                </div>
								<div class="row">
                                    <div class="col-md-2 col-2">
                                        <h4 class="header-title"><?=$_["streams_live"]?></h4>
                                    </div>
									<?php if (hasPermissions("adv", "live_connections")) { ?>
								    <a href="./streams.php?filter=1">
								    <?php } ?>
                                    <div class="col-md-2 col-2">
                                        <button id="s_<?=$rServer["id"]?>_online" type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min">0</button></a>
                                    </div>
						            <div class="col-md-2 col-2">
                                        <h4 class="header-title"><?=$_["streams_off"]?></h4>
                                    </div>
									<?php if (hasPermissions("adv", "live_connections")) { ?>
								    <a href="./streams.php?filter=2">
								    <?php } ?>
                                    <div class="col-md-2 col-2">
                                        <button id="s_<?=$rServer["id"]?>_offline" type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min">0</button></a>
                                    </div>
									<div class="col-md-4 col-4">
                                        <div class="progress-w-left">
                                            <!--<h4 class="progress-value header-title mdi mdi-chip font-18"></h4>-->
                                            <div class="progress progress-lg">
                                                <div class="progress-bar" id="s_<?=$rServer["id"]?>_mem" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="row">
                                    <div class="col-md-2 col-2">
							            <h4 class="header-title"><?=$_["input"]?></h4>
                                    </div>
                                    <div class="col-md-2 col-2">
							            <button id="s_<?=$rServer["id"]?>_input" type="button" class="btn btn-info btn-xs waves-effect waves-light btn-fixed-min">0</button>
                                    </div>
                                    <div class="col-md-2 col-2">
                                        <h4 class="header-title"><?=$_["output"]?></h4>
                                    </div>
                                    <div class="col-md-2 col-2">
							            <button id="s_<?=$rServer["id"]?>_output" type="button" class="btn btn-info btn-xs waves-effect waves-light btn-fixed-min">0</button>
                                    </div>
									
									<div class="col-md-4 col-4">
									    
										<?php if ($rServer["enable_duplex"] == 0) { ?>
										
                                        <div class="progress-w-left">
                                            <!--<h4 class="progress-value header-title mdi mdi-access-point-network font-18"></h4>-->
											<div class="progress progress-lg">
												<div class="progress-bar" id="s_<?=$rServer["id"]?>_net" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
										
                                        </div>
										
										<?php } else { ?>
										
										<div class="progress-w-left1">
											<div class="progress1 progress-lg">
												<div class="progress-bar" id="s_<?=$rServer["id"]?>_inet" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
											</div>	
											<div class="progress1 progress-lg">
												<div class="progress-bar" id="s_<?=$rServer["id"]?>_onet" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
											</div>												
                                        </div>
										
										<?php }	?>
										
                                     </div>
									 
                                </div>
							</div>
							<div class="card">
                            </div>
						</div><br>						
							<?php } ?><br>	
					</div>
                </div>					
				<div class="tab-pane tab-pane-server" id="server-tab">
                        <div class="row">
                            <div class="col-md-6 col-xl-3">
                                <div class="card-bg active-connections">
                                    <div class="row">
                                        <div class="col-6">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-sm bg-secondary rounded">
												<i class="fe-zap avatar-title font-22 text-white"></i>
											</div>
											<?php } else { ?>
                                            <div class="avatar-sm bg-soft-purple rounded">
                                                <i class="fe-zap avatar-title font-22 text-purple"></i>
                                            </div>
											<?php } ?>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark my-1"><span data-plugin="counterup" class="entry">0</span></h3>
                                                <p class="text-muted mb-1 text-truncate"><?=$_["open_connections"]?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <h6 class="text-uppercase"><?=$_["total_connections"]?> <span class="float-right entry-percentage">0</span></h6>
                                        <div class="progress progress-sm m-0">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
                                            <div class="progress-bar bg-secondary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } else { ?>
											<div class="progress-bar bg-purple" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } ?>
                                                <span class="sr-only">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->

                            <div class="col-md-6 col-xl-3">
                                <div class="card-bg online-users">
                                    <div class="row">
                                        <div class="col-6">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-sm bg-secondary rounded">
												<i class="fe-users avatar-title font-22 text-white"></i>
											</div>
											<?php } else { ?>
                                            <div class="avatar-sm bg-soft-success rounded">
                                                <i class="fe-users avatar-title font-22 text-success"></i>
                                            </div>
											<?php } ?>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark my-1"><span data-plugin="counterup" class="entry">0</span></h3>
                                                <p class="text-muted mb-1 text-truncate"><?=$_["online_users"]?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <h6 class="text-uppercase"><?=$_["total_active"]?> <span class="float-right entry-percentage">0</span></h6>
                                        <div class="progress progress-sm m-0">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
                                            <div class="progress-bar bg-secondary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } else { ?>
                                            <div class="progress-bar bg-success" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } ?>
                                                <span class="sr-only">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->

                            <div class="col-md-6 col-xl-3">
                                <div class="card-bg input-flow">
                                    <div class="row">
                                        <div class="col-6">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-sm bg-secondary rounded">
												<i class="fe-trending-down avatar-title font-22 text-white"></i>
											</div>
											<?php } else { ?>
                                            <div class="avatar-sm bg-soft-primary rounded">
                                                <i class="fe-trending-down avatar-title font-22 text-primary"></i>
                                            </div>
											<?php } ?>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark my-1"><span data-plugin="counterup" class="entry">0</span> <small>Mbps</small></h3>
                                                <p class="text-muted mb-1 text-truncate"><?=$_["input_flow"]?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <h6 class="text-uppercase"><?=$_["network_load"]?> <span class="float-right entry-percentage">0%</span></h6>
                                        <div class="progress progress-sm m-0">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
                                            <div class="progress-bar bg-secondary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } else { ?>
                                            <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } ?>
                                                <span class="sr-only">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->

                            <div class="col-md-6 col-xl-3">
                                <div class="card-bg output-flow">
                                    <div class="row">
                                        <div class="col-6">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-sm bg-secondary rounded">
												<i class="fe-trending-up avatar-title font-22 text-white"></i>
											</div>
											<?php } else { ?>
                                            <div class="avatar-sm bg-soft-info rounded">
                                                <i class="fe-trending-up avatar-title font-22 text-info"></i>
                                            </div>
											<?php } ?>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark my-1"><span data-plugin="counterup" class="entry">0</span> <small>Mbps</small></h3>
                                                <p class="text-muted mb-1 text-truncate"><?=$_["output_flow"]?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <h6 class="text-uppercase"><?=$_["network_load"]?> <span class="float-right entry-percentage">0%</span></h6>
                                        <div class="progress progress-sm m-0">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
                                            <div class="progress-bar bg-secondary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } else { ?>
                                            <div class="progress-bar bg-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } ?>
                                                <span class="sr-only">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->
                            
                            <div class="col-md-6 col-xl-3">
                                <div class="card-bg active-streams">
                                    <div class="row">
                                        <div class="col-6">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-sm bg-secondary rounded">
												<i class="fe-arrow-up-right avatar-title font-22 text-white"></i>
											</div>
											<?php } else { ?>
                                            <div class="avatar-sm bg-soft-purple rounded">
                                                <i class="fe-arrow-up-right avatar-title font-22 text-purple"></i>
                                            </div>
											<?php } ?>
                                        </div>
                                        <div class="col-6">
                                            <a href="javascript:void(0);" onClick="onlineStreams()">
                                            <div class="text-right">
                                                <h3 class="text-dark my-1"><span data-plugin="counterup" class="entry">0</span></h3>
                                                <p class="text-muted mb-1 text-truncate"><?=$_["online_streams"]?></p>
                                            </div>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="javascript:void(0);" onClick="offlineStreams()">
                                    <div class="mt-3">
                                        <h6 class="text-uppercase"><?=$_["offline_streams"]?> <span class="float-right entry-percentage">0</span></h6>
                                        <div class="progress progress-sm m-0">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
                                            <div class="progress-bar bg-secondary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } else { ?>
                                            <div class="progress-bar bg-purple" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } ?>
                                                <span class="sr-only">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                    </a>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->

                            <div class="col-md-6 col-xl-3">
                                <div class="card-box cpu-usage">
                                    <div class="row">
                                        <div class="col-6">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-sm bg-secondary rounded">
												<i class="fe-cpu avatar-title font-22 text-white"></i>
											</div>
											<?php } else { ?>
                                            <div class="avatar-sm bg-soft-success rounded">
                                                <i class="fe-cpu avatar-title font-22 text-success"></i>
                                            </div>
											<?php } ?>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark my-1"><span data-plugin="counterup" class="entry">0</span><small>%</small></h3>
                                                <p class="text-muted mb-1 text-truncate"><?=$_["cpu_usage"]?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <h6 class="text-uppercase">&nbsp;</h6>
                                        <div class="progress progress-sm m-0">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
                                            <div class="progress-bar bg-secondary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } else { ?>
                                            <div class="progress-bar bg-success" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } ?>
                                                <span class="sr-only">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->

                            <div class="col-md-6 col-xl-3">
                                <div class="card-box mem-usage">
                                    <div class="row">
                                        <div class="col-6">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-sm bg-secondary rounded">
												<i class="fe-terminal avatar-title font-22 text-white"></i>
											</div>
											<?php } else { ?>
                                            <div class="avatar-sm bg-soft-primary rounded">
                                                <i class="fe-terminal avatar-title font-22 text-primary"></i>
                                            </div>
											<?php } ?>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark my-1"><span data-plugin="counterup" class="entry">0</span><small>%</small></h3>
                                                <p class="text-muted mb-1 text-truncate"><?=$_["mem_usage"]?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <h6 class="text-uppercase">&nbsp;</h6>
                                        <div class="progress progress-sm m-0">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
                                            <div class="progress-bar bg-secondary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } else { ?>
                                            <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
											<?php } ?>
                                                <span class="sr-only">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->
                           
                            <div class="col-md-6 col-xl-3">
                                <div class="card-box uptime">
                                    <div class="row">
                                        <div class="col-6">
											<?php if ($rAdminSettings["dark_mode"]) { ?>
											<div class="avatar-sm bg-secondary rounded">
												<i class="fe-power avatar-title font-22 text-white"></i>
											</div>
											<?php } else { ?>
                                            <div class="avatar-sm bg-soft-info rounded">
                                                <i class="fe-power avatar-title font-22 text-info"></i>
                                            </div>
											<?php } ?>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark my-1 entry">--</h3>
                                                <p class="text-muted mb-1 text-truncate"><?=$_["system_uptime"]?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <h6 class="text-uppercase">&nbsp;</span></h6>
                                        <div class="progress-sm m-0"></div>
                                    </div>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->

                        </div>
                    </div>
                </div>	
                <!-- unicio estatisticas-->
				
		<div class="row">		
<?php if (($rPermissions["is_admin"]) && ($rAdminSettings["active_statistics"])) { ?>
<style>
.infoServ td {
padding:0px 4px 0px 4px;
}
#Statistics {
  font-family: Tahoma, Verdana, sans-serif;
  font-weight: bold;
  width: 100%;
  height: 400px;
  font-size: 11px;

}
.row2 {
    display: flex;
    overflow: hidden;

}
.col2 {
}
</style>												
		        <div class="col-xl-4">
					<div class="card">
						<div class="card-bg">
			                <div id="Statistics" class="card-header border">	
							    <font size="3" color="#000000" class="card-title mb-0"><center><?=$_["statistics"]?></center></font><br>
								<div class= separator></div><br>
								<div class="row">
									<div class="col-1">
										<div class="avatar-sm bg-pink">
											<i class="fas fa-laptop-code avatar-title font-18 text-icon"></i>
										</div>
									</div>	
									<div class="col-3">	
										<a href="mags.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp;&nbsp; <?=$_["mags"]?></b></p></span>
									</div>		
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $devicesmag; ?></span></p>
										</a>	
									</div>
									<div class="col-1">
										<div class="avatar-sm bg-pink">
											<i class="fas fa-chalkboard-teacher avatar-title font-18 text-icon"></i>
										</div>
									</div>
									<div class="col-3">	
										<a href="users.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp;&nbsp; <?=$_["users"]?></b></p></span>
									</div>
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $smarttv; ?></span></p>
										</a>	
									</div>
								</div>		
							<div class= separator></div><br>
								<div class="row">
									<div class="col-1">
										<div class="avatar-sm bg-info">
											<i class="fas fa-layer-group avatar-title font-18 text-icon"></i>
										</div>
									</div>	
									<div class="col-3">	
										<a href="bouquets.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp;&nbsp; <?=$_["bouquets"]?></b></p></span>
									</div>		
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $bouquets; ?></span></p>
										</a>	
									</div>
									<div class="col-1">
										<div class="avatar-sm bg-info">
											<i class="fas fa-list-ol avatar-title font-18 text-icon"></i>
										</div>
									</div>
									<div class="col-3">	
										<a href="streams.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp;&nbsp; <?=$_["channels"]?></b></p></span>
									</div>
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $channels; ?></span></p>
										</a>	
									</div>
								</div>		
							    <div class= separator></div><br>
								<div class="row">
									<div class="col-1">
										<div class="avatar-sm bg-warning">
											<i class="far fa-file-video avatar-title font-18 text-icon"></i>
										</div>
									</div>	
									<div class="col-3">	
										<a href="episodes.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp;&nbsp; <?=$_["episodes"]?></b></p></span>
									</div>		
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $episodes; ?></span></p>
										</a>	
									</div>
									<div class="col-1">
										<div class="avatar-sm bg-warning">
											<i class="fas fa-music avatar-title font-18 text-icon"></i>
										</div>
									</div>
									<div class="col-3">	
										<a href="radios.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp;&nbsp; <?=$_["radio"]?></b></p></span>
									</div>
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $radio; ?></span></p>
										</a>	
									</div>
								</div>			
							 <div class= separator></div><br> 
								<div class="row">
									<div class="col-1">
										<div class="avatar-sm bg-success">
											<i class="fas fa-video avatar-title font-18 text-icon"></i>
										</div>
									</div>	
									<div class="col-3">	
										<a href="movies.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp;&nbsp; <?=$_["movies"]?></b></p></span>
									</div>		
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $vod; ?></span></p>
										</a>	
									</div>
									<div class="col-1">
										<div class="avatar-sm bg-success">
											<i class="fas fa-film avatar-title font-18 text-icon"></i>
										</div>
									</div>
									<div class="col-3">	
										<a href="series.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp;&nbsp; <?=$_["series"]?></b></p></span>
									</div>
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $series; ?></span></p>
										</a>	
									</div>
								</div>
							 <div class= separator></div><br> 
								<div class="row">
									<div class="col-1">
										<div class="avatar-sm bg-danger">
											<i class="fas fa-server avatar-title font-18 text-icon"></i>
										</div>
									</div>	
									<div class="col-3">	
										<a href="servers.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp;&nbsp; <?=$_["servers"]?></b></p></span>
									</div>		
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $server; ?></span></p>
										</a>	
									</div>
									<div class="col-1">
										<div class="avatar-sm bg-danger">
											<i class="fas fa-users avatar-title font-18 text-icon"></i>
										</div>
									</div>
									<div class="col-3">	
										<a href="reg_users.php">
											<span><p class="text-muted1 mb-1 text-dark"><b>&nbsp; <?=$_["resellers"]?></b></p></span>
									</div>
									<div class="col-2">		
											<p type="button" class="btn btn-secondary btn-xs waves-effect waves-light btn-fixed-min"><span><?php echo $reseller; ?></span></p>
										</a>	
									</div>
								</div>
								<div class= separator></div>
							</div>	
                        </div>
					</div>
				</div>
<?php } ?>
<!-- fim estatisticas-->							
<?php if ($rAdminSettings["dashboard_world_map_live"]) { ?>
<style>
.infoServ td {
padding:0px 4px 0px 4px;
}
#WorldMapLive {
  color: #ffffff;
  width: 100%;
  height: 400px;
  font-size: 11px;

}
.row2 {
    display: flex;
    overflow: hidden;

}
.col2 {
}
</style>

            <div class="col-xl-4">
                <div class="card">
                    <div class="card-bg border">
						<div id="WorldMapLive"></div>
				    </div>
			    </div>
		    </div>

<?php } ?>

<?php if ($rAdminSettings["dashboard_world_map_activity"]) { ?>
<style>
.infoServ td {
padding:0px 4px 0px 4px;
}
#WorldMapActivity {
  color: #ffffff;
  width: 100%;
  height: 400px;
  font-size: 11px;

}
.row2 {
    display: flex;
    overflow: hidden;

}
.col2 {
}
</style>
            <div class="col-xl-4">
                <div class="card">
                    <div class="card-bg border">
						<div id="WorldMapActivity"></div>
					</div>
				</div>
			</div>
		</div>
  
<?php } ?>
                <!-- end row -->
				<?php } else { ?>
				<div class="alert alert-danger show text-center" role="alert" style="margin-top:20px;">
					<?=$_["dashboard_no_permissions"]?><br/>
					<?php if ($rSettings["sidebar"]) { echo $_["dashboard_nav_left"]; } else { echo $_["dashboard_nav_top"]; } ?>
				</div>
				<?php } ?>
               
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-knob/jquery.knob.min.js"></script>
        <script src="assets/libs/peity/jquery.peity.min.js"></script>
		<script src="assets/libs/apexcharts/apexcharts.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/jquery-number/jquery.number.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
		<script src="assets/js/app.min.js"></script>
		<script src="assets/js/amcharts4/ammap.js"></script>
        <script src="assets/js/amcharts4/writemap.js?5"></script>
        <script src="assets/js/amcharts4/worldLow3.js"></script>
        <script src="assets/js/amcharts4/light.js"></script>
        
        <script>
        rServerID = "home";
		rChart = null;
		rDates = null;
		rOptions = null;
        
        function offlineStreams() {
            window.location.href = "./streams.php?filter=2&server=" + window.rServerID;
        }
        
        function onlineStreams() {
            window.location.href = "./streams.php?filter=1&server=" + window.rServerID;
        }
		
        function getStats(auto=true) {
            var rStart = Date.now();
            if (window.rServerID == "home") {
                rURL = "./api.php?action=stats";
            } else {
                rURL = "./api.php?action=stats&server_id=" + window.rServerID;
            }
            $.getJSON(rURL, function(data) {
                // Open Connections
                var rCapacity = Math.ceil((data.open_connections / data.total_connections) * 100);
                if (isNaN(rCapacity)) { rCapacity = 0; }
                $(".active-connections .entry").html($.number(data.open_connections, 0));
                $(".active-connections .entry-percentage").html($.number(data.total_connections, 0));
                $(".active-connections .progress-bar").prop("aria-valuenow", rCapacity);
                $(".active-connections .progress-bar").css("width", rCapacity.toString() + "%");
                $(".active-connections .sr-only").html(rCapacity.toString() + "%");
                // Online Users
                var rCapacity = Math.ceil((data.online_users / data.total_users) * 100);
                if (isNaN(rCapacity)) { rCapacity = 0; }
                $(".online-users .entry").html($.number(data.online_users, 0));
                $(".online-users .entry-percentage").html($.number(data.total_users, 0));
                $(".online-users .progress-bar").prop("aria-valuenow", rCapacity);
                $(".online-users .progress-bar").css("width", rCapacity.toString() + "%");
                $(".online-users .sr-only").html(rCapacity.toString() + "%");
                // Network Load - Input
                var rCapacity = Math.ceil((Math.ceil(data.bytes_received) / data.network_guaranteed_speed) * 100);
                if (isNaN(rCapacity)) { rCapacity = 0; }
                $(".input-flow .entry").html($.number(Math.ceil(data.bytes_received), 0));
                $(".input-flow .entry-percentage").html(rCapacity.toString() + "%");
                $(".input-flow .progress-bar").prop("aria-valuenow", rCapacity);
                $(".input-flow .progress-bar").css("width", rCapacity.toString() + "%");
                $(".input-flow .sr-only").html(rCapacity.toString() + "%");
                // Network Load - Output
                var rCapacity = Math.ceil((Math.ceil(data.bytes_sent) / data.network_guaranteed_speed) * 100);
                if (isNaN(rCapacity)) { rCapacity = 0; }
                $(".output-flow .entry").html($.number(Math.ceil(data.bytes_sent), 0));
                $(".output-flow .entry-percentage").html(rCapacity.toString() + "%");
                $(".output-flow .progress-bar").prop("aria-valuenow", rCapacity);
                $(".output-flow .progress-bar").css("width", rCapacity.toString() + "%");
                $(".output-flow .sr-only").html(rCapacity.toString() + "%");
                // Active Streams
                var rCapacity = Math.ceil((data.total_running_streams / (data.offline_streams + data.total_running_streams)) * 100);
                if (isNaN(rCapacity)) { rCapacity = 0; }
                $(".active-streams .entry").html($.number(data.total_running_streams, 0));
                $(".active-streams .entry-percentage").html($.number(data.offline_streams, 0));
                $(".active-streams .progress-bar").prop("aria-valuenow", rCapacity);
                $(".active-streams .progress-bar").css("width", rCapacity.toString() + "%");
                $(".active-streams .sr-only").html(rCapacity.toString() + "%");
				$(".offline-streams .entry").html($.number(data.offline_streams, 0));
                // CPU Usage
                $(".cpu-usage .entry").html(data.cpu);
                $(".cpu-usage .entry-percentage").html(data.cpu.toString() + "%");
                $(".cpu-usage .progress-bar").prop("aria-valuenow", data.cpu);
                $(".cpu-usage .progress-bar").css("width", data.cpu.toString() + "%");
                $(".cpu-usage .sr-only").html(data.cpu.toString() + "%");
                // Memory Usage
                $(".mem-usage .entry").html(data.mem);
                $(".mem-usage .entry-percentage").html(data.mem.toString() + "%");
                $(".mem-usage .progress-bar").prop("aria-valuenow", data.mem);
                $(".mem-usage .progress-bar").css("width", data.mem.toString() + "%");
                $(".mem-usage .sr-only").html(data.mem.toString() + "%");
                // Uptime
				if (data.uptime) {
					$(".uptime .entry").html(data.uptime.split(" ").slice(0,2).join(" "));
				}
				// Per Server
				$(data.servers).each(function(i) {
					$("#s_" + data.servers[i].server_id + "_conns").html($.number(data.servers[i].open_connections, 0));
					$("#s_" + data.servers[i].server_id + "_users").html($.number(data.servers[i].online_users, 0));
					$("#s_" + data.servers[i].server_id + "_online").html($.number(data.servers[i].total_running_streams, 0));
					$("#s_" + data.servers[i].server_id + "_offline").html($.number(data.servers[i].offline_streams, 0));
				    $("#s_" + data.servers[i].server_id + "_input").html($.number(Math.ceil(data.servers[i].bytes_received), 0));
					$("#s_" + data.servers[i].server_id + "_output").html($.number(Math.ceil(data.servers[i].bytes_sent), 0));
					$("#s_" + data.servers[i].server_id + "_total_users").html($.number(data.servers[i].total_connections, 0));
					//cpu ans mem usage
					$("#s_" + data.servers[i].server_id + "_cpu").removeClass("bg-success").removeClass("bg-danger").removeClass("bg-warning");
					$("#s_" + data.servers[i].server_id + "_cpu").attr("aria-valuenow", data.servers[i].cpu);
                    $("#s_" + data.servers[i].server_id + "_cpu").css("width", data.servers[i].cpu + "%");
					$("#s_" + data.servers[i].server_id + "_cpu").html(data.servers[i].cpu + "% Cpu");//% Cpu
                    $("#s_" + data.servers[i].server_id + "_mem").removeClass("bg-success").removeClass("bg-danger").removeClass("bg-warning");
					$("#s_" + data.servers[i].server_id + "_mem").attr("aria-valuenow", data.servers[i].mem);
                    $("#s_" + data.servers[i].server_id + "_mem").css("width", data.servers[i].mem + "%");
					$("#s_" + data.servers[i].server_id + "_mem").html(data.servers[i].mem + "% Ram");//% Ram
					// Networks					
					var rOutput = data.servers[i].bytes_received;
					var rInput = data.servers[i].bytes_sent;
					var rSpeed = data.servers[i].network_guaranteed_speed;
					var rPourcentage = Math.round( ( ( rInput + rOutput ) / rSpeed )  * 100 );
					var rPourcentagei = Math.round( ( ( rOutput ) / rSpeed )  * 100 );
					var rPourcentageo = Math.round( ( ( rInput ) / rSpeed )  * 100 );
					//Network Usage
					$("#s_" + data.servers[i].server_id + "_net").removeClass("bg-success").removeClass("bg-danger").removeClass("bg-warning");
					$("#s_" + data.servers[i].server_id + "_net").attr('aria-valuenow', rPourcentage );
					$("#s_" + data.servers[i].server_id + "_net").css("width", rPourcentage + "%");
					$("#s_" + data.servers[i].server_id + "_net").html( rPourcentage + "<?=$_["network_usage"]?>");//% Network
					// Network Usage input
					$("#s_" + data.servers[i].server_id + "_inet").removeClass("bg-success").removeClass("bg-danger").removeClass("bg-warning");
					$("#s_" + data.servers[i].server_id + "_inet").attr('aria-valuenow', rPourcentagei );
					$("#s_" + data.servers[i].server_id + "_inet").css("width", rPourcentagei + "%");
					$("#s_" + data.servers[i].server_id + "_inet").html( rPourcentagei + "<?=$_["network_usage_input"]?>");//% Input
					//Network Usage output
					$("#s_" + data.servers[i].server_id + "_onet").removeClass("bg-success").removeClass("bg-danger").removeClass("bg-warning");
					$("#s_" + data.servers[i].server_id + "_onet").attr('aria-valuenow', rPourcentageo );
					$("#s_" + data.servers[i].server_id + "_onet").css("width", rPourcentageo + "%");
					$("#s_" + data.servers[i].server_id + "_onet").html( rPourcentageo + "<?=$_["network_usage_output"]?>");//% Output
					if (data.servers[i].uptime) {
						$("#s_" + data.servers[i].server_id + "_uptime").html(data.servers[i].uptime.split(" ").slice(0,2).join(" "));
					}
				    if (data.servers[i].cpu > 75) {
                        $("#s_" + data.servers[i].server_id + "_cpu").addClass("bg-danger");
                    } else if (data.servers[i].cpu > 50) {
                        $("#s_" + data.servers[i].server_id + "_cpu").addClass("bg-warning");
                    } else {
                        $("#s_" + data.servers[i].server_id + "_cpu").addClass("bg-success");
                    }
                    if (data.servers[i].mem > 75) {
                        $("#s_" + data.servers[i].server_id + "_mem").addClass("bg-danger");
                    } else if (data.servers[i].mem > 50) {
                        $("#s_" + data.servers[i].server_id + "_mem").addClass("bg-warning");
                    } else {
                        $("#s_" + data.servers[i].server_id + "_mem").addClass("bg-success");
                    }
					if (data.servers[i].net > 75) {
                        $("#s_" + data.servers[i].server_id + "_net").addClass("bg-danger");
                    } else if (data.servers[i].net > 50) {
                        $("#s_" + data.servers[i].server_id + "_net").addClass("bg-warning");
                    } else {
                        $("#s_" + data.servers[i].server_id + "_net").addClass("bg-info");
                    }
					if (data.servers[i].inet > 75) {
                        $("#s_" + data.servers[i].server_id + "_inet").addClass("bg-danger");
                    } else if (data.servers[i].inet > 50) {
                        $("#s_" + data.servers[i].server_id + "_inet").addClass("bg-warning");
                    } else {
                        $("#s_" + data.servers[i].server_id + "_inet").addClass("bg-info");
                    }
					if (data.servers[i].onet > 75) {
                        $("#s_" + data.servers[i].server_id + "_onet").addClass("bg-danger");
                    } else if (data.servers[i].onet > 50) {
                        $("#s_" + data.servers[i].server_id + "_onet").addClass("bg-warning");
                    } else {
                        $("#s_" + data.servers[i].server_id + "_onet").addClass("bg-info");
                    }
				});
                if (auto) {
                    if (Date.now() - rStart < 1000) {
                        setTimeout(getStats, 1000 - (Date.now() - rStart));
                    } else {
                        getStats();
                    }
                }
            }).fail(function() {
                if (auto) {
                    setTimeout(getStats, 1000);
                }
            });
        }
        
        $('.dashboard-tabs .nav-link').on('click', function (e) {
            window.rServerID = $(e.target).data("id");
            getStats(false);
            $(".nav-link").each(function() {
                $(this).removeClass("active");
            });
            $(e.target).addClass("active");
            if (window.rServerID == "home") {
                if (!$("#server-home").is(":visible")) {
                    $("#server-tab").hide();
                    $("#server-home").show();
                }
            } else {
                if (!$("#server-tab").is(":visible")) {
                    $("#server-home").hide();
                    $("#server-tab").show();
                }
            }
        });
		$('[data-plugin="peity-line"]').each(function(t, i) {
                $(this).peity("line", $(this).data());
            });
		<?php if (($rSettings["save_closed_connection"]) && ($rAdminSettings["dashboard_stats"])) { ?>
		function setPeriod(rPeriod) {
			if ((window.rDates[rPeriod][0]) && (window.rDates[rPeriod][1])) {
				window.rOptions["xaxis"]["min"] = window.rDates[rPeriod][0]*1000;
				window.rOptions["xaxis"]["max"] = window.rDates[rPeriod][1]*1000;
				window.rChart.updateOptions(window.rOptions);
				$(".apexcharts-zoom-in-icon").trigger('click');
				$(".apexcharts-zoom-out-icon").trigger('click');
			} else {
				window.rOptions["xaxis"]["min"] = undefined;
				window.rOptions["xaxis"]["max"] = undefined;
				window.rChart.updateOptions(window.rOptions);
			}
		}
        
		function getChart() {
			rURL = "./api.php?action=chart_stats";
			$.getJSON(rURL, function(rStatistics) {
				window.rDates = rStatistics["dates"];
				window.rOptions = {
					chart: {
						height: 350,
						type: "area",
						stacked: false,
						zoom: {
							type: 'x',
							enabled: true,
							autoScaleYaxis: true
						}
					},
					colors: ["#56c2d6"],
					dataLabels: {
						enabled: false
					},
					stroke: {
						width: [2],
						curve: "smooth"
					},
					series: [{
						name: "<?=$_["open_connections"]?>",
						data: rStatistics["data"]["conns"]
					}],
					fill: {
						type: "gradient", 
						gradient: {
							opacityFrom: .6,
							opacityTo: .8
						}
					},
					xaxis: {
						type: "datetime",
						min: window.rDates['day'][0]*1000,
						max: window.rDates['day'][1]*1000
					},
					tooltip: {
					  y: {
						formatter: function(value, { series, seriesIndex, dataPointIndex, w }) {
						  return parseInt(value)
						}
					  }
					}
				};
				(window.rChart = new ApexCharts(document.querySelector("#statistics"), window.rOptions)).render();
				$(".apexcharts-zoom-in-icon").trigger('click');
				$(".apexcharts-zoom-out-icon").trigger('click');
			});
		}
		<?php } ?>
        $(document).ready(function() {
            getStats();
			<?php if (($rSettings["save_closed_connection"]) && ($rAdminSettings["dashboard_stats"])) { ?>
			getChart();
			<?php } ?>
        });
        </script>
		
		<script src="assets/js/amcharts4/writemaplive.js"></script>
		<script>
		<?php if ($rAdminSettings["dashboard_world_map_live"]) { ?>
				var mapData = showMap("WorldMapLive", [<?php getWorldMapLive(); ?>], '<?=$_["live_by_country"]?>');
		<?php } ?>
        </script>

        <script src="assets/js/amcharts4/writemapactivity.js"></script>
		<script>
		<?php if ($rAdminSettings["dashboard_world_map_activity"]) { ?>
				var mapData = showMap("WorldMapActivity", [<?php getWorldMapActivity(); ?>], '<?=$_["activity_by_country"]?>');
		<?php } ?>
        </script>
    </body>
</html>
<?php
include "session.php"; include "functions.php";
if (!$rPermissions["is_admin"]) { exit; }

$_RESULT = null;
if (isset($_POST["submit_update"])) {
    set_time_limit(0);
    ini_set('mysql.connect_timeout', 0);
    ini_set('max_execution_time', 0);

    $rFile = '';
    if (!empty($_POST['m3u_url'])) {
        $rFile = file_get_contents(trim($_POST['m3u_url']));
    } else if (isset($_FILES['m3u_file']) && $_FILES['m3u_file']['error'] == UPLOAD_ERR_OK) {
        $rFile = file_get_contents($_FILES['m3u_file']['tmp_name']);
    }

    if (!empty($rFile)) {
        // Parse M3U
        preg_match_all('/(?P<tag>#EXTINF:)|(?:(?P<prop_key>[-a-z]+)=\"(?P<prop_val>[^\"]+)\")|(?<name>,[^\r\n]+)|(?<url>http[^\s]+)/', $rFile, $rMatches);
        $rResults = [];
        $rIndex = -1;
        for ($i = 0; $i < count($rMatches[0]); $i++) {
            $rItem = $rMatches[0][$i];
            if (!empty($rMatches['tag'][$i])) {
                ++$rIndex;
            } elseif (!empty($rMatches['prop_key'][$i])) {
                $rResults[$rIndex][$rMatches['prop_key'][$i]] = trim($rMatches['prop_val'][$i]);
            } elseif (!empty($rMatches['name'][$i])) {
                $rResults[$rIndex]['name'] = trim(substr($rItem, 1));
            } elseif (!empty($rMatches['url'][$i])) {
                $rResults[$rIndex]['url'] = trim($rItem);
            }
        }

        $rStats = array("total" => count($rResults), "updated" => 0, "inserted" => 0, "skipped" => 0, "errors" => 0);
        $rUpdateMode = isset($_POST["update_mode"]) ? $_POST["update_mode"] : "smart";
        $rServerID = isset($_POST["servers"]) ? intval($_POST["servers"]) : 1;
        $rTargetType = isset($_POST["target_type"]) ? intval($_POST["target_type"]) : 0; // 0=auto, 1=live, 2=movies, 5=series

        foreach ($rResults as $rResult) {
            if (empty($rResult['name']) || empty($rResult['url'])) {
                $rStats["skipped"]++;
                continue;
            }

            // Determine stream type
            $rType = $rTargetType;
            if ($rType == 0) {
                $rGroup=strtolower(isset($rResult['group-title'])?$rResult['group-title']:'');
                $rName=strtolower($rResult['name']);
                $rUrl=strtolower($rResult['url']);
                if (strpos($rUrl,'/series/')!==false || preg_match('/s\d{1,2}e\d{1,3}/i',$rName) || strpos($rGroup,'series')!==false || strpos($rGroup,'séries')!==false || strpos($rGroup,'temporada')!==false){
                    $rType=5;
                } elseif (strpos($rUrl,'/movie/')!==false || preg_match('/\.(mp4|mkv|avi|mov|flv|wmv|mpeg|mpg)$/i',$rUrl) || strpos($rGroup,'movie')!==false || strpos($rGroup,'filme')!==false || strpos($rGroup,'cinema')!==false){
                    $rType=2;
                } else {
                    $rType=1;
                }
            }

            $rStreamName = trim($rResult['name']);
            $rStreamURL = trim($rResult['url']);
            $rIcon = isset($rResult['tvg-logo']) ? $rResult['tvg-logo'] : '';
            $rCategory = isset($rResult['group-title']) ? $rResult['group-title'] : '';

            // Check for existing stream by name similarity
            $rEscapedName = $db->real_escape_string($rStreamName);
            $rExisting = null;

            if ($rUpdateMode == "name" || $rUpdateMode == "smart") {
                // Search by exact name match first
                $result = $db->query("SELECT * FROM `streams` WHERE `stream_display_name` = '" . $rEscapedName . "' AND `type` = " . intval($rType) . " LIMIT 1;");
                if ($result && $result->num_rows > 0) {
                    $rExisting = $result->fetch_assoc();
                }
            }

            // If not found by name, try URL match
            if (!$rExisting && ($rUpdateMode == "url" || $rUpdateMode == "smart")) {
                $rEscapedURL = $db->real_escape_string($rStreamURL);
                $result = $db->query("SELECT `id` FROM `streams` WHERE `stream_source` LIKE '%\"$rEscapedURL\"%' AND `type` = " . intval($rType) . " LIMIT 1;");
                if ($result && $result->num_rows > 0) {
                    $rRow = $result->fetch_assoc();
                    $result = $db->query("SELECT * FROM `streams` WHERE `id` = " . intval($rRow["id"]) . " LIMIT 1;");
                    if ($result && $result->num_rows > 0) {
                        $rExisting = $result->fetch_assoc();
                    }
                }
            }

            if ($rExisting) {
                // UPDATE existing stream
                $rUpdateURL = json_encode(array($rStreamURL));
                $rProperties = json_encode(array(
                    "movie_image" => $rIcon,
                    "backdrop_path" => array(),
                    "youtube_trailer" => "",
                    "genre" => $rCategory,
                    "plot" => "",
                    "cast" => "",
                    "rating" => "",
                    "director" => "",
                    "releasedate" => "",
                    "tmdb_id" => ""
                ));

                $rQuery = "UPDATE `streams` SET 
                    `stream_display_name` = '" . $rEscapedName . "',
                    `stream_source` = '" . $db->real_escape_string($rUpdateURL) . "',
                    `stream_icon` = '" . $db->real_escape_string($rIcon) . "',
                    `movie_propeties` = '" . $db->real_escape_string($rProperties) . "'";

                // Update category if provided and exists
                if (!empty($rCategory)) {
                    $rCatEscaped = $db->real_escape_string($rCategory);
                    $catResult = $db->query("SELECT `id` FROM `stream_categories` WHERE `category_name` = '" . $rCatEscaped . "' AND `category_type` = " . intval($rType) . " LIMIT 1;");
                    if ($catResult && $catResult->num_rows > 0) {
                        $rCatRow = $catResult->fetch_assoc();
                        $rQuery .= ", `category_id` = " . intval($rCatRow["id"]);
                    }
                }

                $rQuery .= " WHERE `id` = " . intval($rExisting["id"]) . ";";

                if ($db->query($rQuery)) {
                    // Update streams_sys if server assignment changed
                    $sysResult = $db->query("SELECT `id` FROM `streams_sys` WHERE `stream_id` = " . intval($rExisting["id"]) . " LIMIT 1;");
                    if ($sysResult && $sysResult->num_rows > 0) {
                        $db->query("UPDATE `streams_sys` SET `server_id` = " . intval($rServerID) . " WHERE `stream_id` = " . intval($rExisting["id"]) . ";");
                    } else {
                        $db->query("INSERT INTO `streams_sys` (`stream_id`, `server_id`, `parent_id`, `pid`, `to_analyze`, `stream_status`, `stream_started`, `stream_info`, `monitor_pid`, `current_source`, `bitrate`, `progress_info`, `on_demand`, `delay_pid`, `delay_available_at`) VALUES (" . intval($rExisting["id"]) . ", " . intval($rServerID) . ", NULL, NULL, 0, 0, NULL, '', NULL, NULL, '', '', 0, NULL, NULL);");
                    }

                    // Update bouquets if configured
                    if (!empty($rCategory)) {
                        $rCatEscaped = $db->real_escape_string($rCategory);
                        $bouquetResult = $db->query("SELECT `id` FROM `bouquets` WHERE `bouquet_name` LIKE '%" . $rCatEscaped . "%' LIMIT 1;");
                        if ($bouquetResult && $bouquetResult->num_rows > 0) {
                            $rBouquet = $bouquetResult->fetch_assoc();
                            // Ensure stream is in bouquet
                            $rBouquetStreams = json_decode($rBouquet["bouquet_channels"], true);
                            if (!is_array($rBouquetStreams)) { $rBouquetStreams = array(); }
                            $rStreamTypeID = intval($rExisting["id"]) + ($rType * 100000);
                            if (!in_array($rStreamTypeID, $rBouquetStreams)) {
                                $rBouquetStreams[] = $rStreamTypeID;
                                $db->query("UPDATE `bouquets` SET `bouquet_channels` = '" . $db->real_escape_string(json_encode($rBouquetStreams)) . "' WHERE `id` = " . intval($rBouquet["id"]) . ";");
                            }
                        }
                    }

                    $rStats["updated"]++;
                } else {
                    $rStats["errors"]++;
                }
            } else {
                // INSERT new stream (no duplicate found)
                $rCategoryID = null;
                if (!empty($rCategory)) {
                    $rCatEscaped = $db->real_escape_string($rCategory);
                    // Check if category exists
                    $catResult = $db->query("SELECT `id` FROM `stream_categories` WHERE `category_name` = '" . $rCatEscaped . "' AND `category_type` = " . intval($rType) . " LIMIT 1;");
                    if ($catResult && $catResult->num_rows > 0) {
                        $rCatRow = $catResult->fetch_assoc();
                        $rCategoryID = intval($rCatRow["id"]);
                    } else {
                        // Create new category
                        $db->query("INSERT INTO `stream_categories` (`category_name`, `category_type`) VALUES ('" . $rCatEscaped . "', " . intval($rType) . ");");
                        $rCategoryID = $db->insert_id;
                    }
                }

                $rSource = json_encode(array($rStreamURL));
                $rProperties = json_encode(array(
                    "movie_image" => $rIcon,
                    "backdrop_path" => array(),
                    "youtube_trailer" => "",
                    "genre" => $rCategory,
                    "plot" => "",
                    "cast" => "",
                    "rating" => "",
                    "director" => "",
                    "releasedate" => "",
                    "tmdb_id" => ""
                ));

                $rQuery = "INSERT INTO `streams` (`type`, `category_id`, `stream_display_name`, `stream_source`, `stream_icon`, `notes`, `created_channel_location`, `enable_transcode`, `transcode_attributes`, `custom_ffmpeg`, `movie_propeties`, `movie_subtitles`, `read_native`, `target_container`, `stream_all`, `remove_subtitles`, `custom_sid`, `epg_id`, `channel_id`, `epg_lang`, `order`, `auto_restart`, `transcode_profile_id`, `pids_create_channel`, `cchannel_rsources`, `gen_timestamps`, `added`, `series_no`, `direct_source`, `tv_archive_duration`, `tv_archive_server_id`, `tv_archive_pid`, `movie_symlink`, `redirect_stream`, `rtmp_output`, `number`, `allow_record`, `probesize_ondemand`, `custom_map`, `external_push`, `delay_minutes`) VALUES (" . intval($rType) . ", " . ($rCategoryID ? intval($rCategoryID) : "NULL") . ", '" . $rEscapedName . "', '" . $db->real_escape_string($rSource) . "', '" . $db->real_escape_string($rIcon) . "', '', NULL, 0, '[]', '', '" . $db->real_escape_string($rProperties) . "', '', 0, '[\"mp4\"]', 0, 0, NULL, NULL, NULL, NULL, 0, '', 0, '', '', 1, " . time() . ", 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 128000, '', '', 0);";

                if ($db->query($rQuery)) {
                    $rNewID = $db->insert_id;
                    $db->query("INSERT INTO `streams_sys` (`stream_id`, `server_id`, `parent_id`, `pid`, `to_analyze`, `stream_status`, `stream_started`, `stream_info`, `monitor_pid`, `current_source`, `bitrate`, `progress_info`, `on_demand`, `delay_pid`, `delay_available_at`) VALUES (" . intval($rNewID) . ", " . intval($rServerID) . ", NULL, NULL, 0, 0, NULL, '', NULL, NULL, '', '', 0, NULL, NULL);");

                    // Add to bouquet if category exists
                    if (!empty($rCategory)) {
                        $rCatEscaped = $db->real_escape_string($rCategory);
                        $bouquetResult = $db->query("SELECT `id` FROM `bouquets` WHERE `bouquet_name` LIKE '%" . $rCatEscaped . "%' LIMIT 1;");
                        if ($bouquetResult && $bouquetResult->num_rows > 0) {
                            $rBouquet = $bouquetResult->fetch_assoc();
                            $rBouquetStreams = json_decode($rBouquet["bouquet_channels"], true);
                            if (!is_array($rBouquetStreams)) { $rBouquetStreams = array(); }
                            $rStreamTypeID = $rNewID + ($rType * 100000);
                            if (!in_array($rStreamTypeID, $rBouquetStreams)) {
                                $rBouquetStreams[] = $rStreamTypeID;
                                $db->query("UPDATE `bouquets` SET `bouquet_channels` = '" . $db->real_escape_string(json_encode($rBouquetStreams)) . "' WHERE `id` = " . intval($rBouquet["id"]) . ";");
                            }
                        }
                    }

                    $rStats["inserted"]++;
                } else {
                    $rStats["errors"]++;
                }
            }
        }

        $_RESULT = $rStats;
    } else {
        $_RESULT = array("error" => "Falha ao carregar o arquivo M3U. Verifique a URL ou selecione um arquivo válido.");
    }
}

$rCategories = Array(0 => Array("category_name" => "Select Type"), 1 => Array("category_name" => "Live TV"), 2 => Array("category_name" => "Movies"), 5 => Array("category_name" => "Series"));
$rServers = getServers();

if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
 if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content boxed-layout-ext"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper boxed-layout-ext"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li><a href="./dashboard.php"><button type="button" class="btn btn-primary waves-effect waves-light btn-sm"><i class="mdi mdi-keyboard-backspace"></i> Back</button></a></li>
                                </ol>
                            </div>
                            <h4 class="page-title">M3U Update (No Duplicates)</h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
                <div class="row">
                    <div class="col-xl-12">
                        <?php if (isset($_RESULT) && !isset($_RESULT["error"])) { ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <strong>Update Complete!</strong><br>
                            Total: <?=$_RESULT["total"]?> | Updated: <?=$_RESULT["updated"]?> | Inserted: <?=$_RESULT["inserted"]?> | Skipped: <?=$_RESULT["skipped"]?> | Errors: <?=$_RESULT["errors"]?>
                        </div>
                        <?php } else if (isset($_RESULT) && isset($_RESULT["error"])) { ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?=htmlspecialchars($_RESULT["error"])?>
                        </div>
                        <?php } ?>
                        <div class="card">
                            <div class="card-body">
                                <form action="./m3u_update_nodup.php" method="POST" id="update_form" enctype="multipart/form-data">
                                    <div class="form-group row mb-4">
                                        <label class="col-md-3 col-form-label">Update Mode</label>
                                        <div class="col-md-9">
                                            <select name="update_mode" id="update_mode" class="form-control" data-toggle="select2">
                                                <option value="smart">Smart (Name + URL Match)</option>
                                                <option value="name">Name Only</option>
                                                <option value="url">URL Only</option>
                                            </select>
                                            <small class="text-muted">Smart mode checks both name and URL to find existing streams. Falls back to the other method if no match is found.</small>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label class="col-md-3 col-form-label">Content Type</label>
                                        <div class="col-md-9">
                                            <select name="target_type" id="target_type" class="form-control" data-toggle="select2">
                                                <option value="0">Auto-Detect (Smart)</option>
                                                <option value="1">Live TV</option>
                                                <option value="2">Movies (VOD)</option>
                                                <option value="5">Series Episodes</option>
                                            </select>
                                            <small class="text-muted">If set to Auto-Detect, the system will determine the type based on the URL extension.</small>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label class="col-md-3 col-form-label">Server</label>
                                        <div class="col-md-9">
                                            <select name="servers" id="servers" class="form-control" data-toggle="select2">
                                                <?php foreach ($rServers as $rServerID => $rServer) { ?>
                                                <option value="<?=$rServer["server_id"]?>"><?=$rServer["server_name"]?> (<?=$rServer["server_ip"]?>)</option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label class="col-md-3 col-form-label">M3U File</label>
                                        <div class="col-md-9">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="m3u_file" name="m3u_file" accept=".m3u,.m3u8,.txt">
                                                <label class="custom-file-label" for="m3u_file">Choose file...</label>
                                            </div>
                                            <small class="text-muted">Upload an M3U file from your computer.</small>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label class="col-md-3 col-form-label">M3U URL</label>
                                        <div class="col-md-9">
                                            <input type="url" class="form-control" id="m3u_url" name="m3u_url" placeholder="https://example.com/playlist.m3u">
                                            <small class="text-muted">Or provide a URL to an M3U playlist.</small>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-4">
                                        <label class="col-md-3 col-form-label">Options</label>
                                        <div class="col-md-9">
                                            <div class="custom-control custom-checkbox mb-2">
                                                <input type="checkbox" class="custom-control-input" id="create_categories" name="create_categories" checked>
                                                <label class="custom-control-label" for="create_categories">Auto-create missing categories</label>
                                            </div>
                                            <div class="custom-control custom-checkbox mb-2">
                                                <input type="checkbox" class="custom-control-input" id="assign_bouquets" name="assign_bouquets" checked>
                                                <label class="custom-control-label" for="assign_bouquets">Auto-assign to matching bouquets</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <button type="submit" name="submit_update" class="btn btn-primary waves-effect waves-light">
                                                <i class="mdi mdi-sync"></i> Start Update (No Duplicates)
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- How it works section -->
                        <div class="card mt-4">
                            <div class="card-body">
                                <h5 class="card-title"><i class="mdi mdi-information-outline"></i> How It Works</h5>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="text-center mb-3">
                                            <i class="mdi mdi-magnify" style="font-size: 48px; color: #039cfd;"></i>
                                            <h6>1. Detection</h6>
                                            <p class="text-muted small">Scans the M3U file and compares each entry against existing streams in the database by name and URL.</p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="text-center mb-3">
                                            <i class="mdi mdi-pencil" style="font-size: 48px; color: #039cfd;"></i>
                                            <h6>2. Update</h6>
                                            <p class="text-muted small">If a matching stream is found, it updates the name, URL, icon, and properties without creating a duplicate.</p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="text-center mb-3">
                                            <i class="mdi mdi-plus-circle" style="font-size: 48px; color: #039cfd;"></i>
                                            <h6>3. Insert</h6>
                                            <p class="text-muted small">New streams that don't match any existing entry are added. Categories and bouquets are auto-created.</p>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <h6><i class="mdi mdi-shield-check"></i> Duplicate Prevention</h6>
                                <p class="text-muted mb-0">
                                    The system prevents duplicates using multiple strategies: exact name match within the same content type, URL match within the stream sources, and intelligent grouping. 
                                    Each stream is only updated or inserted once per import cycle.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
        // Custom file label
        $('.custom-file-input').on('change', function() {
            var fileName = $(this).val().split('\\').pop();
            $(this).next('.custom-file-label').addClass("selected").html(fileName);
        });
        </script>
    </body>
</html>

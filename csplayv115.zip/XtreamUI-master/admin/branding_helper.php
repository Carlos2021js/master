<?php
/** CS Player - identidade visual e mídia, independente do banco. */
if (!function_exists('cs_branding_config')) {
    function cs_branding_config() {
        static $config = null;
        if ($config !== null) return $config;
        $file = __DIR__ . '/assets/uploads/branding/branding.json';
        $config = [];
        if (is_file($file)) {
            $decoded = json_decode((string) @file_get_contents($file), true);
            if (is_array($decoded)) $config = $decoded;
        }
        return $config;
    }
    function cs_branding_value($key, $fallback = null) {
        $c = cs_branding_config();
        return array_key_exists($key, $c) ? $c[$key] : $fallback;
    }
    function cs_branding_safe_color($value, $fallback) {
        $value = trim((string)$value);
        return preg_match('/^#[0-9a-fA-F]{6}$/', $value) ? strtoupper($value) : $fallback;
    }
    function cs_branding_icon_catalog() {
        return [
            'dashboard' => ['fe-activity', 'mdi mdi-view-dashboard-outline', 'fas fa-chart-line', 'fas fa-gauge-high'],
            'servers' => ['fas fa-server', 'mdi mdi-server-network', 'fas fa-database', 'fas fa-network-wired'],
            'management' => ['fas fa-cog', 'mdi mdi-cog-outline', 'fas fa-sliders-h', 'mdi mdi-tune-variant'],
            'resellers' => ['fas fa-users', 'mdi mdi-account-group-outline', 'fas fa-user-tie', 'mdi mdi-account-multiple-plus'],
            'users' => ['fas fa-desktop', 'mdi mdi-account-outline', 'fas fa-user-circle', 'mdi mdi-account-multiple-outline'],
            'content' => ['fas fa-play', 'mdi mdi-play-box-outline', 'fas fa-photo-video', 'mdi mdi-movie-open-outline'],
            'bouquets' => ['fas fa-spa', 'mdi mdi-flower-tulip-outline', 'fas fa-layer-group', 'mdi mdi-layers-outline'],
            'iptv_apps' => ['fas fa-qrcode', 'mdi mdi-apps', 'fas fa-th-large', 'mdi mdi-application-outline'],
        ];
    }
    function cs_branding_theme_css() {
        $defaults = [
            'header_start' => '#111827', 'header_end' => '#2563EB', 'sidebar_bg' => '#FFFFFF',
            'menu_surface' => '#FFFFFF', 'menu_active' => '#EFF6FF', 'menu_text' => '#475467',
            'menu_text_active' => '#2563EB', 'page_bg' => '#F4F7FB'
        ];
        $colors = [];
        foreach ($defaults as $key => $fallback) $colors[$key] = cs_branding_safe_color(cs_branding_value('theme_'.$key, $fallback), $fallback);
        $catalog = cs_branding_icon_catalog();
        $icons = [];
        foreach ($catalog as $key => $choices) {
            $candidate = (string)cs_branding_value('menu_icon_'.$key, $choices[0]);
            $icons[$key] = in_array($candidate, $choices, true) ? $candidate : $choices[0];
        }
        $css = '<style id="cs-branding-theme">:root{--cs-brand-header-start:'.$colors['header_start'].';--cs-brand-header-end:'.$colors['header_end'].';--cs-brand-sidebar-bg:'.$colors['sidebar_bg'].';--cs-brand-menu-surface:'.$colors['menu_surface'].';--cs-brand-menu-active:'.$colors['menu_active'].';--cs-brand-menu-text:'.$colors['menu_text'].';--cs-brand-menu-text-active:'.$colors['menu_text_active'].';--cs-brand-page-bg:'.$colors['page_bg'].'}';
        $css .= 'body{background-color:var(--cs-brand-page-bg)!important}#topnav,#topnav .navbar-custom,body>.navbar-custom,#wrapper>.navbar-custom,.footer,.csplayer-shared-footer{background-image:linear-gradient(135deg,var(--cs-brand-header-start),var(--cs-brand-header-end))!important;background-color:var(--cs-brand-header-start)!important;color:#fff!important}#topnav .topbar-menu{background:var(--cs-brand-header-start)!important}.left-side-menu,#sidebar-menu{background:var(--cs-brand-sidebar-bg)!important}#navigation{background:var(--cs-brand-menu-surface)!important}#topnav .navigation-menu>li>a{color:var(--cs-brand-menu-text)!important}#topnav .navigation-menu>li>a:hover,#topnav .navigation-menu>li>a:focus-visible,#topnav .navigation-menu>li.active>a{color:var(--cs-brand-menu-text-active)!important;background:var(--cs-brand-menu-active)!important}#topnav .navigation-menu .submenu{background:var(--cs-brand-menu-surface)!important}#topnav .navigation-menu .submenu li a{color:var(--cs-brand-menu-text)!important}#topnav .navigation-menu .submenu li a:hover,#topnav .navigation-menu .submenu li a:focus-visible{color:var(--cs-brand-menu-text-active)!important;background:var(--cs-brand-menu-active)!important}#sidebar-menu>ul>li>a{color:var(--cs-brand-menu-text)!important}#sidebar-menu>ul>li>a:hover,#sidebar-menu>ul>li>a:focus-visible,#sidebar-menu>ul>li>a.open,#sidebar-menu>ul>li>a.active{color:var(--cs-brand-menu-text-active)!important;background:var(--cs-brand-menu-active)!important}#sidebar-menu .nav-second-level,#sidebar-menu .nav-third-level{background:color-mix(in srgb,var(--cs-brand-menu-active) 34%,var(--cs-brand-menu-surface))!important}.topnav-menu>li>.nav-link,.topnav-menu>li>.navbar-toggle,.topnav-menu-left>li>.button-menu-mobile{background:color-mix(in srgb,var(--cs-brand-header-end) 34%,transparent)!important}.footer a,.footer .copyright,.csplayer-shared-footer a,.csplayer-shared-footer .copyright{color:#fff!important}.footer .container-fluid,.csplayer-shared-footer .container-fluid{background:transparent!important}';
        $css .= '</style>';
        $payload = json_encode($icons, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $css .= '<script>(function(){var icons='.$payload.';function apply(){document.querySelectorAll("[data-menu-key]").forEach(function(el){var key=el.getAttribute("data-menu-key"),icon=icons[key];if(icon){el.className=icon+" cs-custom-menu-icon";}});}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",apply);}else{apply();}}());</script>';
        return $css;
    }
    function cs_branding_asset($slot, $fallback = '') {
        $config = cs_branding_config();
        if (!empty($config[$slot]) && is_string($config[$slot])) {
            $relative = ltrim(str_replace(['..', '\\'], ['', '/'], $config[$slot]), '/');
            if (is_file(__DIR__ . '/' . $relative)) return $relative . '?v=' . @filemtime(__DIR__ . '/' . $relative);
        }
        return $fallback;
    }
    function cs_branding_avatar_html($username, $size = 28) {
        $src = cs_branding_asset('admin_avatar', '');
        if ($src !== '') return '<img src="'.htmlspecialchars($src,ENT_QUOTES,'UTF-8').'" alt="Admin" style="width:'.(int)$size.'px;height:'.(int)$size.'px;border-radius:50%;object-fit:cover;margin-right:8px;vertical-align:middle">';
        return '<i class="fas fa-user-alt"></i>';
    }
    function cs_branding_background_media($context) {
        $video = cs_branding_asset($context.'_video', '');
        $fallbacks = ['login' => 'assets/images/bg1.png', 'dashboard' => 'assets/images/bgpro.png'];
        $image = cs_branding_asset($context.'_background', $fallbacks[$context] ?? '');
        $opacity = max(0, min(100, (int)cs_branding_value($context.'_overlay', 35))) / 100;
        $muted = cs_branding_value($context.'_muted', true) ? ' muted' : '';
        $loop = cs_branding_value($context.'_loop', true) ? ' loop' : '';
        $autoplay = cs_branding_value($context.'_autoplay', true) ? ' autoplay' : '';
        $controls = cs_branding_value($context.'_controls', false) ? ' controls' : '';
        $videoType = strtolower(pathinfo(parse_url($video, PHP_URL_PATH) ?: $video, PATHINFO_EXTENSION)) === 'webm' ? 'video/webm' : 'video/mp4';
        $html = '<div class="cs-media-bg" aria-hidden="true">';
        if ($video) $html .= '<video id="cs-'.$context.'-video" playsinline preload="metadata"'.$autoplay.$loop.$muted.$controls.' poster="'.htmlspecialchars($image,ENT_QUOTES,'UTF-8').'"><source src="'.htmlspecialchars($video,ENT_QUOTES,'UTF-8').'" type="'.$videoType.'"></video>';
        elseif ($image) $html .= '<div class="cs-media-image" style="background-image:url(\''.htmlspecialchars($image,ENT_QUOTES,'UTF-8').'\')"></div>';
        $html .= '<div class="cs-media-overlay" style="background:rgba(5,10,20,'.$opacity.')"></div></div>';
        if ($video && !$muted) $html .= '<button type="button" class="cs-media-sound" onclick="csToggleMediaSound(\''.$context.'\')" title="Ativar/desativar áudio"><i class="mdi mdi-volume-high"></i></button>';
        return $html;
    }
    function cs_branding_media_css() {
        $banner = cs_branding_asset('banner_main', '');
        $css = '<style>.cs-media-bg{position:fixed;inset:0;z-index:0;overflow:hidden;background:#07101d;pointer-events:none}.account-pages,.cs-dashboard-surface,.navbar-custom,.left-side-menu,.topnav,.footer{position:relative;z-index:1}.cs-media-bg video,.cs-media-bg .cs-media-image{width:100%;height:100%;object-fit:cover;background-size:cover;background-position:center}.cs-media-bg .cs-media-overlay{position:absolute;inset:0}.cs-media-sound{position:fixed;right:18px;bottom:18px;z-index:1050;width:44px;height:44px;border:0;border-radius:50%;background:rgba(0,0,0,.62);color:#fff;font-size:21px;box-shadow:0 8px 25px rgba(0,0,0,.28)}.cs-dashboard-surface{position:relative;z-index:1}.cs-dashboard-transparent .card,.cs-dashboard-transparent .card-box{backdrop-filter:blur(8px);background-color:rgba(255,255,255,.88)!important}';
        if ($banner) {
            $css .= '#topnav .navbar-custom{background-image:linear-gradient(90deg,rgba(10,20,38,.78),rgba(37,99,235,.62)),url("'.htmlspecialchars($banner,ENT_QUOTES,'UTF-8').'")!important;background-size:cover;background-position:center}#topnav .nav-user{background-image:none!important}';
        }
        $css .= '</style><script>function csToggleMediaSound(c){var v=document.getElementById("cs-"+c+"-video");if(!v)return;v.muted=!v.muted;if(v.paused)v.play().catch(function(){});}document.addEventListener("click",function(){document.querySelectorAll(".cs-media-bg video[autoplay]").forEach(function(v){if(v.paused)v.play().catch(function(){});});},{once:true});</script>';
        return $css;
    }
}

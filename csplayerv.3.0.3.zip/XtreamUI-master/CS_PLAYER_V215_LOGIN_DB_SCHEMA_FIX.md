# CS PLAYER 2.0.15 build 215 — Login / MariaDB / Schema

Correção baseada no banco `xtream_iptvpro` fornecido.

- `login_flood`: id, username, ip, dateadded — usado sem alteração de schema.
- `reg_users`: username, password, email, member_group_id, status e google_2fa_sec — login por usuário/e-mail compatível.
- `member_groups`: group_id, is_admin, is_reseller, is_banned — permissões preservadas.
- conexão configurada permanece prioritária; fallback local somente quando aplicável.
- falha temporária do MariaDB retorna 503 controlado em vez de fatal PHP.
- `prepare()`, `bind_param()`, `execute()` e consultas de `login_flood` não são mais encadeadas sem validação.
- nenhum CREATE/ALTER/DROP é executado por esta atualização.
- banco de dados não é modificado.

# CS PLAYER 2.0.14 build 214

Correção direcionada ao erro de login observado em produção:
- `mysqli (HY000/2002) Connection refused` em `admin/functions.php`;
- `Call to a member function bind_param() on bool` em `admin/login.php`.

Melhorias:
- preserva host/porta configurados como primeira tentativa;
- fallback local seguro para 3306/IPv4/socket quando a configuração aponta para banco local;
- não altera banco, tabelas ou credenciais;
- falha de conexão gera HTTP 503 e mensagem controlada, sem fatal de PHP;
- `prepare()/bind_param()/execute()` do controle de flood são validados;
- falha da tabela auxiliar `login_flood` não derruba o login;
- mantém integralmente correções dos dois menus e Web Player 2.0.13.

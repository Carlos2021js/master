<?php
require __DIR__ . '/bootstrap.php';
$cfg = cs_player_load_config();
if (empty($cfg['enabled'])) { http_response_code(503); exit('Web Player temporariamente indisponível.'); }
if (!empty($_SESSION['cs_player_auth'])) { header('Location: home.php'); exit; }
$error = $_SESSION['cs_player_error'] ?? '';
unset($_SESSION['cs_player_error']);
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#08090c"><title><?=htmlspecialchars($cfg['brand'])?> · Web Player</title><link rel="stylesheet" href="assets/player.css"></head>
<body class="login-page"><div class="login-backdrop"></div><header class="login-header"><div class="brand-mark">CS</div><div class="brand-name"><?=htmlspecialchars($cfg['brand'])?></div></header>
<main class="login-shell"><section class="login-card"><span class="eyebrow">WEB PLAYER</span><h1><?=htmlspecialchars($cfg['login_title'])?></h1><p><?=htmlspecialchars($cfg['login_subtitle'])?></p>
<?php if ($error): ?><div class="alert error"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="post" action="auth.php" autocomplete="on"><label>Usuário<input name="username" required autocomplete="username" placeholder="Seu usuário"></label><label>Senha<div class="password-wrap"><input id="password" type="password" name="password" required autocomplete="current-password" placeholder="Sua senha"><button type="button" class="ghost-icon" onclick="togglePass()" aria-label="Mostrar senha">Ver</button></div></label><button class="primary-btn" type="submit"><span>Entrar</span><small>detecção inteligente de DNS</small></button></form>
<div class="login-features"><span>✓ Multi-DNS</span><span>✓ Reconexão</span><span>✓ PiP</span></div></section></main>
<script>function togglePass(){const i=document.getElementById('password');i.type=i.type==='password'?'text':'password';}</script></body></html>

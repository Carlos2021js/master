# CS PLAYER — Inventário de arquivos legados e compatibilidade

## Escopo

O inventário foi feito sobre a cópia extraída do ZIP original. A comparação de listas mostrou **1.090 arquivos no original e 1.090 arquivos na cópia final**, sem arquivos removidos. Os arquivos a seguir continuam presentes porque podem ser usados por instalações, importadores, rotinas administrativas ou integrações existentes.

| Arquivo ou grupo | Papel preservado | Ajuste de compatibilidade |
|---|---|---|
| `admin/player/bootstrap.php` | Inicialização, configuração, autenticação, catálogo e helpers do Web Player | Tornou-se o ponto de entrada da configuração e do resolvedor de delivery |
| `admin/player/http_transport.php` | Transporte HTTP | Concentra requests individuais e batch; TLS verificável por padrão |
| `admin/player/json_dns_compat.php` | Compatibilidade com configuração JSON DNS | Mantém funções antigas e espelho, sem reinjetar DNS built-in |
| `admin/player/legacy_compat.php` | Motor e contratos de autenticação legados | Mantém funções e delega o request HTTP ao transporte central |
| `admin/player/dns_health.php` | Saúde, falhas, latência e cooldown de DNS | Mantido como módulo separado e consumido pela lista oficial |
| `admin/player/proxy_lib.php` | Proxy de mídia e manifests | Mantém proxy especializado para streams contínuos; TLS passa a ser controlável |
| `admin/player/stream.php` | Endpoint de entrega Direct/Proxy/HLS/TS/VOD | Usa resolvedor único sem retirar caminhos de entrega |
| `admin/player/live_stream.php` | Wrapper Live | Mantém `live_prefer_ts` e delega delivery ao endpoint comum |
| `admin/player/vod_stream.php` | Wrapper VOD | Mantém MKV/remux e delega delivery ao endpoint comum |
| `admin/player/api.php` | Catálogo, categorias, EPG, TMDB e failover | EPG e fontes externas foram alinhados ao transporte central |
| `admin/player/tmdb_service.php` | Busca e enriquecimento TMDB | Mantém cache, imagens e trailers; request usa transporte central |
| `admin/player/settings.php` | Interface administrativa | Mantém todos os campos, com correções de diagnóstico e preservação de estado |
| `admin/player/assets/player.js` | Player do navegador | Mantém fallback Direct→Proxy e envia somente overrides explícitos |
| `admin/player_admin_api.php` | API administrativa | Parte da configuração persistida e normaliza booleanos |
| `wwwdir/cs_stream.php` | Gateway público de streaming | Mantém HLS, Range e streaming contínuo; TLS configurável |
| `admin/cs_player.php` | Camada de compatibilidade do painel legado | Não removida; suas funções de log são protegidas por ordem de inclusão |
| `admin/functions.php` | Funções gerais e integrações do painel | Não alterado nesta auditoria, inclusive contratos não relacionados ao Web Player |
| `admin/m3u_update_nodup.php` e `admin/m3u_update_nodup1.php` | Importadores M3U independentes | Não fundidos nem removidos |
| `admin/movie.php` e `admin/stream.php` | Importadores/cadastros administrativos | Mantidos para preservar os fluxos do painel |
| `admin/logs/cs-player/web-player-dns.json` | Espelho de integração JSON | Continua sendo gerado a partir da configuração oficial |
| `admin/player/storage/*` | Arquivos históricos de persistência | Preservados, mas não vencem a fonte oficial por data |

## Arquivos adicionados

Foram adicionados somente relatórios de auditoria no diretório raiz do projeto: a matriz de configuração, a auditoria de duplicidades, o mapa de configurações legadas, o mapa de rotas, a auditoria HTTP e este conjunto de documentação. O arquivo SQL original não fazia parte do ZIP do projeto e não foi copiado nem alterado nesta etapa.

## Política de remoção

Nenhum arquivo original foi removido. A consolidação foi feita no código de decisão: cópias alternativas deixaram de ser lidas automaticamente, built-ins deixaram de ser reinjetados após a remoção manual e wrappers deixaram de escolher delivery em duplicidade. A compatibilidade de nomes, contratos e módulos foi preservada.

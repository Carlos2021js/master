# CS PLAYER — Auditoria de rotas

## Rotas principais do Web Player

| Rota | Método/entrada | Função | Dependência central | Resultado da auditoria |
|---|---|---|---|---|
| `index.php` | GET/POST de login | Autentica usuário e inicia sessão | `bootstrap.php`, lista DNS oficial | Mantida |
| `auth.php` | POST | Autenticação Xtream/M3U e failover | `cs_player_active_dns()` e wrappers compatíveis | Mantida |
| `home.php` | GET autenticado | Renderiza interface e injeta configuração no navegador | `cs_player_load_config()` | Mantida |
| `api.php?action=home` | GET autenticado | Catálogo, categorias, destaques e estado do servidor | `cs_player_api_batch()` | Mantida; batch centralizado |
| `api.php?action=category` | GET autenticado | Catálogo filtrado por categoria | `cs_player_api_call()` | Mantida |
| `api.php?action=series_info` | GET autenticado | Temporadas e episódios | `cs_player_api_call()` | Mantida |
| `api.php?action=epg_now` | GET autenticado | Programa atual e próximo | Cache XML + transporte central | Mantida |
| `api.php?action=tmdb_enrich` | GET autenticado | Enriquecimento de filmes/séries | `tmdb_service.php` | Mantida |
| `api.php?action=failover` | GET autenticado | Troca de DNS após falha | Lista DNS oficial | Mantida |
| `player_admin_api.php?action=get` | GET administrador | Leitura de configuração e saúde DNS | `cs_player_load_config()` | Mantida |
| `player_admin_api.php?action=save` | POST administrador | Salva configurações do Web Player | `cs_player_save_config()` | Mantida; escrita oficial única |
| `player_admin_api.php?action=test` | GET administrador | Testa API/M3U e descobre rota | Transporte central | Mantida |
| `player_admin_api.php?action=dns_health` | GET administrador | Expõe latência, falhas e cooldown | `dns_health.php` | Mantida; frontend alinhado |
| `player_admin_api.php?action=preflight` | GET administrador | Autodiagnóstico de ambiente | Configuração e filesystem | Mantida |
| `live_stream.php` | GET autenticado | Wrapper para canais ao vivo | `stream.php` | Mantida; delivery centralizado |
| `vod_stream.php` | GET autenticado | Wrapper para filmes e séries | `stream.php` | Mantida; MKV/remux preservado |
| `stream.php` | GET autenticado | Entrega Direct, Proxy, HLS, TS e remux | `cs_player_resolve_delivery_mode()` | Mantida; decisão única |
| `proxy.php`/módulos de proxy | GET contínuo | Proxy de mídia e manifests | `proxy_lib.php` | Mantido como motor especializado |
| `wwwdir/cs_stream.php` | GET público com credenciais | Gateway M3U e apps IPTV | Bootstrap + streaming contínuo | Mantida; HLS, Range e TLS preservados |
| `ad_proxy.php` | GET autenticado | Entrega de anúncio | Proxy especializado | Mantida |
| `cast_token.php`/`cast_stream.php` | GET autenticado | Transmissão para dispositivos compatíveis | Token e proxy | Mantida |
| `requests.php`/`requests_api.php` | GET/POST autenticado | Pedidos e respostas de atendimento | Banco existente + mapa de compatibilidade | Mantida |
| `client_error.php` | POST autenticado | Registro de erros do navegador | Logger do Web Player | Mantida |

## Hierarquia de autenticação

O fluxo normal carrega a configuração oficial, extrai somente DNS manuais habilitados e ordena por estratégia e saúde. Um DNS informado explicitamente na sessão pode ser colocado na primeira posição sem apagar os demais. A lista de servidores do banco usada para o painel administrativo é uma fonte distinta de servidores fixos do painel e não é adicionada à lista manual do Web Player.

O modo Xtream consulta endpoints configurados e preserva candidatos de `player_api.php` e `panel_api.php`. O modo M3U preserva `get.php`, `m3u_plus`, `output` e parâmetros adicionais. Os wrappers `legacy_compat.php` e `json_dns_compat.php` continuam atendendo contratos históricos, mas delegam requests ao transporte central quando carregados pelo bootstrap.

## Entrega de mídia

A decisão de entrega segue a ordem: override de item quando explícito; override de request quando explícito; política por formato; política por tipo; política global; e fallback automático conforme proxy habilitado. `direct`, `proxy`, `proxy_hls`, `remux` e `auto` continuam válidos quando aplicáveis. A entrega contínua permanece separada da camada de APIs para evitar carregar streams longos em memória.

## Controle de acesso

As rotas administrativas continuam protegidas pela sessão e permissões existentes. Os endpoints do Web Player continuam exigindo sessão ou credenciais conforme o fluxo original. A auditoria não alterou o banco nem os nomes das tabelas, e nenhuma rota administrativa foi removida.

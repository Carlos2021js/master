# CS PLAYER — Mapa de configurações legadas

Este documento registra as chaves e formatos legados encontrados no Web Player. A compatibilidade foi mantida sem permitir que valores antigos sobrescrevam silenciosamente a configuração oficial.

| Chave/formato legado | Onde aparece | Conversão ou uso atual | Estado |
|---|---|---|---|
| `admin/player/storage/config.php` | Instalações anteriores | Lido apenas em migração quando ainda não existe marcador; salvo na fonte oficial | Preservado |
| `admin/player/storage/config.json` | Instalações anteriores | Lido apenas em migração única; arquivo não é apagado | Preservado |
| `admin/player/storage/runtime-config.php` | Fallback de persistência anterior | Não é fonte normal de leitura nem de escrita; permanece documentado | Preservado, fora da decisão |
| `/tmp/cs-player-web-player-config.php` | Fallback temporário anterior | Não participa da leitura/escrita normal | Preservado como constante de compatibilidade |
| `admin/logs/cs-player/web-player-config.bak.php` | Backup do runtime | Usado somente quando a fonte primária não puder ser lida | Preservado como recuperação |
| `web-player-dns.json` | Compatibilidade com importadores e integrações antigas | Espelho gerado após o salvamento oficial; leitura passiva | Preservado |
| `dns_number` | JSON DNS histórico | Mantido no espelho exportado | Preservado |
| `serverN`, `serverN_name`, `serverN_enabled`, `serverN_priority` | JSON DNS histórico | Exportados a partir de `cfg['dns']`, sem adicionar built-ins | Preservado |
| `serverN_ip_mode` e `serverN_ip_mode_configured` | JSON DNS histórico | Mantidos no espelho e usados pelos wrappers compatíveis | Preservado |
| `provider_mode` | Linhas DNS manuais | Continua escolhendo Xtream, M3U ou modo automático | Preservado |
| `m3u_path`, `m3u_output`, `m3u_extra_query` | DNS M3U | Mantidos para os três importadores e geração de URL | Preservado |
| `live_proxy_mode` | Wrapper Live antigo | Continua validado, mas a decisão final passa por `cs_player_resolve_delivery_mode()` | Preservado como entrada de compatibilidade |
| `vod_proxy_mode` | Wrapper VOD antigo | Continua validado, mas a decisão final passa por `cs_player_resolve_delivery_mode()` | Preservado como entrada de compatibilidade |
| `stream_delivery_mode` | Modo global anterior | Participa da prioridade depois do formato e do tipo | Preservado |
| `delivery_hls`, `delivery_ts`, `delivery_mp4`, `delivery_mkv` | Modo por formato | Participam do resolvedor único | Preservado |
| `_delivery_mode` | Destaques e itens específicos | Override por item, com precedência sobre o modo global | Preservado |
| `format=remux` | VOD/MKV | Mantido para remux de MKV | Preservado |
| `direct_source` | Catálogo externo | Sanitizado antes de entrar no cache da sessão | Preservado |
| `container_extension` | Catálogo externo | Sanitizado em uma única atribuição | Preservado |
| `dns_json_compat` | Compatibilidade JSON | Continua habilitando o caminho legado, mas não altera a lista oficial | Preservado |
| `dns_auto_discovery` | Compatibilidade de descoberta | Continua carregado e enviado quando existente; não injeta DNS na lista manual | Preservado |
| `allow_legacy_tls` | Nova chave de compatibilidade controlada | `false` por padrão; somente `true` permite certificados legados em transportes autorizados | Acrescentado sem remover chaves |

## Regras de migração

A migração ocorre apenas se o arquivo oficial ainda não tiver sido carregado e se o marcador `web-player-config.php.migration-v1` não existir. Depois que o conteúdo é salvo com sucesso na fonte oficial, o marcador é criado e o arquivo antigo continua disponível para auditoria. A migração não executa SQL e não altera o banco.

As chaves desconhecidas no nível principal da configuração não são descartadas pelo carregamento, pois a combinação usa `array_replace()` sobre os defaults. A API administrativa parte da configuração persistida e modifica apenas os campos controlados pelo formulário, reduzindo o risco de perda de configurações adicionadas por versões futuras.

## Compatibilidade de booleanos

A função `cs_player_bool()` interpreta corretamente valores booleanos nativos, números, `0`, `1`, `false`, `true`, `off`, `on`, `no`, `yes`, `disabled` e `enabled`. Isso evita que a string legada `"false"` seja tratada como verdadeiro por uma simples chamada a `empty()` ou conversão booleana.

# CS PLAYER — Matriz de configuração

## Objetivo

Esta matriz documenta a fonte de verdade da configuração do Web Player após a auditoria. A regra aplicada foi preservar as chaves e os recursos existentes, mas impedir que cópias temporárias ou espelhos concorram com a configuração oficial.

| Domínio | Fonte oficial de leitura | Fonte oficial de escrita | Compatibilidade preservada | Regra efetiva |
|---|---|---|---|---|
| Configuração geral do Web Player | `admin/logs/cs-player/web-player-config.php` | O mesmo arquivo, por gravação atômica | `admin/player/storage/config.php`, `admin/player/storage/config.json`, `runtime-config.php` e cópia temporária continuam presentes e documentados | Fallback normal por `mtime` foi eliminado; somente a fonte oficial participa da leitura normal |
| DNS manual | Chave `dns` dentro da configuração oficial | API `admin/player_admin_api.php` via `cs_player_save_config()` | Espelho `web-player-dns.json` continua sendo atualizado para compatibilidade | A lista manual habilitada é a única lista usada por `cs_player_active_dns()` |
| Espelho JSON DNS | `web-player-dns.json` somente para compatibilidade/exportação | `cs_player_save_config()` chama o espelhamento uma vez | Funções `cs_player_json_dns_load/export/save()` continuam disponíveis | Leitura não regrava e não adiciona built-ins |
| Política de delivery | `stream_delivery_mode`, `delivery_hls`, `delivery_ts`, `delivery_mp4`, `delivery_mkv`, `live_proxy_mode`, `vod_proxy_mode` | API administrativa | Wrappers Live/VOD e `_delivery_mode` por item continuam aceitos | `cs_player_resolve_delivery_mode()` decide de forma determinística |
| Transporte HTTP de API | `admin/player/http_transport.php` | Não aplicável | `cs_player_http_json()`, `cs_player_legacy_get()` e wrappers JSON continuam disponíveis | Requests curtos e batch usam o transporte central |
| Proxy de mídia | `admin/player/proxy_lib.php` e gateway contínuo público | Não aplicável | Range, HLS, MPEG-TS, MP4, MKV e remux continuam disponíveis | Proxy contínuo permanece especializado; TLS passa a ser controlável pela configuração |
| Cache de EPG | `admin/logs/cs-player/epg-cache/*.xml` | `admin/player/api.php` | Endpoint `epg_now` continua disponível | Download utiliza transporte central e gravação temporária atômica |
| Metadados TMDB | Cache local do serviço TMDB | `admin/player/tmdb_service.php` | Enriquecimento, imagens e trailers continuam disponíveis | Requisição curta usa transporte central |

## Política de leitura e escrita

A fonte primária é `CS_PLAYER_CONFIG_PRIMARY`, apontando para `admin/logs/cs-player/web-player-config.php`. O carregamento normal lê apenas esse arquivo. O backup é usado somente para recuperação quando a fonte primária não puder ser lida. Os arquivos antigos permanecem no projeto para compatibilidade e auditoria, mas não podem voltar a vencer por data de modificação.

O salvamento cria um arquivo temporário no mesmo diretório, usa lock exclusivo, descarrega o conteúdo, utiliza `fsync()` quando disponível, aplica `rename()` atômico, ajusta a permissão para `0640`, invalida o OPcache quando disponível e relê o arquivo para comparar o conteúdo persistido. Uma falha no destino oficial retorna erro; não há fallback silencioso para `/tmp`.

## Chaves críticas

| Chave | Normalização | Comportamento padrão |
|---|---|---|
| `dns` | URLs normalizadas, duplicatas removidas e `enabled` convertido por `cs_player_bool()` | Mantém os defaults existentes apenas em instalação sem configuração persistida |
| `allow_legacy_tls` | Booleano explícito | `false`; certificados são verificados por padrão |
| `proxy_enabled`, `proxy_hls`, `proxy_vod` | Booleano explícito | Mantém os defaults da instalação |
| `stream_delivery_mode` e chaves por formato | Enumeração validada | `auto` quando ausente ou inválido |
| `live_proxy_mode`, `vod_proxy_mode` | Enumeração validada | Mantém os defaults existentes |
| `config_version` | Inteiro lógico acrescentado no salvamento | `1` na primeira gravação |
| `updated_at` | Unix timestamp acrescentado no salvamento | Atualizado a cada gravação oficial |

## Regra de compatibilidade

Nenhuma função legada necessária foi apagada. Quando uma função representa uma interface antiga, ela permanece como wrapper do serviço central. A remoção ocorreu somente no sentido de retirar decisões concorrentes da cadeia ativa, como a seleção por `mtime`, a reinjeção automática de built-ins e a injeção duplicada de `delivery` nos wrappers Live/VOD.

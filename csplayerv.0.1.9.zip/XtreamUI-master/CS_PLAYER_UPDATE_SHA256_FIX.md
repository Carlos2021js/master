# Correção da validação SHA-256 do CS PLAYER

## Causa comprovada

A proteção de integridade do updater funcionou corretamente e cancelou a instalação. O problema estava no `update.json` remoto, não no cálculo local do SHA-256.

O manifesto reserva do GitHub declarou para `csplayerv.5.1.2.zip`:

- SHA-256 informado: `c39e2a05627d0bfe8cbccdc2380acb8eebf0426abcc3c19c7439e02f3f9edc45`
- Tamanho informado: `23288382` bytes

O próprio URL de download do manifesto entregou um ZIP válido com:

- SHA-256 real: `314288844da589f09f16091b899cd1767cb7e8af883473b0b70e9c072d5ab9db`
- Tamanho real: `16321359` bytes

O ZIP anexado pelo usuário apresentou exatamente o mesmo SHA-256 e tamanho do download público. Portanto, o pacote não estava corrompido; o hash e o tamanho publicados no manifesto estavam desatualizados ou pertenciam a outra versão do arquivo.

## Correção preparada

O arquivo `update.json` corrigido está no mesmo diretório desta documentação. Ele mantém versão 5.1.2/build 512, o mesmo URL de download, `database_changes: false`, preservação de configuração e backup antes da atualização, mas substitui SHA-256 e tamanho pelos valores reais.

O updater também foi reforçado para validar tamanho antes do SHA-256 e registrar, sem expor dados sensíveis, os valores esperado e recebido em caso de divergência. A atualização continua cancelada quando qualquer verificação falha.

## Procedimento de publicação

Substitua o conteúdo do `update.json` no canal que o servidor utiliza. O Dropbox configurado no updater está excluído no momento; o canal reserva GitHub respondeu normalmente e é o canal efetivo utilizado no diagnóstico. Depois da publicação, confirme que o URL do ZIP e o `sha256` do manifesto correspondem ao mesmo arquivo byte a byte.

A validação foi feita localmente com o ZIP anexado e com o ZIP baixado do URL público. Não foi realizada publicação externa nem alteração automática no GitHub/Dropbox.

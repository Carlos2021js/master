# CS PLAYER — Auditoria de duplicidades de configuração

## Critério

Uma duplicação foi considerada removível somente quando havia evidência de que ela poderia substituir uma configuração válida, reinjetar dados removidos ou tomar uma decisão diferente do serviço oficial. Interfaces antigas foram preservadas como wrappers, aliases ou camadas de compatibilidade.

| Duplicação observada | Local | Risco | Tratamento aplicado | Compatibilidade |
|---|---|---|---|---|
| Seleção da cópia runtime mais recente por `mtime` | `admin/player/bootstrap.php` | Uma cópia antiga em `storage` ou `/tmp` podia vencer a configuração salva pelo administrador | Removida da cadeia normal; a fonte primária é sempre lida primeiro | Constantes e caminhos legados continuam definidos e o backup continua disponível |
| Escrita simultânea em três destinos | `cs_player_save_config()` | Criava divergência e permitia que um destino alternativo voltasse a ser lido | Escrita oficial única e atômica | Backup do arquivo anterior continua sendo criado |
| Built-ins adicionados durante exportação JSON | `json_dns_compat.php` | DNS removido pela interface podia voltar no espelho/login | `cs_player_json_dns_rows_with_builtins()` permanece, mas o export usa somente a lista oficial | Funções e arquivo JSON continuam disponíveis |
| Regravação do espelho durante leitura JSON | `cs_player_json_dns_load()` | Um GET podia alterar o estado e reinjetar defaults | Leitura tornou-se passiva | O espelho continua legível por integrações antigas |
| Autenticação JSON lendo espelho em vez do repositório oficial | `cs_player_json_compat_authenticate()` | Espelho obsoleto podia autenticar contra DNS removido | Usa `cs_player_active_dns()` | Fallback de função permanece quando o serviço central não existir |
| Decisão de `delivery` em Live/VOD e no `stream.php` | `live_stream.php`, `vod_stream.php`, `stream.php` | A mesma configuração podia produzir modos diferentes por endpoint | Criado `cs_player_resolve_delivery_mode()` e wrappers deixam de injetar modo automaticamente | Parâmetro explícito `delivery` e formato `remux` continuam aceitos |
| Decisão de `delivery` no frontend e backend | `player.js` e `stream.php` | Configuração exibida no frontend podia divergir da execução | O frontend envia somente override de item ou fallback após erro; backend resolve o modo normal | Fallback Direct→Proxy permanece |
| Transporte cURL separado do batch de APIs | `bootstrap.php` e `http_transport.php` | TLS, timeouts e IP podiam variar entre requests equivalentes | `cs_player_transport_request_batch()` concentra o batch | `cs_player_api_batch()` mantém o mesmo formato de resultado |
| Transporte stream wrapper separado nas interfaces legadas | `json_dns_compat.php`, `legacy_compat.php` | TLS e headers diferentes para o mesmo tipo de autenticação | Wrappers delegam ao transporte central | Assinaturas e chaves históricas de retorno foram mantidas |
| Requisição EPG independente | `api.php` | TLS desligado e cache sem política central | EPG usa transporte central e mantém cache XML atômico | Endpoint e formato de resposta preservados |
| Requisição TMDB independente | `tmdb_service.php` | Política HTTP duplicada | Serviço usa transporte central | Cache, enriquecimento, imagens e trailers preservados |
| Campos `direct_source` e `container_extension` repetidos | `api.php` | A segunda atribuição anulava a sanitização da primeira | Mantida uma única atribuição sanitizada | Cache de fontes externas continua funcionando |
| Funções de log em `admin/cs_player.php` e `bootstrap.php` | Camada legada e bootstrap | Parecem duplicadas estaticamente, mas possuem guardas de declaração e são usadas em cadeias de inclusão diferentes | Não removidas | Compatibilidade do painel legado e do Web Player mantida |
| Constante TMDB definida em dois arquivos | `admin/functions.php` e serviço TMDB | O projeto pode carregar arquivos em ordens diferentes | Ambas permanecem protegidas por `defined()` | Nenhuma funcionalidade existente foi eliminada |

## Conclusão

As duplicidades realmente concorrentes foram retiradas somente da cadeia de decisão. As interfaces antigas continuam no código e delegam ao núcleo oficial quando o fluxo passa pelo Web Player. O inventário original e o final possuem a mesma quantidade de arquivos; não houve arquivo removido.

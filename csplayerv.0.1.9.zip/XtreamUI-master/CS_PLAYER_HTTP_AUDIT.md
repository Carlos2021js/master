# CS PLAYER — Auditoria HTTP e TLS

## Arquitetura consolidada

O transporte curto de APIs está concentrado em `admin/player/http_transport.php`. A função `cs_player_transport_request()` atende requests individuais e `cs_player_transport_request_batch()` atende o carregamento paralelo da home. `cs_player_http_json()`, `cs_player_legacy_get()`, `cs_player_stream_http_json()` e `cs_player_curl_http_json()` permanecem como interfaces de compatibilidade, mas delegam ao transporte central.

O proxy de mídia não foi fundido ao transporte de APIs porque possui requisitos diferentes: streams contínuos, Range, callbacks de escrita, HLS com reescrita de manifest e baixa latência. `proxy_lib.php` e `wwwdir/cs_stream.php` continuam especializados, porém usam a mesma política TLS configurável e não carregam o conteúdo inteiro do stream em memória.

| Área | Implementação oficial | Timeout/política | Resultado |
|---|---|---|---|
| Request JSON individual | `cs_player_transport_request()` | 3–60 s, User-Agent e Accept centralizados | Consolidada |
| Batch JSON | `cs_player_transport_request_batch()` | Mesmo timeout/TLS/IP do transporte individual | Consolidada e paralela |
| Fallback PHP stream | Dentro do transporte central | Somente quando solicitado ou necessário para JSON | Mantido dentro do núcleo |
| API Xtream | `cs_player_http_json()`/`cs_player_api_call()` | Configuração oficial e modo IP da sessão | Mantida |
| Compatibilidade legacy | `cs_player_legacy_get()` | Wrapper do transporte, com permissão legada TLS explícita no adapter | Mantida |
| JSON DNS legacy | Wrappers do transporte | Contratos históricos preservados | Mantida |
| EPG XML | `api.php?action=epg_now` | Transporte central, cache XML, escrita temporária e rename | Consolidada |
| TMDB | `tmdb_service.php` | Transporte central, JSON e TLS verificado | Consolidada |
| Probe M3U | `cs_player_probe_m3u()` | Leitura parcial até 128 KiB, sem alterar banco | Mantida com TLS configurável |
| Probe administrativo | `cs_admin_probe_request()` | Transporte central, preserva status/latência/IP | Consolidada |
| Proxy de manifest | `proxy_lib.php` | Especializado, cache curto e TLS configurável | Mantido |
| Gateway público HLS/Range | `wwwdir/cs_stream.php` | Especializado, stream contínuo e TLS configurável | Mantido |

## TLS

A política padrão passou a verificar certificados: `CURLOPT_SSL_VERIFYPEER` fica ativo e `CURLOPT_SSL_VERIFYHOST` usa `2`. A chave `allow_legacy_tls` permanece disponível para instalações que dependem de certificados legados, mas seu padrão é `false`. Essa opção é propagada aos transportes central, batch, EPG, M3U, proxy e gateway público.

O adapter de `legacy_compat.php` continua aceitando a configuração `allow_legacy_tls` para não eliminar provedores antigos que dependem desse comportamento, mas não a força como verdadeira. Esse caminho é explícito, isolado e registrado como compatibilidade; todos os transportes ficam seguros por padrão.

## Segurança e dados sensíveis

Logs existentes continuam usando hashes e redaction para credenciais. URLs de catálogo podem conter credenciais no fluxo original; por isso os eventos auditados devem registrar host, endpoint, status, latência e hashes, nunca senha. A chave TMDB presente no projeto foi identificada como segredo hardcoded de configuração histórica e deve ser substituída por variável de ambiente ou segredo de implantação em produção; esta auditoria não a removeu para não quebrar a funcionalidade existente.

## Cache e falhas

O cache de EPG grava em arquivo temporário e renomeia somente quando o status e o tamanho mínimo são válidos. O cache de catálogo e TMDB permanece com seus TTLs originais. O transporte retorna `ok`, `http_code/status`, `body`, `data/json`, `content_type`, `errno`, `error`, `remote_ip`, `effective_url`, duração e tentativas, permitindo diagnósticos consistentes sem repetir chamadas por camadas concorrentes.

## Limitações conhecidas

Os módulos gerais do painel fora do escopo do Web Player ainda possuem transportes próprios para tarefas administrativas amplas, atualização, Google Drive ou importação de playlists. Eles não foram removidos porque não pertencem ao fluxo do Web Player e podem ser necessários ao painel XtreamUI. Os importadores `m3u_update_nodup.php` e `m3u_update_nodup1.php` continuam independentes conforme solicitado.

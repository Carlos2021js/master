# CS PLAYER — Correção de DNS e M3U Plus

## Problema identificado

O Web Player recebia uma URL completa de playlist `get.php`, mas o salvamento administrativo preservava o endereço apenas como DNS base e mantinha `provider_mode=auto`. Com isso, o login e as camadas de compatibilidade podiam tentar `player_api.php` antes do endpoint M3U correto. Servidores que entregam somente M3U apareciam como falhos, mesmo quando o formato M3U era o fluxo válido.

O espelho JSON também não carregava caminho e saída M3U, e o pré-login JSON sondava `player_api.php` em servidores explicitamente M3U. Isso produzia ruído e podia consumir tempo, retries e health checks antes do teste real de `get.php`.

## Correções aplicadas

| Componente | Correção |
|---|---|
| Salvamento administrativo | URLs cujo caminho termina em `get.php` passam automaticamente a `provider_mode=m3u` |
| Saída M3U | `output=mpegts` ou `output=hls` da URL completa é preservado quando válido |
| Caminho M3U | `get.php` ou caminho configurado é salvo separadamente do DNS base |
| Query adicional | Parâmetros não sensíveis são preservados; `username`, `password`, `token`, `auth`, `secret`, `type` e `output` não ficam no DNS |
| Frontend de diagnóstico | Quando o campo contém `/get.php`, o modo automático é convertido em M3U antes do teste |
| Compatibilidade JSON | Espelho exporta/carrega `serverN_path` e `serverN_output` |
| Pré-login JSON | Linhas explicitamente M3U não são sondadas como `player_api.php` |
| Pré-login legacy | Servidores explicitamente M3U não entram na tentativa legacy Xtream antes do M3U |
| Autenticação Xtream | cURL próprio foi substituído pelo transporte central, preservando perfis, IP, timeout, TLS e diagnóstico |
| Ambiente sem cURL | Probe e download M3U usam fallback controlado por streams PHP, em vez de marcar todo DNS como offline |
| Cache M3U | Chave inclui DNS, caminho, saída, usuário e hash da senha, evitando catálogo de outra credencial |
| Failover de catálogo | Se o login M3U passa, mas a lista falha, outro DNS ativo compatível pode ser testado automaticamente |
| Rota alternativa | A sessão preserva caminho/output do DNS original ao usar HTTP/HTTPS ou porta alternativa |
| Servidores do banco | `http_broadcast_port` e `https_broadcast_port` agora são usados; não há mais forçamento universal para `:80` |
| Painel móvel | Avisos e códigos DNS recebem quebra de linha responsiva sem fragmentar o texto caractere a caractere |
| Compatibilidade | Nenhum arquivo, importador ou motor existente foi removido |
| Banco | Nenhum SQL foi executado ou alterado |

## Fluxo esperado após a correção

Quando o administrador informa uma URL completa `get.php`, o sistema mantém o host/porta como DNS base e registra a intenção M3U. No login, o servidor é testado pelo caminho M3U com o usuário e a senha digitados no formulário. Se a resposta começar com `#EXTM3U`, o servidor é selecionado, a sessão recebe `provider_mode=m3u` e o catálogo continua pelo fluxo M3U existente.

Quando o administrador informa apenas um domínio ou IP, o comportamento anterior é preservado: o modo pode continuar `auto`, `smart`, `xc` ou `xtream`, e o sistema mantém descoberta de rotas e fallback M3U quando configurado.

## Testes realizados

| Teste | Resultado |
|---|---|
| URL M3U completa detectada como M3U | PASS |
| Caminho `get.php` preservado | PASS |
| Credenciais não persistem no endpoint derivado | PASS |
| DNS manual-only não reinjeta built-ins | PASS |
| Normalização de protocolo duplicado | PASS |
| Prioridade Direct/Proxy/HLS/MP4/remux | PASS |
| Escrita atômica e releitura | PASS |
| Autenticação M3U fixture com usuário/senha | PASS |
| Senha M3U inválida rejeitada | PASS |
| Catálogo M3U fixture | PASS |
| Fallback sem cURL | PASS |
| Portas reais do servidor preservadas | PASS |
| Fallback XC/Smart/Auto para M3U | PASS |
| Lint PHP | 0 erros |
| Sintaxe JavaScript | 0 erros |

## Observação sobre o servidor informado

O endpoint informado foi testado no ambiente de diagnóstico e respondeu `HTTP 404` com uma página Nginx. O código foi corrigido para não perder o caminho M3U nem confundir M3U com Xtream, mas a instalação deve ser testada no servidor/porta que efetivamente entrega a lista no ambiente do usuário. Se o provedor usar porta diferente ou rota adicional, ela deve ser informada no campo DNS/URL e no caminho M3U.

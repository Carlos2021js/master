<?php
/**
 * CS PLAYER - Compatibilidade DNS via JSON clássico
 * Baseado no fluxo funcional de players que mantêm serverN/serverN_name em JSON.
 * Não altera banco de dados e não substitui o motor avançado; funciona como camada
 * de compatibilidade antes do fallback Smart/XC/M3U existente.
 */

if (!defined('CS_PLAYER_INTERNAL')) {
    http_response_code(403);
    exit;
}

if (!defined('CS_PLAYER_DNS_JSON_FILE')) {
    define('CS_PLAYER_DNS_JSON_FILE', dirname(__DIR__) . '/logs/cs-player/web-player-dns.json');
}

function cs_player_json_dns_builtin_rows() {
    return array(
        array(
            'id' => 'builtin_main_server',
            'name' => 'Main Server',
            'url' => 'http://169.58.140.143:80',
            'enabled' => true,
            'priority' => 10,
            'provider_mode' => 'auto',
            'ip_mode' => 'ipv4',
        ),
        array(
            'id' => 'builtin_powerplay',
            'name' => 'Power play',
            'url' => 'http://power08121562.shop:80',
            'enabled' => true,
            'priority' => 20,
            'provider_mode' => 'auto',
            'ip_mode' => 'ipv4',
        ),
    );
}

function cs_player_json_dns_rows_with_builtins(array $cfg) {
    $rows = array();
    $seen = array();
    foreach (($cfg['dns'] ?? array()) as $row) {
        if (!is_array($row)) continue;
        $url = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($url === '') continue;
        $key = strtolower(rtrim($url, '/'));
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $row['url'] = $url;
        $rows[] = $row;
    }
    // Os built-ins continuam disponíveis para compatibilidade histórica, mas não
    // são acrescentados automaticamente. A configuração oficial é soberana;
    // DNS removido pelo administrador não pode retornar pelo espelho JSON.
    return $rows;
}

function cs_player_json_dns_export(array $cfg) {
    $out = [
        'sitename' => (string)($cfg['brand'] ?? 'CS Player'),
        'dns_number' => 'manual',
        'engine' => 'csplayer-json-compat',
        'updated_at' => date('c'),
    ];
    $i = 1;
    foreach (cs_player_json_dns_rows_with_builtins($cfg) as $row) {
        if (!is_array($row)) continue;
        $url = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($url === '') continue;
        $configuredIpMode = strtolower(trim((string)($row['ip_mode'] ?? 'auto')));
        if (!in_array($configuredIpMode, array('auto', 'ipv4', 'ipv6'), true)) $configuredIpMode = 'auto';
        $effectiveIpMode = $configuredIpMode;
        $host = (string)(parse_url($url, PHP_URL_HOST) ?: '');
        $scheme = strtolower((string)(parse_url($url, PHP_URL_SCHEME) ?: 'http'));
        $port = (int)(parse_url($url, PHP_URL_PORT) ?: ($scheme === 'https' ? 443 : 80));
        // Para DNS externos HTTP/80 em modo Auto, prefira IPv4 no motor JSON.
        // A escolha configurada no painel continua registrada separadamente.
        if ($configuredIpMode === 'auto' && $host !== '' && !filter_var($host, FILTER_VALIDATE_IP) && $scheme === 'http' && $port === 80) {
            $effectiveIpMode = 'ipv4';
        }
        $out['server' . $i . '_name'] = trim((string)($row['name'] ?? '')) ?: ('Servidor ' . $i);
        $out['server' . $i] = $url;
        $out['server' . $i . '_enabled'] = function_exists('cs_player_bool') ? cs_player_bool($row['enabled'] ?? false, false) : !empty($row['enabled']);
        $out['server' . $i . '_priority'] = max(1, (int)($row['priority'] ?? $i));
        $out['server' . $i . '_mode'] = (string)($row['provider_mode'] ?? 'auto');
        $out['server' . $i . '_path'] = (string)($row['m3u_path'] ?? 'get.php');
        $out['server' . $i . '_output'] = (string)($row['m3u_output'] ?? 'mpegts');
        $out['server' . $i . '_ip_mode_configured'] = $configuredIpMode;
        $out['server' . $i . '_ip_mode'] = $effectiveIpMode;
        $i++;
    }
    return $out;
}

function cs_player_json_dns_save(array $cfg) {
    $path = CS_PLAYER_DNS_JSON_FILE;
    $dir = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    $json = json_encode(cs_player_json_dns_export($cfg), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if (!is_string($json)) return false;
    $tmp = $path . '.tmp.' . getmypid();
    if (@file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) return false;
    @chmod($tmp, 0640);
    if (!@rename($tmp, $path)) { @unlink($tmp); return false; }
    return true;
}

function cs_player_json_dns_load(array $cfg) {
    $path = CS_PLAYER_DNS_JSON_FILE;
    // O JSON é somente espelho de compatibilidade/exportação. Ler nunca deve
    // regravar configuração nem reintroduzir DNS removidos.
    $raw = @file_get_contents($path);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($data)) $data = cs_player_json_dns_export($cfg);
    $rows = [];
    for ($i = 1; $i <= 1000; $i++) {
        $url = trim((string)($data['server' . $i] ?? ''));
        if ($url === '') continue;
        $url = cs_player_normalize_dns($url);
        if ($url === '') continue;
        $rows[] = [
            'id' => 'json_' . $i . '_' . substr(sha1($url), 0, 8),
            'name' => trim((string)($data['server' . $i . '_name'] ?? '')) ?: ('Servidor ' . $i),
            'url' => $url,
            'enabled' => !array_key_exists('server' . $i . '_enabled', $data) || (function_exists('cs_player_bool') ? cs_player_bool($data['server' . $i . '_enabled'], true) : !empty($data['server' . $i . '_enabled'])),
            'priority' => max(1, (int)($data['server' . $i . '_priority'] ?? $i)),
            'provider_mode' => (string)($data['server' . $i . '_mode'] ?? 'auto'),
            'm3u_path' => (string)($data['server' . $i . '_path'] ?? 'get.php'),
            'm3u_output' => (string)($data['server' . $i . '_output'] ?? 'mpegts'),
            'ip_mode' => (string)($data['server' . $i . '_ip_mode'] ?? 'auto'),
            'ip_mode_configured' => (string)($data['server' . $i . '_ip_mode_configured'] ?? ($data['server' . $i . '_ip_mode'] ?? 'auto')),
            'source' => 'json',
            '_index' => 'json:' . $i,
            '_sort' => max(1, (int)($data['server' . $i . '_priority'] ?? $i)),
        ];
    }
    usort($rows, function ($a, $b) {
        return ((int)$a['_sort']) <=> ((int)$b['_sort']);
    });
    return array_values(array_filter($rows, function ($row) { return !empty($row['enabled']); }));
}

function cs_player_stream_http_json($url, $timeout, $userAgent) {
    if (!function_exists('cs_player_transport_request')) return null;
    $res = cs_player_transport_request((string)$url, [
        'timeout' => max(3, (int)$timeout),
        'user_agent' => (string)$userAgent,
        'json' => true,
        'classic_stream_fallback' => true,
    ]);
    return [
        'body' => is_string($res['body'] ?? null) ? $res['body'] : '',
        'data' => is_array($res['data'] ?? null) ? $res['data'] : null,
        'http_code' => (int)($res['http_code'] ?? 0),
        'time_ms' => (int)($res['time_ms'] ?? 0),
        'response_bytes' => is_string($res['body'] ?? null) ? strlen($res['body']) : 0,
        'headers' => is_array($res['headers'] ?? null) ? $res['headers'] : [],
        'curl_errno' => (int)($res['curl_errno'] ?? 0),
        'curl_error' => (string)($res['curl_error'] ?? ''),
    ];
}

function cs_player_curl_http_json($url, $timeout, $userAgent, $ipMode) {
    if (!function_exists('cs_player_transport_request')) return null;
    $res = cs_player_transport_request((string)$url, [
        'timeout' => max(3, (int)$timeout),
        'user_agent' => (string)$userAgent,
        'ip_mode' => (string)$ipMode,
        'json' => true,
    ]);
    return [
        'body' => is_string($res['body'] ?? null) ? $res['body'] : '',
        'data' => is_array($res['data'] ?? null) ? $res['data'] : null,
        'http_code' => (int)($res['http_code'] ?? 0),
        'time_ms' => (int)($res['time_ms'] ?? 0),
        'response_bytes' => is_string($res['body'] ?? null) ? strlen($res['body']) : 0,
        'curl_errno' => (int)($res['curl_errno'] ?? 0),
        'curl_error' => (string)($res['curl_error'] ?? ''),
        'remote_ip' => (string)($res['remote_ip'] ?? ''),
        'effective_url' => (string)($res['effective_url'] ?? $url),
        'ip_mode' => (string)($res['ip_mode'] ?? $ipMode),
    ];
}

function cs_player_json_compat_authenticate(array $cfg, $username, $password) {
    if (empty($cfg['dns_json_compat'])) return null;
    $servers = function_exists('cs_player_active_dns') ? cs_player_active_dns($cfg) : cs_player_json_dns_load($cfg);
    if (!$servers) return null;
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36';
    $timeout = max(5, min(30, (int)($cfg['request_timeout'] ?? 10)));
    $diagnostics = array();
    foreach ($servers as $row) {
        $providerMode = strtolower(trim((string)($row['provider_mode'] ?? 'auto')));
        if ($providerMode === 'm3u' || preg_match('~/get\.php$~i', (string)($row['m3u_path'] ?? ''))) continue;
        $base = rtrim((string)$row['url'], '/');
        $url = $base . '/player_api.php?username=' . rawurlencode((string)$username) . '&password=' . rawurlencode((string)$password);
        $configuredIp = strtolower((string)($row['ip_mode'] ?? 'auto'));
        if ($configuredIp === 'ipv4') $attemptModes = array('ipv4');
        elseif ($configuredIp === 'ipv6') $attemptModes = array('ipv6');
        else $attemptModes = array('ipv4', 'auto');

        foreach ($attemptModes as $ipMode) {
            $res = cs_player_transport_request($url, array('timeout'=>$timeout,'user_agent'=>$ua,'ip_mode'=>$ipMode,'json'=>true));
            $payload = cs_player_normalize_auth_payload(is_array($res['data']) ? $res['data'] : null, (string)$username);
            $ok = cs_player_is_authenticated_response($payload);
            $host = (string)(parse_url($base, PHP_URL_HOST) ?: '');
            $port = (int)(parse_url($base, PHP_URL_PORT) ?: (stripos($base, 'https://') === 0 ? 443 : 80));
            $diagnostics[] = array(
                'host' => $host,
                'port' => $port,
                'http_code' => (int)$res['http_code'],
                'json' => is_array($res['data']),
                'time_ms' => (int)$res['time_ms'],
                'response_bytes' => (int)($res['response_bytes'] ?? (isset($res['body']) && is_string($res['body']) ? strlen($res['body']) : 0)),
                'endpoint' => 'player_api.php',
                'provider' => 'json_compat',
                'ip_mode' => (string)($res['ip_mode'] ?? $ipMode),
                'remote_ip' => (string)($res['remote_ip'] ?? ''),
                'curl_errno' => (int)($res['curl_errno'] ?? 0),
            );
            if ($ok) {
                $selectedIp = (string)($res['ip_mode'] ?? $ipMode);
                $row['api_endpoint'] = 'player_api.php';
                $row['provider_mode_selected'] = 'json_xtream';
                $row['http_profile_selected'] = 'classic_json';
                $row['ip_mode_selected'] = $selectedIp;
                $row['ip_mode'] = $selectedIp === 'auto' ? $configuredIp : $selectedIp;
                $_SESSION['cs_player_json_ip_mode'] = $selectedIp;
                $_SESSION['cs_player_ip_mode_selected'] = $selectedIp;
                $_SESSION['cs_player_transport_dns_url'] = $base;
                $_SESSION['cs_player_transport_engine'] = 'json_compat';
                cs_player_record_dns_health($row, true, (int)$res['time_ms'], 'json_xtream');
                if ($selectedIp === 'ipv4' && $configuredIp === 'auto') {
                    cs_player_write_log('json_dns_ipv4_fallback_selected', array(
                        'host' => $host,
                        'port' => $port,
                        'remote_ip' => (string)($res['remote_ip'] ?? ''),
                        'time_ms' => (int)$res['time_ms'],
                    ), 'info');
                }
                cs_player_write_log('json_dns_auth_selected', array(
                    'host' => $host,
                    'port' => $port,
                    'time_ms' => (int)$res['time_ms'],
                    'engine' => 'json_compat',
                    'ip_mode' => $selectedIp,
                    'remote_ip' => (string)($res['remote_ip'] ?? ''),
                ), 'info');
                return array('row' => $row, 'data' => $payload, 'provider_mode' => 'json_xtream', 'diagnostics' => $diagnostics);
            }
        }
    }
    cs_player_write_log('json_dns_auth_failed', array('dns_count' => count($servers), 'diagnostics' => $diagnostics), 'warning');
    return array('error' => 'json_compat_auth_failed', 'diagnostics' => $diagnostics);
}

function cs_player_json_compat_api_call($dns, $username, $password, $action, array $extra) {
    $params = array_merge(array('username' => $username, 'password' => $password), $extra);
    if ((string)$action !== '') $params['action'] = (string)$action;
    $cfg = cs_player_load_config();
    $timeout = max(5, min(30, (int)($cfg['request_timeout'] ?? 10)));
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/58.0.3029.110 Safari/537.36';
    $sessionDns = trim((string)($_SESSION['cs_player_transport_dns_url'] ?? ''));
    $base = $sessionDns !== '' ? $sessionDns : (string)$dns;
    $url = rtrim($base, '/') . '/player_api.php?' . http_build_query($params);
    $selectedIp = (string)($_SESSION['cs_player_ip_mode_selected'] ?? $_SESSION['cs_player_json_ip_mode'] ?? 'ipv4');
    $res = cs_player_transport_request($url, array('timeout'=>$timeout,'user_agent'=>$ua,'ip_mode'=>$selectedIp,'json'=>true));
    if (!empty($res['ok']) && is_array($res['data'])) {
        $_SESSION['cs_player_ip_mode_selected'] = (string)$res['ip_mode'];
        $_SESSION['cs_player_json_ip_mode'] = (string)$res['ip_mode'];
        $_SESSION['cs_player_transport_dns_url'] = $base;
        return $res['data'];
    }
    cs_player_write_log('json_dns_catalog_request_failed', array(
        'host'=>(string)(parse_url($base, PHP_URL_HOST) ?: ''),
        'action'=>(string)$action,
        'http_code'=>(int)($res['http_code'] ?? 0),
        'remote_ip'=>(string)($res['remote_ip'] ?? ''),
        'ip_mode'=>(string)($res['ip_mode'] ?? ''),
        'attempts'=>$res['attempts'] ?? array(),
    ), 'warning');
    return null;
}

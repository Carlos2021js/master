<?php
/** CS Player - TMDB enrichment service (server side only). */
if (!defined('CS_PLAYER_TMDB_API_KEY')) {
    define('CS_PLAYER_TMDB_API_KEY', '25fd37f463eaf2bda3d7309a62db248a');
}

function cs_player_tmdb_log(string $event, array $context = [], string $level = 'warning'): void {
    if (function_exists('cs_player_write_log')) cs_player_write_log($event, $context, $level);
}

function cs_player_tmdb_cache_dir(): string {
    $dir = __DIR__ . '/cache/tmdb';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}

function cs_player_tmdb_http(string $path, array $query = []): ?array {
    $query['api_key'] = CS_PLAYER_TMDB_API_KEY;
    $query['language'] = $query['language'] ?? 'pt-BR';
    $url = 'https://api.themoviedb.org/3/' . ltrim($path, '/') . '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    if (!function_exists('cs_player_transport_request')) {
        cs_player_tmdb_log('tmdb_transport_unavailable', ['path'=>$path]);
        return null;
    }
    $res = cs_player_transport_request($url, [
        'timeout'=>8,
        'connect_timeout'=>4,
        'accept'=>'application/json',
        'user_agent'=>'CS-Player-TMDB/1.0',
        'json'=>true,
        'allow_legacy_tls'=>false,
    ]);
    $code = (int)($res['http_code'] ?? 0);
    if (empty($res['ok']) || $code < 200 || $code >= 300 || !is_array($res['data'] ?? null)) {
        cs_player_tmdb_log('tmdb_request_failed', ['path'=>$path,'http_code'=>$code,'curl_error'=>(string)($res['curl_error'] ?? '')]);
        return null;
    }
    return $res['data'];
}

function cs_player_tmdb_image(?string $path, string $size = 'w1280'): string {
    $path = trim((string)$path);
    if ($path === '') return '';
    return 'https://image.tmdb.org/t/p/' . $size . $path;
}

function cs_player_tmdb_best_video(array $videos): string {
    foreach (($videos['results'] ?? []) as $video) {
        if (($video['site'] ?? '') === 'YouTube' && in_array(($video['type'] ?? ''), ['Trailer','Teaser'], true) && !empty($video['key'])) {
            return 'https://www.youtube.com/watch?v=' . rawurlencode((string)$video['key']);
        }
    }
    return '';
}



function cs_player_tmdb_prepare_title(string $title, int $year = 0): array {
    $original = trim($title);
    $search = $original;

    // Extrai o ano do próprio título antes de remover ruídos.
    if ($year <= 0 && preg_match('/[\(\[]\s*((?:19|20)\d{2})\s*[\)\]]/u', $search, $m)) {
        $year = (int)$m[1];
    } elseif ($year <= 0 && preg_match('/(?:^|\D)((?:19|20)\d{2})\s*$/u', $search, $m)) {
        $candidateYear = (int)$m[1];
        $maxYear = (int)date('Y') + 2;
        if ($candidateYear >= 1900 && $candidateYear <= $maxYear) $year = $candidateYear;
    }

    // Remove prefixos técnicos comuns de fornecedores sem alterar o título exibido.
    // Ex.: "011ZE Nova Geracao (2026)" -> "Nova Geracao".
    $search = preg_replace('/^\s*(?=[A-Z0-9_-]{3,10}\s+)(?=[A-Z0-9_-]*[A-Z])(?=[A-Z0-9_-]*\d)[A-Z0-9_-]+\s+/u', '', $search) ?? $search;
    for ($i = 0; $i < 3; $i++) {
        $next = preg_replace('/^\s*(?:BR|PT|US|UK|LAT|LANCAMENTO|LANÇAMENTO|FILME|MOVIE|SERIE|SÉRIE|VOD)\s*[:|\-]\s*/iu', '', $search) ?? $search;
        if ($next === $search) break;
        $search = $next;
    }

    // Remove tags de qualidade/idioma e marcadores de episódio usados pelo provedor.
    $search = preg_replace('/[\[\(](?:4K|UHD|FHD|HD|1080P|720P|H265|HEVC|DUBLADO|LEGENDADO|DUAL(?: AUDIO)?|PT-BR|BR)[\]\)]/iu', ' ', $search) ?? $search;
    $search = preg_replace('/\b(?:4K|UHD|FHD|HD|1080P|720P|H265|HEVC|DUBLADO|LEGENDADO|DUAL(?: AUDIO)?|PT-BR)\b/iu', ' ', $search) ?? $search;
    $search = preg_replace('/\bS\d{1,2}\s*E\d{1,3}\b/iu', ' ', $search) ?? $search;
    $search = preg_replace('/\b\d{1,2}x\d{1,3}\b/iu', ' ', $search) ?? $search;
    $search = preg_replace('/[\(\[]\s*(?:19|20)\d{2}\s*[\)\]]/u', ' ', $search) ?? $search;

    $search = trim(preg_replace('/\s{2,}/u', ' ', $search) ?? $search, " \t\n\r\0\x0B-|:");
    if ($search === '') $search = $original;
    return ['original'=>$original, 'search'=>$search, 'year'=>$year];
}

function cs_player_tmdb_normalize_title(string $value): string {
    $value = mb_strtolower(trim($value), 'UTF-8');
    $value = preg_replace('/\b(19|20)\d{2}\b/u', ' ', $value) ?? $value;
    $value = preg_replace('/\b(4k|uhd|fhd|hd|1080p|720p|dual audio|dublado|legendado)\b/iu', ' ', $value) ?? $value;
    $value = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value;
    $value = preg_replace('/[^a-z0-9]+/i', ' ', $value) ?? $value;
    return trim(preg_replace('/\s+/', ' ', $value) ?? $value);
}

function cs_player_tmdb_match_score(array $row, string $type, string $title, int $year): int {
    if (!empty($row['adult'])) return -1000;
    $candidate = (string)($row[$type === 'series' ? 'name' : 'title'] ?? '');
    $original = (string)($row[$type === 'series' ? 'original_name' : 'original_title'] ?? '');
    $wanted = cs_player_tmdb_normalize_title($title);
    $a = cs_player_tmdb_normalize_title($candidate);
    $b = cs_player_tmdb_normalize_title($original);
    if ($wanted === '' || ($a === '' && $b === '')) return -1000;
    $score = 0;
    if ($wanted === $a || $wanted === $b) $score += 100;
    else {
        similar_text($wanted, $a, $pa);
        similar_text($wanted, $b, $pb);
        $score += (int)round(max($pa, $pb));
    }
    if ($year > 0) {
        $date = (string)($row[$type === 'series' ? 'first_air_date' : 'release_date'] ?? '');
        $candidateYear = preg_match('/^(\d{4})/', $date, $m) ? (int)$m[1] : 0;
        if ($candidateYear === $year) $score += 20;
        elseif ($candidateYear > 0 && abs($candidateYear - $year) === 1) $score += 8;
        elseif ($candidateYear > 0 && abs($candidateYear - $year) >= 3) $score -= 20;
    }
    return $score;
}

function cs_player_tmdb_enrich(string $type, string $title, int $year = 0, int $tmdbId = 0): ?array {
    $type = $type === 'series' ? 'series' : 'movie';
    $title = trim($title);
    if ($title === '' && $tmdbId <= 0) return null;
    $prepared = cs_player_tmdb_prepare_title($title, $year);
    $searchTitle = (string)$prepared['search'];
    $year = (int)$prepared['year'];
    // v2 invalida apenas o cache de pesquisa/matching antigo, sem tocar no catálogo.
    $cacheKey = sha1('v2|' . $type . '|' . mb_strtolower($searchTitle, 'UTF-8') . '|' . $year . '|' . $tmdbId . '|pt-BR');
    $cacheFile = cs_player_tmdb_cache_dir() . '/' . $cacheKey . '.json';
    if (is_file($cacheFile) && (time() - (int)@filemtime($cacheFile)) < 604800) {
        $cached = json_decode((string)@file_get_contents($cacheFile), true);
        if (is_array($cached)) return $cached;
    }

    $apiType = $type === 'series' ? 'tv' : 'movie';
    if ($tmdbId <= 0) {
        $query = ['query'=>$searchTitle, 'include_adult'=>'false', 'page'=>1, 'language'=>'pt-BR'];
        if ($year > 0) $query[$type === 'series' ? 'first_air_date_year' : 'primary_release_year'] = $year;
        $search = cs_player_tmdb_http('search/' . $apiType, $query);
        $results = is_array($search['results'] ?? null) ? $search['results'] : [];
        if (!$results && $year > 0) {
            unset($query[$type === 'series' ? 'first_air_date_year' : 'primary_release_year']);
            $search = cs_player_tmdb_http('search/' . $apiType, $query);
            $results = is_array($search['results'] ?? null) ? $search['results'] : [];
        }
        $best = null; $bestScore = -1000;
        foreach (array_slice($results, 0, 10) as $candidate) {
            if (!is_array($candidate) || empty($candidate['id'])) continue;
            $score = cs_player_tmdb_match_score($candidate, $type, $searchTitle, $year);
            if ($score > $bestScore) { $best = $candidate; $bestScore = $score; }
        }
        // Nunca usa o primeiro resultado apenas por existir. Sem correspondência forte,
        // devolve null para preservar os dados reais do catálogo.
        if (!is_array($best) || $bestScore < 82) {
            cs_player_tmdb_log('tmdb_match_rejected', ['type'=>$type,'title_hash'=>substr(hash('sha256',$title),0,12),'query_hash'=>substr(hash('sha256',$searchTitle),0,12),'year'=>$year,'score'=>$bestScore], 'info');
            return null;
        }
        $tmdbId = (int)$best['id'];
    }

    $details = cs_player_tmdb_http($apiType . '/' . $tmdbId, [
        'append_to_response'=>'videos,credits,images',
        'include_image_language'=>'pt,en,null',
        'language'=>'pt-BR',
    ]);
    if (!is_array($details)) return null;
    if (!empty($details['adult'])) { cs_player_tmdb_log('tmdb_adult_metadata_rejected', ['type'=>$type,'tmdb_id'=>$tmdbId], 'info'); return null; }
    $genres = [];
    foreach (($details['genres'] ?? []) as $genre) if (!empty($genre['name'])) $genres[] = (string)$genre['name'];
    $cast = [];
    foreach (array_slice($details['credits']['cast'] ?? [], 0, 8) as $person) if (!empty($person['name'])) $cast[] = (string)$person['name'];
    $yearValue = (string)($details[$type === 'series' ? 'first_air_date' : 'release_date'] ?? '');
    $runtime = $type === 'series' ? (int)(($details['episode_run_time'][0] ?? 0)) : (int)($details['runtime'] ?? 0);
    $payload = [
        'tmdb_id'=>$tmdbId,
        'type'=>$type,
        'title'=>(string)($details[$type === 'series' ? 'name' : 'title'] ?? $title),
        'original_title'=>(string)($details[$type === 'series' ? 'original_name' : 'original_title'] ?? ''),
        'overview'=>(string)($details['overview'] ?? ''),
        'poster'=>cs_player_tmdb_image($details['poster_path'] ?? '', 'w500'),
        'backdrop'=>cs_player_tmdb_image($details['backdrop_path'] ?? '', 'original'),
        'year'=>preg_match('/^(\d{4})/', $yearValue, $m) ? (int)$m[1] : 0,
        'rating'=>round((float)($details['vote_average'] ?? 0), 1),
        'genres'=>$genres,
        'runtime'=>$runtime,
        'cast'=>$cast,
        'trailer'=>cs_player_tmdb_best_video($details['videos'] ?? []),
        'tagline'=>(string)($details['tagline'] ?? ''),
        'status'=>(string)($details['status'] ?? ''),
        'fallback_only'=>true,
    ];
    @file_put_contents($cacheFile, json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), LOCK_EX);
    return $payload;
}

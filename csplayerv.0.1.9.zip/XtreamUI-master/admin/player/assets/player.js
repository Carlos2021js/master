const PlayerUI = (() => {
  const themeKey = 'csplayer_theme';
  let data = { content: { live: [], movies: [], series: [] }, categories: {}, server: { name: 'DNS' } };
  let currentType = 'home';
  let currentItem = null;
  let hls = null;
  let mpegtsPlayer = null;
  let castAvailable = false;
  let remotePlaybackWatchId = null;
  let stallTimer = null;
  let lastProgress = 0;
  let retries = 0;
  let recovering = false;
  let liveTsFallback = false;
  let recoverTimer = null;
  let hlsSoftRetries = 0;
  let hlsMediaRecoveries = 0;
  let recoveryHistory = [];
  let streamGeneration = 0;
  let heroItems = [];
  let heroIndex = 0;
  let heroTimer = null;
  let heroPausedUntil = 0;
  let seriesModalState = null;
  // Runtime Smart Delivery: Direct continua sendo a primeira tentativa quando configurado,
  // mas Canais/Filmes/Séries mudam automaticamente para o proxy interno se o navegador
  // ou o provedor bloquear CORS, redirects, MPEG-TS/HLS cross-origin ou o container direto.
  let forcedProxyFallback = false;
  let lastResolvedDelivery = 'auto';
  const tmdbCache = new Map();

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (match) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[match]));
  const imageOf = (item) => item?._highlight_image || item?.stream_icon || item?.cover || item?.cover_big || item?.movie_image || item?.backdrop_path?.[0] || '';
  const titleOf = (item) => item?.name || item?.title || item?.stream_display_name || 'Sem título';
  const typeOf = (item, type) => (type === 'mixed' || type === 'continue') ? (item?._type || 'movie') : type;
  const categoryIdOf = (item) => String(item?.category_id ?? item?.categoryId ?? '');
  const yearOf = (item) => {
    const value = String(item?.releaseDate || item?.release_date || item?.year || item?.added || '');
    const match = value.match(/(19|20)\d{2}/);
    return match ? Number(match[0]) : 0;
  };
  const dateScoreOf = (item) => {
    const value = item?.added || item?.last_modified || item?.releaseDate || item?.release_date || item?.year || 0;
    const numeric = Number(value);
    if (Number.isFinite(numeric) && numeric > 0) return numeric;
    const parsed = Date.parse(String(value));
    return Number.isFinite(parsed) ? parsed / 1000 : 0;
  };
  const newest = (items) => [...(Array.isArray(items) ? items : [])].sort((a, b) => (yearOf(b) - yearOf(a)) || (dateScoreOf(b) - dateScoreOf(a)) || titleOf(a).localeCompare(titleOf(b), 'pt-BR'));
  const currentYear = () => new Date().getFullYear();
  const normalizeCategoryName = (value) => String(value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  const categorySortKey = (category) => {
    const name = normalizeCategoryName(category?.category_name);
    const release = /\blancamentos?\b/.test(name);
    const yearMatch = name.match(/\b(19|20)\d{2}\b/);
    const year = yearMatch ? Number(yearMatch[0]) : 0;
    if (release) return [0, year ? -year : 0, name];
    if (/\b(novidades?|recentes?|mais recentes|novos?)\b/.test(name)) return [1, 0, name];
    return [2, 0, name];
  };
  const sortedCategories = (categories) => [...(Array.isArray(categories) ? categories : [])]
    .map((category, index) => ({ category, index, key: categorySortKey(category) }))
    .sort((a, b) => {
      for (let i = 0; i < 3; i += 1) {
        if (a.key[i] === b.key[i]) continue;
        if (typeof a.key[i] === 'string') return a.key[i].localeCompare(b.key[i], 'pt-BR');
        return a.key[i] - b.key[i];
      }
      return a.index - b.index;
    }).map((row) => row.category);
  const tmdbIdOf = (item) => Number(item?.tmdb_id || item?.info?.tmdb_id || 0) || 0;
  const hasText = (value) => typeof value === 'string' && value.trim().length > 0;
  const localOverviewOf = (item) => [item?._highlight_synopsis, item?.plot, item?.description, item?.overview].find(hasText) || '';
  const localBackdropOf = (item) => {
    const backdrop = Array.isArray(item?.backdrop_path) ? item.backdrop_path.find(hasText) : item?.backdrop_path;
    return hasText(backdrop) ? backdrop : '';
  };
  const localRatingOf = (item) => Number(item?.rating || item?.rating_5based || 0) || 0;

  const runtimeLabel = (minutes) => {
    const n = Number(minutes || 0); if (!n) return '';
    const h = Math.floor(n / 60), m = n % 60;
    return h ? `${h}h ${m ? `${m}min` : ''}`.trim() : `${m}min`;
  };
  async function tmdbMetadata(item, type) {
    if (!item || !['movie','series'].includes(type)) return null;
    const cacheKey = `${type}:${tmdbIdOf(item)}:${titleOf(item)}:${yearOf(item)}`;
    if (tmdbCache.has(cacheKey)) return tmdbCache.get(cacheKey);
    try {
      const qs = new URLSearchParams({ action:'tmdb_enrich', type, title:titleOf(item), year:String(yearOf(item)||0), tmdb_id:String(tmdbIdOf(item)||0) });
      const payload = await fetchJSON(`api.php?${qs.toString()}`);
      const meta = payload?.data || null;
      tmdbCache.set(cacheKey, meta);
      return meta;
    } catch (error) {
      tmdbCache.set(cacheKey, null);
      reportClientError(error, 'tmdb.enrich');
      return null;
    }
  }

  function safeRead(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch (error) { return fallback; }
  }


  function toast(message, tone = 'info', timeout = 2600) {
    const region = document.getElementById('toastRegion');
    if (!region || !message) return;
    const node = document.createElement('div');
    node.className = `player-toast ${tone}`;
    node.innerHTML = `<span>${tone === 'success' ? '✓' : tone === 'warning' ? '!' : tone === 'error' ? '×' : 'i'}</span><strong>${esc(message)}</strong>`;
    region.appendChild(node);
    requestAnimationFrame(() => node.classList.add('show'));
    setTimeout(() => { node.classList.remove('show'); setTimeout(() => node.remove(), 240); }, Math.max(1200, timeout));
  }

  function updateNetworkStatus() {
    const online = navigator.onLine !== false;
    const badge = document.getElementById('networkBadge');
    if (badge) {
      badge.textContent = online ? '● Online' : '● Offline';
      badge.classList.toggle('offline', !online);
    }
    document.body.classList.toggle('is-offline', !online);
    if (!online) toast('Sem conexão. O player tentará reconectar automaticamente.', 'warning', 4200);
  }

  window.addEventListener('online', () => {
    updateNetworkStatus();
    if (currentItem && !document.getElementById('playerModal')?.classList.contains('hidden')) {
      clearTimeout(recoverTimer); recovering = false; retries = 0; startStream();
    }
  });
  window.addEventListener('offline', updateNetworkStatus);

  function uniqueMixed(items) {
    const seen = new Set();
    return (Array.isArray(items) ? items : []).filter((entry) => {
      const item = entry?.item || entry;
      const type = entry?.type || item?._type || 'movie';
      const key = `${type}:${item?.stream_id || item?.series_id || item?.id || titleOf(item)}`;
      if (seen.has(key)) return false;
      seen.add(key); return true;
    });
  }

  function scoreOf(item) {
    const rating = Number(item?.rating || item?.rating_5based || 0) || 0;
    const year = yearOf(item) || 0;
    const freshness = Math.max(0, year - (currentYear() - 5));
    return rating * 100 + freshness * 8 + Math.min(20, dateScoreOf(item) / 1e9);
  }

  function topTenItems() {
    const mixed = [
      ...(data.content?.movies || []).map((item) => ({ ...item, _type: 'movie' })),
      ...(data.content?.series || []).map((item) => ({ ...item, _type: 'series' }))
    ];
    return uniqueMixed(mixed).sort((a, b) => scoreOf(b) - scoreOf(a)).slice(0, 10);
  }

  function allSearchItems() {
    return [
      ...(data.content?.live || []).map((item) => ({ ...item, _type: 'live' })),
      ...(data.content?.movies || []).map((item) => ({ ...item, _type: 'movie' })),
      ...(data.content?.series || []).map((item) => ({ ...item, _type: 'series' }))
    ];
  }

  function normalizeSearch(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  }

  function bindRailControls() {
    document.querySelectorAll('.rail').forEach((railNode) => {
      const track = railNode.querySelector('.rail-track');
      if (!track) return;
      railNode.querySelector('[data-rail-prev]')?.addEventListener('click', () => track.scrollBy({ left: -Math.max(280, track.clientWidth * .82), behavior: 'smooth' }));
      railNode.querySelector('[data-rail-next]')?.addEventListener('click', () => track.scrollBy({ left: Math.max(280, track.clientWidth * .82), behavior: 'smooth' }));
    });
  }

  function reportClientError(error, context = '') {
    try {
      const payload = JSON.stringify({
        message: String(error?.message || error || 'Erro não especificado'),
        stack: String(error?.stack || ''),
        context: String(context || '').slice(0, 160),
      });
      const blob = new Blob([payload], { type: 'application/json' });
      if (navigator.sendBeacon) {
        navigator.sendBeacon('client_error.php', blob);
      } else {
        fetch('client_error.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: payload, keepalive: true }).catch(() => {});
      }
    } catch (ignored) {}
  }

  window.addEventListener('error', (event) => reportClientError(event.error || event.message, 'window.error'));
  window.addEventListener('unhandledrejection', (event) => reportClientError(event.reason, 'unhandledrejection'));

  function themeFromStorage() {
    try {
      const stored = localStorage.getItem(themeKey);
      if (stored === 'light' || stored === 'dark') return stored;
    } catch (error) {}
    return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }

  function setTheme(theme) {
    const next = theme === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem(themeKey, next); } catch (error) {}
    const button = document.getElementById('themeToggle');
    if (button) {
      button.textContent = next === 'dark' ? '☀' : '☾';
      button.title = next === 'dark' ? 'Ativar modo claro' : 'Ativar modo escuro';
      button.setAttribute('aria-label', button.title);
      button.setAttribute('aria-pressed', String(next === 'dark'));
    }
  }

  function toggleTheme() {
    setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  }

  async function fetchJSON(url) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 35000);
    let response;
    try {
      response = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' }, signal: controller.signal });
    } catch (error) {
      reportClientError(error, `fetch:${url}`);
      if (error?.name === 'AbortError') throw new Error('O servidor demorou demais para responder. Tente novamente.');
      throw error;
    } finally {
      window.clearTimeout(timer);
    }
    let payload = {};
    try { payload = await response.json(); } catch (error) {}
    if (response.status === 401) {
      location.href = 'index.php';
      throw new Error('Sessão expirada.');
    }
    if (!response.ok || payload.ok === false) {
      throw new Error(payload.error || payload.message || `Falha na comunicação (${response.status}).`);
    }
    return payload;
  }

  function card(item, type, poster = false) {
    const cardType = typeOf(item, type);
    const id = item?.stream_id || item?.series_id || item?.id || 0;
    const image = imageOf(item);
    const progress = type === 'continue' && Number.isFinite(Number(item?._progress)) ? Math.max(0, Math.min(100, Number(item._progress))) : 0;
    const progressBar = progress > 0 ? `<span class="card-progress" aria-label="${Math.round(progress)}% assistido"><i style="width:${progress}%"></i></span>` : '';
    const badge = cardType === 'live' ? '<span class="card-badge live-badge">AO VIVO</span>' : (item?.rating ? `<span class="card-badge">★ ${esc(item.rating)}</span>` : '');
    const typeLabel = cardType === 'live' ? 'Canal' : cardType === 'series' ? 'Série' : 'Filme';
    return `<article class="media-card ${poster ? 'poster' : ''}" data-type="${esc(cardType)}" data-source="${type === 'mixed' ? (currentType === 'favorites' ? 'favorites' : 'mixed') : type === 'continue' ? 'continue' : esc(cardType)}" data-id="${esc(id)}" tabindex="0" role="button" aria-label="Abrir ${esc(titleOf(item))}">${image ? `<img loading="lazy" decoding="async" src="${esc(image)}" alt="" onerror="this.remove()">` : `<div class="fallback">${esc(titleOf(item))}</div>`}${badge}<div class="card-hover"><span class="card-play">▶</span><span class="card-title">${esc(titleOf(item))}</span><small>${[typeLabel, yearOf(item)||'', categoryNameOf(item,cardType)].filter(Boolean).map(esc).join(' · ')}</small></div><div class="caption">${esc(titleOf(item))}</div>${progressBar}</article>`;
  }

  function rail(title, items, type, poster = false) {
    if (!Array.isArray(items) || !items.length) return '';
    return `<section class="rail" data-type="${esc(type)}"><div class="rail-heading"><h2>${esc(title)}</h2><div class="rail-controls"><button type="button" data-rail-prev aria-label="Voltar">‹</button><button type="button" data-rail-next aria-label="Avançar">›</button></div></div><div class="rail-track ${poster ? 'poster-track' : ''}">${items.slice(0, 80).map((item) => card(item, type, poster)).join('')}</div></section>`;
  }

  function currentList(type) {
    if (type === 'live') return data.content.live || [];
    if (type === 'movie') return data.content.movies || [];
    if (type === 'series') return data.content.series || [];
    if (type === 'continue') return safeRead('csplayer_continue', []);
    return safeRead('csplayer_favorites', []);
  }

  function categoryRails(items, type, categories, poster) {
    if (!Array.isArray(categories)) return '';
    return sortedCategories(categories).slice(0, 24).map((category) => {
      const id = String(category?.category_id ?? '');
      const filtered = (Array.isArray(items) ? items : []).filter((item) => categoryIdOf(item) === id);
      return rail(category?.category_name || 'Categoria', newest(filtered), type, poster);
    }).join('');
  }

  function releaseYearRails(items, type, poster = true) {
    const list = Array.isArray(items) ? items : [];
    const groups = new Map();
    list.forEach((item) => {
      const y = yearOf(item);
      if (y >= 1900 && y <= currentYear() + 1) {
        if (!groups.has(y)) groups.set(y, []);
        groups.get(y).push(item);
      }
    });
    return [...groups.keys()].sort((a,b)=>b-a).slice(0, 12).map((y) =>
      rail(`Lançamentos ${y}`, newest(groups.get(y)), type, poster)
    ).join('');
  }

  function render() {
    const rails = document.getElementById('rails');
    if (!rails) return;
    let html = '';
    const live = newest(data.content.live);
    const movies = newest(data.content.movies);
    const series = newest(data.content.series);
    const year = currentYear();
    if (currentType === 'home') {
      const continueItems = safeRead('csplayer_continue', []).sort((a, b) => Number(b?._updatedAt || 0) - Number(a?._updatedAt || 0));
      html += rail('Continue assistindo', continueItems, 'continue', true);
      html += releaseYearRails(movies, 'movie', true);
      const top10 = topTenItems();
      if (top10.length) html += rail('Top 10 para você', top10, 'mixed', true).replace('class="rail-track poster-track"', 'class="rail-track poster-track top10-track"');
      html += rail('Canais ao vivo', live, 'live');
      html += categoryRails(live, 'live', data.categories?.live, false);
      html += categoryRails(movies, 'movie', data.categories?.movies, true);
      html += categoryRails(series, 'series', data.categories?.series, true);
    } else if (currentType === 'favorites') {
      const favorites = safeRead('csplayer_favorites', []);
      html = rail('Minha Lista', favorites, 'mixed', true) || '<div class="empty-state">Sua lista ainda está vazia.</div>';
    } else {
      const map = {
        live: ['Canais', live, 'live', false, data.categories?.live],
        movies: ['Filmes', movies, 'movie', true, data.categories?.movies],
        series: ['Séries', series, 'series', true, data.categories?.series]
      };
      const selected = map[currentType];
      if (selected) {
        if (currentType === 'movies' || currentType === 'series') {
          // Primeiro organiza automaticamente pelo ano real informado pelo servidor.
          // Depois mantém todas as categorias originais do servidor, sem removê-las.
          html += releaseYearRails(selected[1], selected[2], selected[3]);
          html += categoryRails(selected[1], selected[2], selected[4], selected[3]);
          html += rail(currentType === 'movies' ? 'Todos os filmes' : 'Todas as séries', selected[1], selected[2], selected[3]);
        } else {
          html += rail(selected[0], selected[1], selected[2], selected[3]);
          html += categoryRails(selected[1], selected[2], selected[4], selected[3]);
        }
      }
    }
    rails.innerHTML = html || '<div class="empty-state">Nenhum conteúdo disponível no momento.</div>';
    bindCards();
    bindRailControls();
    fillCategories();
  }

  function bindCards() {
    document.querySelectorAll('.media-card').forEach((element) => {
      const open = () => {
        const type = element.dataset.type;
        const source = element.dataset.source;
        const id = String(element.dataset.id);
        const list = source === 'favorites' ? safeRead('csplayer_favorites', []) : source === 'continue' ? safeRead('csplayer_continue', []) : source === 'mixed' ? allSearchItems() : currentList(type);
        const item = list.find((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === id);
        if (item) showInfo(item, typeOf(item, type));
      };
      element.addEventListener('click', open);
      element.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(); }
      });
    });
  }

  function fillCategories() {
    const select = document.getElementById('categoryFilter');
    if (!select) return;
    const key = currentType === 'movies' ? 'movies' : currentType === 'series' ? 'series' : 'live';
    const categories = currentType === 'favorites' ? [] : sortedCategories(data.categories?.[key] || []);
    select.disabled = !categories.length;
    select.innerHTML = '<option value="">Todas as categorias</option>' + categories.map((category) => `<option value="${esc(category.category_id)}">${esc(category.category_name)}</option>`).join('');
  }

  function categoryNameOf(item, type) {
    const key = type === 'movie' ? 'movies' : type === 'series' ? 'series' : 'live';
    const category = (data.categories?.[key] || []).find((entry) => String(entry?.category_id ?? '') === categoryIdOf(item));
    return category?.category_name || '';
  }

  function setHero(item, type) {
    if (!item) return;
    currentItem = { item, type: typeOf(item, type) };
    const normalizedType = currentItem.type;
    const title = document.getElementById('heroTitle');
    const meta = document.getElementById('heroMeta');
    const description = document.getElementById('heroDesc');
    const hero = document.getElementById('hero');
    if (title) title.textContent = titleOf(item);
    if (meta) meta.textContent = [normalizedType === 'live' ? 'Ao vivo' : normalizedType === 'movie' ? 'Filme' : 'Série', categoryNameOf(item, normalizedType), yearOf(item) || '', item.rating ? `★ ${item.rating}` : ''].filter(Boolean).join(' · ');
    if (description) description.textContent = localOverviewOf(item) || 'Sinopse não disponível.';
    const image = Array.isArray(item.backdrop_path) ? item.backdrop_path[0] : (item.backdrop_path || imageOf(item));
    if (hero && image) hero.style.backgroundImage = `url("${String(image).replace(/["\\]/g, '')}")`;
  }

  async function enrichHero(item, type) {
    const normalizedType = typeOf(item, type);
    if (!['movie','series'].includes(normalizedType)) return;
    const meta = await tmdbMetadata(item, normalizedType);
    if (!meta || !currentItem || String(currentItem.item?.stream_id || currentItem.item?.series_id || '') !== String(item?.stream_id || item?.series_id || '')) return;
    const hero = document.getElementById('hero');
    if (hero && !localBackdropOf(item) && !imageOf(item) && meta.backdrop) hero.style.backgroundImage = `url("${String(meta.backdrop).replace(/["\\]/g, '')}")`;
    const desc = document.getElementById('heroDesc'); if (desc && !localOverviewOf(item) && meta.overview) desc.textContent = meta.overview;
    const pieces = [normalizedType === 'movie' ? 'Filme' : 'Série', yearOf(item) || meta.year || '', categoryNameOf(item, normalizedType) || (meta.genres || []).slice(0,3).join(' · '), runtimeLabel(meta.runtime)].filter(Boolean);
    const metaEl = document.getElementById('heroMeta'); if (metaEl) metaEl.textContent = pieces.join(' · ');
    const score = document.getElementById('heroMatch'); if (score && !localRatingOf(item)) score.textContent = meta.rating ? `★ ${meta.rating}` : '';
    const eye = document.getElementById('heroEyebrow'); if (eye) eye.textContent = normalizedType === 'movie' ? 'FILME EM DESTAQUE' : 'SÉRIE EM DESTAQUE';
  }

  function stopHeroTimer() {
    if (heroTimer) { clearTimeout(heroTimer); heroTimer = null; }
    document.getElementById('heroProgress')?.classList.remove('running');
  }

  function heroIntervalMs() {
    return Math.max(4, Number(window.CS_PLAYER_CONFIG?.heroInterval || 8)) * 1000;
  }

  function restartHeroProgress() {
    const progress = document.getElementById('heroProgress');
    if (!progress) return;
    progress.classList.remove('running');
    void progress.offsetWidth;
    progress.style.setProperty('--hero-duration', `${heroIntervalMs() / 1000}s`);
    if (window.CS_PLAYER_CONFIG?.heroAutoplay !== false && heroItems.length > 1 && !document.hidden) progress.classList.add('running');
  }

  function scheduleHeroRotation(delayOverride = 0) {
    stopHeroTimer();
    if (window.CS_PLAYER_CONFIG?.heroAutoplay === false || heroItems.length < 2 || document.hidden) return;
    const now = Date.now();
    const pauseRemaining = Math.max(0, heroPausedUntil - now);
    const delay = Math.max(250, Number(delayOverride) || pauseRemaining || heroIntervalMs());
    if (!pauseRemaining) restartHeroProgress();
    heroTimer = setTimeout(() => {
      if (document.hidden) return;
      const remaining = Math.max(0, heroPausedUntil - Date.now());
      if (remaining > 0) { scheduleHeroRotation(remaining); return; }
      showHeroAt(heroIndex + 1, true);
    }, delay);
  }

  function renderHeroDots() {
    const dots = document.getElementById('heroDots');
    if (!dots) return;
    if (heroItems.length <= 1) { dots.innerHTML = ''; return; }
    const visible = Math.min(heroItems.length, 12);
    const start = Math.max(0, Math.min(heroIndex - Math.floor(visible / 2), heroItems.length - visible));
    dots.innerHTML = heroItems.slice(start, start + visible).map((_, localIndex) => {
      const index = start + localIndex;
      return `<button type="button" class="hero-dot ${index === heroIndex ? 'active' : ''}" data-hero-index="${index}" aria-label="Ir ao destaque ${index + 1}" title="${esc(titleOf(heroItems[index].item))}"></button>`;
    }).join('');
    dots.querySelectorAll('[data-hero-index]').forEach((button) => button.addEventListener('click', () => selectHeroManually(Number(button.dataset.heroIndex))));
  }

  function renderHeroSelector() {
    const list = document.getElementById('heroSelectorList');
    if (!list) return;
    list.innerHTML = heroItems.map((entry, index) => {
      const item = entry.item || {};
      const type = typeOf(item, entry.type);
      const label = type === 'live' ? 'Canal' : type === 'series' ? 'Série' : 'Filme';
      const image = imageOf(item);
      return `<button type="button" class="hero-selector-item ${index === heroIndex ? 'active' : ''}" data-hero-pick="${index}">${image ? `<img src="${esc(image)}" alt="" loading="lazy" onerror="this.remove()">` : '<span class="hero-selector-fallback">▶</span>'}<span><strong>${esc(titleOf(item))}</strong><small>${esc(label)} · Destaque ${index + 1}</small></span></button>`;
    }).join('') || '<div class="hero-selector-empty">Nenhum destaque disponível.</div>';
    list.querySelectorAll('[data-hero-pick]').forEach((button) => button.addEventListener('click', () => {
      selectHeroManually(Number(button.dataset.heroPick));
      closeHeroSelector();
    }));
  }

  function openHeroSelector() {
    const panel = document.getElementById('heroSelector');
    const button = document.getElementById('heroSelectorButton');
    renderHeroSelector();
    panel?.classList.remove('hidden');
    button?.setAttribute('aria-expanded', 'true');
  }

  function closeHeroSelector() {
    document.getElementById('heroSelector')?.classList.add('hidden');
    document.getElementById('heroSelectorButton')?.setAttribute('aria-expanded', 'false');
  }

  function selectHeroManually(index) {
    heroPausedUntil = Date.now() + 8000;
    showHeroAt(index, false);
    scheduleHeroRotation(Math.max(250, heroPausedUntil - Date.now()));
  }

  function showHeroAt(index, automatic = false) {
    if (!heroItems.length) return;
    heroIndex = (Number(index) + heroItems.length) % heroItems.length;
    const pick = heroItems[heroIndex];
    const hero = document.getElementById('hero');
    if (hero) hero.classList.add('hero-switching');
    window.setTimeout(() => {
      setHero(pick.item, pick.type);
      enrichHero(pick.item, pick.type);
      renderHeroDots();
      renderHeroSelector();
      if (hero) hero.classList.remove('hero-switching');
    }, automatic ? 140 : 60);
    if (automatic) scheduleHeroRotation();
  }

  function setupHeroCarousel(items) {
    stopHeroTimer();
    heroItems = Array.isArray(items) ? items.filter((entry) => entry?.item) : [];
    if (window.CS_PLAYER_CONFIG?.heroOrder === 'random' && heroItems.length > 1) {
      heroItems = [...heroItems].sort(() => Math.random() - 0.5);
    }
    heroIndex = 0;
    heroPausedUntil = 0;
    renderHeroDots();
    renderHeroSelector();
    if (heroItems.length) showHeroAt(0, false);
    document.getElementById('heroPrev')?.addEventListener('click', () => selectHeroManually(heroIndex - 1));
    document.getElementById('heroNext')?.addEventListener('click', () => selectHeroManually(heroIndex + 1));
    document.getElementById('heroSelectorButton')?.addEventListener('click', (event) => {
      event.preventDefault();
      const panel = document.getElementById('heroSelector');
      if (panel?.classList.contains('hidden')) openHeroSelector(); else closeHeroSelector();
    });
    document.getElementById('heroSelectorClose')?.addEventListener('click', closeHeroSelector);

    const hero = document.getElementById('hero');
    if (hero) {
      let touchX = null;
      hero.addEventListener('touchstart', (event) => { touchX = event.touches?.[0]?.clientX ?? null; }, { passive: true });
      hero.addEventListener('touchend', (event) => {
        if (touchX === null) return;
        const endX = event.changedTouches?.[0]?.clientX ?? touchX;
        const delta = endX - touchX;
        touchX = null;
        if (Math.abs(delta) >= 45) selectHeroManually(heroIndex + (delta < 0 ? 1 : -1));
      }, { passive: true });
    }
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) stopHeroTimer(); else scheduleHeroRotation();
    });
    document.addEventListener('click', (event) => {
      const panel = document.getElementById('heroSelector');
      const button = document.getElementById('heroSelectorButton');
      if (panel && button && !panel.classList.contains('hidden') && !panel.contains(event.target) && !button.contains(event.target)) closeHeroSelector();
    });
    scheduleHeroRotation();
  }

  function seriesProgressKey(seriesId) { return `csplayer_series_progress:${seriesId}`; }

  function readSeriesProgress(seriesId) {
    try { return JSON.parse(localStorage.getItem(seriesProgressKey(seriesId)) || '{}') || {}; } catch (error) { return {}; }
  }

  function saveSeriesProgress(seriesId, season, episode) {
    try {
      localStorage.setItem(seriesProgressKey(seriesId), JSON.stringify({
        season: String(season),
        episode_id: String(episode?.id || episode?.stream_id || ''),
        episode_num: Number(episode?.episode_num || episode?.episode_number || 0),
        title: titleOf(episode),
        updated_at: Date.now()
      }));
    } catch (error) {}
  }

  function episodeNumberOf(episode, index = 0) {
    const n = Number(episode?.episode_num || episode?.episode_number || episode?.sort || episode?.num || 0);
    return n > 0 ? n : index + 1;
  }

  function episodeImageOf(episode, series) {
    return episode?.info?.movie_image || episode?.movie_image || episode?.stream_icon || imageOf(series) || '';
  }

  function episodeOverviewOf(episode) {
    return episode?.info?.plot || episode?.plot || episode?.description || episode?.overview || '';
  }

  function closeSeriesModal() {
    document.getElementById('seriesModal')?.classList.add('hidden');
    seriesModalState = null;
  }

  function renderSeriesSeason(season) {
    if (!seriesModalState) return;
    const { series, info, episodes } = seriesModalState;
    const seasonKey = String(season);
    const list = Array.isArray(episodes?.[seasonKey]) ? episodes[seasonKey] : [];
    seriesModalState.season = seasonKey;
    document.querySelectorAll('#seriesSeasonTabs [data-season]').forEach((button) => {
      button.classList.toggle('active', String(button.dataset.season) === seasonKey);
      button.setAttribute('aria-selected', String(String(button.dataset.season) === seasonKey));
    });
    const target = document.getElementById('seriesEpisodes');
    if (!target) return;
    const progress = readSeriesProgress(series.series_id || series.id);
    if (!list.length) {
      target.innerHTML = '<div class="series-empty">Nenhum episódio disponível nesta temporada.</div>';
      return;
    }
    target.innerHTML = list.map((episode, index) => {
      const eid = String(episode?.id || episode?.stream_id || '');
      const number = episodeNumberOf(episode, index);
      const active = progress.episode_id && String(progress.episode_id) === eid;
      const img = episodeImageOf(episode, series);
      const overview = episodeOverviewOf(episode);
      const ext = String(episode?.container_extension || '').toUpperCase();
      return `<button class="series-episode ${active ? 'is-current' : ''}" type="button" data-episode-index="${index}" aria-label="Assistir episódio ${number}: ${esc(titleOf(episode))}">
        <span class="series-episode-thumb">${img ? `<img loading="lazy" decoding="async" src="${esc(img)}" alt="" onerror="this.remove()">` : '<span class="series-episode-fallback">▶</span>'}<span class="series-episode-play">▶</span></span>
        <span class="series-episode-copy"><span class="series-episode-line"><strong><b>E${String(number).padStart(2,'0')}</b> ${esc(titleOf(episode))}</strong>${active ? '<em>Continuar</em>' : ''}</span>${overview ? `<small>${esc(overview)}</small>` : '<small>Toque para assistir este episódio.</small>'}<span class="series-episode-meta">${[ext, episode?.added ? 'Disponível' : ''].filter(Boolean).map(esc).join(' · ')}</span></span>
      </button>`;
    }).join('');
    target.querySelectorAll('[data-episode-index]').forEach((button) => button.addEventListener('click', () => {
      const episode = list[Number(button.dataset.episodeIndex)];
      if (!episode) return;
      saveSeriesProgress(series.series_id || series.id, seasonKey, episode);
      closeSeriesModal();
      play({ ...episode, _episode: true, _series_id: series.series_id || series.id, _series_name: titleOf(series), stream_id: episode.id || episode.stream_id, name: episode.title || episode.name || episode.stream_display_name || `Episódio ${episodeNumberOf(episode)}` }, 'series');
    }));
  }

  async function openSeriesModal(item) {
    const modal = document.getElementById('seriesModal');
    const body = document.getElementById('seriesModalBody');
    if (!modal || !body) return;
    modal.classList.remove('hidden');
    body.innerHTML = '<div class="series-loading"><span class="loading-spinner"></span><strong>Carregando temporadas e episódios...</strong></div>';
    try {
      const response = await fetchJSON(`api.php?action=series_info&id=${encodeURIComponent(item.series_id || item.id)}`);
      const payload = response.data || {};
      const episodes = payload.episodes || {};
      const seasonKeys = Object.keys(episodes).filter((key) => Array.isArray(episodes[key]) && episodes[key].length).sort((a,b)=>Number(a)-Number(b));
      const info = payload.info || {};
      const progress = readSeriesProgress(item.series_id || item.id);
      const initialSeason = seasonKeys.includes(String(progress.season)) ? String(progress.season) : (seasonKeys[0] || '');
      seriesModalState = { series: item, info, episodes, season: initialSeason };
      const cover = info.cover || imageOf(item);
      const backdrop = (Array.isArray(info.backdrop_path) ? info.backdrop_path[0] : info.backdrop_path) || localBackdropOf(item) || cover;
      const plot = info.plot || localOverviewOf(item) || 'Sinopse não disponível.';
      const rating = info.rating || item.rating || '';
      const release = info.releaseDate || item.releaseDate || item.release_date || '';
      const genre = info.genre || item.genre || categoryNameOf(item, 'series');
      const totalEpisodes = seasonKeys.reduce((sum,key)=>sum+(episodes[key]?.length||0),0);
      body.innerHTML = `<section class="series-detail-hero" ${backdrop ? `style="background-image:url('${esc(backdrop)}')"` : ''}>
        <div class="series-detail-shade"></div>
        <div class="series-detail-content">${cover ? `<img class="series-detail-cover" src="${esc(cover)}" alt="Capa de ${esc(titleOf(item))}" onerror="this.remove()">` : ''}<div class="series-detail-copy"><span class="eyebrow">SÉRIE</span><h2>${esc(info.name || titleOf(item))}</h2><div class="series-detail-meta">${[yearOf(item) || (String(release).match(/(19|20)\d{2}/)?.[0] || ''), rating ? `★ ${rating}` : '', `${seasonKeys.length} temporada${seasonKeys.length===1?'':'s'}`, `${totalEpisodes} episódio${totalEpisodes===1?'':'s'}`, genre].filter(Boolean).map(esc).join(' · ')}</div><p>${esc(plot)}</p><div class="series-smart-status"><span>✓ Temporadas organizadas automaticamente</span>${progress.episode_id ? '<span>↻ Continue de onde parou</span>' : ''}</div></div></div>
      </section><section class="series-browser"><div class="series-browser-head"><div><span class="eyebrow">EPISÓDIOS</span><h3>Escolha a temporada</h3></div><span class="series-count">${totalEpisodes} episódios</span></div><div id="seriesSeasonTabs" class="series-season-tabs" role="tablist">${seasonKeys.map((key) => `<button type="button" role="tab" data-season="${esc(key)}" class="${String(key)===initialSeason?'active':''}" aria-selected="${String(key)===initialSeason?'true':'false'}">Temporada ${esc(key)}</button>`).join('')}</div><div id="seriesEpisodes" class="series-episodes"></div></section>`;
      if (!seasonKeys.length) {
        document.getElementById('seriesEpisodes').innerHTML = '<div class="series-empty">Esta série ainda não possui temporadas ou episódios disponíveis no servidor.</div>';
        return;
      }
      document.querySelectorAll('#seriesSeasonTabs [data-season]').forEach((button) => button.addEventListener('click', () => renderSeriesSeason(button.dataset.season)));
      renderSeriesSeason(initialSeason);
      const current = document.querySelector('#seriesEpisodes .is-current');
      if (current) setTimeout(() => current.scrollIntoView({ block:'nearest', behavior:'smooth' }), 80);
    } catch (error) {
      body.innerHTML = `<div class="series-empty"><strong>Não foi possível carregar os episódios.</strong><span>${esc(error?.message || 'Tente novamente.')}</span><button type="button" id="seriesRetryBtn">Tentar novamente</button></div>`;
      document.getElementById('seriesRetryBtn')?.addEventListener('click', () => openSeriesModal(item));
    }
  }

  async function showInfo(item, type) {
    const normalizedType = typeOf(item, type);
    if (normalizedType === 'series') { await openSeriesModal(item); return; }
    setHero(item, normalizedType);
    enrichHero(item, normalizedType);
    const body = document.getElementById('infoBody');
    if (!body) return;
    const isFavorite = safeRead('csplayer_favorites', []).some((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === String(item?.stream_id || item?.series_id || item?.id));
    const initialImage = imageOf(item);
    body.innerHTML = `<div class="detail-hero" ${initialImage ? `style="background-image:url('${esc(initialImage)}')"` : ''}><div class="detail-gradient"></div><div class="detail-copy"><span class="eyebrow">${normalizedType === 'live' ? 'TV AO VIVO' : normalizedType === 'movie' ? 'FILME' : 'SÉRIE'}</span><h2>${esc(titleOf(item))}</h2><div class="detail-meta" id="detailMeta">${[yearOf(item)||'', item.rating ? `★ ${item.rating}` : '', categoryNameOf(item, normalizedType)].filter(Boolean).map(esc).join(' · ')}</div><p id="detailOverview">${esc(localOverviewOf(item) || 'Sinopse não disponível.')}</p><div class="hero-buttons"><button class="light-btn" id="infoPlay" type="button">▶ Assistir</button><button class="round-action" id="favoriteBtn" type="button" title="Minha Lista">${isFavorite ? '✓' : '＋'}</button><a class="round-action hidden" id="trailerBtn" target="_blank" rel="noopener" title="Trailer">▶</a></div><div class="detail-extra" id="detailExtra"></div></div></div>`;
    document.getElementById('infoModal')?.classList.remove('hidden');
    document.getElementById('infoPlay')?.addEventListener('click', () => play(item, normalizedType));
    document.getElementById('favoriteBtn')?.addEventListener('click', () => {
      const added = favorite(item, normalizedType);
      const button = document.getElementById('favoriteBtn'); if (button) button.textContent = added ? '✓' : '＋';
    });
    if (['movie','series'].includes(normalizedType)) {
      const meta = await tmdbMetadata(item, normalizedType);
      if (meta) {
        const heroNode = body.querySelector('.detail-hero'); if (heroNode && !initialImage && meta.backdrop) heroNode.style.backgroundImage = `url("${String(meta.backdrop).replace(/["\\]/g,'')}")`;
        const overview = document.getElementById('detailOverview'); if (overview && !localOverviewOf(item) && meta.overview) overview.textContent = meta.overview;
        const metaLine = document.getElementById('detailMeta'); if (metaLine) metaLine.textContent = [localRatingOf(item) ? `★ ${localRatingOf(item)}` : (meta.rating ? `★ ${meta.rating}` : ''), yearOf(item) || meta.year || '', runtimeLabel(meta.runtime), categoryNameOf(item, normalizedType) || (meta.genres || []).slice(0,3).join(' · ')].filter(Boolean).join(' · ');
        const extra = document.getElementById('detailExtra'); if (extra) extra.innerHTML = `${meta.cast?.length ? `<p><b>Elenco:</b> ${esc(meta.cast.join(', '))}</p>` : ''}${meta.tagline ? `<p class="tagline">${esc(meta.tagline)}</p>` : ''}`;
        const trailer = document.getElementById('trailerBtn'); if (trailer && meta.trailer) { trailer.href = meta.trailer; trailer.classList.remove('hidden'); }
      }
    }
  }

  function favorite(item, type) {
    const favorites = safeRead('csplayer_favorites', []);
    const id = String(item?.stream_id || item?.series_id || item?.id);
    const index = favorites.findIndex((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === id);
    if (index >= 0) { favorites.splice(index, 1); localStorage.setItem('csplayer_favorites', JSON.stringify(favorites)); toast('Removido da Minha Lista.', 'info'); return false; }
    favorites.push({ ...item, _type: type });
    localStorage.setItem('csplayer_favorites', JSON.stringify(favorites.slice(-100)));
    toast('Adicionado à Minha Lista.', 'success');
    return true;
  }

  async function play(item, type) {
    let normalizedType = typeOf(item, type);
    if (normalizedType === 'series' && !item?._episode) {
      await openSeriesModal(item);
      return;
    }
    currentItem = { item, type: normalizedType };
    closeInfo();
    document.getElementById('playerModal')?.classList.remove('hidden');
    document.getElementById('playerTitle').textContent = titleOf(item);
    document.getElementById('playerStatus').textContent = data.server?.name || 'DNS';
    retries = 0;
    hlsSoftRetries = 0; hlsMediaRecoveries = 0; recoveryHistory = [];
    liveTsFallback = false;
    forcedProxyFallback = false;
    lastResolvedDelivery = 'auto';
    playPreroll(startStream);
  }

  function normalizedStreamExt(item = currentItem?.item || {}) {
    const explicit = String(item.container_extension || item.container || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    if (explicit) return explicit === 'mpegts' ? 'ts' : explicit;
    const source = String(item.direct_source || item.stream_url || '');
    const match = source.match(/\.([a-z0-9]{2,6})(?:$|[?#])/i);
    return match ? (match[1].toLowerCase() === 'mpegts' ? 'ts' : match[1].toLowerCase()) : '';
  }

  function streamUrl(forceFormat = '') {
    const item = currentItem.item;
    const id = item.stream_id || item.id;
    const ext = normalizedStreamExt(item);
    let requested = String(forceFormat || '').toLowerCase();
    if (!requested && currentItem.type === 'live' && (liveTsFallback || ext === 'ts')) requested = 'ts';
    if (!requested && ext === 'mkv') requested = 'remux';
    const format = requested ? `&format=${encodeURIComponent(requested)}` : '';
    // O backend é a autoridade da política normal de entrega. O frontend só
    // envia um override explícito do item ou força proxy após erro de Direct.
    const itemDelivery=String(item?._delivery_mode||'inherit');
    let delivery=itemDelivery!=='inherit'?itemDelivery:'auto';
    if (forcedProxyFallback && delivery === 'auto') delivery = 'proxy';
    lastResolvedDelivery = String(delivery || 'auto');
    const endpoint=currentItem.type==='live'?'live_stream.php':'vod_stream.php';
    return `${endpoint}?type=${encodeURIComponent(currentItem.type)}&id=${encodeURIComponent(id)}&ext=${encodeURIComponent(ext)}${format}&delivery=${encodeURIComponent(delivery||'auto')}&v=${Date.now()}`;
  }

  function switchDirectToProxy(reason = '') {
    if (forcedProxyFallback || lastResolvedDelivery !== 'direct' || !currentItem) return false;
    forcedProxyFallback = true;
    const label = currentItem.type === 'live' ? 'canal' : (currentItem.type === 'series' ? 'episódio' : 'filme');
    setHealth(`Direct indisponível para este ${label}. Ativando compatibilidade automática…`, false);
    try { destroyHls(true); } catch (_) {}
    try { if (mpegtsPlayer) { mpegtsPlayer.destroy(); mpegtsPlayer = null; } } catch (_) {}
    try {
      const video = document.getElementById('video');
      if (video) { video.pause(); video.removeAttribute('src'); video.load(); }
    } catch (_) {}
    reportClientError(new Error(`Smart Delivery fallback: ${reason || 'direct_failed'}`), 'player.direct_to_proxy');
    setTimeout(() => { if (currentItem) startStream(); }, 180);
    return true;
  }

  function hlsOptions() {
    const retryLimit = Math.max(2, Number(window.CS_PLAYER_CONFIG?.retries || 7));
    return {
      enableWorker: true,
      lowLatencyMode: false,
      backBufferLength: 45,
      maxBufferLength: 40,
      maxMaxBufferLength: 90,
      maxBufferHole: 0.8,
      highBufferWatchdogPeriod: 3,
      nudgeOffset: 0.12,
      nudgeMaxRetry: 4,
      manifestLoadingTimeOut: 12000,
      manifestLoadingMaxRetry: retryLimit,
      manifestLoadingRetryDelay: 700,
      levelLoadingTimeOut: 12000,
      levelLoadingMaxRetry: retryLimit,
      fragLoadingTimeOut: 20000,
      fragLoadingMaxRetry: retryLimit,
      fragLoadingRetryDelay: 650,
      startFragPrefetch: true,
      testBandwidth: true,
    };
  }

  function adContentKey(){if(!currentItem)return'';const i=currentItem.item||{};return `${currentItem.type}:${i.stream_id||i.id||i.series_id||0}`;}
  function shouldPlayAd(){const c=window.CS_PLAYER_CONFIG||{},i=currentItem?.item||{},m=String(i._ad_mode||'inherit'),on=m==='on'?true:(m==='off'?false:!!c.adsEnabled);if(!on||(!String(i._ad_url||'').trim()&&!c.adsHasGlobal))return false;const f=String(c.adsFrequency||'session'),k=`csplayer_ad_seen:${f==='content'?adContentKey():'session'}`;return f==='always'||sessionStorage.getItem(k)!=='1';}
  function markAdSeen(){const c=window.CS_PLAYER_CONFIG||{},f=String(c.adsFrequency||'session');if(f==='always')return;try{sessionStorage.setItem(`csplayer_ad_seen:${f==='content'?adContentKey():'session'}`,'1')}catch(e){}}
  function playPreroll(next){if(!shouldPlayAd()){next();return}const l=document.getElementById('adLayer'),v=document.getElementById('adVideo'),im=document.getElementById('adImage'),sk=document.getElementById('adSkipBtn'),cd=document.getElementById('adCountdown'),cl=document.getElementById('adClick');if(!l||!v||!im||!sk){next();return}const c=window.CS_PLAYER_CONFIG||{},i=currentItem?.item||{},id=i.stream_id||i.id||i.series_id||0,u=`ad_proxy.php?type=${encodeURIComponent(currentItem.type)}&id=${encodeURIComponent(id)}&v=${Date.now()}`,custom=String(i._ad_url||''),image=String(c.adsType||'auto')==='image'||(String(c.adsType||'auto')==='auto'&&/\.(jpe?g|png|webp|gif)(?:$|[?#])/i.test(custom));let done=false,remain=Math.max(0,Number(c.adsSkip||5)),timer=null,st=null;const end=()=>{if(done)return;done=true;markAdSeen();clearInterval(timer);clearInterval(st);try{v.pause();v.removeAttribute('src');v.load()}catch(e){}im.removeAttribute('src');l.classList.add('hidden');sk.classList.add('hidden');next()};sk.onclick=end;sk.classList.toggle('hidden',remain>0);if(cl){const h=String(c.adsClick||'').trim();if(h){cl.href=h;cl.style.pointerEvents='auto'}else{cl.removeAttribute('href');cl.style.pointerEvents='none'}}l.classList.remove('hidden');if(remain>0){if(cd)cd.textContent=`Você poderá pular em ${remain}s`;st=setInterval(()=>{remain-=1;if(remain<=0){clearInterval(st);sk.classList.remove('hidden');if(cd)cd.textContent=''}else if(cd)cd.textContent=`Você poderá pular em ${remain}s`},1000)}else sk.classList.remove('hidden');if(image){v.classList.add('hidden');im.classList.remove('hidden');im.src=u;let sec=Math.max(3,Number(c.adsImageSeconds||8));timer=setInterval(()=>{sec-=1;if(cd&&remain<=0)cd.textContent=`Conteúdo começa em ${Math.max(0,sec)}s`;if(sec<=0)end()},1000);im.onerror=end}else{im.classList.add('hidden');v.classList.remove('hidden');v.src=u;v.onended=end;v.onerror=end;v.play().catch(()=>{sk.classList.remove('hidden');if(cd)cd.textContent='Pule o anúncio para continuar'})}}


  async function loadLiveEpg(item) {
    const g=window.CS_PLAYER_CONFIG||{};
    if(!g.liveEpgEnabled) return;
    const channel=String(item?.epg_channel_id||item?.epg_id||'').trim();
    if(!channel) return;
    try{
      const r=await fetchJSON(`api.php?action=epg_now&channel=${encodeURIComponent(channel)}`);
      const cur=r?.data?.current, next=r?.data?.next;
      const status=document.getElementById('playerStatus');
      if(status&&cur?.title) status.textContent=`Agora: ${cur.title}${next?.title?' · Próx.: '+next.title:''}`;
    }catch(e){}
  }

  function livePlaybackExt(item) {
    let ext=normalizedStreamExt(item);
    const g=window.CS_PLAYER_CONFIG||{};
    if(!ext && String(g.providerMode||'')==='m3u' && String(g.m3uOutput||'mpegts')==='mpegts' && g.livePreferTs!==false) ext='ts';
    if(ext==='mpegts') ext='ts';
    return ext;
  }

  function startLiveEngine(video, generation) {
    const ext=livePlaybackExt(currentItem.item);
    const isTs=liveTsFallback || ext==='ts';
    const url=streamUrl(isTs?'ts':'');
    destroyHls(true);
    loadLiveEpg(currentItem.item);
    if(isTs){
      setHealth('Conectando ao canal MPEG-TS…',false);
      if(window.mpegts?.isSupported?.()){
        try{
          mpegtsPlayer=mpegts.createPlayer({type:'mpegts',isLive:true,url},{
            enableWorker:true,lazyLoad:false,liveBufferLatencyChasing:true,
            liveBufferLatencyMaxLatency:3,liveBufferLatencyMinRemain:0.8,
            autoCleanupSourceBuffer:true,autoCleanupMaxBackwardDuration:30,
            autoCleanupMinBackwardDuration:10,stashInitialSize:128*1024
          });
          mpegtsPlayer.attachMediaElement(video);mpegtsPlayer.load();
          mpegtsPlayer.on(mpegts.Events.ERROR,()=>{if(generation===streamGeneration&&!switchDirectToProxy('mpegts_network_or_cors'))recover();});
          video.play().then(()=>setHealth('Canal ao vivo · MPEG-TS',true)).catch(()=>{});
          return;
        }catch(error){reportClientError(error,'live.mpegts.start');}
      }
      // Fallback nativo para TVs/browsers que suportam TS diretamente.
      video.onerror=()=>{if(generation===streamGeneration&&!switchDirectToProxy('live_native_media_error'))recover();};
      video.src=url;video.preload='auto';video.play().then(()=>setHealth('Canal ao vivo',true)).catch((e)=>{if(e?.name==='NotSupportedError')switchDirectToProxy('live_native_not_supported');});
      return;
    }
    setHealth('Conectando ao canal HLS…',false);
    if(window.Hls&&Hls.isSupported()){
      hls=new Hls(hlsOptions());hls.loadSource(url);hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED,()=>{if(generation!==streamGeneration)return;hlsSoftRetries=0;hlsMediaRecoveries=0;refreshQualityMenu();video.play().catch(()=>{});setHealth('Canal ao vivo · HLS',true);});
      hls.on(Hls.Events.LEVEL_SWITCHED,refreshQualityMenu);
      hls.on(Hls.Events.ERROR,(_,error)=>{
        if(generation!==streamGeneration||!error)return;
        const code=Number(error?.response?.code||error?.networkDetails?.status||0),details=String(error?.details||'');
        if(!error.fatal){if(/bufferStalledError|fragLoadError/i.test(details))setHealth('Ajustando buffer do canal…',false);return;}
        if(error.type===Hls.ErrorTypes.NETWORK_ERROR&&switchDirectToProxy(`hls_network_${code||'cors'}`))return;
        if(error.type===Hls.ErrorTypes.NETWORK_ERROR&&hlsSoftRetries<3){hlsSoftRetries++;setHealth(`Recuperando HLS (${hlsSoftRetries}/3)…`,false);const active=hls;setTimeout(()=>{if(active===hls&&currentItem){try{active.startLoad(-1)}catch(_){recover()}}},450*hlsSoftRetries);return;}
        if(error.type===Hls.ErrorTypes.MEDIA_ERROR&&hlsMediaRecoveries<2){hlsMediaRecoveries++;try{hls.recoverMediaError();return}catch(_){}}
        if(!liveTsFallback&&(code===404||/manifest|levelLoad/i.test(details))){liveTsFallback=true;recovering=false;setHealth('HLS indisponível. Alternando para TS…',false);setTimeout(startStream,250);return;}
        recover();
      });
    }else{
      video.onerror=()=>{if(generation===streamGeneration&&!switchDirectToProxy('live_hls_native_error'))recover();};
      video.src=url;video.preload='auto';video.play().then(()=>setHealth('Canal ao vivo · HLS nativo',true)).catch((e)=>{if(e?.name==='NotSupportedError')switchDirectToProxy('live_hls_native_not_supported');});
    }
  }

  function startVodEngine(video, generation) {
    const ext=normalizedStreamExt(currentItem.item)||'mp4';
    const isMkv=ext==='mkv';
    const isHls=ext==='m3u8';
    const url=streamUrl(isMkv?'remux':'');
    destroyHls(true);
    if(isHls&&window.Hls&&Hls.isSupported()){
      setHealth('Carregando vídeo HLS…',false);
      hls=new Hls(hlsOptions());hls.loadSource(url);hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED,()=>{if(generation!==streamGeneration)return;video.play().catch(()=>{});setHealth('Reproduzindo vídeo HLS',true);});
      hls.on(Hls.Events.ERROR,(_,e)=>{if(generation!==streamGeneration||!e?.fatal)return;if(e.type===Hls.ErrorTypes.NETWORK_ERROR&&switchDirectToProxy('vod_hls_network_or_cors'))return;recover();});
      return;
    }
    setHealth(isMkv?'Preparando MKV para reprodução…':'Carregando filme/episódio…',false);
    video.onerror=()=>{if(generation===streamGeneration&&!switchDirectToProxy(isMkv?'mkv_direct_error':'vod_direct_media_error'))recover();};
    video.src=url;video.preload='auto';
    video.play().then(()=>setHealth(isMkv?'Reproduzindo MKV compatível':'Reproduzindo',true)).catch((e)=>{if(e?.name==='NotSupportedError')switchDirectToProxy(isMkv?'mkv_not_supported':'vod_not_supported');});
  }


  // CS PLAYER 4.0.5 — PiP avançado + fallback universal sobre a interface.
  let cs405FloatingPip=false;
  let cs405WakeLock=null;

  function cs405PlayerShell(){
    return document.getElementById('playerModal') ||
      document.querySelector('.player-modal,.cs-player-modal,[data-player-shell],.player-stage');
  }

  function cs405EnsurePipCss(){
    if(document.getElementById('cs405-pip-style'))return;
    const st=document.createElement('style');
    st.id='cs405-pip-style';
    st.textContent=`
      .cs405-floating-pip{
        position:fixed!important;right:12px!important;bottom:82px!important;
        width:min(var(--cs405-pip-w,420px),calc(100vw - 24px))!important;
        height:auto!important;max-height:72vh!important;margin:0!important;
        z-index:2147483647!important;transform:none!important;overflow:hidden!important;
        border-radius:16px!important;background:#000!important;
        box-shadow:0 28px 90px rgba(0,0,0,.72),0 0 0 1px rgba(255,255,255,.15)!important;
        isolation:isolate!important;
      }
      .cs405-floating-pip video{width:100%!important;height:auto!important;max-height:58vh!important;object-fit:contain!important;background:#000!important}
      .cs405-pip-label{position:absolute;left:10px;top:8px;z-index:2147483647;background:rgba(0,0,0,.72);color:#fff;
        padding:6px 9px;border-radius:9px;font:600 12px/1.2 system-ui;max-width:70%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none}
      @media(max-width:700px){.cs405-floating-pip{width:var(--cs405-pip-mw,94vw)!important;right:3vw!important;bottom:76px!important}}
    `;
    document.head.appendChild(st);
  }

  function cs405RefreshPipLabel(){
    const shell=cs405PlayerShell();if(!shell)return;
    let label=shell.querySelector('.cs405-pip-label');
    const cfg=window.CS_PLAYER_CONFIG||{};
    if(!cs405FloatingPip||(!cfg.pipShowTitle&&!cfg.pipShowStatus)){label?.remove();return;}
    if(!label){label=document.createElement('div');label.className='cs405-pip-label';shell.appendChild(label);}
    const title=String(currentItem?.item?.name||currentItem?.item?.title||'CS PLAYER');
    const status=String(document.getElementById('playerStatus')?.textContent||'');
    label.textContent=[cfg.pipShowTitle?title:'',cfg.pipShowStatus?status:''].filter(Boolean).join(' · ');
  }

  function cs405EnterFloatingPip(){
    const cfg=window.CS_PLAYER_CONFIG||{};
    if(cfg.pipFloatingEnabled===false)return false;
    const shell=cs405PlayerShell();if(!shell)return false;
    cs405EnsurePipCss();
    shell.style.setProperty('--cs405-pip-w',`${Math.max(280,Number(cfg.pipFloatingWidth||420))}px`);
    shell.style.setProperty('--cs405-pip-mw',`${Math.max(70,Number(cfg.pipFloatingMobileWidth||94))}vw`);
    shell.classList.add('cs405-floating-pip');
    cs405FloatingPip=true;cs405RefreshPipLabel();return true;
  }

  function cs405ExitFloatingPip(){
    const shell=cs405PlayerShell();
    shell?.classList.remove('cs405-floating-pip');
    shell?.querySelector('.cs405-pip-label')?.remove();
    cs405FloatingPip=false;
  }

  async function cs405TogglePip(){
    const cfg=window.CS_PLAYER_CONFIG||{};
    const video=document.getElementById('video');if(!video)return false;
    if(document.pictureInPictureElement){
      try{await document.exitPictureInPicture();return true}catch(_){}
    }
    if(cs405FloatingPip){cs405ExitFloatingPip();return true;}
    if(cfg.advancedPipEnabled!==false && document.pictureInPictureEnabled && !video.disablePictureInPicture){
      try{await video.requestPictureInPicture();cs405ExitFloatingPip();return true}catch(_){}
    }
    if(cfg.pipAutoFallback!==false)return cs405EnterFloatingPip();
    return false;
  }

  async function cs405Wake(){
    const cfg=window.CS_PLAYER_CONFIG||{};
    if(cfg.playerKeepAwake===false||!('wakeLock' in navigator))return;
    try{cs405WakeLock=await navigator.wakeLock.request('screen')}catch(_){}
  }
  async function cs405ReleaseWake(){try{await cs405WakeLock?.release?.()}catch(_){}cs405WakeLock=null;}

  window.CSPlayerPip={
    toggle:cs405TogglePip,
    enter:async()=>{if(!document.pictureInPictureElement&&!cs405FloatingPip)return cs405TogglePip();return true},
    floating:cs405EnterFloatingPip,
    exitFloating:cs405ExitFloatingPip,
    active:()=>!!(document.pictureInPictureElement||cs405FloatingPip)
  };

  document.addEventListener('click',(ev)=>{
    const target=ev.target.closest?.('[data-action="pip"],#pipBtn,.pip-btn,[data-pip]');
    if(!target)return;
    ev.preventDefault();ev.stopPropagation();cs405TogglePip();
  },true);

  document.addEventListener('keydown',(ev)=>{
    const cfg=window.CS_PLAYER_CONFIG||{};
    if(cfg.playerKeyboardShortcuts===false||!currentItem)return;
    if(/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName||''))return;
    const video=document.getElementById('video');if(!video)return;
    const k=ev.key.toLowerCase();
    if(k==='p'){ev.preventDefault();cs405TogglePip();}
    else if(k==='f'){ev.preventDefault();(cs405PlayerShell()||video).requestFullscreen?.();}
    else if(ev.key===' '){ev.preventDefault();video.paused?video.play().catch(()=>{}):video.pause();}
    else if(ev.key==='ArrowRight'&&currentItem.type!=='live'){video.currentTime=Math.min(video.duration||Infinity,video.currentTime+10);}
    else if(ev.key==='ArrowLeft'&&currentItem.type!=='live'){video.currentTime=Math.max(0,video.currentTime-10);}
  });

  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&currentItem)cs405Wake();});
  window.addEventListener('pagehide',cs405ReleaseWake);

  function startStream() {
    const video=document.getElementById('video');
    if(!video||!currentItem)return;
    const generation=++streamGeneration;
    const cfg=window.CS_PLAYER_CONFIG||{};
    try{video.preload=String(cfg.playerPreload||'auto')}catch(_){}
    cs405Wake();
    if(currentItem.type==='live') startLiveEngine(video,generation);
    else startVodEngine(video,generation);
    attachHealth();
    restorePosition();
    refreshTrackMenu();
  }

  function attachHealth() {
    const video = document.getElementById('video');
    if (!video) return;
    video.onplaying = () => { recovering = false; retries = 0; setHealth('Reproduzindo', true); updatePlayerControls(); };
    video.onwaiting = () => { setHealth('Bufferizando...', false); updatePlayerControls(); };
    video.onerror = () => recover();
    video.ontimeupdate = () => { lastProgress = Date.now(); savePosition(); updatePlayerControls(); };
    clearInterval(stallTimer);
    lastProgress = Date.now();
    stallTimer = setInterval(() => {
      const timeout = Number(window.CS_PLAYER_CONFIG?.stall || 12) * 1000;
      if (!video.paused && Date.now() - lastProgress > timeout) recover();
    }, 3000);
  }

  async function recover() {
    if (!currentItem || recovering) return;
    const now = Date.now();
    recoveryHistory = recoveryHistory.filter((stamp) => now - stamp < 60000);
    recoveryHistory.push(now);
    recovering = true;
    const limit = Math.max(2, Number(window.CS_PLAYER_CONFIG?.retries || 7));
    const video = document.getElementById('video');
    const position = Number(video?.currentTime || 0);

    // Circuit breaker: evita ciclo frenético em servidor fora do ar, mas continua reconectando sozinho.
    if (recoveryHistory.length > 8) {
      setHealth('Servidor instável. Nova tentativa automática em 15s…', false);
      clearTimeout(recoverTimer);
      recoverTimer = setTimeout(() => { recovering = false; recoveryHistory = []; if (currentItem) startStream(); }, 15000);
      return;
    }

    if (retries < limit) {
      retries += 1;
      const delay = Math.min(10000, 700 * Math.pow(1.55, retries - 1));
      setHealth(`Reconectando automaticamente (${retries}/${limit})…`, false);
      clearTimeout(recoverTimer);
      recoverTimer = setTimeout(() => {
        recovering = false;
        startStream();
        const target = document.getElementById('video');
        if (target && currentItem?.type !== 'live' && position > 1) {
          target.addEventListener('loadedmetadata', () => { try { target.currentTime = Math.min(position, Number.isFinite(target.duration) ? target.duration : position); } catch (error) {} }, { once: true });
        }
      }, delay);
      return;
    }
    if (window.CS_PLAYER_CONFIG?.failover) {
      setHealth('Alternando servidor automaticamente…', false);
      try {
        const response = await fetchJSON('api.php?action=failover');
        if (response.ok) {
          data.server.name = response.server;
          const badge = document.getElementById('serverBadge'); if (badge) badge.textContent = response.server;
          const status = document.getElementById('playerStatus'); if (status) status.textContent = response.server;
          retries = 0; hlsSoftRetries = 0; hlsMediaRecoveries = 0;
          recovering = false;
          startStream();
          return;
        }
      } catch (error) {}
    }
    recovering = false;
    retries = 0;
    reportClientError(new Error('Recuperação automática do stream acionada.'), 'stream.recover');
    setHealth('Aguardando o servidor. Reconexão automática ativa…', false);
    clearTimeout(recoverTimer);
    recoverTimer = setTimeout(() => { if (currentItem) { recovering = false; startStream(); } }, 12000);
  }

  function destroyHls(clearVideo = true) {
    if (hls) { try { hls.stopLoad(); } catch (_) {} try { hls.destroy(); } catch (_) {} hls = null; }
    if (mpegtsPlayer) { try { mpegtsPlayer.pause(); } catch (_) {} try { mpegtsPlayer.unload(); } catch (_) {} try { mpegtsPlayer.detachMediaElement(); } catch (_) {} try { mpegtsPlayer.destroy(); } catch (_) {} mpegtsPlayer = null; }
    const video = document.getElementById('video');
    if (clearVideo && video) { video.pause(); video.removeAttribute('src'); video.load(); }
    refreshQualityMenu();
  }

  function setHealth(text, online) {
    const label = document.getElementById('healthText');
    const dot = document.getElementById('healthDot');
    if (label) label.textContent = text;
    if (dot) { dot.style.background = online ? 'var(--success)' : 'var(--warning)'; dot.style.boxShadow = online ? '0 0 0 4px color-mix(in srgb, var(--success) 18%, transparent)' : '0 0 0 4px color-mix(in srgb, var(--warning) 18%, transparent)'; }
  }

  function formatMediaTime(value) {
    const seconds = Math.max(0, Math.floor(Number(value) || 0));
    const h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), s = seconds % 60;
    return h > 0 ? `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}` : `${m}:${String(s).padStart(2,'0')}`;
  }

  function updatePlayerControls() {
    const video = document.getElementById('video'); if (!video) return;
    const play = document.getElementById('playPauseBtn');
    const center = document.getElementById('centerPlayBtn');
    const mute = document.getElementById('muteBtn');
    const volume = document.getElementById('volumeBar');
    const seek = document.getElementById('seekBar');
    const time = document.getElementById('timeDisplay');
    const isPlaying = !video.paused && !video.ended;
    if (play) play.textContent = isPlaying ? '❚❚' : '▶';
    if (center) { center.classList.toggle('is-playing', isPlaying); center.querySelector('span').textContent = isPlaying ? '❚❚' : '▶'; }
    if (mute) mute.textContent = video.muted || video.volume === 0 ? '🔇' : (video.volume < .5 ? '🔉' : '🔊');
    if (volume) volume.value = video.muted ? 0 : video.volume;
    const duration = Number.isFinite(video.duration) ? video.duration : 0;
    if (seek) { seek.disabled = !duration || currentItem?.type === 'live'; seek.value = duration ? Math.round((video.currentTime / duration) * 1000) : 0; }
    if (time) time.textContent = currentItem?.type === 'live' ? 'AO VIVO' : `${formatMediaTime(video.currentTime)} / ${formatMediaTime(duration)}`;
  }

  function refreshQualityMenu() {
    const button = document.getElementById('qualityBtn');
    const label = document.getElementById('qualityLabel');
    if (!button) return;
    const levels = Array.isArray(hls?.levels) ? hls.levels : [];
    const available = !!hls && levels.length > 1;
    button.classList.toggle('hidden', !available);
    if (!available || !label) return;
    const levelIndex = Number(hls.currentLevel);
    if (levelIndex < 0) label.textContent = 'Qualidade automática';
    else {
      const level = levels[levelIndex] || {};
      label.textContent = level.height ? `Qualidade ${level.height}p` : `Qualidade nível ${levelIndex + 1}`;
    }
  }

  function cycleQuality() {
    if (!hls || !Array.isArray(hls.levels) || hls.levels.length < 2) return;
    const levels = hls.levels.map((level, index) => ({ index, height: Number(level.height || 0), bitrate: Number(level.bitrate || 0) }))
      .sort((a,b) => (b.height - a.height) || (b.bitrate - a.bitrate));
    const sequence = [-1, ...levels.map((row) => row.index)];
    const current = Number(hls.currentLevel);
    const at = sequence.indexOf(current);
    hls.currentLevel = sequence[(at + 1) % sequence.length];
    hls.nextLevel = hls.currentLevel;
    refreshQualityMenu();
    document.getElementById('playerSettings')?.classList.add('hidden');
  }

  function refreshTrackMenu() {
    const button = document.getElementById('tracksBtn');
    if (!button) return;
    const video = document.getElementById('video');
    const textCount = Number(video?.textTracks?.length || 0);
    const hlsSubs = Number(hls?.subtitleTracks?.length || 0);
    const hlsAudio = Number(hls?.audioTracks?.length || 0);
    button.classList.toggle('hidden', textCount === 0 && hlsSubs === 0 && hlsAudio <= 1);
  }

  function cycleTracks() {
    if (hls && Array.isArray(hls.subtitleTracks) && hls.subtitleTracks.length) {
      hls.subtitleDisplay = true;
      hls.subtitleTrack = hls.subtitleTrack < 0 ? 0 : (hls.subtitleTrack + 1 >= hls.subtitleTracks.length ? -1 : hls.subtitleTrack + 1);
      toast(hls.subtitleTrack < 0 ? 'Legendas desativadas.' : `Legenda: ${hls.subtitleTracks[hls.subtitleTrack]?.name || hls.subtitleTracks[hls.subtitleTrack]?.lang || 'ativa'}`, 'success');
    } else {
      const tracks = document.getElementById('video')?.textTracks;
      if (tracks?.length) {
        let active = -1;
        for (let i=0;i<tracks.length;i+=1) if (tracks[i].mode === 'showing') active = i;
        const next = active + 1 >= tracks.length ? -1 : active + 1;
        for (let i=0;i<tracks.length;i+=1) tracks[i].mode = i === next ? 'showing' : 'disabled';
        toast(next < 0 ? 'Legendas desativadas.' : `Legenda: ${tracks[next].label || tracks[next].language || 'ativa'}`, 'success');
      }
    }
    document.getElementById('playerSettings')?.classList.add('hidden');
  }

  function initYouTubePlayerControls() {
    const video = document.getElementById('video'); if (!video || video.dataset.ytReady === '1') return;
    video.dataset.ytReady = '1';
    const stage = document.getElementById('videoStage');
    const controls = document.getElementById('ytControls');
    const settings = document.getElementById('playerSettings');
    const toggle = () => video.paused ? video.play().catch(()=>{}) : video.pause();
    document.getElementById('centerPlayBtn')?.addEventListener('click', toggle);
    video.addEventListener('click', toggle);
    video.addEventListener('play', updatePlayerControls); video.addEventListener('pause', updatePlayerControls);
    video.addEventListener('loadedmetadata', () => { updatePlayerControls(); refreshTrackMenu(); });
    video.addEventListener('durationchange', updatePlayerControls);
    document.getElementById('seekBar')?.addEventListener('input', (event) => {
      if (currentItem?.type === 'live' || !Number.isFinite(video.duration) || video.duration <= 0) return;
      video.currentTime = (Number(event.target.value) / 1000) * video.duration; updatePlayerControls();
    });
    document.getElementById('volumeBar')?.addEventListener('input', (event) => { video.muted = false; video.volume = Math.max(0, Math.min(1, Number(event.target.value))); updatePlayerControls(); });
    document.getElementById('muteBtn')?.addEventListener('click', () => { video.muted = !video.muted; updatePlayerControls(); });
    document.getElementById('playerCloseBtn')?.addEventListener('click', closePlayer);
    document.getElementById('pipBtn')?.addEventListener('click', async () => {
      settings?.classList.add('hidden');
      try { if (document.pictureInPictureElement) await document.exitPictureInPicture(); else if (document.pictureInPictureEnabled && video.requestPictureInPicture) await video.requestPictureInPicture(); } catch (error) {}
    });
    document.getElementById('fullscreenBtn')?.addEventListener('click', async () => { try { if (document.fullscreenElement) await document.exitFullscreen(); else if (stage?.requestFullscreen) await stage.requestFullscreen(); } catch (error) {} });
    document.getElementById('settingsBtn')?.addEventListener('click', (event) => { event.stopPropagation(); settings?.classList.toggle('hidden'); });
    document.getElementById('qualityBtn')?.addEventListener('click', cycleQuality);
    document.getElementById('tracksBtn')?.addEventListener('click', cycleTracks);
    document.getElementById('playerInfoBtn')?.addEventListener('click', () => { settings?.classList.add('hidden'); if (currentItem) showInfo(currentItem.item, currentItem.type); });
    const pipButton = document.getElementById('pipBtn');
    if (pipButton) pipButton.classList.toggle('hidden', !(window.CS_PLAYER_CONFIG?.pip && document.pictureInPictureEnabled && video.requestPictureInPicture));
    document.addEventListener('pointerdown', (event) => { if (settings && !settings.classList.contains('hidden') && !settings.contains(event.target) && event.target?.id !== 'settingsBtn') settings.classList.add('hidden'); });
    let hideTimer = null;
    const showControls = () => { stage?.classList.add('controls-visible'); clearTimeout(hideTimer); if (!video.paused) hideTimer = setTimeout(() => { settings?.classList.add('hidden'); stage?.classList.remove('controls-visible'); }, 3200); };
    ['mousemove','touchstart','pointerdown'].forEach((name) => stage?.addEventListener(name, showControls, {passive:true}));
    controls?.addEventListener('pointerdown', (event) => event.stopPropagation());
    video.addEventListener('pause', () => stage?.classList.add('controls-visible'));
    video.addEventListener('play', showControls);
    stage?.classList.add('controls-visible');
    document.addEventListener('keydown', (event) => {
      if (document.getElementById('playerModal')?.classList.contains('hidden')) return;
      if (['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) return;
      if (event.code === 'Space' || event.key === 'Enter' && document.activeElement === stage) { event.preventDefault(); toggle(); }
      if (event.key === 'ArrowRight' && currentItem?.type !== 'live') video.currentTime = Math.min(video.duration || Infinity, video.currentTime + 10);
      if (event.key === 'ArrowLeft' && currentItem?.type !== 'live') video.currentTime = Math.max(0, video.currentTime - 10);
      if (event.key.toLowerCase() === 'm') { video.muted = !video.muted; updatePlayerControls(); }
      if (event.key.toLowerCase() === 'f') document.getElementById('fullscreenBtn')?.click();
    });
    updatePlayerControls();
    refreshQualityMenu();
    refreshTrackMenu();
  }

  function setAppLoading(active, title = 'Carregando seu conteúdo...', text = 'Conectando ao servidor e organizando canais, filmes e séries.') {
    const overlay = document.getElementById('appLoading');
    if (!overlay) return;
    overlay.classList.toggle('hidden', !active);
    overlay.setAttribute('aria-hidden', active ? 'false' : 'true');
    const titleNode = document.getElementById('appLoadingTitle');
    const textNode = document.getElementById('appLoadingText');
    if (titleNode) titleNode.textContent = title;
    if (textNode) textNode.textContent = text;
    document.body.classList.toggle('is-loading', active);
  }

  function closePlayer() { savePosition(); destroyHls(true); clearInterval(stallTimer); clearTimeout(recoverTimer); recovering = false; document.getElementById('playerModal')?.classList.add('hidden'); }
  function closeInfo() { document.getElementById('infoModal')?.classList.add('hidden'); }
  function retry() { retries = 0; startStream(); }
  function keyForPos() { if (!currentItem) return ''; const item = currentItem.item; return `cspos:${currentItem.type}:${item.stream_id || item.id || item.series_id}`; }
  function rememberContinue(position = 0, duration = 0) {
    if (!window.CS_PLAYER_CONFIG?.remember || !currentItem || currentItem.type === 'live') return;
    const safeDuration = Number(duration || 0);
    const item = { ...currentItem.item, _type: currentItem.type, _position: Number(position || 0), _progress: safeDuration > 0 ? Math.max(0, Math.min(100, Number(position || 0) / safeDuration * 100)) : Number(currentItem.item?._progress || 0), _updatedAt: Date.now() };
    const key = String(item.stream_id || item.id || item.series_id || '');
    if (!key) return;
    const items = safeRead('csplayer_continue', []).filter((entry) => String(entry?.stream_id || entry?.id || entry?.series_id || '') !== key);
    items.unshift(item);
    try { localStorage.setItem('csplayer_continue', JSON.stringify(items.slice(0, 30))); } catch (error) {}
  }
  function savePosition() {
    if (!window.CS_PLAYER_CONFIG?.remember || !currentItem || currentItem.type === 'live') return;
    const video = document.getElementById('video');
    if (video?.currentTime > 10) {
      try { localStorage.setItem(keyForPos(), String(video.currentTime)); } catch (error) {}
      rememberContinue(video.currentTime, video.duration);
    }
  }
  function restorePosition() {
    if (!window.CS_PLAYER_CONFIG?.remember || currentItem?.type === 'live') return;
    const savedItem = safeRead('csplayer_continue', []).find((entry) => String(entry?.stream_id || entry?.id || entry?.series_id || '') === String(currentItem.item?.stream_id || currentItem.item?.id || currentItem.item?.series_id || ''));
    const position = Number(localStorage.getItem(keyForPos()) || savedItem?._position || 0);
    if (position > 10) document.getElementById('video')?.addEventListener('loadedmetadata', () => { try { document.getElementById('video').currentTime = position; } catch (error) {} }, { once: true });
  }

  function search(query) {
    const normalized = normalizeSearch(query);
    const clear = document.getElementById('clearSearch');
    clear?.classList.toggle('hidden', !normalized);
    if (!normalized) { render(); return; }
    const tokens = normalized.split(' ').filter(Boolean);
    const results = allSearchItems().map((item) => {
      const type = item._type || 'movie';
      const haystack = normalizeSearch([titleOf(item), categoryNameOf(item, type), item?.genre, item?.plot, item?.description].filter(Boolean).join(' '));
      const exact = haystack.includes(normalized) ? 100 : 0;
      const matched = tokens.reduce((sum, token) => sum + (haystack.includes(token) ? 15 : 0), 0);
      return { item, score: exact + matched + scoreOf(item) / 200 };
    }).filter((entry) => entry.score > 0).sort((a, b) => b.score - a.score).slice(0, 120).map((entry) => entry.item);
    const rails = document.getElementById('rails');
    if (!rails) return;
    rails.innerHTML = results.length ? rail(`Resultados para “${query.trim()}”`, results, 'mixed', true) : `<div class="empty-state search-empty"><strong>Nenhum resultado encontrado</strong><span>Tente outro título, categoria ou gênero.</span></div>`;
    bindCards(); bindRailControls();
  }

  function surpriseMe() {
    const pool = uniqueMixed([
      ...(data.content?.movies || []).map((item) => ({ ...item, _type: 'movie' })),
      ...(data.content?.series || []).map((item) => ({ ...item, _type: 'series' }))
    ]);
    if (!pool.length) { toast('Nenhum filme ou série disponível.', 'warning'); return; }
    const pick = pool[Math.floor(Math.random() * pool.length)];
    showInfo(pick, pick._type || 'movie');
    toast(`Sugestão: ${titleOf(pick)}`, 'success');
  }

  function quickFilter(key) {
    if (key === 'releases') {
      currentType = 'movies';
      document.querySelectorAll('[data-view]').forEach((el) => el.classList.toggle('active', el.dataset.view === 'movies'));
      render();
      const category = sortedCategories(data.categories?.movies || []).find((cat) => /lancamentos?/i.test(normalizeCategoryName(cat?.category_name)));
      if (category) { const select = document.getElementById('categoryFilter'); if (select) { select.value = String(category.category_id); select.dispatchEvent(new Event('change')); } }
      return;
    }
    const map = { live: 'live', movies: 'movies', series: 'series', favorites: 'favorites' };
    if (map[key]) {
      currentType = map[key];
      document.querySelectorAll('[data-view]').forEach((el) => el.classList.toggle('active', el.dataset.view === currentType));
      render(); window.scrollTo({ top: Math.max(0, document.getElementById('rails')?.offsetTop - 90 || 0), behavior: 'smooth' });
    }
  }

  async function filterCategory(event) {
    const id = event.target.value;
    if (!id) { render(); return; }
    const type = currentType === 'movies' ? 'movies' : currentType === 'series' ? 'series' : 'live';
    setAppLoading(true, 'Atualizando conteúdo...', 'Buscando os itens desta categoria.');
    try {
      const response = await fetchJSON(`api.php?action=category&type=${type}&category_id=${encodeURIComponent(id)}`);
      data.content[type] = response.data || [];
      render();
    } catch (error) { setHealth(error.message, false); }
    finally { setAppLoading(false); }
  }

  function focusSearch() { document.getElementById('globalSearch')?.focus(); }



  // Google Cast / Remote Playback — CS Player v6.3.5
  let castReady = false;
  let castContext = null;
  let castSession = null;
  let castRemotePlayer = null;
  let castRemoteController = null;

  function castButtonState(state, text = '') {
    const button = document.getElementById('castBtn');
    const status = document.getElementById('castStatus');
    if (!button) return;
    const connected = state === 'connected';
    const available = connected || state === 'ready';
    castAvailable = available;
    button.classList.toggle('hidden', !available);
    button.classList.toggle('cast-connected', connected);
    button.classList.toggle('cast-unavailable', !available);
    button.setAttribute('aria-pressed', connected ? 'true' : 'false');
    button.title = connected ? 'Transmitindo para TV' : 'Transmitir para TV';
    if (status) {
      status.textContent = text || (connected ? 'Transmitindo para TV' : '');
      status.classList.toggle('hidden', !(text || connected));
    }
  }

  function initRemotePlaybackAvailability() {
    const video = document.getElementById('video');
    if (!video?.remote?.watchAvailability) return;
    try {
      video.remote.watchAvailability((available) => {
        if (available && !castSession) castButtonState('ready');
        else if (!available && !castSession && (!castContext || castContext.getCastState?.() === window.cast?.framework?.CastState?.NO_DEVICES_AVAILABLE)) castButtonState('unavailable');
      }).then((id) => { remotePlaybackWatchId = id; }).catch(() => {});
    } catch (_) {}
  }

  function initCastFramework() {
    if (!window.cast?.framework || !window.chrome?.cast) { initRemotePlaybackAvailability(); return false; }
    try {
      castContext = cast.framework.CastContext.getInstance();
      castContext.setOptions({
        receiverApplicationId: chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID,
        autoJoinPolicy: chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED
      });
      const syncAvailability = () => {
        const state = castContext.getCastState?.();
        if (state === cast.framework.CastState.CONNECTED) castButtonState('connected');
        else if (state === cast.framework.CastState.CONNECTING || state === cast.framework.CastState.NOT_CONNECTED) castButtonState('ready');
        else castButtonState('unavailable');
      };
      castContext.addEventListener(cast.framework.CastContextEventType.CAST_STATE_CHANGED, syncAvailability);
      castRemotePlayer = new cast.framework.RemotePlayer();
      castRemoteController = new cast.framework.RemotePlayerController(castRemotePlayer);
      castContext.addEventListener(cast.framework.CastContextEventType.SESSION_STATE_CHANGED, (event) => {
        const connected = [cast.framework.SessionState.SESSION_STARTED, cast.framework.SessionState.SESSION_RESUMED].includes(event.sessionState);
        castSession = connected ? castContext.getCurrentSession() : null;
        if (connected) castButtonState('connected', `Transmitindo para ${castSession?.getCastDevice?.().friendlyName || 'TV'}`);
        else syncAvailability();
        if (!connected && document.getElementById('video')) {
          const saved = castRemotePlayer?.savedPlayerState;
          if (saved && Number(saved.currentTime) > 0 && !currentItem?.type?.includes('live')) {
            try { document.getElementById('video').currentTime = Number(saved.currentTime); } catch (error) {}
          }
        }
      });
      castReady = true;
      syncAvailability();
      initRemotePlaybackAvailability();
      return true;
    } catch (error) {
      reportClientError(error, 'cast.init');
      castButtonState('unavailable');
      initRemotePlaybackAvailability();
      return false;
    }
  }

  function castContentType(item, type) {
    const ext = String(item?.container_extension || item?.container || '').toLowerCase();
    if (type === 'live' || ext === 'm3u8') return 'application/x-mpegURL';
    if (ext === 'webm') return 'video/webm';
    if (ext === 'mkv') return 'video/x-matroska';
    if (ext === 'ts') return 'video/mp2t';
    return 'video/mp4';
  }

  async function createCastMediaUrl() {
    if (!currentItem) throw new Error('Abra um canal, filme ou episódio antes de transmitir.');
    const item = currentItem.item || {};
    const body = new URLSearchParams({
      type: currentItem.type,
      id: String(item.stream_id || item.id || ''),
      ext: String(item.container_extension || item.container || ''),
      title: titleOf(item),
      image: imageOf(item) || ''
    });
    const response = await fetch('cast_token.php', { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body: body.toString(), credentials: 'same-origin' });
    const json = await response.json().catch(() => ({}));
    if (!response.ok || !json.ok || !json.url) throw new Error(json.message || 'Não foi possível preparar a transmissão.');
    return new URL(json.url, window.location.href).href;
  }

  async function loadCurrentOnCast() {
    castSession = castContext?.getCurrentSession?.();
    if (!castSession) throw new Error('Nenhuma TV conectada.');
    const url = await createCastMediaUrl();
    const item = currentItem.item || {};
    const mediaInfo = new chrome.cast.media.MediaInfo(url, castContentType(item, currentItem.type));
    const metadata = new chrome.cast.media.GenericMediaMetadata();
    metadata.title = titleOf(item);
    metadata.subtitle = currentItem.type === 'live' ? 'Ao vivo · CS Player' : 'CS Player';
    const image = imageOf(item);
    if (image) metadata.images = [new chrome.cast.Image(image)];
    mediaInfo.metadata = metadata;
    mediaInfo.streamType = currentItem.type === 'live' ? chrome.cast.media.StreamType.LIVE : chrome.cast.media.StreamType.BUFFERED;
    const request = new chrome.cast.media.LoadRequest(mediaInfo);
    const video = document.getElementById('video');
    if (currentItem.type !== 'live' && video && Number(video.currentTime) > 0) request.currentTime = Number(video.currentTime);
    request.autoplay = true;
    await castSession.loadMedia(request);
    if (video) video.pause();
    castButtonState('connected', `Transmitindo para ${castSession.getCastDevice?.().friendlyName || 'TV'}`);
    toast('Transmissão iniciada na TV.', 'success');
  }

  async function castToTV() {
    if (!currentItem) { toast('Abra um canal, filme ou episódio primeiro.', 'warning'); return; }
    if (!window.isSecureContext && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
      // O Web Sender do Google Cast é projetado para páginas HTTPS. O fallback Remote Playback ainda pode existir em alguns navegadores.
      const video = document.getElementById('video');
      if (video?.remote?.prompt) {
        try { await video.remote.prompt(); return; } catch (error) {}
      }
      toast('Para transmitir como no YouTube, abra o Web Player por HTTPS.', 'warning');
      return;
    }
    if (!castReady && !initCastFramework()) {
      const video = document.getElementById('video');
      if (video?.remote?.prompt) {
        try { await video.remote.prompt(); return; } catch (error) {}
      }
      toast('Google Cast não está disponível neste navegador.', 'warning');
      return;
    }
    try {
      if (!castContext.getCurrentSession()) await castContext.requestSession();
      await loadCurrentOnCast();
    } catch (error) {
      if (String(error).includes('cancel')) return;
      reportClientError(error, 'cast.start');
      toast(error?.message || 'Não foi possível transmitir para a TV.', 'warning');
    }
  }

  async function init() {
    setTheme(document.documentElement.dataset.theme || themeFromStorage());
    document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
    const rails = document.getElementById('rails');
    if (rails) rails.innerHTML = '<div class="skeleton"></div><div class="skeleton"></div>';
    setAppLoading(true);
    try {
      const requestStarted = (window.performance && performance.now) ? performance.now() : Date.now();
      data = await fetchJSON('api.php?action=home');
      data.content = data.content || { live: [], movies: [], series: [] };
      data.content.live = newest(data.content.live);
      data.content.movies = newest(data.content.movies);
      data.content.series = newest(data.content.series);
      const requestLatency = Math.max(0, Math.round(((window.performance && performance.now) ? performance.now() : Date.now()) - requestStarted));
      const server = data.server?.name || 'DNS';
      const dnsSource = data.server?.dns_source || 'automático';
      const totalContent = ['live', 'movies', 'series'].reduce((total, key) => total + (Array.isArray(data.content?.[key]) ? data.content[key].length : 0), 0);
      const serverBadge = document.getElementById('serverBadge');
      if (serverBadge) {
        serverBadge.textContent = `${server} · ${totalContent} itens · ${requestLatency}ms`;
        serverBadge.title = `Servidor: ${server}. Origem DNS: ${dnsSource}. Conteúdo recebido: ${totalContent}. Latência: ${requestLatency} ms.`;
      }
      const manual = (Array.isArray(data.manual_highlights) ? data.manual_highlights : []).filter((item) => item && item._manual_highlight !== false);
      const manualHeroItems = manual.map((item) => ({ item, type: item._type || 'movie' }));
      const automaticHeroItems = [...(data.content?.movies || []).slice(0,12).map(item=>({item,type:'movie'})), ...(data.content?.series || []).slice(0,12).map(item=>({item,type:'series'})), ...(data.content?.live || []).slice(0,4).map(item=>({item,type:'live'}))];
      setupHeroCarousel(manualHeroItems.length ? manualHeroItems : automaticHeroItems);
      document.getElementById('heroPlay')?.addEventListener('click', () => currentItem && play(currentItem.item, currentItem.type));
      document.getElementById('heroInfo')?.addEventListener('click', () => currentItem && showInfo(currentItem.item, currentItem.type));
      render();
      setAppLoading(false);
      document.querySelectorAll('[data-view]').forEach((button) => button.addEventListener('click', () => {
        currentType = button.dataset.view;
        document.querySelectorAll('[data-view]').forEach((element) => element.classList.toggle('active', element.dataset.view === currentType));
        render();
      }));
      document.getElementById('globalSearch')?.addEventListener('input', (event) => search(event.target.value));
      document.getElementById('clearSearch')?.addEventListener('click', () => { const input = document.getElementById('globalSearch'); if (input) { input.value = ''; input.focus(); search(''); } });
      document.getElementById('categoryFilter')?.addEventListener('change', filterCategory);
      document.getElementById('surpriseBtn')?.addEventListener('click', surpriseMe);
      document.querySelectorAll('[data-quick]').forEach((button) => button.addEventListener('click', () => quickFilter(button.dataset.quick)));
      document.getElementById('castBtn')?.addEventListener('click', castToTV);
      window.addEventListener('csplayer:cast-api', (event) => { if (event.detail?.available) initCastFramework(); else castButtonState('unavailable'); });
      if (window.cast?.framework && window.chrome?.cast) initCastFramework();
      initYouTubePlayerControls();
      updateNetworkStatus();
      window.addEventListener('online', () => { updateNetworkStatus(); toast('Conexão restabelecida.', 'success'); });
      window.addEventListener('offline', updateNetworkStatus);
      document.addEventListener('keydown', (event) => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); focusSearch(); } if (event.key === 'Escape') { closeHeroSelector(); closeInfo(); closeSeriesModal(); } });
      window.addEventListener('beforeunload', savePosition);
    } catch (error) {
      reportClientError(error, 'home.init');
      setAppLoading(false, 'Não foi possível carregar', error.message || 'Verifique a conexão e tente novamente.');
      if (rails) rails.innerHTML = `<div class="empty-state">${esc(error.message || 'Não foi possível carregar o conteúdo.')}</div>`;
    }
  }

  function showFavorites(){ currentType='favorites'; document.querySelectorAll('[data-view]').forEach((element)=>element.classList.toggle('active',element.dataset.view==='favorites')); render(); document.getElementById('profileMenu')?.classList.add('hidden'); }
  function toggleThemeFromMenu(){ toggleTheme(); document.getElementById('profileMenu')?.classList.add('hidden'); }
  document.addEventListener('click',(event)=>{const btn=document.getElementById('profileMenuButton'),menu=document.getElementById('profileMenu');if(!btn||!menu)return;if(btn.contains(event.target)){event.preventDefault();menu.classList.toggle('hidden');btn.setAttribute('aria-expanded',String(!menu.classList.contains('hidden')));return;}if(!menu.contains(event.target)){menu.classList.add('hidden');btn.setAttribute('aria-expanded','false');}});
  return { init, showInfo, play, openSeriesModal, closeSeriesModal, closePlayer, closeInfo, retry, focusSearch, toggleTheme, showFavorites, toggleThemeFromMenu };
})();
document.addEventListener('DOMContentLoaded', PlayerUI.init);

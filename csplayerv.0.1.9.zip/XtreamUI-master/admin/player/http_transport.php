<?php
/**
 * CS PLAYER - Transporte HTTP unificado para Web Player (PHP 7.4+)
 * Mantém DNS, família IP e telemetria consistentes entre login, catálogo e reprodução.
 */
if (!defined('CS_PLAYER_INTERNAL')) { http_response_code(403); exit; }

function cs_player_transport_ip_mode($requested = null) {
    $mode = strtolower(trim((string)($requested !== null ? $requested : ($_SESSION['cs_player_ip_mode_selected'] ?? $_SESSION['cs_player_json_ip_mode'] ?? 'auto'))));
    return in_array($mode, array('auto','ipv4','ipv6'), true) ? $mode : 'auto';
}

function cs_player_transport_attempt_modes($requested = null) {
    $mode = cs_player_transport_ip_mode($requested);
    if ($mode === 'ipv4') return array('ipv4');
    if ($mode === 'ipv6') return array('ipv6');
    // Em Auto, IPv4 primeiro porque diversos provedores IPTV publicam AAAA/CDN sem API funcional.
    return array('ipv4','auto');
}

function cs_player_transport_request($url, array $options = array()) {
    $timeout = max(3, min(60, (int)($options['timeout'] ?? 10)));
    $connectTimeout = max(1, min($timeout, (int)($options['connect_timeout'] ?? min(10, $timeout))));
    $ua = (string)($options['user_agent'] ?? 'CSPlayer-Web/1.0');
    $accept = (string)($options['accept'] ?? 'application/json, text/plain, */*');
    $wantJson = !array_key_exists('json', $options) || !empty($options['json']);
    $requestedIp = $options['ip_mode'] ?? null;
    $attemptModes = cs_player_transport_attempt_modes($requestedIp);
    $attempts = array();
    $allowLegacyTls = function_exists('cs_player_bool')
        ? cs_player_bool($options['allow_legacy_tls'] ?? false, false)
        : !empty($options['allow_legacy_tls']);

    if (!function_exists('curl_init')) {
        return array('ok'=>false,'http_code'=>0,'body'=>'','data'=>null,'curl_errno'=>-1,'curl_error'=>'cURL indisponível','remote_ip'=>'','effective_url'=>(string)$url,'time_ms'=>0,'ip_mode'=>'none','attempts'=>$attempts);
    }

    foreach ($attemptModes as $ipMode) {
        $ch = curl_init((string)$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $connectTimeout);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: '.$accept, 'Connection: keep-alive', 'Cache-Control: no-cache'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, !$allowLegacyTls);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $allowLegacyTls ? 0 : 2);
        if (defined('CURLOPT_IPRESOLVE')) {
            if ($ipMode === 'ipv4' && defined('CURL_IPRESOLVE_V4')) curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
            elseif ($ipMode === 'ipv6' && defined('CURL_IPRESOLVE_V6')) curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V6);
        }
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno = (int)curl_errno($ch);
        $error = (string)curl_error($ch);
        $remoteIp = defined('CURLINFO_PRIMARY_IP') ? (string)curl_getinfo($ch, CURLINFO_PRIMARY_IP) : '';
        $effective = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $contentType = defined('CURLINFO_CONTENT_TYPE') ? (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE) : '';
        $ms = (int)round(((float)curl_getinfo($ch, CURLINFO_TOTAL_TIME)) * 1000);
        $redirects = (int)curl_getinfo($ch, CURLINFO_REDIRECT_COUNT);
        curl_close($ch);
        $decoded = ($wantJson && is_string($body)) ? json_decode($body, true) : null;
        $ok = is_string($body) && $errno === 0 && $code >= 200 && $code < 400 && (!$wantJson || is_array($decoded));
        $attempts[] = array('ip_mode'=>$ipMode,'http_code'=>$code,'remote_ip'=>$remoteIp,'time_ms'=>$ms,'curl_errno'=>$errno,'response_bytes'=>is_string($body)?strlen($body):0);
        if ($ok) {
            $_SESSION['cs_player_ip_mode_selected'] = $ipMode;
            $_SESSION['cs_player_json_ip_mode'] = $ipMode;
            return array('ok'=>true,'http_code'=>$code,'status'=>$code,'body'=>$body,'data'=>is_array($decoded)?$decoded:null,'json'=>is_array($decoded)?$decoded:null,'headers'=>array(),'content_type'=>$contentType,'curl_errno'=>$errno,'errno'=>$errno,'curl_error'=>$error,'error'=>$error,'remote_ip'=>$remoteIp,'effective_url'=>$effective,'time_ms'=>$ms,'duration_ms'=>$ms,'redirects'=>$redirects,'ip_mode'=>$ipMode,'attempts'=>$attempts);
        }
        // Se IPv4 chegou ao host mas a rota respondeu 401/403, não troque para uma família diferente.
        if ($ipMode === 'ipv4' && in_array($code, array(401,403), true)) break;
    }
    // Compatibilidade com players clássicos: alguns provedores respondem diferente ao stream wrapper do PHP.
    // Este fallback replica o fluxo simples do Web Player de referência sem alterar o DNS cadastrado.
    if (!empty($options['classic_stream_fallback']) || $wantJson) {
        $headers = 'User-Agent: '.$ua."\r\n".'Accept: '.$accept."\r\n".'Connection: close'."\r\n";
        $ctx = stream_context_create(array(
            'http'=>array('method'=>'GET','header'=>$headers,'timeout'=>$timeout,'ignore_errors'=>true,'follow_location'=>1,'max_redirects'=>5,'protocol_version'=>1.1),
            'ssl'=>array('verify_peer'=>!$allowLegacyTls,'verify_peer_name'=>!$allowLegacyTls,'allow_self_signed'=>$allowLegacyTls)
        ));
        $started = microtime(true);
        $streamBody = @file_get_contents((string)$url, false, $ctx);
        $streamMs = (int)round((microtime(true)-$started)*1000);
        $streamHeaders = isset($http_response_header) && is_array($http_response_header) ? $http_response_header : array();
        $streamCode = 0;
        foreach ($streamHeaders as $line) if (preg_match('~^HTTP/\S+\s+(\d{3})~i',(string)$line,$m)) $streamCode=(int)$m[1];
        $streamDecoded = ($wantJson && is_string($streamBody)) ? json_decode($streamBody,true) : null;
        $streamOk = is_string($streamBody) && $streamCode>=200 && $streamCode<400 && (!$wantJson || is_array($streamDecoded));
        $attempts[] = array('ip_mode'=>'classic_stream','http_code'=>$streamCode,'remote_ip'=>'','time_ms'=>$streamMs,'curl_errno'=>0,'response_bytes'=>is_string($streamBody)?strlen($streamBody):0);
        if ($streamOk) return array('ok'=>true,'http_code'=>$streamCode,'status'=>$streamCode,'body'=>$streamBody,'data'=>is_array($streamDecoded)?$streamDecoded:null,'json'=>is_array($streamDecoded)?$streamDecoded:null,'headers'=>$streamHeaders,'content_type'=>(string)($streamHeaders[0] ?? ''),'curl_errno'=>0,'errno'=>0,'curl_error'=>'','error'=>null,'remote_ip'=>'','effective_url'=>(string)$url,'time_ms'=>$streamMs,'duration_ms'=>$streamMs,'redirects'=>0,'ip_mode'=>'classic_stream','attempts'=>$attempts);
    }
    $last = end($attempts);
    $failedBody = isset($streamBody) && is_string($streamBody) ? $streamBody : (isset($body) && is_string($body) ? $body : '');
    $failedData = isset($streamDecoded) && is_array($streamDecoded) ? $streamDecoded : (isset($decoded) && is_array($decoded) ? $decoded : null);
    $failedCode = (int)($last['http_code'] ?? 0);
    $failedTime = (int)($last['time_ms'] ?? 0);
    $failedError = isset($error) ? $error : '';
    return array('ok'=>false,'http_code'=>$failedCode,'status'=>$failedCode,'body'=>$failedBody,'data'=>$failedData,'json'=>$failedData,'headers'=>array(),'content_type'=>isset($contentType)?$contentType:'','curl_errno'=>(int)($last['curl_errno']??0),'errno'=>(int)($last['curl_errno']??0),'curl_error'=>$failedError,'error'=>$failedError,'remote_ip'=>(string)($last['remote_ip']??''),'effective_url'=>isset($effective)?$effective:(string)$url,'time_ms'=>$failedTime,'duration_ms'=>$failedTime,'redirects'=>isset($redirects)?$redirects:0,'ip_mode'=>(string)($last['ip_mode']??cs_player_transport_ip_mode($requestedIp)),'attempts'=>$attempts);
}

function cs_player_transport_request_batch(array $urls, array $options = array()): array {
    if (!$urls) return array();
    if (!function_exists('curl_multi_init') || !function_exists('curl_init')) {
        $fallback = array();
        foreach ($urls as $key => $url) $fallback[$key] = cs_player_transport_request((string)$url, $options);
        return $fallback;
    }
    $timeout = max(3, min(60, (int)($options['timeout'] ?? 10)));
    $connectTimeout = max(1, min($timeout, (int)($options['connect_timeout'] ?? min(10, $timeout))));
    $ua = (string)($options['user_agent'] ?? 'CSPlayer-Web/1.0');
    $accept = (string)($options['accept'] ?? 'application/json, text/plain, */*');
    $wantJson = !array_key_exists('json', $options) || !empty($options['json']);
    $allowLegacyTls = function_exists('cs_player_bool')
        ? cs_player_bool($options['allow_legacy_tls'] ?? false, false)
        : !empty($options['allow_legacy_tls']);
    $ipMode = cs_player_transport_ip_mode($options['ip_mode'] ?? null);
    $multi = curl_multi_init();
    $handles = array();
    foreach ($urls as $key => $url) {
        $handle = curl_init((string)$url);
        curl_setopt_array($handle, array(
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_MAXREDIRS=>5,
            CURLOPT_CONNECTTIMEOUT=>$connectTimeout, CURLOPT_TIMEOUT=>$timeout,
            CURLOPT_USERAGENT=>$ua, CURLOPT_HTTP_VERSION=>CURL_HTTP_VERSION_1_1,
            CURLOPT_ENCODING=>'', CURLOPT_HTTPHEADER=>array('Accept: '.$accept,'Connection: keep-alive','Cache-Control: no-cache'),
            CURLOPT_SSL_VERIFYPEER=>!$allowLegacyTls, CURLOPT_SSL_VERIFYHOST=>$allowLegacyTls ? 0 : 2,
        ));
        if ($ipMode === 'ipv4' && defined('CURL_IPRESOLVE_V4')) curl_setopt($handle, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        elseif ($ipMode === 'ipv6' && defined('CURL_IPRESOLVE_V6')) curl_setopt($handle, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V6);
        $multiKey = (string)$key;
        curl_multi_add_handle($multi, $handle);
        $handles[$multiKey] = array('key'=>$key, 'handle'=>$handle, 'url'=>(string)$url);
    }
    $running = null;
    do {
        $status = curl_multi_exec($multi, $running);
        if ($running && $status === CURLM_OK) {
            $selected = curl_multi_select($multi, 0.25);
            if ($selected === -1) usleep(10000);
        }
    } while ($running && $status === CURLM_OK);

    $result = array();
    foreach ($handles as $entry) {
        $handle = $entry['handle'];
        $body = curl_multi_getcontent($handle);
        $code = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $errno = (int)curl_errno($handle);
        $error = (string)curl_error($handle);
        $remoteIp = defined('CURLINFO_PRIMARY_IP') ? (string)curl_getinfo($handle, CURLINFO_PRIMARY_IP) : '';
        $effective = (string)curl_getinfo($handle, CURLINFO_EFFECTIVE_URL);
        $ms = (int)round(((float)curl_getinfo($handle, CURLINFO_TOTAL_TIME))*1000);
        $decoded = ($wantJson && is_string($body)) ? json_decode($body, true) : null;
        $ok = is_string($body) && $errno === 0 && $code >= 200 && $code < 400 && (!$wantJson || is_array($decoded));
        $result[$entry['key']] = array(
            'ok'=>$ok, 'http_code'=>$code, 'status'=>$code, 'body'=>is_string($body)?$body:'',
            'data'=>is_array($decoded)?$decoded:null, 'json'=>is_array($decoded)?$decoded:null,
            'headers'=>array(), 'content_type'=>defined('CURLINFO_CONTENT_TYPE') ? (string)curl_getinfo($handle, CURLINFO_CONTENT_TYPE) : '', 'curl_errno'=>$errno, 'errno'=>$errno, 'curl_error'=>$error, 'error'=>$error,
            'remote_ip'=>$remoteIp, 'effective_url'=>$effective ?: $entry['url'], 'time_ms'=>$ms,
            'duration_ms'=>$ms, 'redirects'=>(int)curl_getinfo($handle,CURLINFO_REDIRECT_COUNT),
            'ip_mode'=>$ipMode, 'attempts'=>array(array('ip_mode'=>$ipMode,'http_code'=>$code,'remote_ip'=>$remoteIp,'time_ms'=>$ms,'curl_errno'=>$errno,'response_bytes'=>is_string($body)?strlen($body):0)),
        );
        curl_multi_remove_handle($multi, $handle);
        curl_close($handle);
    }
    curl_multi_close($multi);
    return $result;
}

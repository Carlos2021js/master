<?php
// CS PLAYER 4.0.4 — endpoint exclusivo do Player Live.
$_GET['type'] = 'live';
require __DIR__ . '/bootstrap.php';
$cfg = cs_player_load_config();
$ext = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string)($_GET['ext'] ?? '')));
if ($ext === '' && !empty($cfg['live_prefer_ts']) && (string)($_SESSION['cs_player_provider_mode'] ?? '') === 'm3u') {
    $_GET['ext'] = 'ts';
    $_GET['format'] = 'ts';
}
// `live_proxy_mode` continua sendo aceito como configuração legada, mas a
// decisão final é feita pelo resolvedor único dentro de stream.php.
require __DIR__ . '/stream.php';

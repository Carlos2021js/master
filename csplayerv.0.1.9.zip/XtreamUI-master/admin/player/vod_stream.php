<?php
// CS PLAYER 4.0.4 — endpoint exclusivo de Filmes/Séries.
require __DIR__ . '/bootstrap.php';
$cfg = cs_player_load_config();
$type = strtolower((string)($_GET['type'] ?? 'movie'));
$_GET['type'] = $type === 'series' ? 'series' : 'movie';
$ext = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string)($_GET['ext'] ?? '')));
if ($ext === 'mkv' && !empty($cfg['vod_mkv_remux'])) {
    $_GET['format'] = 'remux';
}
// `vod_proxy_mode` continua sendo aceito como configuração legada, mas a
// decisão final é feita pelo resolvedor único dentro de stream.php.
require __DIR__ . '/stream.php';

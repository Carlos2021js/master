<?php
/** CS_PLAYER_WEBPLAYER_BOOTSTRAP_VERSION: 6.8.0-smart-dns-extreme */
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('CSPLAYER_WEB');
    session_start();
}

define('CS_PLAYER_ROOT', __DIR__);
if (!defined('CS_PLAYER_INTERNAL')) { define('CS_PLAYER_INTERNAL', true); }
define('CS_PLAYER_SHARED_STORAGE', CS_PLAYER_ROOT . '/storage');
define('CS_PLAYER_CONFIG_PRIMARY', dirname(__DIR__) . '/logs/cs-player/web-player-config.php');
define('CS_PLAYER_CONFIG_FILE', CS_PLAYER_SHARED_STORAGE . '/config.php'); // legado/migração; não sobrescrever em atualizações
define('CS_PLAYER_RUNTIME_CONFIG_FILE', CS_PLAYER_CONFIG_PRIMARY);
define('CS_PLAYER_DNS_HEALTH_FILE', dirname(__DIR__) . '/logs/cs-player/web-player-dns-health.php');
define('CS_PLAYER_RUNTIME_CONFIG_FALLBACK_FILE', CS_PLAYER_SHARED_STORAGE . '/runtime-config.php');
define('CS_PLAYER_RUNTIME_CONFIG_BACKUP_FILE', dirname(__DIR__) . '/logs/cs-player/web-player-config.bak.php');
define('CS_PLAYER_RUNTIME_CONFIG_TMP_FILE', rtrim(sys_get_temp_dir(), '/\\') . '/cs-player-web-player-config.php');
define('CS_PLAYER_CONFIG_MIGRATION_MARKER', CS_PLAYER_CONFIG_PRIMARY . '.migration-v1');

if (!function_exists('cs_player_write_log')) {
    function cs_player_log_path(): string {
        return dirname(__DIR__) . '/logs/cs-player/web-player.log';
    }

    function cs_player_rotate_log_if_needed(string $path, int $maxBytes = 5242880): void {
        if (!is_file($path)) return;
        $size = @filesize($path);
        if (!is_int($size) || $size < $maxBytes) return;
        $backup = $path . '.1';
        if (is_file($backup)) @unlink($backup);
        @rename($path, $backup);
    }

    function cs_player_write_log(string $event, array $context = [], string $level = 'error'): bool {
        $path = cs_player_log_path();
        cs_player_rotate_log_if_needed($path);
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $safe = [];
        foreach ($context as $key => $value) {
            $key = preg_replace('/[^a-zA-Z0-9_.-]/', '_', (string)$key);
            if (preg_match('/pass|password|token|secret|api[_-]?key/i', $key)) {
                $safe[$key] = '[REDACTED]';
            } elseif (is_scalar($value) || $value === null) {
                $safe[$key] = $value;
            } else {
                $safe[$key] = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }
        }
        $line = json_encode([
            'time' => date('c'),
            'level' => strtolower($level),
            'event' => (string)$event,
            'request_id' => substr(hash('sha256', session_id() . '|' . microtime(true) . '|' . random_int(0, PHP_INT_MAX)), 0, 12),
            'context' => $safe,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($line) && @file_put_contents($path, $line . PHP_EOL, FILE_APPEND | LOCK_EX) !== false;
    }
}

define('CS_PLAYER_LEGACY_CONFIG_FILE', CS_PLAYER_SHARED_STORAGE . '/config.json');

/**
 * Carrega as dependências críticas de forma segura.
 * Se um arquivo estiver ausente, gera um erro controlado em vez de fatal.
 */
$required_dependencies = [
    'http_transport.php',
    'json_dns_compat.php',
    'legacy_compat.php',
    'dns_health.php'
];

foreach ($required_dependencies as $dependency) {
    $dependency_path = __DIR__ . '/' . $dependency;
    if (!is_file($dependency_path)) {
        if (function_exists('cs_player_write_log')) {
            cs_player_write_log('missing_dependency', ['file' => $dependency], 'error');
        }
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
        exit('CS PLAYER: dependência ausente - ' . $dependency);
    }
    require_once $dependency_path;
}

function cs_player_default_config(): array {
    return [
        'enabled' => true,
        'brand' => 'CS Player',
        'login_title' => 'CS Player',
        'login_subtitle' => 'Entre com sua assinatura para continuar',
        'home_title' => 'Início',
        'smart_login' => true,
        'dns_failover' => true,
        'dns_strategy' => 'smart',
        'dns_fail_threshold' => 2,
        'dns_cooldown' => 90,
        'dns_prefer_last' => true,
        'dns_json_compat' => true,
        // Descoberta inteligente de rota: preserva o DNS informado e, quando necessário,
        // tenta HTTP/HTTPS e portas padrão sem alterar a configuração salva.
        'dns_auto_discovery' => true,
        'dns_discovery_max_candidates' => 4,
        'pip_enabled' => true,
        'autoplay_next' => false,
        'remember_position' => true,
        'hls_retries' => 7,
        'stall_timeout' => 15,
        'request_timeout' => 8,
        'allow_legacy_tls' => false,
        'dns' => [
            [
                'id' => 'builtin_main_server',
                'name' => 'Main Server',
                'url' => 'http://169.58.140.143:80',
                'enabled' => true,
                'priority' => 10,
                'provider_mode' => 'auto',
                'http_profile' => 'smarters',
                'ip_mode' => 'ipv4',
                'output' => 'mpegts',
                'm3u_path' => 'get.php',
            ],
            [
                'id' => 'builtin_powerplay',
                'name' => 'Power play',
                'url' => 'http://power08121562.shop:80',
                'enabled' => true,
                'priority' => 20,
                'provider_mode' => 'm3u',
                'http_profile' => 'smarters',
                'ip_mode' => 'ipv4',
                'output' => 'mpegts',
                'm3u_path' => 'get.php',
            ],
        ],
        'provider_auto_fallback_m3u' => true,
        'm3u_cache_ttl' => 1800,
        'm3u_user_agent' => 'IPTVSmartersPro',
        'manual_highlights' => [],
        'hero_autoplay' => true,
        'hero_interval' => 8,
        'hero_order' => 'manual',
        'proxy_enabled' => true,
        'proxy_hls' => true,
        'proxy_vod' => true,
        'proxy_cast' => true,
        'proxy_log_enabled' => true,
        'proxy_retries' => 4,
        'proxy_connect_timeout' => 5,
        'proxy_read_timeout' => 24,
        'proxy_manifest_cache' => 1,
        'stream_delivery_mode' => 'auto',
        'stream_hide_origin' => true,
        'delivery_hls' => 'proxy_hls',
        'delivery_ts' => 'proxy',
        'delivery_mp4' => 'proxy',
        'delivery_mkv' => 'proxy',
        // CS PLAYER 4.0.4 — motores especializados
        'live_player_enabled' => true,
        'live_prefer_ts' => true,
        'live_proxy_mode' => 'proxy',
        'live_epg_enabled' => true,
        'live_epg_url' => '',
        'live_epg_cache_ttl' => 300,
        'vod_player_enabled' => true,
        'vod_proxy_mode' => 'proxy',
        'vod_mkv_remux' => true,
        'vod_tmdb_enabled' => true,
        'vod_autoplay_next' => true,

        // CS PLAYER 4.0.6 — experiência profissional
        'advanced_pip_enabled' => true,
        'pip_auto_fallback' => true,
        'pip_floating_enabled' => true,
        'pip_floating_width' => 420,
        'pip_floating_mobile_width' => 94,
        'pip_show_title' => true,
        'pip_show_status' => true,
        'player_autoplay' => true,
        'player_preload' => 'auto',
        'player_resume_enabled' => true,
        'player_resume_min_seconds' => 15,
        'player_resume_save_interval' => 5,
        'player_keyboard_shortcuts' => true,
        'player_keep_awake' => true,
        'player_max_recovery_cycles' => 4,
        'player_recovery_backoff_ms' => 650,
        'prefer_direct_source' => true,
        'client_profile_enabled' => true,
        'client_show_expiry' => true,
        'client_show_connections' => true,

        'ads_enabled' => false,
        'ads_preroll_url' => '',
        'ads_preroll_type' => 'auto',
        'ads_click_url' => '',
        'ads_skip_seconds' => 5,
        'ads_image_seconds' => 8,
        'ads_frequency' => 'session',
    ];
}

function cs_player_bool($value, bool $default = false): bool {
    if (is_bool($value)) return $value;
    if (is_int($value) || is_float($value)) return (int)$value !== 0;
    if (is_string($value)) {
        $value = strtolower(trim($value));
        if (in_array($value, ['0', 'false', 'off', 'no', 'disabled', ''], true)) return false;
        if (in_array($value, ['1', 'true', 'on', 'yes', 'enabled'], true)) return true;
    }
    return $default;
}

function cs_player_resolve_delivery_mode(string $type, string $extension = '', string $requested = 'auto', array $itemConfig = [], ?array $globalConfig = null): string {
    $cfg = $globalConfig ?? cs_player_load_config();
    $valid = ['auto', 'direct', 'proxy', 'proxy_hls', 'remux'];
    $requested = strtolower(trim($requested));
    $itemMode = strtolower(trim((string)($itemConfig['delivery_mode'] ?? 'inherit')));
    if (in_array($itemMode, $valid, true) && $itemMode !== 'auto') return $itemMode;
    if (in_array($requested, $valid, true) && $requested !== 'auto') return $requested;

    $type = strtolower(trim($type));
    $extension = strtolower(ltrim(trim($extension), '.'));
    $formatKey = '';
    if (in_array($extension, ['m3u8', 'm3u'], true)) $formatKey = 'delivery_hls';
    elseif (in_array($extension, ['ts', 'mpegts'], true)) $formatKey = 'delivery_ts';
    elseif ($extension === 'mp4') $formatKey = 'delivery_mp4';
    elseif ($extension === 'mkv') $formatKey = 'delivery_mkv';

    $candidates = [];
    if ($formatKey !== '') $candidates[] = (string)($cfg[$formatKey] ?? 'auto');
    if ($type === 'live') $candidates[] = (string)($cfg['live_proxy_mode'] ?? 'auto');
    elseif (in_array($type, ['movie', 'series', 'vod'], true)) $candidates[] = (string)($cfg['vod_proxy_mode'] ?? 'auto');
    $candidates[] = (string)($cfg['stream_delivery_mode'] ?? 'auto');

    foreach ($candidates as $mode) {
        $mode = strtolower(trim($mode));
        if (in_array($mode, $valid, true) && $mode !== 'auto') return $mode;
    }

    $proxyEnabled = cs_player_bool($cfg['proxy_enabled'] ?? false, false);
    if (!$proxyEnabled) return 'direct';
    if (in_array($extension, ['m3u8', 'm3u'], true) && cs_player_bool($cfg['proxy_hls'] ?? false, false)) return 'proxy_hls';
    if ($type === 'live' && cs_player_bool($cfg['proxy_hls'] ?? false, false)) return 'proxy';
    if (in_array($type, ['movie', 'series', 'vod'], true) && cs_player_bool($cfg['proxy_vod'] ?? false, false)) return 'proxy';
    return 'direct';
}

function cs_player_load_config(): array {
    $default = cs_player_default_config();
    $data = null;
    $loadedFrom = '';

    // A configuração oficial é a única fonte de leitura normal. Fallbacks não
    // podem vencer por mtime, pois isso faz cópias antigas ou temporárias retornarem.
    $primary = CS_PLAYER_CONFIG_PRIMARY;
    if (is_file($primary) && is_readable($primary) && (int)@filesize($primary) > 20) {
        try {
            $loaded = include $primary;
            if (is_array($loaded)) {
                $data = $loaded;
                $loadedFrom = $primary;
            } else {
                cs_player_write_log('runtime_config_invalid', ['location'=>basename($primary),'reason'=>'not_array'], 'warning');
            }
        } catch (\Throwable $e) {
            cs_player_write_log('runtime_config_load_failed', [
                'location'=>basename($primary),
                'error_class'=>get_class($e),
                'message_hash'=>substr(hash('sha256', $e->getMessage()), 0, 12),
                'line'=>$e->getLine(),
            ], 'error');
        }
    }

    // O backup é apenas recuperação explícita quando a fonte oficial não pode
    // ser lida. Storage/runtime-config.php e /tmp nunca são fontes de leitura.
    if (!is_array($data) && is_file(CS_PLAYER_RUNTIME_CONFIG_BACKUP_FILE)) {
        try {
            $loaded = include CS_PLAYER_RUNTIME_CONFIG_BACKUP_FILE;
            if (is_array($loaded)) {
                $data = $loaded;
                $loadedFrom = CS_PLAYER_RUNTIME_CONFIG_BACKUP_FILE;
                cs_player_write_log('runtime_config_fallback_loaded', ['location'=>basename(CS_PLAYER_RUNTIME_CONFIG_BACKUP_FILE),'reason'=>'backup_recovery'], 'warning');
            }
        } catch (\Throwable $e) {
            cs_player_write_log('runtime_config_load_failed', ['location'=>basename(CS_PLAYER_RUNTIME_CONFIG_BACKUP_FILE),'error_class'=>get_class($e),'message_hash'=>substr(hash('sha256',$e->getMessage()),0,12),'line'=>$e->getLine()], 'error');
        }
    }

    // Migração de arquivos antigos somente quando ainda não existe marcador.
    // Os arquivos legados são preservados para compatibilidade e auditoria, mas
    // deixam de participar da leitura normal após a gravação oficial.
    if (!is_array($data) && !is_file(CS_PLAYER_CONFIG_MIGRATION_MARKER) && is_file(CS_PLAYER_CONFIG_FILE)) {
        $loaded = include CS_PLAYER_CONFIG_FILE;
        if (is_array($loaded)) {
            if (cs_player_save_config($loaded)) {
                $data = $loaded;
                @file_put_contents(CS_PLAYER_CONFIG_MIGRATION_MARKER, "php-config-migrated\n", LOCK_EX);
                @chmod(CS_PLAYER_CONFIG_MIGRATION_MARKER, 0640);
                cs_player_write_log('legacy_config_migrated', ['location'=>basename(CS_PLAYER_CONFIG_FILE)], 'info');
            }
        }
    }
    if (!is_array($data) && !is_file(CS_PLAYER_CONFIG_MIGRATION_MARKER) && is_file(CS_PLAYER_LEGACY_CONFIG_FILE)) {
        $raw = @file_get_contents(CS_PLAYER_LEGACY_CONFIG_FILE);
        $legacy = json_decode((string)$raw, true);
        if (is_array($legacy) && cs_player_save_config($legacy)) {
            $data = $legacy;
            @file_put_contents(CS_PLAYER_CONFIG_MIGRATION_MARKER, "json-config-migrated\n", LOCK_EX);
            @chmod(CS_PLAYER_CONFIG_MIGRATION_MARKER, 0640);
            cs_player_write_log('legacy_config_migrated', ['location'=>basename(CS_PLAYER_LEGACY_CONFIG_FILE)], 'info');
        }
    }

    // Último caminho de recuperação: instalações antigas podem ter apenas
    // web-player-dns.json. Use-o somente se nenhuma configuração oficial,
    // backup ou arquivo legado foi encontrado; servidores do espelho não
    // competem com a fonte oficial quando ela existir.
    if (!is_array($data) && defined('CS_PLAYER_DNS_JSON_FILE') && is_file(CS_PLAYER_DNS_JSON_FILE) && function_exists('cs_player_json_dns_load')) {
        $legacyDnsRows = cs_player_json_dns_load($default);
        if (is_array($legacyDnsRows) && $legacyDnsRows) {
            $default['dns'] = $legacyDnsRows;
            $data = $default;
            $loadedFrom = CS_PLAYER_DNS_JSON_FILE;
            cs_player_write_log('legacy_dns_json_recovered', ['location'=>basename(CS_PLAYER_DNS_JSON_FILE),'dns_count'=>count($legacyDnsRows)], 'warning');
        }
    }
    if (!is_array($data)) return $default;
    $cfg = array_replace($default, $data);
    $cfg['dns'] = is_array($cfg['dns'] ?? null) ? array_values($cfg['dns']) : [];

    $normalizedDns = [];
    $seenDns = [];
    foreach ($cfg['dns'] as $row) {
        if (!is_array($row)) continue;
        $url = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($url === '') continue;
        $key = strtolower(rtrim($url, '/'));
        if (isset($seenDns[$key])) continue;
        $seenDns[$key] = true;
        $row['url'] = $url;
        $normalizedDns[] = $row;
    }
    $cfg['dns'] = array_values($normalizedDns);
    foreach ($cfg['dns'] as &$dnsRow) {
        if (is_array($dnsRow) && array_key_exists('enabled', $dnsRow)) $dnsRow['enabled'] = cs_player_bool($dnsRow['enabled'], false);
    }
    unset($dnsRow);
    $cfg['manual_highlights'] = is_array($cfg['manual_highlights'] ?? null) ? array_values($cfg['manual_highlights']) : [];
    $validDelivery = ['auto','direct','proxy','proxy_hls'];
    $cfg['stream_delivery_mode'] = in_array((string)($cfg['stream_delivery_mode'] ?? 'auto'), $validDelivery, true) ? (string)$cfg['stream_delivery_mode'] : 'auto';
    foreach (['delivery_hls','delivery_ts','delivery_mp4','delivery_mkv'] as $deliveryKey) {
        $cfg[$deliveryKey] = in_array((string)($cfg[$deliveryKey] ?? 'auto'), $validDelivery, true) ? (string)$cfg[$deliveryKey] : 'auto';
    }
    $cfg['stream_hide_origin'] = !array_key_exists('stream_hide_origin', $cfg) || cs_player_bool($cfg['stream_hide_origin'], true);
    $cfg['ads_enabled'] = cs_player_bool($cfg['ads_enabled'] ?? false, false);
    $cfg['allow_legacy_tls'] = cs_player_bool($cfg['allow_legacy_tls'] ?? false, false);
    $cfg['ads_preroll_url'] = trim((string)($cfg['ads_preroll_url'] ?? ''));
    $cfg['ads_preroll_type'] = in_array((string)($cfg['ads_preroll_type'] ?? 'auto'), ['auto','video','image'], true) ? (string)$cfg['ads_preroll_type'] : 'auto';
    $cfg['ads_click_url'] = trim((string)($cfg['ads_click_url'] ?? ''));
    $cfg['ads_skip_seconds'] = max(0,min(30,(int)($cfg['ads_skip_seconds'] ?? 5)));
    $cfg['ads_image_seconds'] = max(3,min(60,(int)($cfg['ads_image_seconds'] ?? 8)));
    $cfg['ads_frequency'] = in_array((string)($cfg['ads_frequency'] ?? 'session'), ['always','session','content'], true) ? (string)$cfg['ads_frequency'] : 'session';
    $cfg['live_player_enabled'] = !array_key_exists('live_player_enabled', $cfg) || cs_player_bool($cfg['live_player_enabled'], true);
    $cfg['live_prefer_ts'] = !array_key_exists('live_prefer_ts', $cfg) || cs_player_bool($cfg['live_prefer_ts'], true);
    $cfg['live_proxy_mode'] = in_array((string)($cfg['live_proxy_mode'] ?? 'proxy'), ['auto','direct','proxy','proxy_hls'], true) ? (string)$cfg['live_proxy_mode'] : 'proxy';
    $cfg['live_epg_enabled'] = !array_key_exists('live_epg_enabled', $cfg) || cs_player_bool($cfg['live_epg_enabled'], true);
    $cfg['live_epg_url'] = trim((string)($cfg['live_epg_url'] ?? ''));
    $cfg['live_epg_cache_ttl'] = max(60,min(3600,(int)($cfg['live_epg_cache_ttl'] ?? 300)));
    $cfg['vod_player_enabled'] = !array_key_exists('vod_player_enabled', $cfg) || cs_player_bool($cfg['vod_player_enabled'], true);
    $cfg['vod_proxy_mode'] = in_array((string)($cfg['vod_proxy_mode'] ?? 'proxy'), ['auto','direct','proxy'], true) ? (string)$cfg['vod_proxy_mode'] : 'proxy';
    $cfg['vod_mkv_remux'] = !array_key_exists('vod_mkv_remux', $cfg) || cs_player_bool($cfg['vod_mkv_remux'], true);
    $cfg['vod_tmdb_enabled'] = !array_key_exists('vod_tmdb_enabled', $cfg) || cs_player_bool($cfg['vod_tmdb_enabled'], true);
    $cfg['vod_autoplay_next'] = !array_key_exists('vod_autoplay_next', $cfg) || cs_player_bool($cfg['vod_autoplay_next'], true);
    foreach ([
        'advanced_pip_enabled','pip_auto_fallback','pip_floating_enabled','pip_show_title',
        'pip_show_status','player_autoplay','player_resume_enabled','player_keyboard_shortcuts',
        'player_keep_awake','prefer_direct_source','client_profile_enabled','client_show_expiry',
        'client_show_connections'
    ] as $k) {
        $cfg[$k] = !array_key_exists($k, $cfg) || cs_player_bool($cfg[$k], true);
    }
    $cfg['pip_floating_width']=max(280,min(720,(int)($cfg['pip_floating_width']??420)));
    $cfg['pip_floating_mobile_width']=max(70,min(100,(int)($cfg['pip_floating_mobile_width']??94)));
    $cfg['player_preload']=in_array((string)($cfg['player_preload']??'auto'),['none','metadata','auto'],true)?(string)$cfg['player_preload']:'auto';
    $cfg['player_resume_min_seconds']=max(5,min(300,(int)($cfg['player_resume_min_seconds']??15)));
    $cfg['player_resume_save_interval']=max(2,min(30,(int)($cfg['player_resume_save_interval']??5)));
    $cfg['player_max_recovery_cycles']=max(1,min(10,(int)($cfg['player_max_recovery_cycles']??4)));
    $cfg['player_recovery_backoff_ms']=max(250,min(5000,(int)($cfg['player_recovery_backoff_ms']??650)));
    return $cfg;
}

function cs_player_config_file_valid(string $path): bool {
    if (!is_file($path) || !is_readable($path) || (int)@filesize($path) <= 20) return false;
    try {
        $loaded = include $path;
        return is_array($loaded);
    } catch (\Throwable $e) {
        cs_player_write_log('runtime_config_validation_failed', [
            'location'=>basename($path),
            'error_class'=>get_class($e),
            'message_hash'=>substr(hash('sha256', $e->getMessage()), 0, 12),
        ], 'error');
        return false;
    }
}

function cs_player_config_write_file(string $path, array $config): bool {
    $dir = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    if (!is_writable($dir)) return false;
    $tmp = @tempnam($dir, '.cs-player-config-');
    if (!is_string($tmp) || $tmp === '') return false;
    $php = "<?php\nif (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }\nreturn " . var_export($config, true) . ";\n";
    $fp = @fopen($tmp, 'wb');
    if (!is_resource($fp)) { @unlink($tmp); return false; }
    $locked = @flock($fp, LOCK_EX);
    $written = false;
    if ($locked) {
        $length = strlen($php);
        $offset = 0;
        while ($offset < $length) {
            $chunk = @fwrite($fp, substr($php, $offset));
            if ($chunk === false || $chunk === 0) break;
            $offset += $chunk;
        }
        $written = $offset === $length;
        if ($written) {
            @fflush($fp);
            if (function_exists('fsync')) @fsync($fp);
        }
        @flock($fp, LOCK_UN);
    }
    @fclose($fp);
    if (!$written) { @unlink($tmp); return false; }
    @chmod($tmp, 0640);
    if (!@rename($tmp, $path)) { @unlink($tmp); return false; }
    @chmod($path, 0640);
    if (function_exists('opcache_invalidate')) @opcache_invalidate($path, true);
    return cs_player_config_file_valid($path);
}

function cs_player_save_config(array $config): bool {
    $primary = CS_PLAYER_CONFIG_PRIMARY;
    $previous = is_file($primary) ? @file_get_contents($primary) : false;
    if (is_string($previous) && strlen($previous) > 20) {
        $bakDir = dirname(CS_PLAYER_RUNTIME_CONFIG_BACKUP_FILE);
        if ((is_dir($bakDir) || @mkdir($bakDir, 0750, true)) && is_writable($bakDir)) {
            @file_put_contents(CS_PLAYER_RUNTIME_CONFIG_BACKUP_FILE, $previous, LOCK_EX);
            @chmod(CS_PLAYER_RUNTIME_CONFIG_BACKUP_FILE, 0640);
        }
        $old = @include $primary;
        if (is_array($old) && !array_key_exists('config_version', $config)) {
            $config['config_version'] = max(1, (int)($old['config_version'] ?? 0) + 1);
        }
    }
    if (!array_key_exists('config_version', $config)) $config['config_version'] = 1;
    $config['updated_at'] = time();

    if (!cs_player_config_write_file($primary, $config)) {
        cs_player_write_log('runtime_config_save_failed', [
            'location'=>basename($primary),
            'dir_exists'=>is_dir(dirname($primary)),
            'dir_writable'=>is_writable(dirname($primary)),
        ], 'error');
        return false;
    }

    $persisted = @include $primary;
    if (!is_array($persisted) || $persisted !== $config) {
        cs_player_write_log('runtime_config_save_verify_failed', [
            'location'=>basename($primary),
            'persisted_is_array'=>is_array($persisted),
        ], 'error');
        return false;
    }
    if (function_exists('cs_player_json_dns_save') && !cs_player_json_dns_save($config)) {
        cs_player_write_log('json_dns_mirror_save_failed', ['dns_count'=>count(is_array($config['dns'] ?? null) ? $config['dns'] : [])], 'warning');
    }
    cs_player_write_log('runtime_config_saved', [
        'location'=>basename($primary),
        'config_version'=>(int)$config['config_version'],
        'dns_count'=>count(is_array($config['dns'] ?? null) ? $config['dns'] : []),
    ], 'info');
    return true;
}

/** Saúde adaptativa dos DNS isolada do bootstrap principal. */
require_once CS_PLAYER_ROOT . '/dns_health.php';

function cs_player_normalize_dns(string $url): string {
    $url = trim($url);
    if ($url === '') return '';
    $url = preg_replace('~\s+~', '', $url) ?? $url;
    if (preg_match('~^https?://https?://~i', $url)) return '';
    $url = preg_replace('~^(https?://)\[(\d{1,3}(?:\.\d{1,3}){3}):?\](?=[:/]|$)~i', '$1$2', $url) ?? $url;
    if (!preg_match('~^https?://~i', $url)) {
        $bare = trim($url);
        if (preg_match('~^(\d{1,3}(?:\.\d{1,3}){3}):$~', $bare, $m)) $bare = $m[1];
        if (substr_count($bare, ':') >= 2 && strpos($bare, '/') === false && isset($bare[0]) && $bare[0] !== '[') {
            $bare = rtrim($bare, ':');
            $url = 'http://[' . trim($bare, '[]') . ']';
        } else {
            $url = 'http://' . $bare;
        }
    }
    $parts = @parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) return '';
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    if (!in_array($scheme, ['http', 'https'], true)) return '';
    $host = strtolower(trim((string)$parts['host'], "[] \t\n\r\0\x0B"));
    $host = rtrim($host, ':');
    if ($host === '') return '';
    $isIpv6 = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false;
    $isIpv4 = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false;
    if (!$isIpv4 && !$isIpv6 && function_exists('idn_to_ascii')) {
        $idn = @idn_to_ascii($host, 0, defined('INTL_IDNA_VARIANT_UTS46') ? INTL_IDNA_VARIANT_UTS46 : 0);
        if (is_string($idn) && $idn !== '') $host = strtolower($idn);
    }
    if (!$isIpv4 && !$isIpv6 && !preg_match('~^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$~i', $host)) return '';
    $renderHost = $isIpv6 ? '[' . $host . ']' : $host;
    $portNum = isset($parts['port']) ? (int)$parts['port'] : 0;
    $port = ($portNum >= 1 && $portNum <= 65535) ? ':' . $portNum : '';
    $path = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
    $path = preg_replace('~/(?:player_api|panel_api|get)\.php$~i', '', $path) ?? $path;
    return $scheme . '://' . $renderHost . $port . rtrim($path, '/');
}

/**
 * Gera rotas de conexão para um DNS sem destruir o endereço configurado.
 * A primeira rota é SEMPRE o valor salvo pelo administrador.
 *
 * Exemplos aceitos:
 *   1.2.3.4 | 1.2.3.4:8080 | dominio.tld | dominio.tld:8080
 *   http(s)://host[:porta][/prefixo] | .../get.php?... | IPv6 [::1]:porta
 */
function cs_player_dns_route_candidates(string $url, int $limit = 4): array {
    $normalized = cs_player_normalize_dns($url);
    if ($normalized === '') return [];
    $limit = max(1, min(8, $limit));
    $parts = @parse_url($normalized);
    if (!is_array($parts) || empty($parts['host'])) return [$normalized];

    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    $host = trim((string)$parts['host'], '[]');
    $isIpv6 = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false;
    $renderHost = $isIpv6 ? '[' . $host . ']' : $host;
    $path = isset($parts['path']) ? '/' . ltrim((string)$parts['path'], '/') : '';
    $path = rtrim($path, '/');
    if ($path === '/') $path = '';
    $explicitPort = isset($parts['port']) ? (int)$parts['port'] : 0;

    $raw = [];
    $add = static function (string $candidate) use (&$raw): void {
        $candidate = cs_player_normalize_dns($candidate);
        if ($candidate === '') return;
        $key = strtolower(rtrim($candidate, '/'));
        if (!isset($raw[$key])) $raw[$key] = $candidate;
    };

    // 1) endereço exatamente como foi configurado.
    $add($normalized);

    if ($explicitPort > 0) {
        // Porta explícita é soberana: nunca a troca silenciosamente.
        // Apenas testa o outro esquema na MESMA porta como fallback de compatibilidade.
        $otherScheme = $scheme === 'https' ? 'http' : 'https';
        $add($otherScheme . '://' . $renderHost . ':' . $explicitPort . $path);
    } else {
        // Sem porta explícita: tenta os pares canônicos, mantendo o esquema preferido primeiro.
        if ($scheme === 'https') {
            $add('https://' . $renderHost . ':443' . $path);
            $add('http://' . $renderHost . $path);
            $add('http://' . $renderHost . ':80' . $path);
        } else {
            $add('http://' . $renderHost . ':80' . $path);
            $add('https://' . $renderHost . $path);
            $add('https://' . $renderHost . ':443' . $path);
        }
    }

    return array_slice(array_values($raw), 0, $limit);
}

function cs_player_with_port(string $url, int $port): string {
    $url = cs_player_normalize_dns($url);
    if ($url === '' || $port < 1 || $port > 65535) return $url;
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['host']) || isset($parts['port'])) return $url;
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    $host = trim((string)$parts['host'], '[]');
    $renderHost = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false ? '[' . $host . ']' : $host;
    $path = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
    return $scheme . '://' . $renderHost . ':' . $port . $path;
}

function cs_player_build_server_url(array $server): string {
    $domain = trim((string)($server['domain_name'] ?? ''));
    $ip = trim((string)($server['server_ip'] ?? ''));
    $source = $domain !== '' ? $domain : $ip;
    if ($source === '') return '';

    $candidate = cs_player_normalize_dns($source);
    if ($candidate === '') return '';
    $parts = parse_url($candidate);
    if (!is_array($parts) || empty($parts['host'])) return '';

    $host = trim((string)$parts['host'], '[]');
    $host = rtrim($host, ':');
    if ($host === '') return '';
    $renderHost = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false ? '[' . $host . ']' : $host;
    $configuredPort = isset($parts['port']) ? (int)$parts['port'] : 0;
    $httpPort = (int)($server['http_broadcast_port'] ?? 0);
    if ($httpPort < 1 || $httpPort > 65535) $httpPort = $configuredPort > 0 ? $configuredPort : 80;
    $path = rtrim((string)($parts['path'] ?? ''), '/');
    return 'http://' . $renderHost . ':' . $httpPort . $path;
}

function cs_player_server_url_candidates(array $server): array {
    $primary = cs_player_build_server_url($server);
    if ($primary === '') return [];
    $routes = [$primary];
    $parts = parse_url($primary);
    if (!is_array($parts) || empty($parts['host'])) return $routes;
    $host = trim((string)$parts['host'], '[]');
    $renderHost = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false ? '[' . $host . ']' : $host;
    $path = rtrim((string)($parts['path'] ?? ''), '/');
    $httpsPort = (int)($server['https_broadcast_port'] ?? 0);
    if ($httpsPort >= 1 && $httpsPort <= 65535) {
        $routes[] = 'https://' . $renderHost . ':' . $httpsPort . $path;
    }
    $unique = [];
    foreach ($routes as $route) {
        $normalized = cs_player_normalize_dns($route);
        if ($normalized !== '' && !isset($unique[strtolower(rtrim($normalized, '/'))])) $unique[strtolower(rtrim($normalized, '/'))] = $normalized;
    }
    return array_values($unique);
}

function cs_player_server_dns_from_rows(array $servers): array {
    $out = [];
    foreach ($servers as $server) {
        if (!is_array($server)) continue;
        if (isset($server['status']) && (int)$server['status'] !== 1) continue;
        $candidates = cs_player_server_url_candidates($server);
        $url = $candidates[0] ?? '';
        if ($url === '') continue;
        $id = (int)($server['id'] ?? 0);
        $httpPort = (int)($server['http_broadcast_port'] ?? 0);
        if ($httpPort < 1 || $httpPort > 65535) $httpPort = (int)(parse_url($url, PHP_URL_PORT) ?: 80);
        $httpsPort = (int)($server['https_broadcast_port'] ?? 0);
        if ($httpsPort < 1 || $httpsPort > 65535) $httpsPort = 0;
        $name = trim((string)($server['server_name'] ?? ''));
        if ($name === '') $name = $id > 0 ? 'Servidor #' . $id : 'Servidor CS Player';
        $out[] = [
            'id' => 'server_' . ($id > 0 ? $id : substr(sha1($url), 0, 8)),
            'server_id' => $id,
            'name' => $name,
            'url' => $url,
            'fallback_urls' => $candidates,
            'http_port' => $httpPort,
            'https_port' => $httpsPort,
            'enabled' => true,
            'priority' => max(1, $id > 0 ? $id : count($out) + 1),
            'fixed' => true,
            'source' => 'streaming_servers',
        ];
    }
    return $out;
}

function cs_player_decode_main_config(string $path): ?array {
    if (!is_file($path)) return null;
    $raw = file_get_contents($path);
    if (!is_string($raw) || $raw === '') return null;
    $decoded = base64_decode($raw, true);
    if ($decoded === false) return null;
    $key = '5709650b0d7806074842c6de575025b1';
    $out = '';
    $keyLen = strlen($key);
    for ($i = 0, $len = strlen($decoded); $i < $len; $i++) {
        $out .= chr(ord($decoded[$i]) ^ ord($key[$i % $keyLen]));
    }
    $data = json_decode($out, true);
    return is_array($data) ? $data : null;
}

function cs_player_db(): ?mysqli {
    static $db = null;
    static $failed = false;
    if ($db instanceof mysqli) return $db;
    if ($failed || !class_exists('mysqli')) return null;
    $info = cs_player_decode_main_config('/home/xtreamcodes/iptv_xtream_codes/config');
    if (!is_array($info)) { $failed = true; return null; }
    mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $conn = @new mysqli(
            (string)($info['host'] ?? 'localhost'),
            (string)($info['db_user'] ?? 'root'),
            (string)($info['db_pass'] ?? ''),
            (string)($info['db_name'] ?? 'xtream_iptvpro'),
            (int)($info['db_port'] ?? 3306)
        );
        if ($conn->connect_errno) { $failed = true; return null; }
        @$conn->set_charset('utf8mb4');
        $db = $conn;
        return $db;
    } catch (\Throwable $e) {
        $failed = true;
        cs_player_write_log('local_db_connect_failed', [
            'error_class'=>get_class($e),
            'message_hash'=>substr(hash('sha256', $e->getMessage()), 0, 12),
        ], 'error');
        return null;
    }
}

function cs_player_client_email_aliases(): array {
    $file = __DIR__ . '/data/client_email_aliases.json';
    if (!is_file($file)) return [];
    $data = json_decode((string)@file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function cs_player_alias_user_id(string $login): int {
    $login = strtolower(trim($login));
    if ($login === '' || strpos($login, '@') === false) return 0;
    foreach (cs_player_client_email_aliases() as $id => $email) {
        if (strtolower(trim((string)$email)) === $login) return (int)$id;
    }
    return 0;
}

function cs_player_users_has_email_column(mysqli $db): bool {
    static $has = null;
    if ($has !== null) return $has;
    $r = @$db->query("SHOW COLUMNS FROM `users` LIKE 'email'");
    $has = $r && $r->num_rows > 0;
    return $has;
}

function cs_player_local_user(string $username, string $password): ?array {
    $db = cs_player_db();
    if (!$db) return null;
    $login = trim($username);
    $aliasId = cs_player_alias_user_id($login);
    if ($aliasId > 0) {
        $stmt = $db->prepare('SELECT * FROM `users` WHERE `id`=? AND `password`=? LIMIT 1');
        if (!$stmt) return null;
        $stmt->bind_param('is', $aliasId, $password);
    } elseif (cs_player_users_has_email_column($db) && strpos($login, '@') !== false) {
        $stmt = $db->prepare('SELECT * FROM `users` WHERE (`username`=? OR LOWER(`email`)=LOWER(?)) AND `password`=? LIMIT 1');
        if (!$stmt) return null;
        $stmt->bind_param('sss', $login, $login, $password);
    } else {
        $stmt = $db->prepare('SELECT * FROM `users` WHERE `username`=? AND `password`=? LIMIT 1');
        if (!$stmt) return null;
        $stmt->bind_param('ss', $login, $password);
    }
    if (!$stmt->execute()) { $stmt->close(); return null; }
    $res = $stmt->get_result();
    $user = $res ? $res->fetch_assoc() : null;
    $stmt->close();
    if (!is_array($user)) return null;
    $now = time();
    if (isset($user['enabled']) && (int)$user['enabled'] !== 1) return null;
    if (isset($user['admin_enabled']) && (int)$user['admin_enabled'] !== 1) return null;
    if (!empty($user['exp_date']) && (int)$user['exp_date'] > 0 && (int)$user['exp_date'] < $now) return null;
    return $user;
}

function cs_player_remember_secret(): string {
    $seed = @file_get_contents('/home/xtreamcodes/iptv_xtream_codes/config');
    return hash('sha256', 'CSPLAYER-REMEMBER-V1|' . (string)$seed, true);
}

function cs_player_make_remember_token(array $user, int $days = 30): string {
    $id = (int)($user['id'] ?? 0);
    $exp = time() + max(1, $days) * 86400;
    $pwd = (string)($user['password'] ?? '');
    $payload = $id . '.' . $exp;
    $sig = hash_hmac('sha256', $payload . '|' . hash('sha256', $pwd), cs_player_remember_secret());
    return rtrim(strtr(base64_encode($payload . '.' . $sig), '+/', '-_'), '=');
}

function cs_player_user_from_remember_token(string $token): ?array {
    if ($token === '') return null;
    $raw = base64_decode(strtr($token, '-_', '+/'), true);
    if (!is_string($raw)) return null;
    $parts = explode('.', $raw, 3);
    if (count($parts) !== 3) return null;
    [$id, $exp, $sig] = $parts;
    if ((int)$id <= 0 || (int)$exp < time()) return null;
    $db = cs_player_db(); if (!$db) return null;
    $stmt = $db->prepare('SELECT * FROM `users` WHERE `id`=? LIMIT 1'); if (!$stmt) return null;
    $uid=(int)$id; $stmt->bind_param('i',$uid); $stmt->execute(); $res=$stmt->get_result(); $user=$res?$res->fetch_assoc():null; $stmt->close();
    if (!is_array($user)) return null;
    $payload = $uid . '.' . (int)$exp;
    $expected = hash_hmac('sha256', $payload . '|' . hash('sha256', (string)($user['password'] ?? '')), cs_player_remember_secret());
    if (!hash_equals($expected, (string)$sig)) return null;
    $now=time();
    if (isset($user['enabled']) && (int)$user['enabled'] !== 1) return null;
    if (isset($user['admin_enabled']) && (int)$user['admin_enabled'] !== 1) return null;
    if (!empty($user['exp_date']) && (int)$user['exp_date'] > 0 && (int)$user['exp_date'] < $now) return null;
    return $user;
}

function cs_player_json_ids($value): array {
    if (is_array($value)) $items = $value;
    else {
        $items = json_decode((string)$value, true);
        if (!is_array($items)) $items = [];
    }
    $out = [];
    foreach ($items as $id) { $id=(int)$id; if ($id>0) $out[$id]=$id; }
    return array_values($out);
}

function cs_player_local_permissions(array $user): array {
    $db = cs_player_db();
    $channels=[]; $series=[];
    $bouquets = cs_player_json_ids($user['bouquet'] ?? '[]');
    if (!$db || !$bouquets) return ['channels'=>[], 'series'=>[]];
    $in = implode(',', array_map('intval', $bouquets));
    $res = @$db->query("SELECT `bouquet_channels`,`bouquet_series` FROM `bouquets` WHERE `id` IN ($in)");
    if ($res) while ($row=$res->fetch_assoc()) {
        foreach (cs_player_json_ids($row['bouquet_channels'] ?? '[]') as $id) $channels[$id]=$id;
        foreach (cs_player_json_ids($row['bouquet_series'] ?? '[]') as $id) $series[$id]=$id;
    }
    return ['channels'=>array_values($channels), 'series'=>array_values($series)];
}

function cs_player_local_auth_response(array $user): array {
    $active = isset($user['active_cons']) ? (int)$user['active_cons'] : 0;
    return [
        'user_info'=>[
            'username'=>(string)($user['username']??''), 'auth'=>1,
            'status'=>'Active', 'exp_date'=>(string)($user['exp_date']??''),
            'is_trial'=>(string)($user['is_trial']??'0'),
            'active_cons'=>$active, 'created_at'=>(string)($user['created_at']??''),
            'max_connections'=>(string)($user['max_connections']??'1'),
            'allowed_output_formats'=>['m3u8','ts','rtmp']
        ],
        'server_info'=>[
            'url'=>(string)($_SERVER['HTTP_HOST']??''),
            'port'=>(string)($_SERVER['SERVER_PORT']??''),
            'https_port'=>'', 'server_protocol'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http',
            'timezone'=>date_default_timezone_get(), 'timestamp_now'=>time(), 'time_now'=>date('Y-m-d H:i:s')
        ]
    ];
}

function cs_player_local_categories(string $type, array $perms): array {
    $db=cs_player_db(); if(!$db) return [];
    $ids=[];
    if ($type==='series') {
        $series=$perms['series']??[]; if(!$series) return [];
        $in=implode(',',array_map('intval',$series));
        $res=@$db->query("SELECT DISTINCT sc.id,sc.category_name FROM series s JOIN stream_categories sc ON sc.id=s.category_id WHERE s.id IN ($in) AND sc.category_type='series' ORDER BY sc.cat_order,sc.category_name");
    } else {
        $channels=$perms['channels']??[]; if(!$channels) return [];
        $streamType=$type==='movie'?2:1; $catType=$type==='movie'?'movie':'live';
        $in=implode(',',array_map('intval',$channels));
        $res=@$db->query("SELECT DISTINCT sc.id,sc.category_name FROM streams s JOIN stream_categories sc ON sc.id=s.category_id WHERE s.id IN ($in) AND s.type=$streamType AND sc.category_type='$catType' ORDER BY sc.cat_order,sc.category_name");
    }
    if(!$res) return [];
    while($r=$res->fetch_assoc()) $ids[]=['category_id'=>(string)$r['id'],'category_name'=>(string)$r['category_name'],'parent_id'=>0];
    return $ids;
}

function cs_player_public_stream_url(string $type, int $id, string $ext, string $username, string $password): string {
    $scheme = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') ? 'https' : 'http';
    if (strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') $scheme = 'https';
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '') return '';
    $type = in_array($type, ['live','movie','series'], true) ? $type : 'live';
    $ext = strtolower(preg_replace('/[^a-z0-9]/i', '', $ext));
    if ($ext === '') $ext = $type === 'live' ? 'ts' : 'mp4';
    return $scheme.'://'.$host.'/cs_stream.php?type='.rawurlencode($type).'&username='.rawurlencode($username).'&password='.rawurlencode($password).'&id='.(int)$id.'&ext='.rawurlencode($ext);
}

function cs_player_local_streams(string $type, array $perms, ?int $categoryId=null, string $username='', string $password=''): array {
    $db=cs_player_db(); if(!$db) return [];
    $ids=$perms['channels']??[]; if(!$ids) return [];
    $streamType=$type==='movie'?2:1; $in=implode(',',array_map('intval',$ids));
    $where="s.id IN ($in) AND s.type=$streamType";
    if($categoryId && $categoryId>0) $where.=' AND s.category_id='.(int)$categoryId;
    $res=@$db->query("SELECT s.* FROM streams s WHERE $where ORDER BY s.stream_display_name ASC LIMIT 5000");
    if(!$res) return [];
    $out=[]; $num=0;
    while($r=$res->fetch_assoc()) {
        $props=json_decode((string)($r['movie_properties']??''),true); if(!is_array($props))$props=[];
        $ext=(string)($r['target_container']??($props['container_extension']??($type==='movie'?'mp4':'m3u8')));
        $icon=(string)($r['stream_icon']??($props['movie_image']??($props['cover_big']??'')));
        $item=['num'=>++$num,'name'=>(string)($r['stream_display_name']??''),'stream_type'=>$type==='movie'?'movie':'live','stream_id'=>(int)$r['id'],'stream_icon'=>$icon,'epg_channel_id'=>(string)($r['epg_id']??''),'added'=>(string)($r['added']??''),'category_id'=>(string)($r['category_id']??''),'custom_sid'=>(string)($r['custom_sid']??''),'tv_archive'=>(int)($r['tv_archive_duration']??0)>0?1:0,'direct_source'=>cs_player_public_stream_url($type==='movie'?'movie':'live',(int)$r['id'],$ext,$username,$password),'tv_archive_duration'=>(int)($r['tv_archive_duration']??0)];
        if($type==='movie'){$item['container_extension']=$ext;$item['rating']=(string)($props['rating']??'');$item['rating_5based']=$props['rating_5based']??0;}
        $out[]=$item;
    }
    return $out;
}

function cs_player_local_series(array $perms, ?int $categoryId=null): array {
    $db=cs_player_db(); if(!$db) return [];
    $ids=$perms['series']??[]; if(!$ids)return[]; $in=implode(',',array_map('intval',$ids));
    $where="id IN ($in)"; if($categoryId&&$categoryId>0)$where.=' AND category_id='.(int)$categoryId;
    $res=@$db->query("SELECT * FROM series WHERE $where ORDER BY title ASC LIMIT 5000"); if(!$res)return[];
    $out=[];$n=0; while($r=$res->fetch_assoc()){$out[]=['num'=>++$n,'name'=>(string)($r['title']??''),'series_id'=>(int)$r['id'],'cover'=>(string)($r['cover']??''),'plot'=>(string)($r['plot']??''),'cast'=>(string)($r['cast']??''),'director'=>(string)($r['director']??''),'genre'=>(string)($r['genre']??''),'releaseDate'=>(string)($r['releaseDate']??($r['release_date']??'')),'last_modified'=>(string)($r['last_modified']??''),'rating'=>(string)($r['rating']??''),'rating_5based'=>$r['rating_5based']??0,'backdrop_path'=>json_decode((string)($r['backdrop_path']??'[]'),true)?:[],'youtube_trailer'=>(string)($r['youtube_trailer']??''),'episode_run_time'=>(string)($r['episode_run_time']??''),'category_id'=>(string)($r['category_id']??'')];}
    return$out;
}

function cs_player_local_series_info(int $seriesId, array $perms, string $username='', string $password=''): ?array {
    if(!in_array($seriesId,$perms['series']??[],true))return null; $db=cs_player_db(); if(!$db)return null;
    $res=@$db->query('SELECT * FROM series WHERE id='.(int)$seriesId.' LIMIT 1'); $series=$res?$res->fetch_assoc():null; if(!$series)return null;
    $eps=[];$seasons=[]; $q=@$db->query("SELECT se.*,s.stream_display_name,s.target_container,s.stream_icon,s.added FROM series_episodes se JOIN streams s ON s.id=se.stream_id WHERE se.series_id=".(int)$seriesId." ORDER BY se.season_num,se.sort");
    if($q) while($r=$q->fetch_assoc()){$season=(int)($r['season_num']??0);$eid=(int)($r['stream_id']??0);$eps[(string)$season][]=['id'=>$eid,'episode_num'=>(int)($r['sort']??0),'title'=>(string)($r['stream_display_name']??''),'container_extension'=>(string)($r['target_container']??'mp4'),'info'=>['movie_image'=>(string)($r['stream_icon']??'')],'added'=>(string)($r['added']??''),'season'=>$season,'direct_source'=>cs_player_public_stream_url('series',$eid,(string)($r['target_container']??'mp4'),$username,$password)]; if(!isset($seasons[$season]))$seasons[$season]=['air_date'=>'','episode_count'=>0,'id'=>$season,'name'=>'Temporada '.$season,'overview'=>'','season_number'=>$season,'cover'=>(string)($series['cover']??'')];$seasons[$season]['episode_count']++;}
    return ['seasons'=>array_values($seasons),'info'=>['name'=>(string)($series['title']??''),'cover'=>(string)($series['cover']??''),'plot'=>(string)($series['plot']??''),'cast'=>(string)($series['cast']??''),'director'=>(string)($series['director']??''),'genre'=>(string)($series['genre']??''),'releaseDate'=>(string)($series['releaseDate']??($series['release_date']??'')),'rating'=>(string)($series['rating']??'')],'episodes'=>$eps];
}

function cs_player_local_api(string $username,string $password,string $action='',array $extra=[]): ?array {
    $user=cs_player_local_user($username,$password); if(!$user)return null;
    if($action==='')return cs_player_local_auth_response($user);
    $perms=cs_player_local_permissions($user); $cat=isset($extra['category_id'])?(int)$extra['category_id']:null;
    if($action==='get_live_categories')return cs_player_local_categories('live',$perms);
    if($action==='get_vod_categories')return cs_player_local_categories('movie',$perms);
    if($action==='get_series_categories')return cs_player_local_categories('series',$perms);
    if($action==='get_live_streams')return cs_player_local_streams('live',$perms,$cat,$username,$password);
    if($action==='get_vod_streams')return cs_player_local_streams('movie',$perms,$cat,$username,$password);
    if($action==='get_series')return cs_player_local_series($perms,$cat);
    if($action==='get_series_info')return cs_player_local_series_info((int)($extra['series_id']??0),$perms,$username,$password);
    return [];
}

function cs_player_extract_http_urls($value, array &$out): void {
    if (is_array($value)) {
        foreach ($value as $item) cs_player_extract_http_urls($item, $out);
        return;
    }
    if (!is_string($value)) return;
    $value = trim($value);
    if ($value === '') return;
    // Aceita URL pura e também estruturas legadas contendo a URL dentro do texto.
    if (preg_match_all('~https?://[^\s\"\'<>]+~i', $value, $matches)) {
        foreach ($matches[0] as $url) {
            $url = str_replace('\\/', '/', trim((string)$url));
            $url = rtrim($url, ",;])}");
            if ($url !== '' && filter_var($url, FILTER_VALIDATE_URL)) $out[$url] = $url;
        }
    }
}

function cs_player_local_stream_sources(int $streamId,string $username,string $password): array {
    $user=cs_player_local_user($username,$password); if(!$user)return []; $perms=cs_player_local_permissions($user);
    $db=cs_player_db(); if(!$db)return [];
    $allowed=in_array($streamId,$perms['channels']??[],true);
    if(!$allowed){$q=@$db->query('SELECT series_id FROM series_episodes WHERE stream_id='.(int)$streamId.' LIMIT 1');$e=$q?$q->fetch_assoc():null;$allowed=$e&&in_array((int)$e['series_id'],$perms['series']??[],true);}
    if(!$allowed)return [];
    $q=@$db->query('SELECT stream_source FROM streams WHERE id='.(int)$streamId.' LIMIT 1');$r=$q?$q->fetch_assoc():null;if(!$r)return [];
    $raw=trim((string)($r['stream_source']??''));
    $out=[];
    $decoded=json_decode($raw,true);
    if(is_array($decoded)) cs_player_extract_http_urls($decoded,$out);
    cs_player_extract_http_urls($raw,$out);
    return array_values($out);
}

function cs_player_local_stream_source(int $streamId,string $username,string $password): ?string {
    $sources=cs_player_local_stream_sources($streamId,$username,$password);
    return $sources ? (string)$sources[0] : null;
}

function cs_player_internal_server_dns(): array {
    static $cache = null;
    if (is_array($cache)) return $cache;
    $cache = [];

    $cfgPath = '/home/xtreamcodes/iptv_xtream_codes/config';
    $info = cs_player_decode_main_config($cfgPath);
    if (!is_array($info)) return $cache;
    if (!class_exists('mysqli')) return $cache;

    mysqli_report(MYSQLI_REPORT_OFF);
    $db = @new mysqli(
        (string)($info['host'] ?? 'localhost'),
        (string)($info['db_user'] ?? 'root'),
        (string)($info['db_pass'] ?? ''),
        (string)($info['db_name'] ?? 'xtream_iptvpro'),
        (int)($info['db_port'] ?? 3306)
    );
    if ($db->connect_errno) return $cache;
    $db->set_charset('utf8mb4');
    $result = @$db->query("SELECT `id`,`server_name`,`domain_name`,`server_ip`,`http_broadcast_port`,`https_broadcast_port`,`status` FROM `streaming_servers` WHERE `status` = 1 ORDER BY `id` ASC");
    if ($result) {
        $rows = [];
        while ($row = $result->fetch_assoc()) $rows[] = $row;
        $cache = cs_player_server_dns_from_rows($rows);
        $result->free();
    }
    $db->close();
    return $cache;
}

function cs_player_active_dns(array $cfg): array {
    $rows = [];
    $seen = [];
    foreach (($cfg['dns'] ?? []) as $idx => $row) {
        if (!is_array($row) || !cs_player_bool($row['enabled'] ?? false, false)) continue;
        $url = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($url === '') continue;
        $key = strtolower(rtrim($url, '/'));
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $row['url'] = $url;
        $row['_index'] = 'manual:' . $idx;
        $row['fixed'] = false;
        $row['source'] = 'manual';
        $row['_sort'] = max(1, (int)($row['priority'] ?? ($idx + 1)));
        $rows[] = $row;
    }
    $strategy=(string)($cfg['dns_strategy']??'smart');
    if($strategy==='smart'){ $health=cs_player_load_dns_health(); usort($rows, static fn($a,$b)=>cs_player_dns_health_score($a,$cfg,$health)<=>cs_player_dns_health_score($b,$cfg,$health)); }
    else usort($rows, static fn($a, $b) => ((int)$a['_sort'] <=> (int)$b['_sort']));
    return array_values($rows);
}

function cs_player_m3u_endpoint_from_url(string $url): string {
    $raw = trim($url);
    if ($raw === '' || !preg_match('~^https?://~i', $raw)) return '';
    $parts = @parse_url($raw);
    if (!is_array($parts) || empty($parts['host'])) return '';
    $path = (string)($parts['path'] ?? '');
    if (!preg_match('~/get\.php$~i', $path)) return '';
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    if (!in_array($scheme, ['http', 'https'], true)) return '';
    $host = trim((string)$parts['host'], "[] \t\n\r\0\x0B");
    if ($host === '') return '';
    $isIpv6 = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false;
    $renderHost = $isIpv6 ? '[' . $host . ']' : $host;
    $port = isset($parts['port']) && (int)$parts['port'] > 0 && (int)$parts['port'] <= 65535 ? ':' . (int)$parts['port'] : '';
    $query = [];
    if (isset($parts['query'])) parse_str((string)$parts['query'], $query);
    foreach (['username','password','token','auth','secret','type','output'] as $key) unset($query[$key]);
    $endpoint = $scheme . '://' . $renderHost . $port . '/' . ltrim($path, '/');
    return $query ? $endpoint . '?' . http_build_query($query) : $endpoint;
}

function cs_player_manual_dns_row(string $url): ?array {
    $raw = trim($url);
    $m3uEndpoint = cs_player_m3u_endpoint_from_url($raw);
    if ($raw === '') return null;
    if (!preg_match('~^https?://~i', $raw)) $raw = 'http://' . ltrim($raw, '/');

    $parts = @parse_url($raw);
    $path = is_array($parts) ? (string)($parts['path'] ?? '') : '';
    $query = [];
    if (is_array($parts) && isset($parts['query'])) {
        parse_str((string)$parts['query'], $query);
    }

    $normalized = cs_player_normalize_dns($raw);
    if ($normalized === '') return null;

    $row = [
        'id' => 'manual_' . substr(hash('sha256', $normalized), 0, 12),
        'server_id' => 0,
        'name' => 'DNS manual',
        'url' => $normalized,
        'enabled' => true,
        'priority' => 0,
        'fixed' => false,
        'source' => 'manual',
        'm3u_endpoint' => $m3uEndpoint,
        '_index' => 'manual:' . substr(hash('sha256', $normalized), 0, 16),
        '_sort' => 0,
    ];

    if (preg_match('~/get\.php$~i', $path)) {
        $row['provider_mode'] = 'm3u';
        $row['m3u_path'] = 'get.php';
        $output = strtolower(trim((string)($query['output'] ?? 'mpegts')));
        $row['m3u_output'] = in_array($output, ['mpegts', 'hls'], true) ? $output : 'mpegts';

        unset($query['username'], $query['password'], $query['type'], $query['output']);
        if ($query) $row['m3u_extra_query'] = $query;
        $row['manual_full_m3u'] = true;
    }

    return $row;
}

function cs_player_session_dns_list(array $cfg, ?string $manualUrl = null, ?bool $manualOnly = null): array {
    $manualUrl = $manualUrl !== null ? $manualUrl : (string)($_SESSION['cs_player_manual_dns'] ?? '');
    $manualOnly = $manualOnly !== null ? $manualOnly : !empty($_SESSION['cs_player_manual_only']);
    $manual = cs_player_manual_dns_row($manualUrl);
    $active = $manualOnly ? [] : cs_player_active_dns($cfg);
    if ($manual) {
        $manualKey = strtolower(rtrim($manual['url'], '/'));
        $active = array_values(array_filter($active, static fn($row) => strtolower(rtrim((string)($row['url'] ?? ''), '/')) !== $manualKey));
        array_unshift($active, $manual);
    }
    return $active;
}

function cs_player_http_json(string $url, int $timeout = 8): ?array {
    $cfg = cs_player_load_config();
    $res = cs_player_transport_request($url, array(
        'timeout' => $timeout,
        'json' => true,
        'ip_mode' => $_SESSION['cs_player_ip_mode_selected'] ?? 'auto',
        'user_agent' => 'CSPlayer-Web/1.0',
        'allow_legacy_tls' => cs_player_bool($cfg['allow_legacy_tls'] ?? false, false),
    ));
    if (empty($res['ok']) || !is_array($res['data'] ?? null)) {
        cs_player_write_log('http_request_failed', array(
            'host' => (string)(parse_url($url, PHP_URL_HOST) ?: ''),
            'http_code' => (int)($res['http_code'] ?? 0),
            'remote_ip' => (string)($res['remote_ip'] ?? ''),
            'ip_mode' => (string)($res['ip_mode'] ?? ''),
            'attempts' => $res['attempts'] ?? array(),
        ), 'error');
        return null;
    }
    return $res['data'];
}

function cs_player_api_call(string $dns, string $username, string $password, string $action = '', array $extra = []): ?array {
    $provider = (string)($_SESSION['cs_player_provider_mode'] ?? '');
    if ($provider === 'local' || !empty($_SESSION['cs_player_local_api'])) return cs_player_local_api($username, $password, $action, $extra);
    if ($provider === 'legacy_ref' && function_exists('cs_player_legacy_api_call')) {
        return cs_player_legacy_api_call($dns, $username, $password, $action, $extra);
    }
    if ($provider === 'json_xtream' && function_exists('cs_player_json_compat_api_call')) {
        return cs_player_json_compat_api_call($dns, $username, $password, $action, $extra);
    }
    $params = array_merge(['username' => $username, 'password' => $password], $extra);
    if ($action !== '') $params['action'] = $action;
    $cfg = cs_player_load_config();
    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));
    $endpoint = cs_player_selected_api_endpoint();
    return cs_player_http_json(rtrim($dns, '/') . '/' . $endpoint . '?' . http_build_query($params), $timeout);
}

function cs_player_api_batch(string $dns, string $username, string $password, array $requests): array {
    $cfg = cs_player_load_config();
    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));
    $result = [];
    if (!$requests) return $result;

    if (in_array((string)($_SESSION['cs_player_provider_mode'] ?? ''), array('json_xtream','legacy_ref'), true)) {
        foreach ($requests as $key => $request) {
            $action = is_array($request) ? (string)($request[0] ?? '') : (string)$request;
            $extra = is_array($request) && isset($request[1]) && is_array($request[1]) ? $request[1] : [];
            $result[$key] = cs_player_api_call($dns, $username, $password, $action, $extra) ?? [];
        }
        return $result;
    }

    $targets = [];
    $actions = [];
    foreach ($requests as $key => $request) {
        $action = is_array($request) ? (string)($request[0] ?? '') : (string)$request;
        $extra = is_array($request) && isset($request[1]) && is_array($request[1]) ? $request[1] : [];
        $params = array_merge(['username' => $username, 'password' => $password], $extra);
        if ($action !== '') $params['action'] = $action;
        $endpoint = cs_player_selected_api_endpoint();
        $targets[$key] = rtrim($dns, '/') . '/' . $endpoint . '?' . http_build_query($params);
        $actions[$key] = $action;
    }
    $responses = cs_player_transport_request_batch($targets, [
        'timeout'=>$timeout,
        'user_agent'=>'CSPlayer-Web/1.0',
        'ip_mode'=>$_SESSION['cs_player_ip_mode_selected'] ?? 'auto',
        'json'=>true,
        'allow_legacy_tls'=>cs_player_bool($cfg['allow_legacy_tls'] ?? false, false),
    ]);
    foreach ($targets as $key => $_target) {
        $response = is_array($responses[$key] ?? null) ? $responses[$key] : [];
        $result[$key] = !empty($response['ok']) && is_array($response['data'] ?? null) ? $response['data'] : [];
        if ($result[$key] === []) {
            cs_player_write_log('batch_request_failed', [
                'host'=>(string)(parse_url($dns, PHP_URL_HOST) ?? ''),
                'action'=>(string)($actions[$key] ?? ''),
                'http_code'=>(int)($response['http_code'] ?? 0),
            ], 'error');
        }
    }
    return $result;
}

function cs_player_normalize_auth_payload(?array $data, string $username = ''): ?array {
    if (!$data) return null;
    if (isset($data['data']) && is_array($data['data']) && isset($data['data']['user_info']) && is_array($data['data']['user_info'])) {
        $data = array_merge($data, ['user_info' => $data['data']['user_info']]);
    }
    if (!isset($data['user_info']) || !is_array($data['user_info'])) {
        if (isset($data['user']) && is_array($data['user'])) {
            $data['user_info'] = $data['user'];
        } elseif (isset($data['auth']) || isset($data['status']) || isset($data['username'])) {
            $data['user_info'] = [
                'auth' => $data['auth'] ?? 1,
                'status' => $data['status'] ?? 'Active',
                'username' => $data['username'] ?? $username,
                'exp_date' => $data['exp_date'] ?? null,
                'active_cons' => $data['active_cons'] ?? null,
                'max_connections' => $data['max_connections'] ?? null,
            ];
        }
    }
    if (isset($data['user_info']) && is_array($data['user_info']) && empty($data['user_info']['username']) && $username !== '') {
        $data['user_info']['username'] = $username;
    }
    return $data;
}

/** Perfis HTTP de compatibilidade para provedores externos. */
function cs_player_http_profile_user_agent(string $profile): string {
    $profile = strtolower(trim($profile));
    switch ($profile) {
        case 'xciptv':
            return 'XCIPTV/7.0 (Android; IPTV)';
        case 'vlc':
            return 'VLC/3.0.20 LibVLC/3.0.20';
        case 'browser':
            return 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/125.0 Mobile Safari/537.36';
        default:
            return 'IPTVSmartersPro';
    }
}

function cs_player_http_profiles(array $row, string $mode): array {
    $custom = trim((string)($row['user_agent'] ?? ''));
    if ($custom !== '') return [['id'=>'custom','ua'=>$custom]];
    $configured = strtolower(trim((string)($row['http_profile'] ?? 'auto')));
    if (in_array($configured, ['smarters','xciptv','vlc','browser'], true)) {
        return [['id'=>$configured,'ua'=>cs_player_http_profile_user_agent($configured)]];
    }
    $ids = in_array($mode, ['smart','m3u'], true) ? ['smarters','xciptv','vlc','browser'] : ['smarters','xciptv'];
    return array_map(static fn($id)=>['id'=>$id,'ua'=>cs_player_http_profile_user_agent($id)], $ids);
}

function cs_player_dns_provider_mode(array $row): string {
    $mode = strtolower(trim((string)($row['provider_mode'] ?? 'auto')));
    return in_array($mode, ['auto','xc','smart','xtream','m3u'], true) ? $mode : 'auto';
}

function cs_player_m3u_output(array $row): string {
    $out = strtolower(trim((string)($row['m3u_output'] ?? 'mpegts')));
    return in_array($out, ['mpegts','hls'], true) ? $out : 'mpegts';
}

function cs_player_m3u_url(string $base, string $username, string $password, array $row = []): string {
    $base = rtrim(cs_player_normalize_dns($base), '/');
    if ($base === '') return '';
    $custom = trim((string)($row['m3u_path'] ?? 'get.php'));
    $custom = ltrim($custom, '/');
    if ($custom === '' || preg_match('~^https?://~i', $custom) || strpos($custom, '..') !== false) $custom = 'get.php';
    $custom = preg_replace('~/{2,}~','/',$custom) ?? 'get.php';
    $basePath = trim((string)(parse_url($base, PHP_URL_PATH) ?? ''), '/');
    if ($basePath !== '' && (strpos($custom, $basePath . '/') === 0 || $custom === $basePath)) {
        $custom = ltrim(substr($custom, strlen($basePath)), '/');
        if ($custom === '') $custom = 'get.php';
    }
    $params = [
        'username' => $username,
        'password' => $password,
        'type' => 'm3u_plus',
        'output' => cs_player_m3u_output($row),
    ];
    if (!empty($row['m3u_extra_query']) && is_array($row['m3u_extra_query'])) {
        foreach ($row['m3u_extra_query'] as $key => $value) {
            if (!array_key_exists((string)$key, $params)) $params[(string)$key] = $value;
        }
    }
    return $base . '/' . $custom . '?' . http_build_query($params);
}

function cs_player_probe_m3u(string $base, string $username, string $password, array $row, int $timeout = 10, string $userAgent = ''): array {
    $url = cs_player_m3u_url($base, $username, $password, $row);
    if ($url === '') return ['ok'=>false,'http_code'=>0,'curl_errno'=>0,'content_type'=>'','bytes'=>0,'time_ms'=>0];
    $cfg = cs_player_load_config();
    $ua = trim($userAgent) ?: (trim((string)($row['user_agent'] ?? '')) ?: (string)($cfg['m3u_user_agent'] ?? 'IPTVSmartersPro'));
    $allowLegacyTls = cs_player_bool($cfg['allow_legacy_tls'] ?? false, false);
    if (!function_exists('curl_init')) {
        $headers = 'User-Agent: '.$ua."\r\n".'Accept: application/x-mpegURL, audio/x-mpegurl, text/plain, */*' . "\r\n" . 'Connection: close' . "\r\n";
        $ctx = stream_context_create([
            'http'=>['method'=>'GET','header'=>$headers,'timeout'=>max(3,$timeout),'ignore_errors'=>true,'follow_location'=>1,'max_redirects'=>5,'protocol_version'=>1.1],
            'ssl'=>['verify_peer'=>!$allowLegacyTls,'verify_peer_name'=>!$allowLegacyTls,'allow_self_signed'=>$allowLegacyTls],
        ]);
        $started = microtime(true);
        $body = @file_get_contents($url, false, $ctx);
        $streamHeaders = isset($http_response_header) && is_array($http_response_header) ? $http_response_header : [];
        $code = 0; $effective = $url;
        foreach ($streamHeaders as $line) {
            if (preg_match('~^HTTP/\\S+\\s+(\\d{3})~i', (string)$line, $m)) $code=(int)$m[1];
            if (stripos((string)$line, 'Content-Type:') === 0) $contentType=trim(substr((string)$line, 13));
            if (stripos((string)$line, 'Location:') === 0) $effective=trim(substr((string)$line, 9));
        }
        $sample = is_string($body) ? substr($body, 0, 131072) : '';
        $trim = ltrim($sample, "\xEF\xBB\xBF\r\n\t ");
        $ok = $code >= 200 && $code < 400 && stripos(substr($trim, 0, 2048), '#EXTM3U') !== false;
        return ['ok'=>$ok,'http_code'=>$code,'curl_errno'=>0,'curl_error'=>'','content_type'=>(string)($contentType ?? ''),'bytes'=>strlen($sample),'url'=>$url,'effective_url'=>$effective,'remote_ip'=>'','redirects'=>0,'http_version'=>1,'time_ms'=>(int)round((microtime(true)-$started)*1000)];
    }
    $sample = '';
    $limit = 131072;
    $intentionalStop = false;
    $started = microtime(true);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_USERAGENT => $ua,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_IPRESOLVE => cs_player_curl_ipresolve($row),
        CURLOPT_ENCODING => '',
        CURLOPT_HTTPHEADER => ['Accept: application/x-mpegURL, audio/x-mpegurl, text/plain, */*', 'Connection: keep-alive'],
        CURLOPT_SSL_VERIFYPEER => !$allowLegacyTls,
        CURLOPT_SSL_VERIFYHOST => $allowLegacyTls ? 0 : 2,
        CURLOPT_WRITEFUNCTION => static function($ch, string $chunk) use (&$sample, $limit, &$intentionalStop): int {
            $need = $limit - strlen($sample);
            if ($need <= 0) { $intentionalStop = true; return 0; }
            $take = substr($chunk, 0, $need); $sample .= $take;
            if (strlen($chunk) > $need) { $intentionalStop = true; return 0; }
            return strlen($chunk);
        },
    ]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $ctype = (string)(curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?? '');
    $effective = (string)(curl_getinfo($ch, CURLINFO_EFFECTIVE_URL) ?? '');
    $remoteIp = (string)(curl_getinfo($ch, CURLINFO_PRIMARY_IP) ?? '');
    $redirects = (int)(curl_getinfo($ch, CURLINFO_REDIRECT_COUNT) ?? 0);
    $httpVersion = (int)(curl_getinfo($ch, CURLINFO_HTTP_VERSION) ?? 0);
    $errno = (int)curl_errno($ch);
    $error = (string)curl_error($ch);
    if ($intentionalStop && defined('CURLE_WRITE_ERROR') && $errno === CURLE_WRITE_ERROR) { $errno = 0; $error = ''; }
    curl_close($ch);
    $trim = ltrim($sample, "\xEF\xBB\xBF\r\n\t ");
    $ok = $code >= 200 && $code < 400 && stripos(substr($trim,0,2048), '#EXTM3U') !== false;
    return ['ok'=>$ok,'http_code'=>$code,'curl_errno'=>$errno,'curl_error'=>$error,'content_type'=>$ctype,'bytes'=>strlen($sample),'url'=>$url,'effective_url'=>$effective,'remote_ip'=>$remoteIp,'redirects'=>$redirects,'http_version'=>$httpVersion,'time_ms'=>(int)round((microtime(true)-$started)*1000)];
}

function cs_player_m3u_cache_file(array $row, string $username, string $password = ''): string {
    $dir = dirname(__DIR__) . '/logs/cs-player/m3u-cache';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $key = hash('sha256', strtolower((string)($row['url'] ?? '')) . '|' . (string)($row['m3u_path'] ?? 'get.php') . '|' . (string)($row['m3u_output'] ?? 'mpegts') . '|' . $username . '|' . hash('sha256', $password));
    return $dir . '/catalog-' . $key . '.php';
}

function cs_player_m3u_clean_title(string $title): string {
    $title = preg_replace('/\s+/', ' ', trim($title)) ?? trim($title);
    return trim($title, " \t\n\r\0\x0B-|:");
}

function cs_player_m3u_episode_parts(string $title): ?array {
    $patterns = [
        '/^(.*?)[\s._-]+S(\d{1,2})\s*E(\d{1,3})(?:\b|[\s._-])/iu',
        '/^(.*?)[\s._-]+(\d{1,2})x(\d{1,3})(?:\b|[\s._-])/iu',
        '/^(.*?)[\s._-]+T(?:EMPORADA)?\s*(\d{1,2})[\s._-]*(?:EP|E|EPISODIO)\s*(\d{1,3})/iu',
    ];
    foreach ($patterns as $p) if (preg_match($p, $title, $m)) return ['series'=>cs_player_m3u_clean_title($m[1]),'season'=>(int)$m[2],'episode'=>(int)$m[3]];
    return null;
}

function cs_player_m3u_classify(string $group, string $title, string $url): string {
    $g = function_exists('mb_strtolower') ? mb_strtolower($group, 'UTF-8') : strtolower($group);
    $plain = iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$g) ?: $g;
    if (preg_match('/(^|\b)(canais?|live|tv|radio)(\b|\s*\|)/i', $plain) || preg_match('~/live/~i', $url) || preg_match('~\.(?:ts|m3u8)(?:\?|$)~i', $url)) return 'live';
    if (cs_player_m3u_episode_parts($title) || preg_match('~/series/~i', $url) || preg_match('/\b(series?|novelas?|doramas?|temporadas?)\b/i', $plain)) return 'series';
    if (preg_match('~/movie/~i', $url) || preg_match('/\b(filmes?|movies?|vod|cinema|colec(?:ao|oes))\b/i', $plain) || preg_match('~\.(?:mp4|mkv|avi|mov)(?:\?|$)~i', $url)) return 'movie';
    return 'live';
}

function cs_player_m3u_download_catalog(array $row, string $username, string $password): ?array {
    $url = cs_player_m3u_url((string)($row['url'] ?? ''), $username, $password, $row);
    if ($url === '') return null;
    $cfg = cs_player_load_config();
    $tmp = tempnam(sys_get_temp_dir(), 'csp_m3u_');
    if (!$tmp) return null;
    $code = 0; $err = 0;
    if (!function_exists('curl_init')) {
        $ua = trim((string)($row['user_agent'] ?? '')) ?: (string)($cfg['m3u_user_agent'] ?? 'IPTVSmartersPro');
        $ctx = stream_context_create([
            'http'=>['method'=>'GET','header'=>'User-Agent: '.$ua."\r\n".'Accept: application/x-mpegURL, audio/x-mpegurl, text/plain, */*' . "\r\n" . 'Connection: close' . "\r\n",'timeout'=>max(10,(int)($cfg['request_timeout'] ?? 8) * 12),'ignore_errors'=>true,'follow_location'=>1,'max_redirects'=>5,'protocol_version'=>1.1],
            'ssl'=>['verify_peer'=>!cs_player_bool($cfg['allow_legacy_tls'] ?? false, false),'verify_peer_name'=>!cs_player_bool($cfg['allow_legacy_tls'] ?? false, false),'allow_self_signed'=>cs_player_bool($cfg['allow_legacy_tls'] ?? false, false)],
        ]);
        $body = @file_get_contents($url, false, $ctx);
        foreach ((array)($http_response_header ?? []) as $line) if (preg_match('~^HTTP/\\S+\\s+(\\d{3})~i', (string)$line, $m)) $code=(int)$m[1];
        if (!is_string($body) || $code < 200 || $code >= 400 || @file_put_contents($tmp, $body, LOCK_EX) === false) { @unlink($tmp); return null; }
    } else {
        $fp = fopen($tmp, 'wb'); if (!$fp) { @unlink($tmp); return null; }
        $ch = curl_init($url);
        $allowLegacyTls = cs_player_bool($cfg['allow_legacy_tls'] ?? false, false);
        curl_setopt_array($ch, [CURLOPT_FILE=>$fp,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>min(8,(int)($cfg['request_timeout'] ?? 8)),CURLOPT_TIMEOUT=>max(60,(int)($cfg['request_timeout'] ?? 8)*12),CURLOPT_USERAGENT=>trim((string)($row['user_agent']??'')) ?: (string)($cfg['m3u_user_agent']??'IPTVSmartersPro'),CURLOPT_HTTP_VERSION=>CURL_HTTP_VERSION_1_1,CURLOPT_IPRESOLVE=>cs_player_curl_ipresolve($row),CURLOPT_ENCODING=>'',CURLOPT_HTTPHEADER=>['Accept: application/x-mpegURL, audio/x-mpegurl, text/plain, */*','Connection: keep-alive'],CURLOPT_SSL_VERIFYPEER=>!$allowLegacyTls,CURLOPT_SSL_VERIFYHOST=>$allowLegacyTls ? 0 : 2]);
        curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); $err=(int)curl_errno($ch); curl_close($ch); fclose($fp);
        if ($code < 200 || $code >= 400 || $err) { @unlink($tmp); return null; }
    }
    $fh=fopen($tmp,'rb'); if(!$fh){@unlink($tmp);return null;}
    $preview = fread($fh, 4096);
    if (!is_string($preview) || stripos(ltrim($preview, "\xEF\xBB\xBF\r\n\t "), '#EXTM3U') === false) { fclose($fh); @unlink($tmp); return null; }
    rewind($fh);
    $cats=['live'=>[],'movie'=>[],'series'=>[]]; $items=['live'=>[],'movie'=>[]]; $series=[]; $episodes=[]; $pending=null; $counter=1;
    while (($line=fgets($fh))!==false) {
        $line=trim($line); if($line==='')continue;
        if(strncmp($line, '#EXTINF:', 8) === 0) {
            $comma=strrpos($line,','); $title=$comma!==false?substr($line,$comma+1):''; $attrs=$comma!==false?substr($line,0,$comma):$line;
            $group='';$logo='';$tvg='';$tvgId='';
            if(preg_match('/group-title="([^"]*)"/iu',$attrs,$m))$group=$m[1];
            if(preg_match('/tvg-logo="([^"]*)"/iu',$attrs,$m))$logo=$m[1];
            if(preg_match('/tvg-name="([^"]*)"/iu',$attrs,$m))$tvg=$m[1];
            if(preg_match('/tvg-id="([^"]*)"/iu',$attrs,$m))$tvgId=$m[1];
            $pending=['title'=>cs_player_m3u_clean_title($title?:$tvg),'group'=>trim($group),'logo'=>trim($logo),'tvg_id'=>trim($tvgId)]; continue;
        }
        if($pending && strncmp($line, '#', 1) !== 0) {
            $mediaUrl=$line; $type=cs_player_m3u_classify($pending['group'],$pending['title'],$mediaUrl); $group=$pending['group']!==''?$pending['group']:'Sem categoria';
            $catId=substr(hash('crc32b',$type.'|'.$group),0,8); $cats[$type][$catId]=['category_id'=>$catId,'category_name'=>$group];
            $id=$counter++;
            if($type==='series') {
                $ep=cs_player_m3u_episode_parts($pending['title']); $seriesTitle=$ep['series']??$pending['title']; $sid=abs(crc32(function_exists('mb_strtolower')?mb_strtolower($seriesTitle,'UTF-8'):strtolower($seriesTitle))); if($sid===0)$sid=$id;
                if(!isset($series[$sid]))$series[$sid]=['series_id'=>$sid,'name'=>$seriesTitle,'cover'=>$pending['logo'],'plot'=>'','category_id'=>$catId,'releaseDate'=>''];
                $season=$ep['season']??1; $episode=$ep['episode']??(count($episodes[$sid][$season]??[])+1); $ext=pathinfo(parse_url($mediaUrl,PHP_URL_PATH)??'',PATHINFO_EXTENSION)?:'mp4';
                $episodes[$sid][$season][]=['id'=>$id,'episode_num'=>$episode,'title'=>$pending['title'],'container_extension'=>$ext,'info'=>['movie_image'=>$pending['logo'],'plot'=>''],'direct_source'=>$mediaUrl];
            } else {
                $ext=pathinfo(parse_url($mediaUrl,PHP_URL_PATH)??'',PATHINFO_EXTENSION); $record=['stream_id'=>$id,'name'=>$pending['title'],'stream_icon'=>$pending['logo'],'category_id'=>$catId,'container_extension'=>$ext,'direct_source'=>$mediaUrl,'stream_type'=>$type==='live'?'live':'movie','epg_channel_id'=>(string)($pending['tvg_id']??'')];
                $items[$type][]=$record;
            }
            $pending=null;
        }
    }
    fclose($fh); @unlink($tmp);
    $catalog=['generated_at'=>time(),'categories'=>['live'=>array_values($cats['live']),'movie'=>array_values($cats['movie']),'series'=>array_values($cats['series'])],'live'=>$items['live'],'movie'=>$items['movie'],'series'=>array_values($series),'episodes'=>$episodes];
    $file=cs_player_m3u_cache_file($row,$username,$password); $php="<?php\nif (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }\nreturn ".var_export($catalog,true).";\n";
    if(@file_put_contents($file.'.tmp',$php,LOCK_EX)!==false){@chmod($file.'.tmp',0600);@rename($file.'.tmp',$file);@chmod($file,0600);} 
    cs_player_write_log('m3u_catalog_built',['host'=>(string)(parse_url((string)$row['url'],PHP_URL_HOST)??''),'live'=>count($items['live']),'movies'=>count($items['movie']),'series'=>count($series)],'info');
    return $catalog;
}

function cs_player_m3u_catalog(array $row, string $username, string $password): ?array {
    $file=cs_player_m3u_cache_file($row,$username,$password); $ttl=max(300,min(86400,(int)(cs_player_load_config()['m3u_cache_ttl']??1800)));
    if(is_file($file) && (time()-(int)filemtime($file))<$ttl){$data=include $file;if(is_array($data))return $data;}
    return cs_player_m3u_download_catalog($row,$username,$password);
}

function cs_player_api_endpoint_candidates(): array {
    return ['player_api.php', 'panel_api.php'];
}

function cs_player_selected_api_endpoint(): string {
    $ep = basename((string)($_SESSION['cs_player_api_endpoint'] ?? 'player_api.php'));
    return in_array($ep, cs_player_api_endpoint_candidates(), true) ? $ep : 'player_api.php';
}

function cs_player_is_authenticated_response(?array $data): bool {
    $data = cs_player_normalize_auth_payload($data);
    if (!$data || !isset($data['user_info']) || !is_array($data['user_info'])) return false;
    $ui = $data['user_info'];
    if (isset($ui['auth']) && !in_array(strtolower((string)$ui['auth']), ['1','true','yes','active'], true)) return false;
    if (isset($ui['status']) && !in_array(strtolower(trim((string)$ui['status'])), ['active','1','enabled','true'], true)) return false;
    return !empty($ui['username']) || isset($ui['auth']) || isset($ui['status']);
}

function cs_player_authenticate_dns(array $dnsList, string $username, string $password): ?array {
    $cfg = cs_player_load_config();

    if (!$dnsList) return null;

    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));
    $discover = !array_key_exists('dns_auto_discovery', $cfg) || !empty($cfg['dns_auto_discovery']);
    $maxCandidates = max(1, min(8, (int)($cfg['dns_discovery_max_candidates'] ?? 4)));
    $diagnostics = [];

    foreach ($dnsList as $row) {
        $configuredBase = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($configuredBase === '') continue;
        $mode = cs_player_dns_provider_mode($row);
        $profiles = cs_player_http_profiles($row, $mode);
        $bases = $discover ? cs_player_dns_route_candidates($configuredBase, $maxCandidates) : [$configuredBase];

        foreach ($bases as $routeIndex => $base) {
            $routeParts = @parse_url($base);
            $routeHost = is_array($routeParts) ? (string)($routeParts['host'] ?? '') : '';
            $routePort = is_array($routeParts) && isset($routeParts['port']) ? (int)$routeParts['port'] : (stripos($base, 'https://') === 0 ? 443 : 80);
            $routeScheme = is_array($routeParts) ? (string)($routeParts['scheme'] ?? 'http') : 'http';

            if ($mode !== 'm3u') {
                foreach (cs_player_api_endpoint_candidates() as $endpoint) {
                    foreach ($profiles as $profile) {
                        $params = http_build_query(['username'=>$username,'password'=>$password]);
                        $target = rtrim($base,'/') . '/' . $endpoint . '?' . $params;
                        $res = cs_player_transport_request($target, [
                            'timeout'=>$timeout,
                            'connect_timeout'=>min(5,$timeout),
                            'user_agent'=>$profile['ua'],
                            'ip_mode'=>(string)($row['ip_mode'] ?? 'auto'),
                            'accept'=>'application/json, text/plain, */*',
                            'json'=>true,
                            'allow_legacy_tls'=>cs_player_bool($cfg['allow_legacy_tls'] ?? false, false),
                        ]);
                        $body = is_string($res['body'] ?? null) ? $res['body'] : '';
                        $code = (int)($res['http_code'] ?? 0);
                        $ctype = (string)($res['content_type'] ?? '');
                        $errno = (int)($res['curl_errno'] ?? 0);
                        $ms = (int)($res['time_ms'] ?? 0);
                        $effective = (string)($res['effective_url'] ?? '');
                        $remoteIp = (string)($res['remote_ip'] ?? '');
                        $redirects = (int)($res['redirects'] ?? 0);
                        $bytes = strlen($body);

                        $decoded = is_array($res['data'] ?? null) ? $res['data'] : null;
                        $decoded = cs_player_normalize_auth_payload(is_array($decoded) ? $decoded : null, $username);
                        if ($code >= 200 && $code < 400 && cs_player_is_authenticated_response($decoded)) {
                            $row['url'] = $base;
                            $row['configured_url'] = $configuredBase;
                            $row['api_endpoint'] = $endpoint;
                            $row['provider_mode_selected'] = ($mode === 'xc' ? 'xc' : 'xtream');
                            $row['http_profile_selected'] = $profile['id'];
                            $row['route_discovered'] = ($base !== $configuredBase);
                            cs_player_record_dns_health($row,true,$ms,'xtream');
                            $_SESSION['cs_player_last_good_dns'] = (string)($row['id'] ?? '');
                            cs_player_write_log('external_dns_auth_selected', [
                                'host'=>$routeHost,'port'=>$routePort,'scheme'=>$routeScheme,'endpoint'=>$endpoint,
                                'provider'=>($mode==='xc'?'xc':'xtream'),'configured_mode'=>$mode,
                                'http_profile'=>$profile['id'],'remote_ip'=>$remoteIp,'redirects'=>$redirects,
                                'route_index'=>$routeIndex,'route_discovered'=>($base!==$configuredBase)
                            ], 'info');
                            return ['row'=>$row,'data'=>$decoded,'provider_mode'=>'xtream'];
                        }
                        $diagnostics[] = [
                            'host'=>$routeHost,'port'=>$routePort,'scheme'=>$routeScheme,'http_code'=>$code,
                            'json'=>is_array($decoded),'content_type'=>$ctype,'curl_errno'=>$errno,'time_ms'=>$ms,
                            'endpoint'=>$endpoint,'provider'=>'xtream','http_profile'=>$profile['id'],'remote_ip'=>$remoteIp,
                            'redirects'=>$redirects,'response_bytes'=>$bytes,
                            'effective_host'=>(string)(parse_url($effective,PHP_URL_HOST) ?? ''),
                            'route_index'=>$routeIndex
                        ];
                        if ($mode === 'auto' && $code === 404) break;
                    }
                }
            }

            // XC/Smart/Auto também podem entregar M3U Plus; só o modo
            // explicitamente Xtream fica impedido de testar get.php.
            if ($mode !== 'xtream') {
                foreach ($profiles as $profile) {
                    $probe = cs_player_probe_m3u($base,$username,$password,$row,max(8,$timeout),$profile['ua']);
                    $diagnostics[] = [
                        'host'=>$routeHost,'port'=>$routePort,'scheme'=>$routeScheme,
                        'http_code'=>(int)($probe['http_code'] ?? 0),'json'=>false,
                        'content_type'=>(string)($probe['content_type'] ?? ''),'curl_errno'=>(int)($probe['curl_errno'] ?? 0),
                        'time_ms'=>(int)($probe['time_ms'] ?? 0),'endpoint'=>(string)($row['m3u_path'] ?? 'get.php'),
                        'provider'=>'m3u_plus','http_profile'=>$profile['id'],'remote_ip'=>(string)($probe['remote_ip'] ?? ''),
                        'redirects'=>(int)($probe['redirects'] ?? 0),'response_bytes'=>(int)($probe['bytes'] ?? 0),
                        'effective_host'=>(string)(parse_url((string)($probe['effective_url'] ?? ''),PHP_URL_HOST) ?? ''),
                        'route_index'=>$routeIndex
                    ];
                    if (!empty($probe['ok'])) {
                        $row['url'] = $base;
                        $row['configured_url'] = $configuredBase;
                        $row['provider_mode_selected'] = 'm3u';
                        $row['api_endpoint'] = (string)($row['m3u_path'] ?? 'get.php');
                        $row['http_profile_selected'] = $profile['id'];
                        $row['route_discovered'] = ($base !== $configuredBase);
                        $data = ['user_info'=>['username'=>$username,'auth'=>1,'status'=>'Active']];
                        cs_player_record_dns_health($row,true,(int)($probe['time_ms'] ?? 0),'m3u');
                        $_SESSION['cs_player_last_good_dns'] = (string)($row['id'] ?? '');
                        cs_player_write_log('external_m3u_auth_selected', [
                            'host'=>$routeHost,'port'=>$routePort,'scheme'=>$routeScheme,
                            'output'=>cs_player_m3u_output($row),'http_profile'=>$profile['id'],
                            'remote_ip'=>(string)($probe['remote_ip'] ?? ''),'redirects'=>(int)($probe['redirects'] ?? 0),
                            'route_index'=>$routeIndex,'route_discovered'=>($base!==$configuredBase)
                        ], 'info');
                        return ['row'=>$row,'data'=>$data,'provider_mode'=>'m3u'];
                    }
                    if ($mode === 'auto' && (int)($probe['http_code'] ?? 0) === 404) break;
                }
            }
        }

        $configuredHost = (string)(parse_url($configuredBase,PHP_URL_HOST) ?? '');
        $rowDiag = array_values(array_filter($diagnostics, static function($d) use ($configuredHost) {
            return (string)($d['host'] ?? '') === $configuredHost;
        }));
        $codes = array_values(array_filter(array_map(static fn($d)=>(int)($d['http_code'] ?? 0),$rowDiag),static fn($v)=>$v>0));
        $latencies = array_values(array_filter(array_map(static fn($d)=>(int)($d['time_ms'] ?? 0),$rowDiag),static fn($v)=>$v>0));
        $authRejected = $codes && count(array_filter($codes,static fn($c)=>in_array($c,[200,401,403],true))) === count($codes);
        cs_player_record_dns_health($row,false,$latencies?(int)round(array_sum($latencies)/count($latencies)):0,$authRejected?'auth_rejected':'upstream_failed');
    }

    // Compatibilidade legacy/JSON é fallback somente depois que o motor oficial
    // tentou as rotas Xtream e M3U configuradas. Assim, um servidor M3U válido
    // não perde tempo nem recebe health check negativo por uma sonda Xtream.
    $hasXtreamCandidate = false;
    foreach ($dnsList as $candidateRow) {
        if (!is_array($candidateRow)) continue;
        if (cs_player_dns_provider_mode($candidateRow) !== 'm3u') { $hasXtreamCandidate = true; break; }
    }
    if ($hasXtreamCandidate && function_exists('cs_player_legacy_authenticate')) {
        $legacyAuth = cs_player_legacy_authenticate($dnsList, $username, $password);
        if (is_array($legacyAuth) && isset($legacyAuth['row'], $legacyAuth['data'])) return $legacyAuth;
    }
    if ($hasXtreamCandidate && !empty($cfg['dns_json_compat']) && function_exists('cs_player_json_compat_authenticate')) {
        $jsonAuth = cs_player_json_compat_authenticate($cfg, $username, $password);
        if (is_array($jsonAuth) && isset($jsonAuth['row'], $jsonAuth['data'])) return $jsonAuth;
    }

    // Último fallback: cliente local do CS Player, sem depender de DNS externo.
    $localUser = cs_player_local_user($username, $password);
    if (is_array($localUser)) {
        $fallbackUrl = '';
        if (!empty($dnsList[0]['url'])) $fallbackUrl = cs_player_normalize_dns((string)$dnsList[0]['url']);
        if ($fallbackUrl === '') {
            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $fallbackUrl = $scheme.'://'.(string)($_SERVER['HTTP_HOST'] ?? 'localhost');
        }
        $row = [
            'id'=>'local_db','server_id'=>0,'name'=>'CS PLAYER Local','url'=>$fallbackUrl,
            'enabled'=>true,'priority'=>0,'source'=>'local','_index'=>'local:db','_sort'=>0,
            'api_endpoint'=>'local','provider_mode_selected'=>'local','ip_mode_selected'=>'auto','local_api'=>true
        ];
        cs_player_write_log('web_player_local_db_fallback_selected', [
            'user_id'=>(int)($localUser['id'] ?? 0),'external_dns_count'=>count($dnsList),
            'external_status'=>'unavailable_or_incompatible'
        ], 'info');
        return ['row'=>$row,'data'=>cs_player_local_auth_response($localUser),'provider_mode'=>'local','local_api'=>true,'local_user'=>$localUser,'diagnostics'=>$diagnostics];
    }
    return ['error'=>'upstream_auth_failed','diagnostics'=>$diagnostics];
}

function cs_player_require_login(): void {
    if (empty($_SESSION['cs_player_auth']) || empty($_SESSION['cs_player_username']) || !isset($_SESSION['cs_player_dns_index'])) {
        header('Location: index.php');
        exit;
    }
}

function cs_player_json(array $payload, int $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function cs_player_session_dns(array $cfg, $requested = null): ?array {
    $active = cs_player_session_dns_list($cfg);
    $sessionUrl = cs_player_normalize_dns((string)($_SESSION['cs_player_transport_dns_url'] ?? $_SESSION['cs_player_dns_url'] ?? ''));
    $index = $requested ?? ($_SESSION['cs_player_dns_index'] ?? '');

    if ($sessionUrl !== '') {
        foreach ($active as $row) {
            $candidate = cs_player_normalize_dns((string)($row['url'] ?? ''));
            if ($candidate !== '' && strtolower(rtrim($candidate,'/')) === strtolower(rtrim($sessionUrl,'/'))) {
                $row['url'] = $sessionUrl;
                $row['ip_mode'] = (string)($_SESSION['cs_player_ip_mode_selected'] ?? ($row['ip_mode'] ?? 'auto'));
                return $row;
            }
        }
        // Se a rota descoberta mudou esquema/porta, reutilize a linha original
        // pelo índice da sessão para preservar m3u_path, output, perfil e
        // parâmetros adicionais. A URL efetiva continua sendo a rota boa.
        foreach ($active as $row) {
            if ((string)($row['_index'] ?? '') !== (string)$index) continue;
            $row['url'] = $sessionUrl;
            $row['ip_mode'] = (string)($_SESSION['cs_player_ip_mode_selected'] ?? ($row['ip_mode'] ?? 'auto'));
            $row['provider_mode_selected'] = (string)($_SESSION['cs_player_provider_mode'] ?? ($row['provider_mode'] ?? 'xtream'));
            $row['api_endpoint'] = (string)($_SESSION['cs_player_api_endpoint'] ?? ($row['api_endpoint'] ?? 'player_api.php'));
            return $row;
        }
        $row = cs_player_manual_dns_row($sessionUrl);
        if (is_array($row)) {
            $row['_index'] = (string)$index;
            $row['name'] = (string)($_SESSION['cs_player_dns_name'] ?? 'Servidor');
            $row['ip_mode'] = (string)($_SESSION['cs_player_ip_mode_selected'] ?? 'auto');
            $row['provider_mode_selected'] = (string)($_SESSION['cs_player_provider_mode'] ?? 'xtream');
            $row['api_endpoint'] = (string)($_SESSION['cs_player_api_endpoint'] ?? 'player_api.php');
            return $row;
        }
    }
    if (!$active) return null;
    foreach ($active as $row) {
        if ((string)$row['_index'] === (string)$index) return $row;
    }
    return $active[0];
}
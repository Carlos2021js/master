<?php
include "./functions.php";
// Endpoint JSON: mantém respostas válidas para chamadas AJAX.
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', '0');
if (!isset($_SESSION["hash"])) {
    exit;
}
if (isset($_GET["action"]) && $_GET["action"] == "user") {
    $rUserID = intval($_GET["user_id"]);
    if ($rPermissions["is_reseller"] && !hasPermissions("user", $rUserID)) {
        echo json_encode(["result" => false]);
        exit;
    }
    if ($rPermissions["is_admin"] && !hasPermissions("adv", "edit_user")) {
        echo json_encode(["result" => false]);
        exit;
    }
    $rSub = $_GET["sub"];
    if ($rSub == "renew") {
        $rPeriode = $_GET["periode"] * 86400;
        $rResult = $db->query("SELECT `exp_date`, `username` FROM `users` WHERE `id` = " . intval($rUserID) . ";");
        if ($rResult && 0 < $rResult->num_rows) {
            $rRow = $rResult->fetch_assoc();
            $date_renew = (int)($rRow['exp_date'] ?? 0) + (int)$rPeriode;
            $db->query("UPDATE `users` SET `exp_date` = " . intval($date_renew) . " WHERE `id` = " . intval($rUserID) . ";");
            
            // Retorna o novo vencimento formatado e o nome do usuário para o modal de confirmação
            echo json_encode([
                "result" => true,
                "username" => $rRow['username'],
                "next_expiration" => date("d/m/Y H:i:s", $date_renew)
            ]);
            exit;
        }
    }
    echo json_encode(["result" => false]);
    exit;
}
echo json_encode(["result" => false]);
?>

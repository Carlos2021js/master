<?php
include "session.php"; include "functions.php";

if ($rPermissions["is_admin"]) {
	if (!hasPermissions("adv", "users")) { exit; }
    $rRegisteredUsers = getRegisteredUsers();
} else {
    $rRegisteredUsers = getRegisteredUsers($rUserInfo["id"]);
}

if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li>
                                        <a href="#" onClick="clearFilters();">
                                            <button type="button" class="btn btn-warning waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-filter-remove"></i>
                                            </button>
                                        </a>
                                        <a href="#" onClick="changeZoom();">
                                            <button type="button" class="btn btn-info waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-magnify"></i>
                                            </button>
                                        </a>
                                        <?php if (!$detect->isMobile()) { ?>
                                        <a href="#" onClick="toggleAuto();">
                                            <button type="button" class="btn btn-dark waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-refresh"></i> <span class="auto-text"><?=$_["auto_refresh"]?></span>
                                            </button>
                                        </a>
                                        <?php } else { ?>
                                        <a href="javascript:location.reload();" onClick="toggleAuto();">
                                            <button type="button" class="btn btn-dark waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-refresh"></i> <?=$_["refresh"]?>
                                            </button>
                                        </a>
                                        <?php }
										if ((hasPermissions("adv", "add_user")) OR ($rPermissions["is_reseller"])) { ?>
                                        <a href="user<?php if ($rPermissions["is_reseller"]) { echo "_reseller"; } ?>.php">
                                            <button type="button" class="btn btn-success waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-plus"></i> <?=$_["add_user"]?>
                                            </button>
                                        </a>
										<?php } ?>
                                    </li>
                                </ol>
                            </div>
                            <h4 class="page-title"><?=$_["users"]?></h4>
                        </div>
                    </div>
                </div>
                <!-- end page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body" style="overflow-x:auto;">
                                <form id="users_search" class="cs-client-filter-panel" autocomplete="off">
                                    <div class="cs-client-filter-grid">
                                        <div class="cs-filter-field cs-filter-search">
                                            <label for="user_search"><i class="mdi mdi-magnify"></i> Pesquisar</label>
                                            <input type="text" class="form-control" id="user_search" value="" placeholder="Pesquisar cliente...">
                                        </div>
                                        <div class="cs-filter-field">
                                            <label for="user_reseller">Revendas</label>
                                            <select id="user_reseller" class="form-control" data-toggle="select2">
                                                <option value="" selected>Todas as revendas</option>
                                                <?php foreach ($rRegisteredUsers as $rRegisteredUser) { ?>
                                                <option value="<?=$rRegisteredUser["id"]?>"><?=$rRegisteredUser["username"]?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="cs-filter-field cs-filter-range">
                                            <label>Vencimento</label>
                                            <div class="cs-date-range"><input type="date" class="form-control" id="user_exp_from" title="Vencimento de"><span>–</span><input type="date" class="form-control" id="user_exp_to" title="Vencimento até"></div>
                                        </div>
                                        <div class="cs-filter-field cs-filter-range">
                                            <label>Criação</label>
                                            <div class="cs-date-range"><input type="date" class="form-control" id="user_created_from" title="Criado de"><span>–</span><input type="date" class="form-control" id="user_created_to" title="Criado até"></div>
                                        </div>
                                        <div class="cs-filter-field">
                                            <label for="user_filter">Situação</label>
                                            <select id="user_filter" class="form-control" data-toggle="select2">
                                                <option value="" selected>Todas</option>
                                                <option value="1"><?=$_["active"]?></option>
                                                <option value="2"><?=$_["disabled"]?></option>
                                                <option value="3"><?=$_["banned"]?></option>
                                                <option value="4"><?=$_["expired"]?></option>
                                                <option value="8"><?=$_["restreamer"]?></option>
                                            </select>
                                        </div>
                                        <div class="cs-filter-field">
                                            <label for="user_trial">Teste</label>
                                            <select id="user_trial" class="form-control" data-toggle="select2">
                                                <option value="" selected>Todos</option>
                                                <option value="1">Somente testes</option>
                                                <option value="0">Somente oficiais</option>
                                            </select>
                                        </div>
                                        <div class="cs-filter-field">
                                            <label for="user_server">Servidor</label>
                                            <select id="user_server" class="form-control" data-toggle="select2"><option value="">Todos os servidores</option><?php foreach (($rServers ?? array()) as $rServer) { ?><option value="<?=intval($rServer['id'])?>"><?=htmlspecialchars($rServer['server_name'] ?: ('Servidor #'.$rServer['id']), ENT_QUOTES, 'UTF-8')?></option><?php } ?></select>
                                        </div>
                                        <div class="cs-filter-field">
                                            <label for="user_connections">Conexões</label>
                                            <select id="user_connections" class="form-control" data-toggle="select2"><option value="">Todas</option><option value="1">Offline (0)</option><option value="2">Online (1+)</option><option value="3">Limite maior que 1</option></select>
                                        </div>
                                    </div>
                                    <div class="cs-client-filter-actions">
                                        <button type="button" class="btn btn-secondary" onclick="clearFilters();"><i class="mdi mdi-close-circle"></i> Limpar Filtro</button>
                                        <?php if ((hasPermissions("adv", "add_user")) OR ($rPermissions["is_reseller"])) { ?>
                                        <a class="btn btn-primary" href="user<?php if ($rPermissions["is_reseller"]) { echo "_reseller"; } ?>.php"><i class="mdi mdi-plus-circle"></i> Adicionar</a>
                                        <?php } ?>
                                        <button type="button" class="btn btn-primary cs-view-toggle" id="toggle-client-view"><i class="mdi mdi-view-grid-outline"></i> Mudar para Cards</button>
                                    </div>
                                    <div class="cs-client-list-tools">
                                        <label for="user_show_entries">Mostrar</label>
                                        <select id="user_show_entries" class="form-control" data-toggle="select2">
                                            <?php foreach (Array(10, 15, 25, 50, 100, 250) as $rShow) { ?>
                                            <option<?php if ($rAdminSettings["default_entries"] == $rShow) { echo " selected"; } ?> value="<?=$rShow?>"><?=$rShow?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </form>
                                <div id="client-cards" class="client-cards-grid" style="display:none;"></div>
                                <table id="datatable-users" class="table table-hover dt-responsive nowrap font-normal">
                                    <thead>
                                        <tr>
                                            <th class="text-center"><?=$_["id"]?></th>
                                            <th><?=$_["username"]?></th>
                                            <th><?=$_["password"]?></th>
                                            <th><?=$_["reseller"]?></th>
                                            <th class="text-center"><?=$_["status"]?></th>
                                            <!--<th class="text-center"><?=$_["online"]?></th>-->
                                            <th class="text-center"><?=$_["acount"]?></th>
                                            <th class="text-center"><?=$_["expiration"]?></th>
                                            <th class="text-center"><?=$_["days"]?></th>
                                            <th class="text-center"><?=$_["conns"]?></th>
                                            <!--<th class="text-center"><?=$_["last_connection"]?></th>-->
											<th class="text-center"><?=$_["info"]?></th>	   
                                            <th class="text-center"><?=$_["actions"]?></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div> <!-- end card body-->
                        </div> <!-- end card -->
                    </div><!-- end col-->
                </div>
                <!-- end row-->
            </div> <!-- end container -->
            <?php if ((($rPermissions["is_reseller"]) && ($rPermissions["allow_download"])) OR ($rPermissions["is_admin"])) { ?>
            <div class="modal fade downloadModal" role="dialog" aria-labelledby="downloadLabel" aria-hidden="true" style="display: none;" data-username="" data-password="">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="downloadModal"><?=$_["download_playlist"]?></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="col-12">
                                <select id="download_type" class="form-control" data-toggle="select2">
                                    <option value=""><?=$_["select_an_ouput_format"]?> </option>
                                    <?php
                                    $result = $db->query("SELECT * FROM `devices` ORDER BY `device_id` ASC;");
                                    if (($result) && ($result->num_rows > 0)) {
                                        while ($row = $result->fetch_assoc()) {
                                            if ($row["copy_text"]) {
                                                echo '<optgroup label="'.$row["device_name"].'"><option data-text="'.str_replace('"', '\"', $row["copy_text"]).'" value="type='.$row["device_key"].'&amp;output=hls">'.$row["device_name"].' - HLS </option><option data-text="'.str_replace('"', '\"', $row["copy_text"]).'" value="type='.$row["device_key"].'&amp;output=mpegts">'.$row["device_name"].' - MPEGTS</option></optgroup>';
                                            } else {
                                                echo '<optgroup label="'.$row["device_name"].'"><option value="type='.$row["device_key"].'&amp;output=hls">'.$row["device_name"].' - HLS </option><option value="type='.$row["device_key"].'&amp;output=mpegts">'.$row["device_name"].' - MPEGTS</option></optgroup>';
                                            }
                                        }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-12" style="margin-top:10px;">
                                <div class="input-group">
                                    <input type="text" class="form-control" id="download_url" value="">
                                    <div class="input-group-append">
                                        <button class="btn btn-warning waves-effect waves-light" type="button" onClick="copyDownload();"><i class="mdi mdi-content-copy"></i></button>
                                        <button class="btn btn-info waves-effect waves-light" type="button" onClick="doDownload();" id="download_button" disabled><i class="mdi mdi-download"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            <?php } ?>
			<?php if ((($rPermissions["is_reseller"]) && ($rPermissions["allow_download"])) OR ($rPermissions["is_admin"])) { ?>
            <div class="modal fade RenewModal" role="dialog" aria-labelledby="payementLabel" aria-hidden="true" style="display: none;" data-username="" data-password="">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="renewModal">Renovar Cliente</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Selecione o período de renovação:</label>
                                <select id="renew_type" class="form-control" data-toggle="select2">
                                    <option value=""> <?=$_["extend_:"]?> </option>
				                    <option value="1"> <?=$_["1_day"]?> </option>									
				                    <option value="31"> <?=$_["1_month"]?> </option>
				                    <option value="92"> <?=$_["3_month"]?> </option>
				                    <option value="183"> <?=$_["6_month"]?> </option>							
				                    <option value="365"> <?=$_["12_month"]?> </option>
                                </select>
                            </div>
                            <div class="mt-3 text-right">
                                <button class="btn btn-info waves-effect waves-light" type="button" onClick="dorenew();" id="renew_button" disabled> <?=$_["ok"]?></button>
                            </div>
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            <?php } ?>

            <!-- MODAL DE CONFIRMAÇÃO DE RENOVAÇÃO (ESTILO FOTO) -->
            <div class="modal fade RenewConfirmModal" role="dialog" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content text-center">
                        <div class="modal-body p-4">
                            <h4 class="mb-3">Confirmação de Renovação</h4>
                            <div class="alert alert-info border-info bg-transparent text-left" style="border: 2px solid #35b8e0 !important; border-radius: 10px;">
                                <p class="mb-1 text-info text-center"><strong>*Confirmação de Renovação*</strong></p>
                                <p class="mb-1">✅ Usuário: <span id="confirm-user" class="font-weight-bold"></span></p>
                                <p class="mb-0">🗓 Próximo Vencimento: <span id="confirm-exp" class="font-weight-bold"></span></p>
                            </div>
                            <div class="row mt-4">
                                <div class="col-6">
                                    <button class="btn btn-success btn-block" onclick="whatsappRenewal()"><i class="mdi mdi-whatsapp"></i> WhatsApp</button>
                                </div>
                                <div class="col-6">
                                    <button class="btn btn-primary btn-block" onclick="copyRenewal()"><i class="mdi mdi-content-copy"></i> Copiar</button>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button class="btn btn-light btn-block text-dark" data-dismiss="modal">Fechar</button>
                            </div>
                            <div class="mt-2">
                                <button class="btn btn-primary btn-block" onclick="copyRenewal(); $('.RenewConfirmModal').modal('hide');">
                                    <i class="mdi mdi-content-copy"></i> Copiar e Fechar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ====== NOVO MODAL DE DETALHES DO CLIENTE ====== -->
            <div class="modal fade UserDetailsModal" role="dialog" aria-labelledby="userDetailsLabel" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-dialog-centered modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="userDetailsLabel">Detalhes do Cliente</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div id="userDetailsContainer">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="card">
                                            <div class="card-body">
                                                <h5 class="card-title">Informações Pessoais</h5>
                                                <div class="alert alert-info border-info bg-transparent" style="border: 2px solid #35b8e0 !important; border-radius: 10px; color: #fff;">
                                                    <div class="mb-1">✅ <strong>Usuário:</strong> <span id="detail-username"></span></div>
                                                    <div class="mb-1">✅ <strong>Senha:</strong> <span id="detail-password"></span></div>
                                                    <div class="mb-1 detail-optional" data-field="plan">📦 <strong>Conteúdo/Plano:</strong> <span id="detail-plan"></span></div>
                                                    <div class="mb-1 detail-optional" data-field="owner">👤 <strong>Revenda:</strong> <span id="detail-owner"></span></div>
                                                    <div class="mb-1 detail-optional" data-field="server">🖥 <strong>Servidor:</strong> <span id="detail-server"></span></div>
                                                    <div class="mb-1">🗓 <strong>Criado em:</strong> <span id="detail-created"></span></div>
                                                    <div class="mb-1">🗓 <strong>Vencimento:</strong> <span id="detail-expiration"></span></div>
                                                    <div class="mb-1">📶 <strong>Conexões:</strong> <span id="detail-connections"></span></div>
                                                    <div class="mt-2"><strong>Status:</strong> <span id="detail-status"></span></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="card">
                                            <div class="card-body">
                                                <h5 class="card-title">Links e Acessos</h5>
                                                <div class="form-group detail-optional" data-field="dns">
                                                    <label><strong>DNS / URL do servidor:</strong></label>
                                                    <div class="input-group"><input type="text" class="form-control" id="detail-dns" readonly><div class="input-group-append"><button class="btn btn-outline-secondary" onclick="copyField('detail-dns')"><i class="mdi mdi-content-copy"></i></button></div></div>
                                                </div>
                                                <div class="form-group">
                                                    <label><strong>Link HLS [MAIS RECOMENDADO] (M3U):</strong></label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" id="detail-link-hls" readonly>
                                                        <div class="input-group-append">
                                                            <button class="btn btn-outline-secondary" onclick="copyField('detail-link-hls')"><i class="mdi mdi-content-copy"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label><strong>Link (M3U):</strong></label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" id="detail-link-mpegts" readonly>
                                                        <div class="input-group-append">
                                                            <button class="btn btn-outline-secondary" onclick="copyField('detail-link-mpegts')"><i class="mdi mdi-content-copy"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group detail-optional" data-field="m3u8">
                                                    <label><strong>Link M3U8:</strong></label>
                                                    <div class="input-group"><input type="text" class="form-control" id="detail-link-m3u8" readonly><div class="input-group-append"><button class="btn btn-outline-secondary" onclick="copyField('detail-link-m3u8')"><i class="mdi mdi-content-copy"></i></button></div></div>
                                                </div>
                                                <div class="form-group detail-optional" data-field="api">
                                                    <label><strong>Player API:</strong></label>
                                                    <div class="input-group"><input type="text" class="form-control" id="detail-player-api" readonly><div class="input-group-append"><button class="btn btn-outline-secondary" onclick="copyField('detail-player-api')"><i class="mdi mdi-content-copy"></i></button></div></div>
                                                </div>
                                                <div class="form-group detail-optional" data-field="epg">
                                                    <label><strong>EPG / XMLTV:</strong></label>
                                                    <div class="input-group"><input type="text" class="form-control" id="detail-epg" readonly><div class="input-group-append"><button class="btn btn-outline-secondary" onclick="copyField('detail-epg')"><i class="mdi mdi-content-copy"></i></button></div></div>
                                                </div>
                                                <div class="form-group">
                                                    <label><strong>Link (SSIPTV):</strong></label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" id="detail-ssiptv" readonly>
                                                        <div class="input-group-append">
                                                            <button class="btn btn-outline-secondary" onclick="copyField('detail-ssiptv')"><i class="mdi mdi-content-copy"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label><strong>XCIPTV:</strong></label>
                                                    <div class="input-group mb-1">
                                                        <span class="input-group-text">URL</span>
                                                        <input type="text" class="form-control" id="detail-xciptv-url" readonly>
                                                        <button class="btn btn-outline-secondary" onclick="copyField('detail-xciptv-url')"><i class="mdi mdi-content-copy"></i></button>
                                                    </div>
                                                    <div class="input-group mb-1">
                                                        <span class="input-group-text">Usuário</span>
                                                        <input type="text" class="form-control" id="detail-xciptv-user" readonly>
                                                        <button class="btn btn-outline-secondary" onclick="copyField('detail-xciptv-user')"><i class="mdi mdi-content-copy"></i></button>
                                                    </div>
                                                    <div class="input-group">
                                                        <span class="input-group-text">Senha</span>
                                                        <input type="text" class="form-control" id="detail-xciptv-pass" readonly>
                                                        <button class="btn btn-outline-secondary" onclick="copyField('detail-xciptv-pass')"><i class="mdi mdi-content-copy"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-success" onclick="whatsappAllDetails()"><i class="mdi mdi-whatsapp"></i> WhatsApp</button>
                            <button class="btn btn-primary" onclick="copyAllDetails()"><i class="mdi mdi-content-copy"></i> Copiar Tudo</button>
                            <button class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ====== FIM DO NOVO MODAL ====== -->

        </div>
        <!-- end wrapper -->
        <?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>
        <script src="assets/js/pages/form-remember.js"></script>
        <script src="assets/js/app.min.js"></script>

        <!-- Datatables init -->
        <script>
        var autoRefresh = true;
        var rClearing = false;

	        function api_renew(rID, rType, rPeriode) {
	            $.getJSON("./api_renew.php?action=user&sub=" + rType + "&user_id=" + rID + "&periode=" + rPeriode, function(data) {
	                if (data.result === true) {
	                    if (rType == "renew") {
	                        $('.RenewModal').modal('hide');
                            $('#confirm-user').text(data.username);
                            $('#confirm-exp').text(data.next_expiration);
                            $('.RenewConfirmModal').modal('show');
	                    }
	                    $.each($('.tooltip'), function (index, element) {   
	                        $(this).remove();
	                    });
	                    $('[data-toggle="tooltip"]').tooltip("hide");
	                    $("#datatable-users").DataTable().ajax.reload(null, false);
	                } else {
	                    $.toast("<?=$_["an_error_occured"]?>");
	                }
	            });
	        }

        function api(rID, rType) {
            if (rType == "delete") {
                if (confirm('<?=$_["are_you_sure_you_want_to_delete_this_user"]?>') == false) {
                    return;
                }
            } else if (rType == "kill") {
                if (confirm('<?=$_["are_you_sure_you_want_to kill"]?>') == false) {
                    return;
                }
            } else if (rType == "resetispuser") {
                if (confirm('<?=$_["are_you_sure_you_want_to_reset_this_isp"]?>') == false) {
                    return;
                }    
            } else if (rType == "lockk") {
                if (confirm('<?=$_["are_you_sure_you_want_to_lock_this_isp"]?>') == false) {
                    return;
                }    
            } else if (rType == "unlockk") {
                if (confirm('<?=$_["are_you_sure_you_want_to_unlock_this_isp"]?>') == false) {
                    return;
                }    
            } else if (rType == "ban") {
                if (confirm('<?=$_["are_you_sure_you_want_to_ban"]?>') == false) {
                    return;
                }    
            } else if (rType == "unban") {
                if (confirm('<?=$_["are_you_sure_you_want_to_unban"]?>') == false) {
                    return;
                }    
            } else if (rType == "enable") {
                if (confirm('<?=$_["are_you_sure_you_want_to_enable"]?>') == false) {
                    return;
                }    
            } else if (rType == "disable") {
                if (confirm('<?=$_["are_you_sure_you_want_to_disable"]?>') == false) {
                    return;
                }    
            }
            $.getJSON("./api.php?action=user&sub=" + rType + "&user_id=" + rID, function(data) {
                if (data.result === true) {
                    if (rType == "delete") {
                        $.toast("<?=$_["user_has_been_deleted"]?>");
                    } else if (rType == "enable") {
                        $.toast("<?=$_["user_has_been_enabled"]?>");
                    } else if (rType == "disable") {
                        $.toast("<?=$_["user_has_been_disabled"]?>");
                    } else if (rType == "unban") {
                        $.toast("<?=$_["user_has_been_unbanned"]?>");
                    } else if (rType == "ban") {
                        $.toast("<?=$_["user_has_been_banned"]?>");
                    } else if (rType == "resetispuser") {
                        $.toast("<?=$_["isp_reseted"]?>");
                    } else if (rType == "lockk") {
                        $.toast("<?=$_["isp-has_been_locked"]?>");
                    } else if (rType == "unlockk") {
                        $.toast("<?=$_["isp_has_been_unlocked"]?>");  
                    } else if (rType == "kill") {
                        $.toast("<?=$_["all_connections_for_this_user_have_been_killed"]?>");                                     
                    }
                    $.each($('.tooltip'), function (index, element) {
                        $(this).remove();
                    });
                    $('[data-toggle="tooltip"]').tooltip("hide");
                    $("#datatable-users").DataTable().ajax.reload(null, false);
                } else {
                    $.toast("<?=$_["an_error_occured_while_processing_your_request"]?>");
                }
            });
        }

        function renew_user(rid, username) {
            $("#renew_type").val("");
            $("#renew_button").attr("disabled", true);
            $('.RenewModal').data('id', rid );
            $('.RenewModal').data('username', username );
            $("#renewModal").text("<?=$_["customer_subscription"]?> : "+ $('.RenewModal').data('username') );
            $('.RenewModal').modal('show');
        }   

        function download(username, password) {
            $("#download_type").val("");
            $("#download_button").attr("disabled", true);
            $('.downloadModal').data('username', username);
            $('.downloadModal').data('password', password);
            $('.downloadModal').modal('show');
        }
       
        $("#download_type").change(function() {
            if ($("#download_type").val().length > 0) {
                <?php
                if (strlen($rUserInfo["reseller_dns"]) > 0) {
                    $rDNS = $rUserInfo["reseller_dns"];
                } else {
                    $rDNS = $rServers[$_INFO["server_id"]]["domain_name"] ? $rServers[$_INFO["server_id"]]["domain_name"] : $rServers[$_INFO["server_id"]]["server_ip"];
                }
                ?>
                <?php if  ($rAdminSettings["use_https_main"]) { ?>
                rText = "https://<?=$rDNS?>:<?=$rServers[$_INFO["server_id"]]["https_broadcast_port"]?>/get.php?username=" + encodeURIComponent($('.downloadModal').data('username')) + "&password=" + encodeURIComponent($('.downloadModal').data('password')) + "&" + decodeURIComponent($('.downloadModal select').val());
                if ($("#download_type").find(':selected').data('text')) {
                    rText = $("#download_type").find(':selected').data('text').replace("{DEVICE_LINK}", '"' + rText + '"');
                    $("#download_button").attr("disabled", true);
                } else {
                    $("#download_button").attr("disabled", false);
                }
                $("#download_url").val(rText);
            } else {
                $("#download_url").val("");
            }
                <?php } else { ?>
                rText = "http://<?=$rDNS?>:<?=$rServers[$_INFO["server_id"]]["http_broadcast_port"]?>/get.php?username=" + encodeURIComponent($('.downloadModal').data('username')) + "&password=" + encodeURIComponent($('.downloadModal').data('password')) + "&" + decodeURIComponent($('.downloadModal select').val());
                if ($("#download_type").find(':selected').data('text')) {
                    rText = $("#download_type").find(':selected').data('text').replace("{DEVICE_LINK}", '"' + rText + '"');
                    $("#download_button").attr("disabled", true);
                } else {
                    $("#download_button").attr("disabled", false);
                }
                $("#download_url").val(rText);
            } else {
                $("#download_url").val("");
            }
                <?php } ?>
        });
  
        $("#renew_type").change(function() {
            if ($("#renew_type").val().length > 0) {
                $("#renew_button").attr("disabled", false);                  
            } else {
                $("#renew_button").attr("disabled", true);
            }
        });
        
        function dorenew() {
            api_renew( $('.RenewModal').data('id'), "renew", $("#renew_type").val() );
            $('.RenewModal').modal('hide');
        }                                             
  
        function doDownload() {
            if ($("#download_url").val().length > 0) {
                window.open($("#download_url").val());
            }
        }
        function copyDownload() {
            $("#download_url").select();
            document.execCommand("copy"); 
        }
        function toggleAuto() {
            if (autoRefresh == true) {
                autoRefresh = false;
                $(".auto-text").html("<?=$_["manual_mode"]?>");
            } else {
                autoRefresh = true;
                $(".auto-text").html("<?=$_["auto_refresh"]?>");
            }
        }
        function getFilter() {
            return $("#user_filter").val();
        }
        function getReseller() {
            return $("#user_reseller").val();
        }
        function reloadUsers() {
            if (autoRefresh == true) {
                $('[data-toggle="tooltip"]').tooltip("hide");
                $("#datatable-users").DataTable().ajax.reload(null, false);
            }
            setTimeout(reloadUsers, 10000);
        }
        function changeZoom() {
            if ($("#datatable-users").hasClass("font-large")) {
                $("#datatable-users").removeClass("font-large");
                $("#datatable-users").addClass("font-normal");
            } else if ($("#datatable-users").hasClass("font-normal")) {
                $("#datatable-users").removeClass("font-normal");
                $("#datatable-users").addClass("font-small");
            } else {
                $("#datatable-users").removeClass("font-small");
                $("#datatable-users").addClass("font-large");
            }
            $("#datatable-users").DataTable().draw();
        }
        function clearFilters() {
            window.rClearing = true;
            $("#user_search").val("").trigger('change');
            $('#user_filter').val("").trigger('change');
            $('#user_reseller').val("").trigger('change');
            $('#user_created_from, #user_created_to, #user_exp_from, #user_exp_to').val('');
            $('#user_server, #user_connections, #user_trial').val('').trigger('change');
            $('#user_show_entries').val("<?=$rAdminSettings["default_entries"] ?: 10?>").trigger('change');
            window.rClearing = false;
            $('#datatable-users').DataTable().search($("#user_search").val());
            $('#datatable-users').DataTable().page.len($('#user_show_entries').val());
            $("#datatable-users").DataTable().page(0).draw('page');
            $('[data-toggle="tooltip"]').tooltip("hide");
            $("#datatable-users").DataTable().ajax.reload( null, false );
        }

        // ========== NOVAS FUNÇÕES PARA DETALHES DO CLIENTE ==========
        function showUserDetails(userId, afterLoad) {
            $.getJSON("get_user_details.php?user_id=" + userId, function(response) {
                if (response.success) {
                    var d = response.data;
                    $('#detail-username').text(d.username);
                    $('#detail-password').text(d.password);
                    $('#detail-plan').text(d.plan);
                    $('#detail-owner').text(d.owner || '');
                    $('#detail-server').text(d.server_name || '');
                    $('#detail-created').text(d.created_at);
                    $('#detail-expiration').text(d.expiration);
                    $('#detail-connections').text(d.connections);
                    
                    var statusText = d.status || 'Indefinido';
                    var badgeClass = statusText === 'Ativo' ? 'success' : (statusText === 'Vencido' ? 'warning' : (statusText === 'Banido' ? 'danger' : 'secondary'));
                    $('#detail-status').html('<span class="badge badge-' + badgeClass + '">' + statusText + '</span>');
                    $('.detail-optional[data-field="plan"]').toggle(!!d.plan);
                    $('.detail-optional[data-field="owner"]').toggle(!!d.owner);
                    $('.detail-optional[data-field="server"]').toggle(!!d.server_name);
                    $('.detail-optional[data-field="dns"]').toggle(!!d.dns);
                    $('.detail-optional[data-field="m3u8"]').toggle(!!d.link_m3u8);
                    $('.detail-optional[data-field="api"]').toggle(!!d.player_api);
                    $('.detail-optional[data-field="epg"]').toggle(!!d.epg_link);

                    $('#detail-dns').val(d.dns || '');
                    $('#detail-link-hls').val(d.link_hls || '');
                    $('#detail-link-mpegts').val(d.link_mpegts || '');
                    $('#detail-link-m3u8').val(d.link_m3u8 || '');
                    $('#detail-player-api').val(d.player_api || '');
                    $('#detail-epg').val(d.epg_link || '');
                    $('#detail-ssiptv').val(d.ssiptv_link);
                    $('#detail-xciptv-url').val(d.xciptv_url);
                    $('#detail-xciptv-user').val(d.xciptv_user);
                    $('#detail-xciptv-pass').val(d.xciptv_pass);
                    
                    $('.UserDetailsModal').modal('show');
                    if (typeof afterLoad === 'function') afterLoad(d);
                } else {
                    $.toast("Erro: " + (response.message || 'Falha ao carregar dados.'));
                }
            }).fail(function() {
                $.toast("Erro de comunicação com o servidor.");
            });
        }

        function copyField(fieldId) {
            var input = document.getElementById(fieldId);
            if (!input) return;
            copyToClipboard(input.value || input.textContent || '');
            $.toast("Copiado para a área de transferência!");
        }

	        function whatsappAllDetails() {
	            var text = getProfessionalDetailsText();
	            window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
	        }
            function getProfessionalDetailsText() {
                function val(selector){ return ($(selector).val ? $(selector).val() : '') || $(selector).text() || ''; }
                function line(label, value, icon){ value = String(value || '').trim(); return value ? (icon + ' *' + label + ':* ' + value + "\n") : ''; }
                function block(label, value, icon){ value = String(value || '').trim(); return value ? ("\n" + icon + ' *' + label + ':*' + "\n" + value + "\n") : ''; }
                var text = "📺 *CS Player — Dados do Cliente*\n\n";
                text += line('Usuário', $('#detail-username').text(), '👤');
                text += line('Senha', $('#detail-password').text(), '🔑');
                text += line('Conteúdo/Plano', $('#detail-plan').text(), '📦');
                text += line('Revenda', $('#detail-owner').text(), '👥');
                text += line('Servidor', $('#detail-server').text(), '🖥');
                text += line('Conexões', $('#detail-connections').text(), '📶');
                text += line('Status', $('#detail-status').text().replace(/\s+/g,' ').trim(), '📌');
                text += line('Criado em', $('#detail-created').text(), '🗓');
                text += line('Vencimento', $('#detail-expiration').text(), '⏳');
                text += block('DNS / Servidor', $('#detail-dns').val(), '🌐');
                text += block('M3U HLS (recomendado)', $('#detail-link-hls').val(), '🟢');
                text += block('M3U MPEG-TS', $('#detail-link-mpegts').val(), '🟡');
                text += block('M3U8', $('#detail-link-m3u8').val(), '🟢');
                text += block('SSIPTV', $('#detail-ssiptv').val(), '🔴');
                text += block('Player API', $('#detail-player-api').val(), '🔗');
                text += block('EPG / XMLTV', $('#detail-epg').val(), '📺');
                if ($('#detail-xciptv-url').val()) {
                    text += "\n🟠 *XCIPTV / Xtream Codes:*\n";
                    text += "URL: " + $('#detail-xciptv-url').val() + "\n";
                    text += "Usuário: " + $('#detail-xciptv-user').val() + "\n";
                    text += "Senha: " + $('#detail-xciptv-pass').val() + "\n";
                }
                return text.trim();
            }
            function whatsappRenewal() {
                var text = "*Confirmação de Renovação*\n\n";
                text += "✅ Usuário: " + $('#confirm-user').text() + "\n";
                text += "🗓 Próximo Vencimento: " + $('#confirm-exp').text();
                window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
            }
            function copyRenewal() {
                var text = "*Confirmação de Renovação*\n\n";
                text += "✅ Usuário: " + $('#confirm-user').text() + "\n";
                text += "🗓 Próximo Vencimento: " + $('#confirm-exp').text();
                copyToClipboard(text);
                $.toast("Confirmação copiada!");
            }
            function copyToClipboard(text) {
                if (navigator.clipboard && window.isSecureContext) {
                    navigator.clipboard.writeText(text);
                } else {
                    var area = $('<textarea>').val(text).appendTo('body').select();
                    document.execCommand('copy');
                    area.remove();
                }
            }
        function renderClientCards() {
            var table = $('#datatable-users').DataTable();
            var html = '';
            table.rows({page: 'current'}).every(function(){
                var d = this.data();
                html += '<article class="client-card"><div class="client-card-heading"><div><strong>' + d[1] + '</strong><small>#' + d[0] + ' · ' + (d[3] || '') + '</small></div><span class="client-card-status">' + d[4] + '</span></div><div class="client-card-row"><span>Vencimento</span><b>' + d[6] + '</b></div><div class="client-card-row"><span>Conexões</span><b>' + d[8] + '</b></div><div class="client-card-row"><span>Tipo</span><b>' + d[5] + '</b></div><div class="client-card-actions"><button type="button" class="btn btn-info" onclick="showUserDetails(' + d[0] + ')"><i class="mdi mdi-eye-outline"></i> Detalhes</button><button type="button" class="btn btn-primary" onclick="showUserDetails(' + d[0] + ', function(){ copyAllDetails(); })"><i class="mdi mdi-content-copy"></i> Copiar tudo</button></div><div class="client-card-more">' + d[10] + '</div></article>';
            });
            $('#client-cards').html(html || '<div class="alert alert-info">Nenhum cliente encontrado.</div>');
        }
        function copyTextValue(userId) {
            var row = $('#datatable-users').DataTable().rows().data().toArray().filter(function(item){ return String(item[0]) === String(userId); })[0];
            if (!row) return;
            var text = 'Usuário: ' + $('<div>').html(row[1]).text() + '\nSenha: ' + $('<div>').html(row[2]).text() + '\nVencimento: ' + $('<div>').html(row[6]).text();
            if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text); else { var area = $('<textarea>').val(text).appendTo('body').select(); document.execCommand('copy'); area.remove(); }
            $.toast('Dados copiados.');
        }
	        function copyAllDetails() {
	            var text = getProfessionalDetailsText();
	            copyToClipboard(text);
	            $.toast("Todos os dados copiados!");
	        }
        // ========== FIM DAS NOVAS FUNÇÕES ==========

        $(document).ready(function() {
            $(window).keypress(function(event){
                if(event.which == 13 && event.target.nodeName != "TEXTAREA") return false;
            });
            formCache.init();
            formCache.fetch();
            
            $.fn.dataTable.ext.errMode = 'none';
            $('select').select2({width: '100%'});
            
            $("#datatable-users").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>",
                    },
                    infoFiltered: ""
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination");
                    $('[data-toggle="tooltip"]').tooltip();
                    if ($('#client-cards').is(':visible')) renderClientCards();
                    // Adiciona o botão "Copiar" na coluna de ações (índice 10) para cada linha
                    $('#datatable-users tbody tr').each(function() {
                        var row = $(this);
                        var userId = row.find('td:eq(0)').text().trim();
                        var actionsCell = row.find('td:eq(10)');
                        if (actionsCell.length && !actionsCell.find('.btn-copy-details').length) {
                            var copyBtn = $('<button class="btn btn-sm btn-info btn-copy-details" title="Abrir detalhes e copiar informações"><i class="mdi mdi-content-copy"></i></button>');
                            copyBtn.on('click', function(e) {
                                e.stopPropagation();
                                showUserDetails(userId);
                            });
                            // Insere antes dos outros botões
                            actionsCell.prepend(copyBtn);
                            actionsCell.prepend(' ');
                        }
                    });
                },
                createdRow: function(row, data, index) {
                    $(row).addClass('user-' + data[0]);
                    var status = $('<div>').html(data[4]).text().toLowerCase();
                    $(row).addClass(status.indexOf('expired') >= 0 ? 'client-row-expired' : (status.indexOf('disabled') >= 0 ? 'client-row-disabled' : (status.indexOf('banned') >= 0 ? 'client-row-banned' : 'client-row-active')));
                },
                responsive: {
                    details: {
                        display: $.fn.dataTable.Responsive.display.modal( {
                            header: function ( row ) {
                                var data = row.data();
                                return 'Detalhes do Usuário #' + data[0];
                            }
                        } ),
                        renderer: $.fn.dataTable.Responsive.renderer.tableAll( {
                            tableClass: 'table table-bordered table-striped'
                        } )
                    }
                },
                processing: true,
                serverSide: true,
                ajax: {
                    url: "./table_search.php",
                    "data": function(d) {
                        d.id = "users";
                        d.filter = getFilter();
                        d.reseller = getReseller();
                        d.created_from = $("#user_created_from").val();
                        d.created_to = $("#user_created_to").val();
                        d.exp_from = $("#user_exp_from").val();
                        d.exp_to = $("#user_exp_to").val();
                        d.server = $("#user_server").val();
                        d.connections = $("#user_connections").val();
                        d.trial = $("#user_trial").val();
                    }
                },
                columnDefs: [
                    {"className": "dt-center", "targets": [0,1,2,3,4,5,6,7,8,9,10]},
                    {"visible": false, "targets": []},
                    {"orderable": false, "targets": [10]}
                ],
                order: [[ 0, "desc" ]],
                pageLength: <?=$rAdminSettings["default_entries"] ?: 10?>,
                stateSave: true
            });
            $("#datatable-users").css("width", "100%");
            
            $('#user_search').keyup(function(){
                if (!window.rClearing) {
                    $('#datatable-users').DataTable().search($(this).val()).draw();
                }
            });
            $('#user_show_entries').change(function(){
                if (!window.rClearing) {
                    $('#datatable-users').DataTable().page.len($(this).val()).draw();
                }
            });
            $('#user_filter').change(function(){
                if (!window.rClearing) {
                    $('[data-toggle="tooltip"]').tooltip("hide");
                    $("#datatable-users").DataTable().ajax.reload( null, false );
                }
            });
            $('#user_created_from, #user_created_to, #user_exp_from, #user_exp_to, #user_server, #user_connections, #user_trial').on('change', function(){
                if (!window.rClearing) $('#datatable-users').DataTable().ajax.reload(null, false);
            });
            function setClientView(mode) {
                var cards = $('#client-cards');
                var wrapper = $('#datatable-users').closest('.dataTables_wrapper');
                var useCards = mode === 'cards';
                cards.toggle(useCards);
                wrapper.toggle(!useCards);
                $('#toggle-client-view').html(useCards ? '<i class="mdi mdi-table"></i> Mudar para Tabela' : '<i class="mdi mdi-view-grid-outline"></i> Mudar para Cards');
                try { localStorage.setItem('cs-client-view', useCards ? 'cards' : 'table'); } catch (e) {}
                if (useCards) renderClientCards();
            }
            $('#toggle-client-view').on('click', function(){
                setClientView($('#client-cards').is(':visible') ? 'table' : 'cards');
            });
            var savedClientView = null;
            try { savedClientView = localStorage.getItem('cs-client-view'); } catch (e) {}
            if (!savedClientView && window.matchMedia && window.matchMedia('(max-width: 767.98px)').matches) savedClientView = 'cards';
            if (savedClientView === 'cards') setTimeout(function(){ setClientView('cards'); }, 0);
            $('#user_reseller').change(function(){
                if (!window.rClearing) {
                    $('[data-toggle="tooltip"]').tooltip("hide");
                    $("#datatable-users").DataTable().ajax.reload( null, false );
                }
            });
            <?php if (!$detect->isMobile()) { ?>
            setTimeout(reloadUsers, 10000);
            <?php } ?>
            <?php if (!$rAdminSettings["auto_refresh"]) { ?>
            toggleAuto();
            <?php } ?>
            if ($('#user_search').val().length > 0) {
                $('#datatable-users').DataTable().search($('#user_search').val()).draw();
            }
        });
        
        $(window).bind('beforeunload', function() {
            formCache.save();
        });
        </script>
        <style>/* Layout de Clientes centralizado em assets/css/csplay-sigma.css */</style>
    </body>
</html>
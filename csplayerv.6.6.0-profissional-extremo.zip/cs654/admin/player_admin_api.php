<?php
include 'session.php'; include 'functions.php';
if ((int)($rPermissions['is_admin'] ?? 0) !== 1 || !hasPermissions('adv','settings')) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'Acesso restrito ao administrador.'], JSON_UNESCAPED_UNICODE);
    exit;
}
require_once __DIR__ . '/player/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function out($a,$s=200){http_response_code($s);echo json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
set_exception_handler(static function (\Throwable $e): void {
    if (function_exists('cs_player_write_log')) cs_player_write_log('player_admin_api_exception', [
        'class'=>get_class($e),'line'=>$e->getLine(),'file'=>basename($e->getFile()),
        'message_hash'=>substr(hash('sha256',$e->getMessage()),0,12)
    ], 'error');
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode(['ok'=>false,'message'=>'Falha interna ao processar as configurações do Web Player. Consulte os logs.'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
});

function cs_admin_fixed_player_dns(): array {
    $servers = function_exists('getStreamingServers') ? getStreamingServers(true) : [];
    return cs_player_server_dns_from_rows(array_values(is_array($servers) ? $servers : []));
}

function cs_admin_probe_request(string $target, int $timeout, string $userAgent = 'CSPlayer-DNS-Probe/1.4'): array {
    $ch = curl_init($target);
    $start = microtime(true);
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,
        CURLOPT_CONNECTTIMEOUT=>min(4,$timeout),CURLOPT_TIMEOUT=>$timeout,CURLOPT_USERAGENT=>$userAgent,
        CURLOPT_HTTP_VERSION=>CURL_HTTP_VERSION_1_1,CURLOPT_ENCODING=>'',
        CURLOPT_HTTPHEADER=>['Accept: application/json, text/plain, application/x-mpegURL, */*','Connection: keep-alive'],
        CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>false,CURLOPT_HEADER=>false,
    ]);
    $body=curl_exec($ch);$err=(string)curl_error($ch);$errno=(int)curl_errno($ch);
    $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$ctype=(string)(curl_getinfo($ch,CURLINFO_CONTENT_TYPE)??'');
    $effective=(string)curl_getinfo($ch,CURLINFO_EFFECTIVE_URL);$remoteIp=(string)(curl_getinfo($ch,CURLINFO_PRIMARY_IP)??'');
    $redirects=(int)(curl_getinfo($ch,CURLINFO_REDIRECT_COUNT)??0);$httpVersion=(int)(curl_getinfo($ch,CURLINFO_HTTP_VERSION)??0);
    curl_close($ch);
    return ['body'=>is_string($body)?$body:'','curl_error'=>$err,'curl_errno'=>$errno,'http_code'=>$code,'content_type'=>$ctype,
        'effective_url'=>$effective?:$target,'remote_ip'=>$remoteIp,'redirects'=>$redirects,'http_version'=>$httpVersion,
        'response_bytes'=>is_string($body)?strlen($body):0,'latency_ms'=>(int)round((microtime(true)-$start)*1000)];
}

function cs_admin_probe_dns(string $url, int $timeout = 5, string $providerMode = 'auto', string $m3uPath = 'get.php', string $m3uOutput = 'mpegts'): array {
    $url = cs_player_normalize_dns($url);
    $providerMode = in_array(strtolower($providerMode), ['auto','xc','smart','xtream','m3u'], true) ? strtolower($providerMode) : 'auto';
    $m3uOutput = in_array(strtolower($m3uOutput), ['mpegts','hls'], true) ? strtolower($m3uOutput) : 'mpegts';
    $m3uPath = trim($m3uPath) !== '' ? ltrim(trim($m3uPath), '/') : 'get.php';
    if ($url === '') {
        cs_player_write_log('server_probe_invalid_dns', ['input' => $url], 'warning');
        return ['ok'=>false,'latency_ms'=>0,'http_code'=>0,'message'=>'DNS inválido'];
    }
    if (!function_exists('curl_init')) {
        cs_player_write_log('server_probe_curl_unavailable', ['host' => (string)(parse_url($url, PHP_URL_HOST) ?? '')], 'critical');
        return ['ok'=>false,'latency_ms'=>0,'http_code'=>0,'message'=>'cURL indisponível'];
    }

    $attempts = [];
    if ($providerMode !== 'm3u') {
        foreach (cs_player_api_endpoint_candidates() as $endpoint) {
            $target = rtrim($url,'/') . '/' . $endpoint . '?username=__csplayer_probe__&password=__csplayer_probe__';
            $r = cs_admin_probe_request($target, $timeout);
            $decoded = json_decode((string)$r['body'], true);
            $attempts[] = ['endpoint'=>'/'.$endpoint,'http_code'=>$r['http_code'],'latency_ms'=>$r['latency_ms'],'json'=>is_array($decoded),'remote_ip'=>$r['remote_ip'],'redirects'=>$r['redirects'],'response_bytes'=>$r['response_bytes'],'effective_host'=>(string)(parse_url($r['effective_url'],PHP_URL_HOST)??'')];
            // A API existe quando devolve JSON, mesmo que as credenciais de probe não autentiquem.
            if ($r['http_code'] >= 200 && $r['http_code'] < 400 && is_array($decoded)) {
                return ['ok'=>true,'provider'=>($providerMode==='xc'?'xc':'xtream'),'endpoint'=>'/'.$endpoint,'latency_ms'=>$r['latency_ms'],'http_code'=>$r['http_code'],'effective_url'=>$r['effective_url'],'message'=>($providerMode==='xc'?'API XC compatível':'Xtream').' detectado via '.$endpoint.'.'];
            }
        }
    }

    if (!in_array($providerMode, ['xtream','xc'], true)) {
        // O botão administrativo não possui usuário/senha do assinante. Portanto, aqui
        // validamos a existência da rota get.php. A autenticação e o #EXTM3U são
        // confirmados no login real do Web Player com as credenciais informadas.
        $target = rtrim($url,'/') . '/' . $m3uPath . '?' . http_build_query([
            'username'=>'__csplayer_probe__',
            'password'=>'__csplayer_probe__',
            'type'=>'m3u_plus',
            'output'=>$m3uOutput,
        ]);
        $r = cs_admin_probe_request($target, $timeout, 'IPTVSmartersPro');
        $trim = ltrim((string)$r['body'], "\xEF\xBB\xBF\r\n\t ");
        $isM3u = stripos(substr($trim, 0, 4096), '#EXTM3U') !== false;
        $routeExists = $r['http_code'] > 0 && $r['http_code'] !== 404;
        $attempts[] = ['endpoint'=>'/'.$m3uPath,'http_code'=>$r['http_code'],'latency_ms'=>$r['latency_ms'],'m3u'=>$isM3u,'remote_ip'=>$r['remote_ip'],'redirects'=>$r['redirects'],'response_bytes'=>$r['response_bytes'],'effective_host'=>(string)(parse_url($r['effective_url'],PHP_URL_HOST)??'')];
        if ($isM3u || $routeExists) {
            $msg = $isM3u
                ? 'M3U Plus respondeu corretamente.'
                : 'Rota M3U Plus encontrada; usuário e senha serão validados no login.';
            return ['ok'=>true,'provider'=>'m3u','endpoint'=>'/'.$m3uPath,'latency_ms'=>$r['latency_ms'],'http_code'=>$r['http_code'],'effective_url'=>$r['effective_url'],'message'=>$msg];
        }
    }

    // Diagnóstico separado da compatibilidade: um host pode estar online e ainda assim não expor a API no caminho esperado.
    $rootProbe = cs_admin_probe_request(rtrim($url,'/').'/', min($timeout,5), 'Mozilla/5.0 CSPlayer/1.4');
    $reachable = (int)$rootProbe['http_code'] > 0 || (int)$rootProbe['curl_errno'] === 0;
    $last = $attempts ? end($attempts) : ['http_code'=>0,'latency_ms'=>0,'endpoint'=>''];
    $code = (int)($last['http_code'] ?? 0);
    $message = $code === 404
        ? 'HTTP 404: nenhuma rota compatível foi encontrada neste domínio/porta.'
        : ($code > 0 ? 'Servidor respondeu HTTP '.$code.', mas não foi detectada API XC ou rota M3U compatível.' : 'Sem resposta; confirme DNS, porta pública e firewall.');
    cs_player_write_log('server_probe_failed', [
        'host'=>(string)(parse_url($url,PHP_URL_HOST)??''),
        'port'=>(int)(parse_url($url,PHP_URL_PORT)??0),
        'http_code'=>$code,
        'latency_ms'=>(int)($last['latency_ms']??0),
        'provider_mode'=>$providerMode,
        'attempts'=>$attempts,
        'reachable'=>$reachable,'remote_ip'=>$rootProbe['remote_ip'],'root_http_code'=>$rootProbe['http_code'],'message'=>$message,
    ], $code===404?'warning':'warning');
    if ($reachable && $code===404) $message='Servidor online, mas nenhuma rota XC/M3U foi detectada neste endereço. O login Smart tentará perfis HTTP compatíveis.';
    return ['ok'=>false,'reachable'=>$reachable,'status'=>$reachable?'online_no_route':'offline','latency_ms'=>(int)($last['latency_ms']??0),'http_code'=>$code,'remote_ip'=>$rootProbe['remote_ip'],'root_http_code'=>$rootProbe['http_code'],'message'=>$message,'attempts'=>$attempts];
}

if($_SERVER['REQUEST_METHOD']==='GET'){
    $cfg=cs_player_load_config();
    if(($_GET['action']??'')==='preflight'){
        $checks=[];
        $add=static function(string $key,bool $ok,string $label,string $detail='') use (&$checks): void {
            $checks[]=['key'=>$key,'ok'=>$ok,'label'=>$label,'detail'=>$detail];
        };
        $phpOk=version_compare(PHP_VERSION,'7.4.0','>=');
        $add('php',$phpOk,'PHP '.PHP_VERSION,$phpOk?'Compatível com CS Player (7.4–8.4) · '.PHP_SAPI:'PHP 7.4 ou superior é necessário.');
        $add('runtime',true,'Runtime do Web Player',basename((string)PHP_BINARY).' · '.PHP_SAPI);
        foreach(['curl','json','mbstring','mysqli'] as $ext){$add('ext_'.$ext,extension_loaded($ext),'Extensão '.$ext,extension_loaded($ext)?'Carregada.':'Ausente.');}
        $essential=[
            'bootstrap.php'=>__DIR__.'/player/bootstrap.php','dns_health.php'=>__DIR__.'/player/dns_health.php','api.php'=>__DIR__.'/player/api.php',
            'stream.php'=>__DIR__.'/player/stream.php','segment.php'=>__DIR__.'/player/segment.php','player.js'=>__DIR__.'/player/assets/player.js','player.css'=>__DIR__.'/player/assets/player.css'
        ];
        foreach($essential as $name=>$path){$add('file_'.$name,is_file($path)&&is_readable($path),$name,(is_file($path)&&is_readable($path))?'OK':'Ausente ou sem leitura.');}
        // Detecta rapidamente sintaxe/funções exclusivas do PHP 8 dentro do módulo player.
        $compatIssues=[];
        $compatPatterns=[
            '/\\bmatch\\s*\\(/'=>'match() PHP 8+',
            '/\\?->/'=>'nullsafe PHP 8+',
            '/\\bstr_(?:contains|starts_with|ends_with)\\s*\\(/'=>'função PHP 8+',
            '/^\\s*#\\[/m'=>'atributo PHP 8+',
        ];
        $pit=new RecursiveIteratorIterator(new RecursiveDirectoryIterator(__DIR__.'/player',FilesystemIterator::SKIP_DOTS));
        foreach($pit as $pf){if(!$pf->isFile()||strtolower($pf->getExtension())!=='php')continue;if($pf->getFilename()==='check_install.php')continue;$src=@file_get_contents($pf->getPathname());if(!is_string($src))continue;foreach($compatPatterns as $rx=>$label){if(preg_match($rx,$src)){$compatIssues[]=basename($pf->getPathname()).': '.$label;}}}
        $add('php74_compat',count($compatIssues)===0,'Compatibilidade PHP 7.4',count($compatIssues)===0?'Nenhuma construção PHP 8 exclusiva detectada.':implode(' · ',array_slice($compatIssues,0,4)));
        $cfgDirs=[dirname(CS_PLAYER_RUNTIME_CONFIG_FILE),dirname(CS_PLAYER_RUNTIME_CONFIG_FALLBACK_FILE),dirname(CS_PLAYER_RUNTIME_CONFIG_TMP_FILE)];
        $writeOk=false;$writeDetail=[];
        foreach($cfgDirs as $dir){$ok=is_dir($dir)?is_writable($dir):is_writable(dirname($dir));$writeOk=$writeOk||$ok;$writeDetail[]=basename($dir).':'.($ok?'gravável':'sem escrita');}
        $add('config_write',$writeOk,'Persistência do Web Player',implode(' · ',$writeDetail));
        $dns=cs_player_active_dns($cfg);$add('dns_count',count($dns)>0,'DNS ativos',count($dns).' DNS manual(is) ativo(s).');
        $proxyOk=empty($cfg['proxy_enabled']) || (is_file(__DIR__.'/player/proxy_lib.php')&&is_readable(__DIR__.'/player/proxy_lib.php'));
        $add('proxy',$proxyOk,'Proxy interno',empty($cfg['proxy_enabled'])?'Desativado.':($proxyOk?'Arquivos disponíveis.':'Arquivo do proxy ausente.'));
        $failed=count(array_filter($checks,static fn($c)=>empty($c['ok'])));
        cs_player_write_log('web_player_preflight', ['checks'=>count($checks),'failed'=>$failed,'dns_active'=>count($dns)], $failed?'warning':'info');
        out(['ok'=>$failed===0,'checks'=>$checks,'failed'=>$failed,'dns_active'=>count($dns),'config_location'=>basename(CS_PLAYER_RUNTIME_CONFIG_FILE)]);
    }

    if(($_GET['action']??'')==='test'){
        $url=cs_player_normalize_dns((string)($_GET['url']??''));
        if(!$url) out(['ok'=>false,'message'=>'DNS inválido'],400);
        out(cs_admin_probe_dns(
            $url,
            max(3,min(15,(int)($cfg['request_timeout']??8))),
            (string)($_GET['provider_mode']??'auto'),
            (string)($_GET['m3u_path']??'get.php'),
            (string)($_GET['m3u_output']??'mpegts')
        ));
    }
    if(($_GET['action']??'')==='dns_health'){
        $items=[]; foreach(cs_player_active_dns($cfg) as $row){$items[]=['id'=>(string)($row['id']??''),'name'=>(string)($row['name']??''),'url'=>(string)($row['url']??''),'health'=>cs_player_dns_health_public($row)];}
        out(['ok'=>true,'items'=>$items,'strategy'=>(string)($cfg['dns_strategy']??'smart')]);
    }
    if(($_GET['action']??'')==='catalog_search'){
        $q=trim((string)($_GET['q']??''));
        if(mb_strlen($q)<2) out(['ok'=>true,'items'=>[]]);
        $db=cs_player_db(); if(!$db) out(['ok'=>false,'message'=>'Banco indisponível'],503);
        $safe=$db->real_escape_string('%'.$q.'%'); $items=[];
        $rs=@$db->query("SELECT id,stream_display_name,stream_icon,type,category_id,movie_properties FROM streams WHERE type IN (1,2) AND stream_display_name LIKE '$safe' ORDER BY stream_display_name LIMIT 35");
        if($rs) while($r=$rs->fetch_assoc()){$props=json_decode((string)($r['movie_properties']??''),true);if(!is_array($props))$props=[];$items[]=['type'=>(int)$r['type']===1?'live':'movie','id'=>(int)$r['id'],'title'=>(string)$r['stream_display_name'],'image'=>(string)($r['stream_icon']?:($props['movie_image']??'')),'synopsis'=>(string)($props['plot']??$props['description']??'')];}
        $rs=@$db->query("SELECT id,title,cover,plot FROM series WHERE title LIKE '$safe' ORDER BY title LIMIT 35");
        if($rs) while($r=$rs->fetch_assoc())$items[]=['type'=>'series','id'=>(int)$r['id'],'title'=>(string)$r['title'],'image'=>(string)($r['cover']??''),'synopsis'=>(string)($r['plot']??'')];
        out(['ok'=>true,'items'=>array_slice($items,0,60)]);
    }
    out([
        'ok'=>true,
        'config'=>$cfg,
        'player_url'=>'player/',
        'player_public_path'=>'/player/',
        'document_root_hint'=>$_SERVER['DOCUMENT_ROOT']??'',
    ]);
}
if($_SERVER['REQUEST_METHOD']!=='POST')out(['ok'=>false],405);
$raw=json_decode((string)file_get_contents('php://input'),true);
if(!is_array($raw))out(['ok'=>false,'message'=>'JSON inválido'],400);
$cfg=cs_player_default_config();
foreach(['enabled','smart_login','dns_failover','pip_enabled','autoplay_next','remember_position','hero_autoplay','proxy_enabled','proxy_hls','proxy_vod','proxy_cast','proxy_log_enabled'] as $k)$cfg[$k]=!empty($raw[$k]);
// Compatibilidade universal: Auto sempre pode cair para M3U Plus após as APIs Xtream.
$cfg['provider_auto_fallback_m3u']=true;
foreach(['brand','login_title','login_subtitle','home_title'] as $k)$cfg[$k]=mb_substr(trim((string)($raw[$k]??$cfg[$k])),0,160);
$cfg['hls_retries']=max(1,min(10,(int)($raw['hls_retries']??4)));
$cfg['stall_timeout']=max(5,min(60,(int)($raw['stall_timeout']??12)));
$cfg['request_timeout']=max(3,min(30,(int)($raw['request_timeout']??8)));
$cfg['dns_strategy']=in_array((string)($raw['dns_strategy']??'smart'),['smart','priority'],true)?(string)$raw['dns_strategy']:'smart';
$cfg['dns_fail_threshold']=max(1,min(5,(int)($raw['dns_fail_threshold']??2)));
$cfg['dns_cooldown']=max(15,min(600,(int)($raw['dns_cooldown']??90)));
$cfg['dns_prefer_last']=!array_key_exists('dns_prefer_last',$raw)||!empty($raw['dns_prefer_last']);
$cfg['m3u_cache_ttl']=max(300,min(86400,(int)($raw['m3u_cache_ttl']??1800)));
$cfg['m3u_user_agent']=mb_substr(trim((string)($raw['m3u_user_agent']??'IPTVSmartersPro')),0,120);
$cfg['hero_interval']=max(4,min(30,(int)($raw['hero_interval']??8)));
$cfg['hero_order']=in_array(($raw['hero_order']??'manual'),['manual','random'],true)?(string)$raw['hero_order']:'manual';
$cfg['proxy_retries']=max(0,min(5,(int)($raw['proxy_retries']??2)));
$cfg['proxy_connect_timeout']=max(2,min(20,(int)($raw['proxy_connect_timeout']??6)));
$cfg['proxy_read_timeout']=max(10,min(120,(int)($raw['proxy_read_timeout']??30)));
$cfg['proxy_manifest_cache']=max(0,min(15,(int)($raw['proxy_manifest_cache']??2)));
if (!$cfg['proxy_enabled']) { $cfg['proxy_hls']=false; $cfg['proxy_vod']=false; $cfg['proxy_cast']=false; }
$cfg['manual_highlights']=[];
foreach(array_slice(is_array($raw['manual_highlights']??null)?$raw['manual_highlights']:[],0,100) as $i=>$row){
    if(!is_array($row))continue; $type=(string)($row['type']??''); $id=(int)($row['id']??0);
    if(!$id||!in_array($type,['live','movie','series'],true))continue;
    $cfg['manual_highlights'][]=['type'=>$type,'id'=>$id,'title'=>mb_substr(trim((string)($row['title']??'')),0,180),'custom_image'=>mb_substr(trim((string)($row['custom_image']??'')),0,1000),'custom_synopsis'=>mb_substr(trim((string)($row['custom_synopsis']??'')),0,2000),'enabled'=>!array_key_exists('enabled',$row)||!empty($row['enabled']),'sort'=>max(1,min(999,(int)($row['sort']??($i+1))))];
}
usort($cfg['manual_highlights'],static fn($a,$b)=>(int)$a['sort']<=>(int)$b['sort']);
$cfg['dns']=[];
foreach(($raw['dns']??[]) as $i=>$row){
    if(!is_array($row))continue;
    $url=cs_player_normalize_dns((string)($row['url']??''));
    if(!$url)continue;
    $cfg['dns'][]=[
        'id'=>(string)($row['id']??('manual_'.($i+1))),
        'name'=>mb_substr(trim((string)($row['name']??('DNS Manual '.($i+1)))),0,80),
        'url'=>$url,
        'enabled'=>!empty($row['enabled']),
        'priority'=>max(1,min(999,(int)($row['priority']??($i+1)))),
        'fixed'=>false,
        'source'=>'manual',
        'provider_mode'=>in_array(strtolower((string)($row['provider_mode']??'auto')),['auto','xc','smart','xtream','m3u'],true)?strtolower((string)$row['provider_mode']):'auto',
        'm3u_output'=>in_array(strtolower((string)($row['m3u_output']??'mpegts')),['mpegts','hls'],true)?strtolower((string)$row['m3u_output']):'mpegts',
        'm3u_path'=>mb_substr(trim((string)($row['m3u_path']??'get.php')),0,160),
        'user_agent'=>mb_substr(trim((string)($row['user_agent']??'')),0,120),
        'http_profile'=>in_array(strtolower((string)($row['http_profile']??'auto')),['auto','smarters','xciptv','vlc','browser'],true)?strtolower((string)$row['http_profile']):'auto',
        'ip_mode'=>in_array(strtolower((string)($row['ip_mode']??'auto')),['auto','ipv4','ipv6'],true)?strtolower((string)$row['ip_mode']):'auto',
    ];
}
if(!cs_player_save_config($cfg))out(['ok'=>false,'message'=>'Não foi possível salvar a configuração persistente do Web Player.'],500);
cs_player_write_log('web_player_config_saved', ['dns_mode'=>'manual_only', 'manual_dns_count'=>count($cfg['dns']), 'enabled_manual_dns'=>count(array_filter($cfg['dns'], static fn($r)=>!empty($r['enabled']))), 'highlights'=>count($cfg['manual_highlights'])], 'info');
out(['ok'=>true,'message'=>'Configurações do Web Player salvas. Somente DNS manuais ativos serão utilizados.','config'=>$cfg]);

<?php
// CS Player - verificador de instalação compatível com PHP 7.4 a 8.4.
// Quando existir o PHP interno legado do servidor, ele é usado como referência de lint,
// mesmo que este script tenha sido iniciado pelo PHP do Ubuntu.

if (version_compare(PHP_VERSION, '7.4.0', '<')) {
    fwrite(STDERR, "PHP 7.4 ou superior e necessario para o Web Player.\n");
    exit(2);
}
if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Execute somente via CLI.\n");
    exit(2);
}

$root = dirname(__DIR__, 2);
$internalPhp = $root . '/php/bin/php';
$lintPhp = (is_file($internalPhp) && is_executable($internalPhp)) ? $internalPhp : PHP_BINARY;
$lintVersion = '';
$versionOut = [];
$versionCode = 0;
@exec(escapeshellarg($lintPhp) . ' -r ' . escapeshellarg('echo PHP_VERSION;') . ' 2>&1', $versionOut, $versionCode);
if ($versionCode === 0 && !empty($versionOut)) {
    $lintVersion = trim(implode('', $versionOut));
}
if ($lintVersion === '') {
    $lintVersion = PHP_VERSION;
}

$files = [];
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($it as $f) {
    if ($f->isFile() && strtolower($f->getExtension()) === 'php') {
        $files[] = $f->getPathname();
    }
}
sort($files);

$failed = 0;
$compatWarnings = 0;
echo "CS PLAYER - verificacao de instalacao\n";
echo "PHP do comando: " . PHP_VERSION . "\n";
echo "PHP usado no lint: " . $lintVersion . " (" . $lintPhp . ")\n";

foreach ($files as $f) {
    $out = [];
    $code = 0;
    $cmd = escapeshellarg($lintPhp) . ' -l ' . escapeshellarg($f) . ' 2>&1';
    @exec($cmd, $out, $code);
    if ($code !== 0) {
        $failed++;
        echo "FALHA: $f\n" . implode("\n", $out) . "\n";
    }
}

// Varredura adicional: construções que quebram no PHP 7.4 mesmo quando o lint
// foi executado acidentalmente por um PHP mais novo.
$playerDir = $root . '/admin/player';
$compatPatterns = [
    '/\\bmatch\\s*\\(/' => 'match() exige PHP 8+',
    '/\\?->/' => 'operador nullsafe exige PHP 8+',
    '/\\bstr_(?:contains|starts_with|ends_with)\\s*\\(/' => 'função nativa exige PHP 8+',
    '/^\\s*#\\[/' => 'atributos exigem PHP 8+',
    '/\\benum\\s+[A-Za-z_]/' => 'enum exige PHP 8.1+',
    '/\\breadonly\\s+(?:class|[A-Za-z_$])/' => 'readonly exige PHP 8.1+',
];
if (is_dir($playerDir)) {
    $pit = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($playerDir, FilesystemIterator::SKIP_DOTS));
    foreach ($pit as $f) {
        if (!$f->isFile() || strtolower($f->getExtension()) !== 'php') continue;
        if ($f->getFilename() === 'check_install.php') continue; // contém os próprios padrões como texto
        $src = @file_get_contents($f->getPathname());
        if (!is_string($src)) continue;
        foreach ($compatPatterns as $rx => $label) {
            if (preg_match($rx, $src)) {
                $compatWarnings++;
                echo "COMPAT PHP 7.4: " . $f->getPathname() . " - " . $label . "\n";
            }
        }
    }
}


// Arquivos de integração do Web Player fora de admin/player também precisam respeitar PHP 7.4.
$extraCompatFiles = [
    $root . '/admin/player_admin_api.php',
    $root . '/admin/settings.php',
];
foreach ($extraCompatFiles as $extraFile) {
    if (!is_file($extraFile)) continue;
    $src = @file_get_contents($extraFile);
    if (!is_string($src)) continue;
    foreach ($compatPatterns as $rx => $label) {
        if (preg_match($rx, $src)) {
            $compatWarnings++;
            echo "COMPAT PHP 7.4: " . $extraFile . " - " . $label . "\n";
        }
    }
}

$bootstrap = $root . '/admin/player/bootstrap.php';
$marker = 'CS_PLAYER_WEBPLAYER_BOOTSTRAP_VERSION: 6.6.0-professional-stable';
$bootstrapOk = false;
if (is_file($bootstrap)) {
    $head = @file_get_contents($bootstrap, false, null, 0, 512);
    $bootstrapOk = is_string($head) && strpos($head, $marker) !== false;
}
echo "Bootstrap esperado: 6.6.0-professional-stable\n";
echo "Bootstrap instalado: " . ($bootstrapOk ? 'OK' : 'DIFERENTE/ANTIGO') . "\n";
echo "Arquivos PHP: " . count($files) . " | Falhas: $failed | Alertas compat PHP 7.4: $compatWarnings\n";
exit(($failed || $compatWarnings || !$bootstrapOk) ? 1 : 0);

# CS PLAYER v6.1.4 — Web Player Local API Fix

## Diagnóstico confirmado pelos logs de 19/08/2026

O teste de portas funcionou corretamente e consultou 80, 443 e 25500. Todas responderam que `/player_api.php` não existe ou não fornece uma API Xtream válida. Portanto, a falha não era mais de DNS/porta: o Web Player dependia de um endpoint Xtream público ausente no próprio painel.

## Correção aplicada

- Servidor interno do CS Player autentica diretamente na tabela `users`.
- Valida `enabled`, `admin_enabled` e `exp_date`.
- Respeita os bouquets vinculados ao cliente.
- Carrega categorias locais de `stream_categories`.
- Carrega canais/filmes de `streams`.
- Carrega séries de `series` e episódios de `series_episodes`.
- Reprodução do servidor interno usa `streams.stream_source` diretamente.
- Não depende de `/player_api.php`, `/live/...`, `/movie/...` ou `/series/...` no servidor interno.
- DNS externos continuam usando `/player_api.php` normalmente.
- Nenhuma tabela, coluna ou ID foi alterado.
- Logs adicionais: `local_auth_selected`, `local_stream_source_unavailable`, `local_stream_origin_failed`.

## Resultado esperado

Ao entrar no Web Player com um cliente válido do próprio CS Player, o log deve registrar `local_auth_selected` e o usuário deve acessar somente o catálogo permitido pelos seus bouquets. O erro 404 de `/player_api.php` deixa de bloquear o login local.

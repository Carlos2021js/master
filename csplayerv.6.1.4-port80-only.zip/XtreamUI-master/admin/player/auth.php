<?php
require __DIR__ . '/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
$cfg = cs_player_load_config();
$username = trim((string)($_POST['username'] ?? ''));
$password = (string)($_POST['password'] ?? '');
if ($username === '' || $password === '') { $_SESSION['cs_player_error'] = 'Informe usuário e senha.'; header('Location: index.php'); exit; }
// O login usa exclusivamente a lista automática sincronizada com streaming_servers.
// Valores manuais de sessões antigas são ignorados e removidos abaixo.
$dnsList = cs_player_session_dns_list($cfg, '', false);
if (!$dnsList) { $_SESSION['cs_player_error'] = 'Nenhum servidor ativo foi sincronizado. Verifique o status dos servidores no painel.'; header('Location: index.php'); exit; }
    $authenticated = cs_player_authenticate_dns($dnsList, $username, $password);
    if (is_array($authenticated) && isset($authenticated['row'], $authenticated['data'])) {
        $row = $authenticated['row'];
        $data = $authenticated['data'];
        session_regenerate_id(true);
        $_SESSION['cs_player_auth'] = true;
        $_SESSION['cs_player_username'] = $username;
        $_SESSION['cs_player_password'] = $password;
        $_SESSION['cs_player_dns_index'] = (string)$row['_index'];
        $_SESSION['cs_player_dns_name'] = (string)($row['name'] ?? 'Servidor');
        $_SESSION['cs_player_dns_url'] = (string)($row['url'] ?? '');
        $_SESSION['cs_player_local_api'] = !empty($authenticated['local_api']) || !empty($row['local_api']);
        unset($_SESSION['cs_player_manual_dns'], $_SESSION['cs_player_manual_only']);
        $_SESSION['cs_player_user_info'] = $data['user_info'] ?? [];
        header('Location: home.php'); exit;
    }

$diagnostics = is_array($authenticated['diagnostics'] ?? null) ? $authenticated['diagnostics'] : [];
cs_player_write_log('web_player_auth_failed', [
    'username_hash' => substr(hash('sha256', $username), 0, 12),
    'dns_count' => count($dnsList),
    'manual_dns' => '',
    'diagnostics' => $diagnostics,
], 'warning');
$codes = array_values(array_filter(array_map(static fn($item) => (int)($item['http_code'] ?? 0), $diagnostics)));
if (in_array(500, $codes, true)) {
    $_SESSION['cs_player_error'] = 'O servidor sincronizado respondeu HTTP 500 durante a autenticação. Verifique o serviço Xtream e o endpoint player_api.php no servidor.';
} elseif (in_array(404, $codes, true)) {
    $_SESSION['cs_player_error'] = 'O servidor sincronizado não encontrou o endpoint player_api.php (HTTP 404). Verifique a porta HTTP de transmissão em Servidores.';
} elseif ($codes) {
    $_SESSION['cs_player_error'] = 'Os servidores sincronizados não aceitaram a requisição de autenticação. Código HTTP: ' . implode(', ', $codes) . '.';
} else {
    $_SESSION['cs_player_error'] = 'Usuário não localizado nos DNS ativos ou assinatura sem acesso.';
}
header('Location: index.php');

<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('CSPLAYER_WEB');
    session_start();
}

define('CS_PLAYER_ROOT', __DIR__);
if (!defined('CS_PLAYER_INTERNAL')) { define('CS_PLAYER_INTERNAL', true); }
define('CS_PLAYER_SHARED_STORAGE', CS_PLAYER_ROOT . '/storage');
define('CS_PLAYER_CONFIG_FILE', CS_PLAYER_SHARED_STORAGE . '/config.php');

if (!function_exists('cs_player_write_log')) {
    function cs_player_log_path(): string {
        return dirname(__DIR__) . '/logs/cs-player/web-player.log';
    }

    function cs_player_write_log(string $event, array $context = [], string $level = 'error'): bool {
        $path = cs_player_log_path();
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $safe = [];
        foreach ($context as $key => $value) {
            $key = preg_replace('/[^a-zA-Z0-9_.-]/', '_', (string)$key);
            if (preg_match('/pass|password|token|secret|api[_-]?key/i', $key)) {
                $safe[$key] = '[REDACTED]';
            } elseif (is_scalar($value) || $value === null) {
                $safe[$key] = $value;
            } else {
                $safe[$key] = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }
        }
        $line = json_encode([
            'time' => date('c'),
            'level' => strtolower($level),
            'event' => (string)$event,
            'request_id' => substr(hash('sha256', session_id() . '|' . microtime(true) . '|' . random_int(0, PHP_INT_MAX)), 0, 12),
            'context' => $safe,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($line) && @file_put_contents($path, $line . PHP_EOL, FILE_APPEND | LOCK_EX) !== false;
    }
}

define('CS_PLAYER_LEGACY_CONFIG_FILE', CS_PLAYER_SHARED_STORAGE . '/config.json');

function cs_player_default_config(): array {
    return [
        'enabled' => true,
        'brand' => 'CS Player',
        'login_title' => 'CS Player',
        'login_subtitle' => 'Entre com sua assinatura para continuar',
        'home_title' => 'Início',
        'smart_login' => true,
        'dns_failover' => true,
        'pip_enabled' => true,
        'autoplay_next' => false,
        'remember_position' => true,
        'hls_retries' => 4,
        'stall_timeout' => 12,
        'request_timeout' => 8,
        'dns' => [],
    ];
}

function cs_player_load_config(): array {
    $default = cs_player_default_config();
    $data = null;

    if (is_file(CS_PLAYER_CONFIG_FILE)) {
        $loaded = include CS_PLAYER_CONFIG_FILE;
        if (is_array($loaded)) {
            $data = $loaded;
        }
    } elseif (is_file(CS_PLAYER_LEGACY_CONFIG_FILE)) {
        $raw = file_get_contents(CS_PLAYER_LEGACY_CONFIG_FILE);
        $legacy = json_decode((string)$raw, true);
        if (is_array($legacy)) {
            $data = $legacy;
            // Migração transparente: preserva a configuração existente sem banco de dados.
            if (cs_player_save_config($legacy)) {
                @unlink(CS_PLAYER_LEGACY_CONFIG_FILE);
            }
        }
    }

    if (!is_array($data)) {
        return $default;
    }
    $cfg = array_replace($default, $data);
    $cfg['dns'] = is_array($cfg['dns'] ?? null) ? array_values($cfg['dns']) : [];
    return $cfg;
}

function cs_player_save_config(array $config): bool {
    $dir = dirname(CS_PLAYER_CONFIG_FILE);
    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
        return false;
    }
    $tmp = CS_PLAYER_CONFIG_FILE . '.tmp';
    $php = "<?php\nif (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }\nreturn " . var_export($config, true) . ";\n";
    if (file_put_contents($tmp, $php, LOCK_EX) === false) {
        return false;
    }
    @chmod($tmp, 0640);
    if (!rename($tmp, CS_PLAYER_CONFIG_FILE)) {
        @unlink($tmp);
        return false;
    }
    @chmod(CS_PLAYER_CONFIG_FILE, 0640);
    return true;
}

function cs_player_normalize_dns(string $url): string {
    $url = trim($url);
    if ($url === '') return '';
    if (!preg_match('~^https?://~i', $url)) {
        // IPv6 sem colchetes é ambíguo para parse_url; trate-o como host puro.
        if (substr_count($url, ':') >= 2 && strpos($url, '/') === false && $url[0] !== '[') {
            $url = 'http://[' . trim($url, '[]') . ']';
        } else {
            $url = 'http://' . $url;
        }
    }
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) return '';
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    if (!in_array($scheme, ['http', 'https'], true)) return '';
    $host = strtolower(trim((string)$parts['host']));
    if ($host === '') return '';
    if (strpos($host, ':') !== false && $host[0] !== '[') $host = '[' . $host . ']';
    $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
    $path = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
    $path = preg_replace('~/player_api\\.php$~i', '', $path) ?? $path;
    return $scheme . '://' . $host . $port . rtrim($path, '/');
}

function cs_player_with_port(string $url, int $port): string {
    $url = cs_player_normalize_dns($url);
    if ($url === '' || $port < 1 || $port > 65535) return $url;
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['host']) || isset($parts['port'])) return $url;
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    $host = (string)$parts['host'];
    $path = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
    return $scheme . '://' . $host . ':' . $port . $path;
}

function cs_player_build_server_url(array $server): string {
    // Regra do CS PLAYER: o servidor interno principal conecta exclusivamente
    // por HTTP na porta 80. Portas/protocolos alternativos são permitidos
    // apenas para DNS externos cadastrados manualmente pelo administrador.
    $domain = trim((string)($server['domain_name'] ?? ''));
    $ip = trim((string)($server['server_ip'] ?? ''));
    $source = $domain !== '' ? $domain : $ip;
    if ($source === '') return '';

    $candidate = cs_player_normalize_dns($source);
    if ($candidate === '') return '';
    $parts = parse_url($candidate);
    if (!is_array($parts) || empty($parts['host'])) return '';

    $host = (string)$parts['host'];
    if (strpos($host, ':') !== false && $host[0] !== '[') $host = '[' . $host . ']';
    return 'http://' . $host . ':80';
}

function cs_player_server_url_candidates(array $server): array {
    $url = cs_player_build_server_url($server);
    return $url === '' ? [] : [$url];
}

function cs_player_server_dns_from_rows(array $servers): array {
    $out = [];
    foreach ($servers as $server) {
        if (!is_array($server)) continue;
        if (isset($server['status']) && (int)$server['status'] !== 1) continue;
        $candidates = cs_player_server_url_candidates($server);
        $url = $candidates[0] ?? '';
        if ($url === '') continue;
        $id = (int)($server['id'] ?? 0);
        $httpPort = 80;
        $httpsPort = 0;
        $name = trim((string)($server['server_name'] ?? ''));
        if ($name === '') $name = $id > 0 ? 'Servidor #' . $id : 'Servidor CS Player';
        $out[] = [
            'id' => 'server_' . ($id > 0 ? $id : substr(sha1($url), 0, 8)),
            'server_id' => $id,
            'name' => $name,
            'url' => $url,
            'fallback_urls' => $candidates,
            'http_port' => $httpPort,
            'https_port' => $httpsPort,
            'enabled' => true,
            'priority' => max(1, $id > 0 ? $id : count($out) + 1),
            'fixed' => true,
            'source' => 'streaming_servers',
        ];
    }
    return $out;
}

function cs_player_decode_main_config(string $path): ?array {
    if (!is_file($path)) return null;
    $raw = file_get_contents($path);
    if (!is_string($raw) || $raw === '') return null;
    $decoded = base64_decode($raw, true);
    if ($decoded === false) return null;
    $key = '5709650b0d7806074842c6de575025b1';
    $out = '';
    $keyLen = strlen($key);
    for ($i = 0, $len = strlen($decoded); $i < $len; $i++) {
        $out .= chr(ord($decoded[$i]) ^ ord($key[$i % $keyLen]));
    }
    $data = json_decode($out, true);
    return is_array($data) ? $data : null;
}


function cs_player_db(): ?mysqli {
    static $db = null;
    static $failed = false;
    if ($db instanceof mysqli) return $db;
    if ($failed || !class_exists('mysqli')) return null;
    $info = cs_player_decode_main_config('/home/xtreamcodes/iptv_xtream_codes/config');
    if (!is_array($info)) { $failed = true; return null; }
    mysqli_report(MYSQLI_REPORT_OFF);
    $conn = @new mysqli(
        (string)($info['host'] ?? 'localhost'),
        (string)($info['db_user'] ?? 'root'),
        (string)($info['db_pass'] ?? ''),
        (string)($info['db_name'] ?? 'xtream_iptvpro'),
        (int)($info['db_port'] ?? 3306)
    );
    if ($conn->connect_errno) { $failed = true; return null; }
    $conn->set_charset('utf8mb4');
    $db = $conn;
    return $db;
}

function cs_player_local_user(string $username, string $password): ?array {
    $db = cs_player_db();
    if (!$db) return null;
    $stmt = $db->prepare('SELECT * FROM `users` WHERE `username`=? AND `password`=? LIMIT 1');
    if (!$stmt) return null;
    $stmt->bind_param('ss', $username, $password);
    if (!$stmt->execute()) { $stmt->close(); return null; }
    $res = $stmt->get_result();
    $user = $res ? $res->fetch_assoc() : null;
    $stmt->close();
    if (!is_array($user)) return null;
    $now = time();
    if (isset($user['enabled']) && (int)$user['enabled'] !== 1) return null;
    if (isset($user['admin_enabled']) && (int)$user['admin_enabled'] !== 1) return null;
    if (!empty($user['exp_date']) && (int)$user['exp_date'] > 0 && (int)$user['exp_date'] < $now) return null;
    return $user;
}

function cs_player_json_ids($value): array {
    if (is_array($value)) $items = $value;
    else {
        $items = json_decode((string)$value, true);
        if (!is_array($items)) $items = [];
    }
    $out = [];
    foreach ($items as $id) { $id=(int)$id; if ($id>0) $out[$id]=$id; }
    return array_values($out);
}

function cs_player_local_permissions(array $user): array {
    $db = cs_player_db();
    $channels=[]; $series=[];
    $bouquets = cs_player_json_ids($user['bouquet'] ?? '[]');
    if (!$db || !$bouquets) return ['channels'=>[], 'series'=>[]];
    $in = implode(',', array_map('intval', $bouquets));
    $res = @$db->query("SELECT `bouquet_channels`,`bouquet_series` FROM `bouquets` WHERE `id` IN ($in)");
    if ($res) while ($row=$res->fetch_assoc()) {
        foreach (cs_player_json_ids($row['bouquet_channels'] ?? '[]') as $id) $channels[$id]=$id;
        foreach (cs_player_json_ids($row['bouquet_series'] ?? '[]') as $id) $series[$id]=$id;
    }
    return ['channels'=>array_values($channels), 'series'=>array_values($series)];
}

function cs_player_local_auth_response(array $user): array {
    $active = isset($user['active_cons']) ? (int)$user['active_cons'] : 0;
    return [
        'user_info'=>[
            'username'=>(string)($user['username']??''), 'auth'=>1,
            'status'=>'Active', 'exp_date'=>(string)($user['exp_date']??''),
            'is_trial'=>(string)($user['is_trial']??'0'),
            'active_cons'=>$active, 'created_at'=>(string)($user['created_at']??''),
            'max_connections'=>(string)($user['max_connections']??'1'),
            'allowed_output_formats'=>['m3u8','ts','rtmp']
        ],
        'server_info'=>[
            'url'=>(string)($_SERVER['HTTP_HOST']??''),
            'port'=>(string)($_SERVER['SERVER_PORT']??''),
            'https_port'=>'', 'server_protocol'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http',
            'timezone'=>date_default_timezone_get(), 'timestamp_now'=>time(), 'time_now'=>date('Y-m-d H:i:s')
        ]
    ];
}

function cs_player_local_categories(string $type, array $perms): array {
    $db=cs_player_db(); if(!$db) return [];
    $ids=[];
    if ($type==='series') {
        $series=$perms['series']??[]; if(!$series) return [];
        $in=implode(',',array_map('intval',$series));
        $res=@$db->query("SELECT DISTINCT sc.id,sc.category_name FROM series s JOIN stream_categories sc ON sc.id=s.category_id WHERE s.id IN ($in) AND sc.category_type='series' ORDER BY sc.cat_order,sc.category_name");
    } else {
        $channels=$perms['channels']??[]; if(!$channels) return [];
        $streamType=$type==='movie'?2:1; $catType=$type==='movie'?'movie':'live';
        $in=implode(',',array_map('intval',$channels));
        $res=@$db->query("SELECT DISTINCT sc.id,sc.category_name FROM streams s JOIN stream_categories sc ON sc.id=s.category_id WHERE s.id IN ($in) AND s.type=$streamType AND sc.category_type='$catType' ORDER BY sc.cat_order,sc.category_name");
    }
    if(!$res) return [];
    while($r=$res->fetch_assoc()) $ids[]=['category_id'=>(string)$r['id'],'category_name'=>(string)$r['category_name'],'parent_id'=>0];
    return $ids;
}

function cs_player_local_streams(string $type, array $perms, ?int $categoryId=null): array {
    $db=cs_player_db(); if(!$db) return [];
    $ids=$perms['channels']??[]; if(!$ids) return [];
    $streamType=$type==='movie'?2:1; $in=implode(',',array_map('intval',$ids));
    $where="s.id IN ($in) AND s.type=$streamType";
    if($categoryId && $categoryId>0) $where.=' AND s.category_id='.(int)$categoryId;
    $res=@$db->query("SELECT s.* FROM streams s WHERE $where ORDER BY s.stream_display_name ASC LIMIT 5000");
    if(!$res) return [];
    $out=[]; $num=0;
    while($r=$res->fetch_assoc()) {
        $props=json_decode((string)($r['movie_properties']??''),true); if(!is_array($props))$props=[];
        $ext=(string)($r['target_container']??($props['container_extension']??($type==='movie'?'mp4':'m3u8')));
        $icon=(string)($r['stream_icon']??($props['movie_image']??($props['cover_big']??'')));
        $item=['num'=>++$num,'name'=>(string)($r['stream_display_name']??''),'stream_type'=>$type==='movie'?'movie':'live','stream_id'=>(int)$r['id'],'stream_icon'=>$icon,'epg_channel_id'=>(string)($r['epg_id']??''),'added'=>(string)($r['added']??''),'category_id'=>(string)($r['category_id']??''),'custom_sid'=>(string)($r['custom_sid']??''),'tv_archive'=>(int)($r['tv_archive_duration']??0)>0?1:0,'direct_source'=>'','tv_archive_duration'=>(int)($r['tv_archive_duration']??0)];
        if($type==='movie'){$item['container_extension']=$ext;$item['rating']=(string)($props['rating']??'');$item['rating_5based']=$props['rating_5based']??0;}
        $out[]=$item;
    }
    return $out;
}

function cs_player_local_series(array $perms, ?int $categoryId=null): array {
    $db=cs_player_db(); if(!$db) return [];
    $ids=$perms['series']??[]; if(!$ids)return[]; $in=implode(',',array_map('intval',$ids));
    $where="id IN ($in)"; if($categoryId&&$categoryId>0)$where.=' AND category_id='.(int)$categoryId;
    $res=@$db->query("SELECT * FROM series WHERE $where ORDER BY title ASC LIMIT 5000"); if(!$res)return[];
    $out=[];$n=0; while($r=$res->fetch_assoc()){$out[]=['num'=>++$n,'name'=>(string)($r['title']??''),'series_id'=>(int)$r['id'],'cover'=>(string)($r['cover']??''),'plot'=>(string)($r['plot']??''),'cast'=>(string)($r['cast']??''),'director'=>(string)($r['director']??''),'genre'=>(string)($r['genre']??''),'releaseDate'=>(string)($r['releaseDate']??($r['release_date']??'')),'last_modified'=>(string)($r['last_modified']??''),'rating'=>(string)($r['rating']??''),'rating_5based'=>$r['rating_5based']??0,'backdrop_path'=>json_decode((string)($r['backdrop_path']??'[]'),true)?:[],'youtube_trailer'=>(string)($r['youtube_trailer']??''),'episode_run_time'=>(string)($r['episode_run_time']??''),'category_id'=>(string)($r['category_id']??'')];}
    return$out;
}

function cs_player_local_series_info(int $seriesId, array $perms): ?array {
    if(!in_array($seriesId,$perms['series']??[],true))return null; $db=cs_player_db(); if(!$db)return null;
    $res=@$db->query('SELECT * FROM series WHERE id='.(int)$seriesId.' LIMIT 1'); $series=$res?$res->fetch_assoc():null; if(!$series)return null;
    $eps=[];$seasons=[]; $q=@$db->query("SELECT se.*,s.stream_display_name,s.target_container,s.stream_icon,s.added FROM series_episodes se JOIN streams s ON s.id=se.stream_id WHERE se.series_id=".(int)$seriesId." ORDER BY se.season_num,se.sort");
    if($q) while($r=$q->fetch_assoc()){$season=(int)($r['season_num']??0);$eid=(int)($r['stream_id']??0);$eps[(string)$season][]=['id'=>$eid,'episode_num'=>(int)($r['sort']??0),'title'=>(string)($r['stream_display_name']??''),'container_extension'=>(string)($r['target_container']??'mp4'),'info'=>['movie_image'=>(string)($r['stream_icon']??'')],'added'=>(string)($r['added']??''),'season'=>$season,'direct_source'=>'']; if(!isset($seasons[$season]))$seasons[$season]=['air_date'=>'','episode_count'=>0,'id'=>$season,'name'=>'Temporada '.$season,'overview'=>'','season_number'=>$season,'cover'=>(string)($series['cover']??'')];$seasons[$season]['episode_count']++;}
    return ['seasons'=>array_values($seasons),'info'=>['name'=>(string)($series['title']??''),'cover'=>(string)($series['cover']??''),'plot'=>(string)($series['plot']??''),'cast'=>(string)($series['cast']??''),'director'=>(string)($series['director']??''),'genre'=>(string)($series['genre']??''),'releaseDate'=>(string)($series['releaseDate']??($series['release_date']??'')),'rating'=>(string)($series['rating']??'')],'episodes'=>$eps];
}

function cs_player_local_api(string $username,string $password,string $action='',array $extra=[]): ?array {
    $user=cs_player_local_user($username,$password); if(!$user)return null;
    if($action==='')return cs_player_local_auth_response($user);
    $perms=cs_player_local_permissions($user); $cat=isset($extra['category_id'])?(int)$extra['category_id']:null;
    if($action==='get_live_categories')return cs_player_local_categories('live',$perms);
    if($action==='get_vod_categories')return cs_player_local_categories('movie',$perms);
    if($action==='get_series_categories')return cs_player_local_categories('series',$perms);
    if($action==='get_live_streams')return cs_player_local_streams('live',$perms,$cat);
    if($action==='get_vod_streams')return cs_player_local_streams('movie',$perms,$cat);
    if($action==='get_series')return cs_player_local_series($perms,$cat);
    if($action==='get_series_info')return cs_player_local_series_info((int)($extra['series_id']??0),$perms);
    return [];
}

function cs_player_local_stream_source(int $streamId,string $username,string $password): ?string {
    $user=cs_player_local_user($username,$password); if(!$user)return null; $perms=cs_player_local_permissions($user);
    $db=cs_player_db(); if(!$db)return null;
    $allowed=in_array($streamId,$perms['channels']??[],true);
    if(!$allowed){$q=@$db->query('SELECT series_id FROM series_episodes WHERE stream_id='.(int)$streamId.' LIMIT 1');$e=$q?$q->fetch_assoc():null;$allowed=$e&&in_array((int)$e['series_id'],$perms['series']??[],true);}
    if(!$allowed)return null;
    $q=@$db->query('SELECT stream_source FROM streams WHERE id='.(int)$streamId.' LIMIT 1');$r=$q?$q->fetch_assoc():null;if(!$r)return null;
    $src=json_decode((string)($r['stream_source']??''),true); if(is_array($src)){foreach($src as $u){if(is_string($u)&&preg_match('~^https?://~i',$u))return $u;}}
    $raw=trim((string)($r['stream_source']??'')); return preg_match('~^https?://~i',$raw)?$raw:null;
}

function cs_player_internal_server_dns(): array {
    static $cache = null;
    if (is_array($cache)) return $cache;
    $cache = [];

    $cfgPath = '/home/xtreamcodes/iptv_xtream_codes/config';
    $info = cs_player_decode_main_config($cfgPath);
    if (!is_array($info)) return $cache;
    if (!class_exists('mysqli')) return $cache;

    mysqli_report(MYSQLI_REPORT_OFF);
    $db = @new mysqli(
        (string)($info['host'] ?? 'localhost'),
        (string)($info['db_user'] ?? 'root'),
        (string)($info['db_pass'] ?? ''),
        (string)($info['db_name'] ?? 'xtream_iptvpro'),
        (int)($info['db_port'] ?? 3306)
    );
    if ($db->connect_errno) return $cache;
    $db->set_charset('utf8mb4');
    $result = @$db->query("SELECT `id`,`server_name`,`domain_name`,`server_ip`,`http_broadcast_port`,`https_broadcast_port`,`status` FROM `streaming_servers` WHERE `status` = 1 ORDER BY `id` ASC");
    if ($result) {
        $rows = [];
        while ($row = $result->fetch_assoc()) $rows[] = $row;
        $cache = cs_player_server_dns_from_rows($rows);
        $result->free();
    }
    $db->close();
    return $cache;
}

function cs_player_active_dns(array $cfg): array {
    // Servidores do próprio CS Player são sempre fixos e sincronizados com streaming_servers.
    $rows = cs_player_internal_server_dns();
    $seen = [];
    foreach ($rows as $row) $seen[strtolower(rtrim((string)$row['url'], '/'))] = true;

    // DNS adicionados manualmente são destinados a outros projetos/servidores externos.
    foreach (($cfg['dns'] ?? []) as $idx => $row) {
        if (!is_array($row) || empty($row['enabled'])) continue;
        $url = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($url === '') continue;
        $key = strtolower(rtrim($url, '/'));
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $row['url'] = $url;
        $row['_index'] = 'external:' . $idx;
        $row['fixed'] = false;
        $row['source'] = 'external';
        // Servidores internos têm precedência; externos começam depois.
        $row['_sort'] = 10000 + (int)($row['priority'] ?? 100);
        $rows[] = $row;
    }
    foreach ($rows as $i => &$row) {
        if (!isset($row['_index'])) $row['_index'] = 'server:' . (int)($row['server_id'] ?? $i);
        if (!isset($row['_sort'])) $row['_sort'] = (int)($row['priority'] ?? ($i + 1));
    }
    unset($row);
    usort($rows, static fn($a,$b) => (int)$a['_sort'] <=> (int)$b['_sort']);
    return array_values($rows);
}

function cs_player_manual_dns_row(string $url): ?array {
    $normalized = cs_player_normalize_dns($url);
    if ($normalized === '') return null;
    return [
        'id' => 'manual_' . substr(hash('sha256', $normalized), 0, 12),
        'server_id' => 0,
        'name' => 'DNS manual',
        'url' => $normalized,
        'enabled' => true,
        'priority' => 0,
        'fixed' => false,
        'source' => 'manual',
        '_index' => 'manual:' . substr(hash('sha256', $normalized), 0, 16),
        '_sort' => 0,
    ];
}

function cs_player_session_dns_list(array $cfg, ?string $manualUrl = null, ?bool $manualOnly = null): array {
    $manualUrl = $manualUrl !== null ? $manualUrl : (string)($_SESSION['cs_player_manual_dns'] ?? '');
    $manualOnly = $manualOnly !== null ? $manualOnly : !empty($_SESSION['cs_player_manual_only']);
    $manual = cs_player_manual_dns_row($manualUrl);
    $active = $manualOnly ? [] : cs_player_active_dns($cfg);
    if ($manual) {
        $manualKey = strtolower(rtrim($manual['url'], '/'));
        $active = array_values(array_filter($active, static fn($row) => strtolower(rtrim((string)($row['url'] ?? ''), '/')) !== $manualKey));
        array_unshift($active, $manual);
    }
    return $active;
}

function cs_player_http_json(string $url, int $timeout = 8): ?array {
    if (!function_exists('curl_init')) {
        cs_player_write_log('http_client_unavailable', ['host' => (string)(parse_url($url, PHP_URL_HOST) ?? '')], 'critical');
        return null;
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_USERAGENT => 'CSPlayer-Web/1.0',
        CURLOPT_HTTPHEADER => ['Accept: application/json', 'Cache-Control: no-cache'],
        CURLOPT_ENCODING => '',
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $error = (string)curl_error($ch);
    curl_close($ch);
    if (!is_string($body) || $code < 200 || $code >= 400) {
        cs_player_write_log('http_request_failed', ['host' => (string)(parse_url($url, PHP_URL_HOST) ?? ''), 'http_code' => $code, 'curl_error' => $error], 'error');
        return null;
    }
    $data = json_decode($body, true);
    if (!is_array($data)) {
        cs_player_write_log('http_invalid_json', ['host' => (string)(parse_url($url, PHP_URL_HOST) ?? ''), 'http_code' => $code], 'error');
        return null;
    }
    return $data;
}

function cs_player_api_call(string $dns, string $username, string $password, string $action = '', array $extra = []): ?array {
    $params = array_merge(['username' => $username, 'password' => $password], $extra);
    if ($action !== '') $params['action'] = $action;
    $cfg = cs_player_load_config();
    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));
    return cs_player_http_json(rtrim($dns, '/') . '/player_api.php?' . http_build_query($params), $timeout);
}

/**
 * Consulta várias ações do Xtream em paralelo para a home do Web Player.
 * Quando curl_multi não estiver disponível, usa a mesma função sequencial
 * existente como fallback, sem alterar o contrato da API.
 */
function cs_player_api_batch(string $dns, string $username, string $password, array $requests): array {
    $cfg = cs_player_load_config();
    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));
    $result = [];
    if (!$requests) return $result;

    if (!function_exists('curl_multi_init') || !function_exists('curl_init')) {
        foreach ($requests as $key => $request) {
            $action = is_array($request) ? (string)($request[0] ?? '') : (string)$request;
            $extra = is_array($request) && isset($request[1]) && is_array($request[1]) ? $request[1] : [];
            $result[$key] = cs_player_api_call($dns, $username, $password, $action, $extra) ?? [];
        }
        return $result;
    }

    $multi = curl_multi_init();
    $handles = [];
    foreach ($requests as $key => $request) {
        $action = is_array($request) ? (string)($request[0] ?? '') : (string)$request;
        $extra = is_array($request) && isset($request[1]) && is_array($request[1]) ? $request[1] : [];
        $params = array_merge(['username' => $username, 'password' => $password], $extra);
        if ($action !== '') $params['action'] = $action;
        $handle = curl_init(rtrim($dns, '/') . '/player_api.php?' . http_build_query($params));
        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT => 'CSPlayer-Web/1.0',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        curl_multi_add_handle($multi, $handle);
        $handles[(string)$key] = $handle;
    }

    $running = null;
    do {
        $status = curl_multi_exec($multi, $running);
        if ($running && $status === CURLM_OK) {
            $selected = curl_multi_select($multi, 0.25);
            if ($selected === -1) usleep(10000);
        }
    } while ($running && $status === CURLM_OK);

    foreach ($handles as $key => $handle) {
        $body = curl_multi_getcontent($handle);
        $code = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $decoded = is_string($body) ? json_decode($body, true) : null;
        $result[$key] = ($code >= 200 && $code < 400 && is_array($decoded)) ? $decoded : [];
        if ($result[$key] === []) {
            cs_player_write_log('batch_request_failed', ['host' => (string)(parse_url($dns, PHP_URL_HOST) ?? ''), 'action' => $action, 'http_code' => $code], 'error');
        }
        curl_multi_remove_handle($multi, $handle);
        curl_close($handle);
    }
    curl_multi_close($multi);
    return $result;
}

function cs_player_is_authenticated_response(?array $data): bool {
    if (!$data || !isset($data['user_info']) || !is_array($data['user_info'])) return false;
    $ui = $data['user_info'];
    if (isset($ui['auth']) && (int)$ui['auth'] !== 1) return false;
    if (isset($ui['status']) && !in_array(strtolower((string)$ui['status']), ['active','1'], true)) return false;
    return !empty($ui['username']) || isset($ui['auth']);
}

/**
 * Valida o mesmo login em todos os DNS ativos em paralelo e retorna o primeiro
 * servidor na ordem de prioridade configurada que confirmou a assinatura.
 */
function cs_player_authenticate_dns(array $dnsList, string $username, string $password): ?array {
    if (!$dnsList) return null;
    $cfg = cs_player_load_config();
    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));

    // O servidor interno do próprio CS Player autentica diretamente na base
    // existente. Assim o Web Player não depende de /player_api.php local.
    foreach ($dnsList as $row) {
        if (empty($row['fixed']) && (($row['source'] ?? '') !== 'internal')) continue;
        $user = cs_player_local_user($username, $password);
        if ($user) {
            $data = cs_player_local_auth_response($user);
            $row['local_api'] = true;
            cs_player_write_log('local_auth_selected', [
                'server_id' => (int)($row['server_id'] ?? 0),
                'host' => (string)(parse_url((string)($row['url'] ?? ''), PHP_URL_HOST) ?? ''),
            ], 'info');
            return ['row' => $row, 'data' => $data, 'local_api' => true];
        }
    }

    // Expande silenciosamente os endereços alternativos dos servidores internos.
    // Para DNS externos continua existindo somente a URL cadastrada pelo Admin.
    $targets = [];
    foreach ($dnsList as $logicalIndex => $row) {
        $urls = (!empty($row['fixed']) && is_array($row['fallback_urls'] ?? null)) ? $row['fallback_urls'] : [(string)($row['url'] ?? '')];
        foreach ($urls as $url) {
            $url = cs_player_normalize_dns((string)$url);
            if ($url === '') continue;
            $targets[] = ['logical_index' => $logicalIndex, 'row' => $row, 'url' => $url];
        }
    }
    if (!$targets) return ['error' => 'no_valid_dns', 'diagnostics' => []];

    if (!function_exists('curl_multi_init') || !function_exists('curl_init')) {
        $diagnostics = [];
        foreach ($targets as $target) {
            $data = cs_player_api_call($target['url'], $username, $password);
            if (cs_player_is_authenticated_response($data)) {
                $row = $target['row'];
                $row['url'] = $target['url'];
                return ['row' => $row, 'data' => $data];
            }
            $diagnostics[] = ['host' => (string)(parse_url($target['url'], PHP_URL_HOST) ?? ''), 'port' => (int)(parse_url($target['url'], PHP_URL_PORT) ?? 0), 'http_code' => 0, 'json' => is_array($data)];
        }
        return ['error' => 'upstream_auth_failed', 'diagnostics' => $diagnostics];
    }

    $multi = curl_multi_init();
    $handles = [];
    foreach ($targets as $targetIndex => $target) {
        $params = http_build_query(['username' => $username, 'password' => $password]);
        $handle = curl_init(rtrim($target['url'], '/') . '/player_api.php?' . $params);
        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT => 'CSPlayer-Web/1.1',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        curl_multi_add_handle($multi, $handle);
        $handles[(string)$targetIndex] = $handle;
    }

    $running = null;
    do {
        $status = curl_multi_exec($multi, $running);
        if ($running && $status === CURLM_OK) {
            $selected = curl_multi_select($multi, 0.25);
            if ($selected === -1) usleep(10000);
        }
    } while ($running && $status === CURLM_OK);

    $responses = [];
    $diagnostics = [];
    foreach ($handles as $targetIndex => $handle) {
        $target = $targets[(int)$targetIndex];
        $body = curl_multi_getcontent($handle);
        $code = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $decoded = is_string($body) ? json_decode($body, true) : null;
        $contentType = (string)(curl_getinfo($handle, CURLINFO_CONTENT_TYPE) ?? '');
        $curlErrno = (int)curl_errno($handle);
        $totalTimeMs = (int)round(((float)curl_getinfo($handle, CURLINFO_TOTAL_TIME)) * 1000);
        $responses[$targetIndex] = ($code >= 200 && $code < 400 && is_array($decoded)) ? $decoded : null;
        $host = (string)(parse_url($target['url'], PHP_URL_HOST) ?? '');
        $port = (int)(parse_url($target['url'], PHP_URL_PORT) ?? 0);
        $diagnostics[] = ['host' => $host, 'port' => $port, 'http_code' => $code, 'json' => is_array($decoded), 'content_type' => $contentType, 'curl_errno' => $curlErrno, 'time_ms' => $totalTimeMs];
        if ($responses[$targetIndex] === null) {
            cs_player_write_log('auth_request_failed', ['host' => $host, 'port' => $port, 'http_code' => $code, 'json' => is_array($decoded), 'content_type' => $contentType, 'curl_errno' => $curlErrno, 'time_ms' => $totalTimeMs], 'warning');
        }
        curl_multi_remove_handle($multi, $handle);
        curl_close($handle);
    }
    curl_multi_close($multi);

    // Respeita a prioridade original: primeiro servidor e, dentro dele, suas
    // portas alternativas na ordem calculada.
    foreach ($targets as $targetIndex => $target) {
        $data = $responses[(string)$targetIndex] ?? null;
        if (cs_player_is_authenticated_response($data)) {
            $row = $target['row'];
            $row['url'] = $target['url'];
            if ($target['url'] !== (string)($target['row']['url'] ?? '')) {
                cs_player_write_log('server_endpoint_failover_selected', [
                    'server_id' => (int)($row['server_id'] ?? 0),
                    'host' => (string)(parse_url($target['url'], PHP_URL_HOST) ?? ''),
                    'port' => (int)(parse_url($target['url'], PHP_URL_PORT) ?? 0),
                ], 'info');
            }
            return ['row' => $row, 'data' => $data];
        }
    }
    return ['error' => 'upstream_auth_failed', 'diagnostics' => $diagnostics];
}

function cs_player_require_login(): void {
    if (empty($_SESSION['cs_player_auth']) || empty($_SESSION['cs_player_username']) || !isset($_SESSION['cs_player_dns_index'])) {
        header('Location: index.php');
        exit;
    }
}

function cs_player_json(array $payload, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function cs_player_session_dns(array $cfg, $requested = null): ?array {
    $active = cs_player_session_dns_list($cfg);
    if (!$active) return null;
    $index = $requested ?? ($_SESSION['cs_player_dns_index'] ?? '');
    foreach ($active as $row) {
        if ((string)$row['_index'] === (string)$index) {
            $sessionUrl = cs_player_normalize_dns((string)($_SESSION['cs_player_dns_url'] ?? ''));
            if ($sessionUrl !== '') {
                $allowed = [(string)($row['url'] ?? '')];
                if (is_array($row['fallback_urls'] ?? null)) $allowed = array_merge($allowed, $row['fallback_urls']);
                foreach ($allowed as $candidate) {
                    if (strtolower(rtrim(cs_player_normalize_dns((string)$candidate), '/')) === strtolower(rtrim($sessionUrl, '/'))) {
                        $row['url'] = $sessionUrl;
                        break;
                    }
                }
            }
            return $row;
        }
    }
    return $active[0];
}

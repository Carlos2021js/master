# CS PLAYER 4.0.5 — Web Player PRO

- Mantém Player Live separado de Player VOD.
- Mantém HTTP, M3U8/HLS, TS/MPEG-TS, MP4 e MKV.
- PiP nativo avançado com fallback flutuante de camada máxima.
- Atalhos para TV/desktop: P PiP, F tela cheia, espaço play/pause, setas ±10s no VOD.
- Wake Lock opcional para evitar desligamento de tela durante reprodução.
- Configurações completas no Settings do administrador.
- Área do cliente preservada e controles de vencimento/conexões configuráveis.
- direct_source original do catálogo M3U é preservado no cache de fontes.
- EPG, TMDB, temporadas/episódios, proxy, HLS proxy, Cast, anúncios, destaques e continuar assistindo preservados.
- Nenhuma migração de schema de banco é necessária.

<?php

if (!function_exists('csJsonArray')) {
    function csJsonArray($value): array {
        if (is_array($value)) return $value;
        if ($value === null || $value === '') return [];
        $decoded = json_decode((string)$value, true);
        return is_array($decoded) ? $decoded : [];
    }
}

include_once("HTMLPurifier.standalone.php");
include_once(__DIR__ . "/cs_player.php");

$rRelease = 32;             // Official Beta Release Number
$rEarlyAccess = "B";	   	// Early Access Release
$rTimeout = 60;             // Seconds Timeout for Functions & Requests
$rSQLTimeout = 5;           // Max execution time for MySQL queries.
$rDebug = false;
$rPurifier = new HTMLPurifier(HTMLPurifier_Config::createDefault());
$rGoogleDriveApi = 'https://www.googleapis.com/';

function XSS($rString, $rSQL = False) {
    global $rPurifier, $db;
    if ((is_null($rString)) OR (strtoupper($rString) == 'NULL')) {
        return null;
    } else if (is_array($rString)) {
        return XSSRow($rString, $rSQL);
    } else if ($rSQL) {
        return $db->real_escape_string(str_replace("&quot;", '"', str_replace("&amp;", "&", $rPurifier->purify($rString))));
    } else {
        return str_replace("&quot;", '"', str_replace("&amp;", "&", $rPurifier->purify($rString)));
    }
}

function getRegUsersStats() {
    global $db;
    $result = $db->query("SELECT * FROM `reg_users` ORDER BY owner_id;");
    return $result->fetch_assoc();
}

function getLastMovies() {
    global $db;
    $result = $db->query("SELECT * FROM streams WHERE type = '2' ORDER by id DESC LIMIT 10;");
    return $result->fetch_assoc();
}

function getLastSeries() {
    global $db;
    $result = $db->query("SELECT * FROM series ORDER by last_modified DESC LIMIT 10;");
    return $result->fetch_assoc();
}

/*function getShowMovies() {
    global $db;
    $result = $db->query("SELECT * FROM streams WHERE type = '2' ORDER by id DESC;");
    return $result->fetch_assoc();
}

function getShowSeries() {
    global $db;
    $result = $db->query("SELECT * FROM series ORDER by id DESC;");
    return $result->fetch_assoc();
}*/

function XSSRow($rRow, $rSQL = False) {
    foreach ($rRow as $rKey => $rValue) {
        if (is_array($rValue)) {
            $rRow[$rKey] = XSSRow($rValue, $rSQL);
        } else {
            $rRow[$rKey] = XSS($rValue, $rSQL);
        }
    }
    return $rRow;
}

function ESC($rString) {
    return XSS($rString, True);
}

function sortArrayByArray(array $rArray, array $rSort) {
    $rOrdered = Array();
    foreach ($rSort as $rValue) {
        if (($rKey = array_search($rValue, $rArray)) !== false) {
            $rOrdered[] = $rValue;
            unset($rArray[$rKey]);
        }
    }
    return $rOrdered + $rArray;
}

function startcmd() {
	echo shell_exec("/usr/bin/python ".MAIN_DIR."pytools/balancer.py >/dev/null 2>&1 &");	
}

function updateGeoLite2() {
    global $rAdminSettings;
    $rManifestURL = trim((string)($rAdminSettings["geolite2_manifest_url"] ?? ""));
    $rDatabaseURL = trim((string)($rAdminSettings["geolite2_database_url"] ?? ""));
    if ($rManifestURL === "" || $rDatabaseURL === "" || !filter_var($rManifestURL, FILTER_VALIDATE_URL) || !filter_var($rDatabaseURL, FILTER_VALIDATE_URL)) {
        return false;
    }
    $rContext = stream_context_create(["http" => ["timeout" => 30, "follow_location" => 1], "https" => ["timeout" => 30, "follow_location" => 1]]);
    $rRawData = @file_get_contents($rManifestURL, false, $rContext);
    $rData = is_string($rRawData) ? json_decode($rRawData, true) : null;
    if (!is_array($rData) || empty($rData["version"])) { return false; }
    $rFileData = @file_get_contents($rDatabaseURL, false, $rContext);
    if (!is_string($rFileData) || strlen($rFileData) < 1024) { return false; }
    $rFilePath = "/home/xtreamcodes/iptv_xtream_codes/GeoLite2.mmdb";
    $rTempPath = $rFilePath . ".tmp." . getmypid();
    if (@file_put_contents($rTempPath, $rFileData, LOCK_EX) !== strlen($rFileData)) { @unlink($rTempPath); return false; }
    exec("sudo chattr -i " . escapeshellarg($rFilePath));
    if (!@rename($rTempPath, $rFilePath)) { @unlink($rTempPath); return false; }
    exec("sudo chattr +i " . escapeshellarg($rFilePath));
    $rAdminSettings["geolite2_version"] = (string)$rData["version"];
    writeAdminSettings();
    return true;
}

function updatePanel() {
    global $rAdminSettings;
    // Atualizações automáticas só são executadas quando um manifesto próprio e confiável é configurado.
    $rManifestURL = trim((string)($rAdminSettings["panel_update_manifest_url"] ?? ""));
    if ($rManifestURL === "" || !filter_var($rManifestURL, FILTER_VALIDATE_URL)) { return false; }
    $rContext = stream_context_create(["http" => ["timeout" => 30, "follow_location" => 1], "https" => ["timeout" => 30, "follow_location" => 1]]);
    $rRawData = @file_get_contents($rManifestURL, false, $rContext);
    $rData = is_string($rRawData) ? json_decode($rRawData, true) : null;
    $rOld = (string)($rAdminSettings["panel_version"] ?? "");
    $rVersion = is_array($rData) ? (string)($rData["version"] ?? "") : "";
    $rUpdateURL = is_array($rData) ? (string)($rData["download_url"] ?? "") : "";
    if ($rVersion === "" || !preg_match('/^[A-Za-z0-9._-]+$/', $rVersion) || $rVersion === $rOld || !filter_var($rUpdateURL, FILTER_VALIDATE_URL)) { return false; }
    // Por segurança, o pacote é apenas baixado e validado. A instalação deve ser feita pelo administrador após backup.
    $rTarget = "/tmp/cs_player_update_" . preg_replace('/[^A-Za-z0-9._-]/', '_', $rVersion) . ".zip";
    $rCommand = "wget --https-only --timeout=30 " . escapeshellarg($rUpdateURL) . " -O " . escapeshellarg($rTarget) . " -o /dev/null";
    exec($rCommand, $rOutput, $rCode);
    if ($rCode !== 0 || !is_file($rTarget) || filesize($rTarget) < 1024) { @unlink($rTarget); return false; }
    $rAdminSettings["pending_panel_version"] = $rVersion;
    $rAdminSettings["pending_panel_update_file"] = $rTarget;
    writeAdminSettings();
    return true;
}

function mapmap() {
    global $db;
         $rQuery = "SELECT geoip_country_code, count(geoip_country_code) AS total FROM user_activity_now GROUP BY geoip_country_code";
        if ($rResult = $db->query($rQuery)) {
            while ($row = $rResult->fetch_assoc()) {
				$gggrr = "{\"code\":".json_encode($row["geoip_country_code"]).",\"value\":".json_encode($row["total"])."},";
                                   echo $gggrr;
            }

        }
    }
function resetSTB($rID) {
    global $db;
    $db->query("UPDATE `mag_devices` SET `ip` = NULL, `ver` = NULL, `image_version` = NULL, `stb_type` = NULL, `sn` = NULL, `device_id` = NULL, `device_id2` = NULL, `hw_version` = NULL, `token` = NULL WHERE `mag_id` = ".intval($rID).";");
}
//isp lock
function resetispnames($rID) {
    global $db;
    $db->query("UPDATE `users` SET `isp_desc` = NULL WHERE `id` = ".intval($rID).";");
}
//isp lock
function getAdminSettings() {
    global $db;
    static $requestCache = null;
    if (is_array($requestCache)) return $requestCache;
    $return = Array();
    $result = $db->query("SELECT `type`, `value` FROM `admin_settings`;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[$row["type"]] = $row["value"];
        }
    }
    $requestCache = $return;
    return $return;
}

function getSettings() {
    global $db;
    $result = $db->query("SELECT * FROM `settings` LIMIT 1;");
    return $result->fetch_assoc();
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($rDebug) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
}

set_time_limit($rTimeout);
ini_set('mysql.connect_timeout', $rSQLTimeout);
ini_set('max_execution_time', $rTimeout);
ini_set('default_socket_timeout', $rTimeout);

define("MAIN_DIR", "/home/xtreamcodes/iptv_xtream_codes/");
define("CONFIG_CRYPT_KEY", "5709650b0d7806074842c6de575025b1");

require_once realpath(dirname(__FILE__))."/mobiledetect.php";
require_once realpath(dirname(__FILE__))."/gauth.php";

function getTimezone() {
    global $db;
    $result = $db->query("SELECT `default_timezone` FROM `settings`;");
    if ((isset($result)) && ($result->num_rows == 1)) {
        return XSS($result->fetch_assoc()["default_timezone"]);
    } else {
        return "Europe/London";
    }
}

function xor_parse($data, $key) {
    $i = 0;
    $output = '';
    foreach (str_split($data) as $char) {
        $output.= chr(ord($char) ^ ord($key[$i++ % strlen($key)]));
    }
    return $output;
}

if (file_exists('/home/xtreamcodes/iptv_xtream_codes/config')) {
    $_INFO = json_decode(xor_parse(base64_decode(file_get_contents(MAIN_DIR . "config")), CONFIG_CRYPT_KEY), True);
} else {
    $_INFO['host'] = "localhost"; 
    $_INFO['db_user'] = "root"; 
    $_INFO['db_pass'] = ""; 
    $_INFO['db_port'] = "7999";
    $_INFO['db_name'] = "xtream_iptvpro";
}

if (!$db = new mysqli($_INFO["host"], $_INFO["db_user"], $_INFO["db_pass"], $_INFO["db_name"], $_INFO["db_port"])) { exit("Não foi possível conectar ao banco de dados MySQL."); } 
$db->set_charset("utf8");
//$db->query("SET GLOBAL MAX_EXECUTION_TIME=".($rSQLTimeout*1000).";");
date_default_timezone_set(getTimezone());

$rAdminSettings = getAdminSettings();
$rSettings = getSettings();
$nabilos = getRegisteredUserHash(@$_SESSION['hash']);

// CS PLAYER: interface administrativa padronizada em Português do Brasil.
// Mantém as chaves internas originais para preservar compatibilidade.
$rInterfaceLang = "br";
if (!file_exists(realpath(dirname(__FILE__))."/lang/br.php")) { $rInterfaceLang = "pt"; }
include realpath(dirname(__FILE__))."/lang/".$rInterfaceLang.".php";

$detect = new Mobile_Detect;
$rClientFilters = Array(
    "NOT_IN_BOUQUET" => "Fora do buquê",
    "CON_SVP" => "Problema de conexão",
    "ISP_LOCK_FAILED" => "Falha no bloqueio de ISP",
    "USER_DISALLOW_EXT" => "Extensão não permitida",
    "AUTH_FAILED" => "Falha na autenticação",
    "USER_EXPIRED" => "User Expired",
    "USER_DISABLED" => "User Disabled",
    "USER_BAN" => "User Banned"
);

function APIRequest($rData) {
    global $rAdminSettings, $rServers, $_INFO;
    ini_set('default_socket_timeout', 5);
    if ($rAdminSettings["local_api"]) {
        $rAPI = "http://127.0.0.1:".$rServers[$_INFO["server_id"]]["http_broadcast_port"]."/api.php";
    } else {
        $rAPI = "http://".$rServers[$_INFO["server_id"]]["server_ip"].":".$rServers[$_INFO["server_id"]]["http_broadcast_port"]."/api.php";
    }
    $rPost = http_build_query($rData);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $rAPI);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $rPost);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    $rData = curl_exec($ch);
    return $rData;
}

function SystemAPIRequest($rServerID, $rData) {
    global $rServers, $rSettings;
    ini_set('default_socket_timeout', 5);
    $rAPI = "http://".$rServers[intval($rServerID)]["server_ip"].":".$rServers[intval($rServerID)]["http_broadcast_port"]."/system_api.php";
    $rData["password"] = $rSettings["live_streaming_pass"];
    $rPost = http_build_query($rData);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $rAPI);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $rPost);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    $rData = curl_exec($ch);
    return $rData;
}
//network interface 1
function multiexplode ($delimiters,$data) {
	$MakeReady = str_replace($delimiters, $delimiters[0], $data);
	$Return    = array_filter(explode($delimiters[0], $MakeReady));
	return  $Return;
}
//network interface 1		 
function sexec($rServerID, $rCommand) {
    global $_INFO;
    if ($rServerID <> $_INFO["server_id"]) {
        return SystemAPIRequest($rServerID, Array("action" => "BackgroundCLI", "cmds" => Array($rCommand)));
    } else {
        return exec($rCommand);
    }
}
//network interface 2
function sexec2($rServerID, $rCommand) {
 $loool = SystemAPIRequest($rServerID, Array("action" => "BackgroundCLI", "cmds" => Array($rCommand)));
 return  $loool;
}

function netnet($rServerID) {
    $ccc = sexec2($rServerID, "ls -1 /sys/class/net");
    $ttt = multiexplode(array('[','"','\n',']'), $ccc);
    array_push($ttt, "");
    return $ttt;
    }
//network interface 2	

function loadnginx($rServerID) {
    sexec($rServerID, "sudo /home/xtreamcodes/iptv_xtream_codes/nginx/sbin/nginx -s reload");
	sexec($rServerID, "sudo /home/xtreamcodes/iptv_xtream_codes/nginx_rtmp/sbin/nginx_rtmp -s reload");
}

function changePort($rServerID, $rType, $rOldPort, $rNewPort) {
	if ($rType == 1) {
		// SSL
		sexec($rServerID, "sed -i 's/listen ".intval($rOldPort)." ssl;/listen ".intval($rNewPort)." ssl;/g' /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf");
	} else if ($rType == 2) {
		// RTMP
		sexec($rServerID, "sed -i 's/listen ".intval($rOldPort).";/listen ".intval($rNewPort).";/g' /home/xtreamcodes/iptv_xtream_codes/nginx_rtmp/conf/nginx.conf");
	} else if ($rType == 0) {
		// HTTP
		sexec($rServerID, "sed -i 's/listen ".intval($rOldPort).";/listen ".intval($rNewPort).";/g' /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf");
	} else if ($rType == 3) {
		// HTTP Admin
		sexec($rServerID, "sed -i 's/listen ".intval($rOldPort).";/listen ".intval($rNewPort).";/g' /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf");
	}
	
}

function changeIsp($rServerID, $rType, $rOldPort, $rNewPort) {
    if ($rType == 3) {
		// ISP
		sexec($rServerID, "sed -i 's/listen ".intval($rOldPort).";/listen ".intval($rNewPort).";/g' /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf");
	    sexec($rServerID, "sed -i 's|:".intval($rOldPort)."/api.php|:".intval($rNewPort)."/api.php|g' /home/xtreamcodes/iptv_xtream_codes/wwwdir/includes/streaming.php");
	}
}

function getPIDs($rServerID) {
    global $rAdminSettings;
    $rReturn = Array();
    $rFilename = tempnam(MAIN_DIR.'tmp/', 'proc_');
    $rCommand = "ps aux >> ".$rFilename;
    sexec($rServerID, $rCommand);
    $rData = ""; $rI = 3;
    while (strlen($rData) == 0) {
        $rData = SystemAPIRequest($rServerID, Array('action' => 'getFile', 'filename' => $rFilename));
        $rI --;
        if (($rI == 0) OR (strlen($rData) > 0)) { break; }
        sleep(1);
    }
    $rProcesses = explode("\n", $rData);
    array_shift($rProcesses);
    foreach ($rProcesses as $rProcess) {
        $rSplit = explode(" ", preg_replace('!\s+!', ' ', trim($rProcess)));
        if (strlen($rSplit[0]) > 0) {
            $rReturn[] = Array("user" => $rSplit[0], "pid" => $rSplit[1], "cpu" => $rSplit[2], "mem" => $rSplit[3], "vsz" => $rSplit[4], "rss" => $rSplit[5], "tty" => $rSplit[6], "stat" => $rSplit[7], "start" => $rSplit[8], "time" => $rSplit[9], "command" => join(" ", array_splice($rSplit, 10, count($rSplit)-10)));
        }
    }
    return $rReturn;
}

function getFreeSpace($rServerID) {
    $rReturn = Array();
    $rFilename = tempnam(MAIN_DIR.'tmp/', 'fs_');
    $rCommand = "df -h >> ".$rFilename;
    sexec($rServerID, $rCommand);
    $rData = SystemAPIRequest($rServerID, Array('action' => 'getFile', 'filename' => $rFilename));
    $rLines = explode("\n", $rData);
    array_shift($rLines);
    foreach ($rLines as $rLine) {
        $rSplit = explode(" ", preg_replace('!\s+!', ' ', trim($rLine)));
        //if ((strlen($rSplit[0]) > 0) && (strpos($rSplit[5], "xtreamcodes") !== false)) {
            $rReturn[] = Array("filesystem" => $rSplit[0], "size" => $rSplit[1], "used" => $rSplit[2], "avail" => $rSplit[3], "percentage" => $rSplit[4], "mount" => join(" ", array_slice($rSplit, 5, count($rSplit)-5)));
        //}
    }
    return $rReturn;
}

/*// novo getFreeSpace
function getSpace($rServerID) {
$rReturn = Array();
$rFilename = tempnam(MAIN_DIR.'tmp/', 'fs_');
$rCommand = "df -h >> ".$rFilename;
sexec($rServerID, $rCommand);
$rData = SystemAPIRequest($rServerID, Array('action' => 'getFile', 'filename' => $rFilename));
$rLines = explode("\n", $rData);
array_shift($rLines);
foreach ($rLines as $rLine) {
$rSplit = explode(" ", preg_replace('!\s+!', ' ', trim($rLine)));
if(sizeof($rSplit)<2)
continue;
//if ((strlen($rSplit[0]) > 0) && (strpos($rSplit[5], "xtreamcodes") !== false)) {
$rReturn[] = Array("filesystem" => $rSplit[0], "size" => $rSplit[1], "used" => $rSplit[2], "avail" => $rSplit[3], "percentage" => $rSplit[4], "mount" => join(" ", array_slice($rSplit, 5, count($rSplit)-5)));
//}
}


$largestSize = 0;
$largestRow = null;
foreach($rReturn as $row){
$rowSize = convertToBytes($row['size']);
if($rowSize>$largestSize){
$largestSize = $rowSize;
$largestRow = $row;
}
}

return $largestRow;
}

function convertToBytes($from) {
$units = ['B', 'K', 'M', 'G', 'T', 'P'];
$number = substr($from, 0, -1);
$suffix = strtoupper(substr($from,-1));

//B or no suffix
if(is_numeric(substr($suffix, 0, 1))) {
return preg_replace('/[^\d]/', '', $from);
}

$exponent = array_flip($units)[$suffix] ?? null;
if($exponent === null) {
return null;
}

return $number * (1024 ** $exponent);
}
//fim novo getFreeSpace*/

function remoteCMD($rServerID, $rCommand) {
    $rReturn = Array();
    $rFilename = tempnam(MAIN_DIR.'tmp/', 'cmd_');
    sexec($rServerID, $rCommand." >> ".$rFilename);
	$rData = ""; $rI = 3;
    while (strlen($rData) == 0) {
        $rData = SystemAPIRequest($rServerID, Array('action' => 'getFile', 'filename' => $rFilename));
        $rI --;
        if (($rI == 0) OR (strlen($rData) > 0)) { break; }
        sleep(1);
    }
	unset($rFilename);
    return $rData;
}

function freeTemp($rServerID) {
    sexec($rServerID, "rm ".MAIN_DIR."tmp/*");
}

function freeStreams($rServerID) {
    sexec($rServerID, "rm ".MAIN_DIR."streams/*");
}

function getStreamPIDs($rServerID) {
    global $db;
    $return = Array();
    $result = $db->query("SELECT `streams`.`id`, `streams`.`stream_display_name`, `streams`.`type`, `streams_sys`.`pid`, `streams_sys`.`monitor_pid`, `streams_sys`.`delay_pid` FROM `streams_sys` LEFT JOIN `streams` ON `streams`.`id` = `streams_sys`.`stream_id` WHERE `streams_sys`.`server_id` = ".intval($rServerID).";");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            foreach (Array("pid", "monitor_pid", "delay_pid") as $rPIDType) {
                if ($row[$rPIDType]) {
                    $return[$row[$rPIDType]] = Array("id" => $row["id"], "title" => $row["stream_display_name"], "type" => $row["type"], "pid_type" => $rPIDType);
                }
            }
        }
    }
    $result = $db->query("SELECT `id`, `stream_display_name`, `type`, `tv_archive_pid` FROM `streams` WHERE `tv_archive_server_id` = ".intval($rServerID).";");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            if ($row["pid"]) {
                $return[$row["pid"]] = Array("id" => $row["id"], "title" => $row["stream_display_name"], "type" => $row["type"], "pid_type" => "timeshift");
            }
        }
    }
    $result = $db->query("SELECT `streams`.`id`, `streams`.`stream_display_name`, `streams`.`type`, `user_activity_now`.`pid` FROM `user_activity_now` LEFT JOIN `streams` ON `streams`.`id` = `user_activity_now`.`stream_id` WHERE `user_activity_now`.`server_id` = ".intval($rServerID).";");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            if ($row["pid"]) {
                $return[$row["pid"]] = Array("id" => $row["id"], "title" => $row["stream_display_name"], "type" => $row["type"], "pid_type" => "activity");
            }
        }
    }
    return $return;
}

function roundUpToAny($n,$x=5) {
    return round(($n+$x/2)/$x)*$x;
}

function checkSource($rServerID, $rFilename) {
    global $rServers, $rSettings;
    $rAPI = "http://".$rServers[intval($rServerID)]["server_ip"].":".$rServers[intval($rServerID)]["http_broadcast_port"]."/system_api.php?password=".$rSettings["live_streaming_pass"]."&action=getFile&filename=".urlencode(escapeshellcmd($rFilename));
    $rCommand = 'timeout 5 '.MAIN_DIR.'bin/ffprobe -show_streams -v quiet "'.$rAPI.'" -of json';
    return json_decode(shell_exec($rCommand), True);
}

function getSelections($rSources) {
    global $db;
    $return = Array();
    foreach ($rSources as $rSource) {
        $result = $db->query("SELECT `id` FROM `streams` WHERE `type` IN (2,5) AND `stream_source` LIKE '%".ESC(str_replace("/", "\/", $rSource))."\"%' ESCAPE '|' LIMIT 1;");
        if (($result) && ($result->num_rows == 1)) {
            $return[] = intval($result->fetch_assoc()["id"]);
        }
    }
    return $return;
}

function getBackups() {
    $rBackups = Array();
    foreach (scandir(MAIN_DIR."adtools/backups/") as $rBackup) {
        $rInfo = pathinfo(MAIN_DIR."adtools/backups/".$rBackup);
        if ($rInfo["extension"] == "gz") {
            $rBackups[] = Array("filename" => $rBackup, "timestamp" => filemtime(MAIN_DIR."adtools/backups/".$rBackup), "date" => date("Y-m-d H:i:s", filemtime(MAIN_DIR."adtools/backups/".$rBackup)), "filesize" => filesize(MAIN_DIR."adtools/backups/".$rBackup));
        }
    }
    usort($rBackups, function($a, $b) {
        return $a['timestamp'] <=> $b['timestamp'];
    });
    return $rBackups;
}

/*function startcmd() {
	echo shell_exec("nohup /usr/bin/python /home/xtreamcodes/iptv_xtream_codes/pytools/balancer.py 2>&1");
}*/

function parseRelease($rRelease) {
    $rCommand = "/usr/bin/python ".MAIN_DIR."pytools/release.py \"".escapeshellcmd($rRelease)."\"";
    return json_decode(shell_exec($rCommand), True);
}

function listDir($rServerID, $rDirectory, $rAllowed=null) {
    global $rServers, $_INFO, $rSettings;
    set_time_limit(60);
    ini_set('max_execution_time', 60);
    $rReturn = Array("dirs" => Array(), "files" => Array());
    if ($rServerID == $_INFO["server_id"]) {
        $rFiles = scanDir($rDirectory);
        foreach ($rFiles as $rKey => $rValue) {
            if (!in_array($rValue, Array(".",".."))) {
                if (is_dir($rDirectory."/".$rValue)) {
                    $rReturn["dirs"][] = $rValue;
                } else {
                    $rExt = strtolower(pathinfo($rValue)["extension"]);
                    if (((is_array($rAllowed)) && (in_array($rExt, $rAllowed))) OR (!$rAllowed)) {
                        $rReturn["files"][] = $rValue;
                    }
                }
            }
        }
    } else {
        if ($rAdminSettings["alternate_scandir"]) {
            $rFilename = tempnam(MAIN_DIR.'tmp/', 'ls_');
            $rCommand = "ls -cm -f --group-directories-first --indicator-style=slash \"".escapeshellcmd($rDirectory)."\" >> ".$rFilename;
            sexec($rServerID, $rCommand);
            $rData = ""; $rI = 2;
            while (strlen($rData) == 0) {
                $rData = SystemAPIRequest($rServerID, Array('action' => 'getFile', 'filename' => $rFilename));
                $rI --;
                if (($rI == 0) OR (strlen($rData) > 0)) { break; }
                sleep(1);
            }
            if (strlen($rData) > 0) {
                $rFiles = explode(",", $rData);
                sort($rFiles);
                foreach($rFiles as $rFile) {
                    $rFile = trim($rFile);
                    if (substr($rFile, -1) == "/") {
                        if ((substr($rFile, 0, -1) <> "..") && (substr($rFile, 0, -1) <> ".")) {
                            $rReturn["dirs"][] = substr($rFile, 0, -1);
                        }
                    } else {
                        $rExt = strtolower(pathinfo($rFile)["extension"]);
                        if (((is_array($rAllowed)) && (in_array($rExt, $rAllowed))) OR (!$rAllowed)) {
                            $rReturn["files"][] = $rFile;
                        }
                    }
                }
            }
        } else {
            $rData = SystemAPIRequest($rServerID, Array('action' => 'viewDir', 'dir' => $rDirectory));
            $rDocument = new DOMDocument();
            $rDocument->loadHTML($rData);
            $rFiles = $rDocument->getElementsByTagName('li');
            foreach($rFiles as $rFile) {
                if (stripos($rFile->getAttribute('class'), "directory") !== false) {
                    $rReturn["dirs"][] = $rFile->nodeValue;
                } else if (stripos($rFile->getAttribute('class'), "file") !== false) {
                    $rExt = strtolower(pathinfo($rFile->nodeValue)["extension"]);
                    if (((is_array($rAllowed)) && (in_array($rExt, $rAllowed))) OR (!$rAllowed)) {
                        $rReturn["files"][] = $rFile->nodeValue;
                    }
                }
            }
        }
    }
    return $rReturn;
}

function scanRecursive($rServerID, $rDirectory, $rAllowed=null) {
    $result = [];
    $rFiles = listDir($rServerID, $rDirectory, $rAllowed);
    foreach ($rFiles["files"] as $rFile) {
        $rFilePath = rtrim($rDirectory, "/").'/'.$rFile;
        $result[] = $rFilePath;
    }
    foreach ($rFiles["dirs"] as $rDir) {
        foreach (scanRecursive($rServerID, rtrim($rDirectory, "/")."/".$rDir."/", $rAllowed) as $rFile) {
            $result[] = $rFile;
        }
    }
    return $result;
}

function getEncodeErrors($rID) {
    global $rSettings;
    $rServers = getStreamingServers(true);
    ini_set('default_socket_timeout', 3);
    $rErrors = Array();
    $rStreamSys = getStreamSys($rID);
    foreach ($rStreamSys as $rServer) {
        $rServerID = $rServer["server_id"];
        if (isset($rServers[$rServerID])) {
            if (!($rServer["pid"] > 0 && $rServer["to_analyze"] == 0 && $rServer["stream_status"] <> 1)) {
                $rFilename = MAIN_DIR."movies/".intval($rID).".errors";
                $rError = SystemAPIRequest($rServerID, Array('action' => 'getFile', 'filename' => $rFilename));
                if (strlen($rError) > 0) {
                    $rErrors[$rServerID] = $rError;
                }
            }
        }
    }
    return $rErrors;
}

function getTimeDifference($rServerID) {
	global $rServers, $rSettings;
    ini_set('default_socket_timeout', 3);
    $rError = SystemAPIRequest($rServerID, Array('action' => 'getDiff', 'main_time' => intval(time())));
    return (is_file($rAPI)) ? intval(file_get_contents($rAPI)) : '';
}

function deleteMovieFile($rServerID, $rID) {
	global $rServers, $rStreams, $rSettings;
    ini_set('default_socket_timeout', 3);
    $rCommand = "rm ".MAIN_DIR."movies/".$rID."*";
    sexec($rServerID, $rCommand);
    //return SystemAPIRequest($rServerID, Array('action' => 'BackgroundCLI', 'action' => Array($rCommand)));
}

function generateString($strength = 10) {
    $input = '23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
    $input_length = strlen($input);
    $random_string = '';
    for($i = 0; $i < $strength; $i++) {
        $random_character = $input[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }
    return $random_string;
}

// Credenciais para aplicativos: usuário começa com letras e usa apenas
// caracteres ASCII seguros para URLs e clientes mais restritivos.
function generateClientUsername($strength = 10) {
    $letters = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
    $rest = '23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
    $result = '';
    for ($i = 0; $i < 3; $i++) {
        $result .= $letters[mt_rand(0, strlen($letters) - 1)];
    }
    for ($i = 3; $i < max(9, intval($strength)); $i++) {
        $result .= $rest[mt_rand(0, strlen($rest) - 1)];
    }
    return $result;
}

function generateClientPassword($strength = 10) {
    return generateString(max(9, intval($strength)));
}

function isValidClientCredential($value, $field = 'username') {
    $value = (string)$value;
    if ($field === 'username') {
        return (bool)preg_match('/^[A-Za-z]{3}[A-Za-z0-9_-]{6,17}$/', $value);
    }
    return (bool)preg_match('/^[A-Za-z0-9_-]{9,64}$/', $value);
}

function clientCredentialUrl($value) {
    return rawurlencode(trim((string)$value));
}

function getStreamingServers($rActive = false) {
    global $db, $rPermissions;
    $return = Array();
    if ($rActive) {
        $result = $db->query("SELECT * FROM `streaming_servers` WHERE `status` = 1 ORDER BY `id` ASC;");
    } else {
        $result = $db->query("SELECT * FROM `streaming_servers` ORDER BY `id` ASC;");
    }
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if ($rPermissions["is_reseller"]) {
                $row["server_name"] = "Server #".$row["id"];
            }
            $return[$row["id"]] = $row;
        }
    }
    return $return;
}

function getStreamingServersByID($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `streaming_servers` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return False;
}

function getStreamList() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT `streams`.`id`, `streams`.`stream_display_name`, `stream_categories`.`category_name` FROM `streams` LEFT JOIN `stream_categories` ON `stream_categories`.`id` = `streams`.`category_id` ORDER BY `streams`.`stream_display_name` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getConnections($rServerID) {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `user_activity_now` WHERE `server_id` = '".ESC($rServerID)."';");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getUserConnections($rUserID) {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `user_activity_now` WHERE `user_id` = '".ESC($rUserID)."';");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getEPGSources() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `epg`;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[$row["id"]] = $row;
        }
    }
    return $return;
}

function findEPG($rEPGName) {
    global $db;
    $result = $db->query("SELECT `id`, `data` FROM `epg`;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            foreach (json_decode($row["data"], True) as $rChannelID => $rChannelData) {
                if ($rChannelID == $rEPGName) {
                    if (count($rChannelData["langs"]) > 0) {
                        $rEPGLang = $rChannelData["langs"][0];
                    } else {
                        $rEPGLang = "";
                    }
                    return Array("channel_id" => $rChannelID, "epg_lang" => $rEPGLang, "epg_id" => intval($row["id"]));
                }
            }
        }
    }
    return null;
}

function getStreamArguments() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `streams_arguments` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[$row["argument_key"]] = $row;
        }
    }
    return $return;
}

function getTranscodeProfiles() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `transcoding_profiles` ORDER BY `profile_id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getWatchFolders($rType=null) {
    global $db;
    $return = Array();
    if ($rType) {
        $result = $db->query("SELECT * FROM `watch_folders` WHERE `type` = '".ESC($rType)."' ORDER BY `id` ASC;");
    } else {
        $result = $db->query("SELECT * FROM `watch_folders` ORDER BY `id` ASC;");
    }
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getWatchCategories($rType=null) {
    global $db;
    $return = Array();
    if ($rType) {
        $result = $db->query("SELECT * FROM `watch_categories` WHERE `type` = ".intval($rType)." ORDER BY `genre_id` ASC;");
    } else {
        $result = $db->query("SELECT * FROM `watch_categories` ORDER BY `genre_id` ASC;");
    }
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[$row["genre_id"]] = $row;
        }
    }
    return $return;
}

function getWatchFolder($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `watch_folders` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getSeriesByTMDB($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `series` WHERE `tmdb_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getSeries() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `series` ORDER BY `title` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getSerie($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `series` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getSeriesTrailer($rTMDBID) {
    // Not implemented in TMDB PHP API...
    global $rSettings, $rAdminSettings;
    if (strlen($rAdminSettings["tmdb_language"]) > 0) {
        $rURL = "https://api.themoviedb.org/3/tv/".$rTMDBID."/videos?api_key=".$rSettings["tmdb_api_key"]."&language=".$rAdminSettings["tmdb_language"];
    } else {
        $rURL = "https://api.themoviedb.org/3/tv/".$rTMDBID."/videos?api_key=".$rSettings["tmdb_api_key"];
    }
    $rJSON = json_decode(file_get_contents($rURL), True);
    foreach ($rJSON["results"] as $rVideo) {
        if ((strtolower($rVideo["type"]) == "trailer") && (strtolower($rVideo["site"]) == "youtube")) {
            return $rVideo["key"];
        }
    }
    return "";
}

function getStills($rTMDBID, $rSeason, $rEpisode) {
    // Not implemented in TMDB PHP API...
    global $rSettings, $rAdminSettings;
    if (strlen($rAdminSettings["tmdb_language"]) > 0) {
        $rURL = "https://api.themoviedb.org/3/tv/".$rTMDBID."/season/".$rSeason."/episode/".$rEpisode."/images?api_key=".$rSettings["tmdb_api_key"]."&language=".$rAdminSettings["tmdb_language"];
    } else {
        $rURL = "https://api.themoviedb.org/3/tv/".$rTMDBID."/season/".$rSeason."/episode/".$rEpisode."/images?api_key=".$rSettings["tmdb_api_key"];
    }
    return json_decode(file_get_contents($rURL), True);
}

function getUserAgents() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `blocked_user_agents` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getISPs() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `isp_addon` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getBlockedIPs() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `blocked_ips` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getMagClaims() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `mag_claims` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getPanelLogs() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `panel_logs` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

//##########
function getBlockedLogins() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `login_flood` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

// LEAKED LINES : For Show Restreamers, remove AND is_restreamer <1
function getLeakedLines() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT FROM_BASE64(mac), username, user_activity.user_id, user_activity.container, user_activity.geoip_country_code, GROUP_CONCAT(DISTINCT user_ip), GROUP_CONCAT(DISTINCT container), GROUP_CONCAT(DISTINCT geoip_country_code), is_restreamer FROM user_activity
INNER JOIN users ON user_id = users.id AND is_mag = 1
INNER JOIN mag_devices ON users.id = mag_devices.user_id
WHERE 1 GROUP BY user_id HAVING COUNT(DISTINCT user_ip) > 1
AND
is_restreamer < 1
UNION
SELECT '', username, user_activity.user_id, user_activity.container, user_activity.geoip_country_code, GROUP_CONCAT(DISTINCT user_ip), GROUP_CONCAT(DISTINCT container), GROUP_CONCAT(DISTINCT geoip_country_code), is_restreamer FROM user_activity
INNER JOIN users ON user_id = users.id AND is_mag = 0
WHERE 1 GROUP BY user_id HAVING COUNT(DISTINCT user_ip) > 1
AND
is_restreamer < 1;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

// SECURITY CENTER
function getSecurityCenter() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT Distinct users.id, users.username, SUBSTR(`streams`.`stream_display_name`, 1, 30) stream_display_name, users.max_connections, (SELECT count(*) FROM `user_activity_now` WHERE `user_activity_now`.`stream_id` = `streams`.`id`) AS `active_connections`, (SELECT count(*) FROM `user_activity_now` WHERE `users`.`id` = `user_activity_now`.`user_id`) AS `total_active_connections` FROM user_activity_now
INNER JOIN `streams` ON `user_activity_now`.`stream_id` = `streams`.`id`
LEFT JOIN users ON user_id = users.id WHERE (SELECT count(*) FROM `user_activity_now` WHERE `users`.`id` = `user_activity_now`.`user_id`) > `users`.`max_connections`
AND
is_restreamer < 1;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}
//############

function getRTMPIPs() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `rtmp_ips` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getStream($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `streams` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getUser($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `users` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getRegisteredUser($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `reg_users` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

// Premium/Turbo UI helpers. They are deliberately additive: if the optional
// migration has not been applied, every profile continues using the legacy UI.
function csplayUiVersionColumnAvailable() {
    global $db;
    static $available = null;
    if ($available !== null) { return $available; }
    $available = false;
    $result = $db->query("SHOW COLUMNS FROM `reg_users` LIKE 'ui_version';");
    if (($result) && ($result->num_rows > 0)) { $available = true; }
    return $available;
}

function csplayNormalizeUiVersion($rVersion) {
    $rVersion = strtolower(trim((string)$rVersion));
    return in_array($rVersion, array('legacy', 'premium', 'turbo'), true) ? $rVersion : 'legacy';
}

function csplayGetUiVersion($rUser = null) {
    if (!is_array($rUser) || !array_key_exists('ui_version', $rUser)) { return 'legacy'; }
    return csplayNormalizeUiVersion($rUser['ui_version']);
}

function csplayUiVersionLabel($rVersion) {
    $rVersion = csplayNormalizeUiVersion($rVersion);
    return array('legacy' => 'Clássico (atual)', 'premium' => 'Premium', 'turbo' => 'Turbo')[ $rVersion ];
}

function getRegisteredUserHash($rHash) {
    global $db;
    $result = $db->query("SELECT * FROM `reg_users` WHERE MD5(`username`) = '".ESC($rHash)."' LIMIT 1;");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getEPG($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `epg` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getStreamOptions($rID) {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `streams_options` WHERE `stream_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["argument_id"])] = $row;
        }
    }
    return $return;
}

function getStreamSys($rID) {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `streams_sys` WHERE `stream_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["server_id"])] = $row;
        }
    }
    return $return;
}

function getRegisteredUsers($rOwner=null, $rIncludeSelf=true) {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `reg_users` ORDER BY `username` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            if ((!$rOwner) OR ($row["owner_id"] == $rOwner) OR (($row["id"] == $rOwner) && ($rIncludeSelf))) {
                $return[intval($row["id"])] = $row;
            }
        }
    }
    if (count($return) == 0) { $return[-1] = Array(); }
    return $return;
}

function hasPermissions($rType, $rID) {
    global $rUserInfo, $db, $rPermissions;
    if ($rType == "user") {
        if (in_array(intval(getUser($rID)["member_id"]), array_keys(getRegisteredUsers($rUserInfo["id"])))) {
            return true;
        }
    } else if ($rType == "pid") {
        $result = $db->query("SELECT `user_id` FROM `user_activity_now` WHERE `pid` = ".intval($rID).";");
        if (($result) && ($result->num_rows > 0)) {
            if (in_array(intval(getUser($result->fetch_assoc()["user_id"])["member_id"]), array_keys(getRegisteredUsers($rUserInfo["id"])))) {
                return true;
            }
        }
    } else if ($rType == "reg_user") {
        if ((in_array(intval($rID), array_keys(getRegisteredUsers($rUserInfo["id"])))) && (intval($rID) <> intval($rUserInfo["id"]))) {
            return true;
        }
    } else if ($rType == "ticket") {
        if (in_array(intval(getTicket($rID)["member_id"]), array_keys(getRegisteredUsers($rUserInfo["id"])))) {
            return true;
        }
    } else if ($rType == "mag") {
        $result = $db->query("SELECT `user_id` FROM `mag_devices` WHERE `mag_id` = ".intval($rID).";");
        if (($result) && ($result->num_rows > 0)) {
            if (in_array(intval(getUser($result->fetch_assoc()["user_id"])["member_id"]), array_keys(getRegisteredUsers($rUserInfo["id"])))) {
                return true;
            }
        }
    } else if ($rType == "e2") {
        $result = $db->query("SELECT `user_id` FROM `enigma2_devices` WHERE `device_id` = ".intval($rID).";");
        if (($result) && ($result->num_rows > 0)) {
            if (in_array(intval(getUser($result->fetch_assoc()["user_id"])["member_id"]), array_keys(getRegisteredUsers($rUserInfo["id"])))) {
                return true;
            }
        }
    } else if (($rType == "adv") && !empty($rPermissions["is_admin"])) {
        // CS Player: qualquer conta marcada pelo grupo existente como administrador
        // recebe acesso completo às funções administrativas já presentes no projeto.
        // Isso restaura opções escondidas por allowed_pages incompleto sem alterar o banco.
        return true;
    }
    return false;
}

function getMemberGroups() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `member_groups` ORDER BY `group_id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["group_id"])] = $row;
        }
    }
    return $return;
}

function getMemberGroup($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `member_groups` WHERE `group_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getRegisteredUsernames() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT `id`, `username` FROM `reg_users` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["id"])] = $row["username"];
        }
    }
    return $return;
}

function getOutputs($rUser=null) {
    global $db;
    $return = Array();
    if ($rUser) {
        $result = $db->query("SELECT `access_output_id` FROM `user_output` WHERE `user_id` = ".intval($rUser).";");
    } else {
        $result = $db->query("SELECT * FROM `access_output` ORDER BY `access_output_id` ASC;");
    }
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            if ($rUser) {
                $return[] = $row["access_output_id"];
            } else {
                $return[] = $row;
            }
        }
    }
    return $return;
}

function getUserBouquets() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT `id`, `bouquet` FROM `users` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["id"])] = $row;
        }
    }
    return $return;
}

function getBouquets() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `bouquets` ORDER BY `bouquet_order` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["id"])] = $row;
        }
    }
    return $return;
}

function getBouquetOrder() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `bouquets` ORDER BY `bouquet_order` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["id"])] = $row;
        }
    }
    return $return;
}

function getBouquet($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `bouquets` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getLanguages() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `languages` ORDER BY `key` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function addToBouquet($rType, $rBouquetID, $rID) {
    global $db;
    $rBouquet = getBouquet($rBouquetID);
    if ($rBouquet) {
        if ($rType == "stream") {
            $rColumn = "bouquet_channels";
        } else {
            $rColumn = "bouquet_series";
        }
        $rChannels = json_decode($rBouquet[$rColumn], True);
        if (!in_array($rID, $rChannels)) {
            $rChannels[] = $rID;
            if (count($rChannels) > 0) {
                $db->query("UPDATE `bouquets` SET `".ESC($rColumn)."` = '".ESC(json_encode(array_values($rChannels)))."' WHERE `id` = ".intval($rBouquetID).";");
            }
        }
    }
}

function removeFromBouquet($rType, $rBouquetID, $rID) {
    global $db;
    $rBouquet = getBouquet($rBouquetID);
    if ($rBouquet) {
        if ($rType == "stream") {
            $rColumn = "bouquet_channels";
        } else {
            $rColumn = "bouquet_series";
        }
        $rChannels = json_decode($rBouquet[$rColumn], True);
        if (($rKey = array_search($rID, $rChannels)) !== false) {
            unset($rChannels[$rKey]);
            $db->query("UPDATE `bouquets` SET `".ESC($rColumn)."` = '".ESC(json_encode(array_values($rChannels)))."' WHERE `id` = ".intval($rBouquetID).";");
        }
    }
}

function getPackages($rGroup=null) {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `packages` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            if ((!isset($rGroup)) OR (in_array(intval($rGroup), json_decode($row["groups"], True)))) {
                $return[intval($row["id"])] = $row;
            }
        }
    }
    return $return;
}

function getPackage($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `packages` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getTranscodeProfile($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `transcoding_profiles` WHERE `profile_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getUserAgent($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `blocked_user_agents` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getISP($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `isp_addon` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getBlockedIP($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `blocked_ips` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getRTMPIP($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `rtmp_ips` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getEPGs() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `epg` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["id"])] = $row;
        }
    }
    return $return;
}

function getCategories($rType="live") {
    global $db;
    static $requestCache = array();
    $cacheKey = $rType === false || $rType === null ? '__all__' : (string) $rType;
    if (array_key_exists($cacheKey, $requestCache)) return $requestCache[$cacheKey];
    $return = Array();
    if ($rType) {
        $result = $db->query("SELECT * FROM `stream_categories` WHERE `category_type` = '".ESC($rType)."' ORDER BY `cat_order` ASC;");
    } else {
        $result = $db->query("SELECT * FROM `stream_categories` ORDER BY `cat_order` ASC;");
    }
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["id"])] = $row;
        }
    }
    $requestCache[$cacheKey] = $return;
    return $return;
}

function getChannels($rType="live") {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `stream_categories` WHERE `category_type` = '".ESC($rType)."' ORDER BY `cat_order` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["id"])] = $row;
        }
    }
    return $return;
}

function getChannelsByID($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `streams` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return False;
}

function getCategory($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `stream_categories` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return False;
}

function getStreamProviders() {
    global $db;
    return $db->query("SELECT * FROM `streams_providers` ORDER BY `provider_id` ASC");
}

function getStreamProvider($providerID) {
    global $db;
    $result = $db->query("SELECT * FROM `streams_providers` WHERE `provider_id` = ".intval($providerID).";");
    return $result->fetch_assoc();
}

function insertProviderDNS($providerName,$providerURL,$user,$pass) {
    global $db;
    $db->query("INSERT INTO streams_providers(provider_name, provider_dns,username,password) VALUES ('$providerName','$providerURL','$user','$pass')");
  }

function updateProviderDNS($providerID,$providerName,$providerURL){
  global $db;
  $db->query("UPDATE `streams_providers` SET  `provider_name` ='$providerName', `provider_dns`='$providerURL' WHERE `provider_id` ='$providerID'");
  }

function deleteProviderDNS($providerID){
    global $db;
    $result = $db->query("DELETE FROM `streams_providers` WHERE `provider_id` = ".intval($providerID).";");
	return false;
    if($result) {
        return true;
    }
  }
  
function getMag($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `mag_devices` WHERE `mag_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        $row = $result->fetch_assoc();
        $result = $db->query("SELECT `pair_id` FROM `users` WHERE `id` = ".intval($row["user_id"]).";");
        if (($result) && ($result->num_rows == 1)) {
            $magrow = $result->fetch_assoc();
            $row["paired_user"] = $magrow["pair_id"];
            $row["username"] = getUser($row["paired_user"])["username"];
        }
        return $row;
    }
    return Array();
}

function getEnigma($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `enigma2_devices` WHERE `device_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        $row = $result->fetch_assoc();
        $result = $db->query("SELECT `pair_id` FROM `users` WHERE `id` = ".intval($row["user_id"]).";");
        if (($result) && ($result->num_rows == 1)) {
            $e2row = $result->fetch_assoc();
            $row["paired_user"] = $e2row["pair_id"];
            $row["username"] = getUser($row["paired_user"])["username"];
        }
        return $row;
    }
    return Array();
}

function getMAGUser($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `mag_devices` WHERE `user_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return "";
}

function getMAGLockDevice($rID) {
    global $db;
    $result = $db->query("SELECT `lock_device` FROM `mag_devices` WHERE `user_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc()["lock_device"];
    }
    return "";
}

function getE2User($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `enigma2_devices` WHERE `user_id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return "";
}

function getTicket($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `tickets` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows > 0)) {
        $row = $result->fetch_assoc();
        $row["replies"] = Array();
        $row["title"] = htmlspecialchars($row["title"]);
        $result = $db->query("SELECT * FROM `tickets_replies` WHERE `ticket_id` = ".intval($rID)." ORDER BY `date` ASC;");
        while ($reply = $result->fetch_assoc()) {
            // Hack to fix display issues on short text.
            $reply["message"] = htmlspecialchars($reply["message"]);
            if (strlen($reply["message"]) < 80) {
                $reply["message"] .= str_repeat("&nbsp; ", 80-strlen($reply["message"]));
            }
            $row["replies"][] = $reply;
        }
        $row["user"] = getRegisteredUser($row["member_id"]);
        return $row;
    }
    return null;
}

function getExpiring($rID) {
	global $db;
	$rAvailableMembers = array_keys(getRegisteredUsers($rID));
	$return = Array();
	$result = $db->query("SELECT `id`, `member_id`, `username`, `password`, `exp_date` FROM `users` WHERE `member_id` IN (".ESC(join(",", $rAvailableMembers)).") AND `exp_date` >= UNIX_TIMESTAMP() ORDER BY `exp_date` ASC LIMIT 100;");
	if (($result) && ($result->num_rows > 0)) {
		while ($row = $result->fetch_assoc()) {
			$return[] = $row;
		}
	}
	return $return;
}

function getTickets($rID=null) {
    global $db;
    $return = Array();
    if ($rID) {
        $result = $db->query("SELECT `tickets`.`id`, `tickets`.`member_id`, `tickets`.`title`, `tickets`.`status`, `tickets`.`admin_read`, `tickets`.`user_read`, `reg_users`.`username` FROM `tickets`, `reg_users` WHERE `member_id` = ".intval($rID)." AND `reg_users`.`id` = `tickets`.`member_id` ORDER BY `id` DESC;");
    } else {
        $result = $db->query("SELECT `tickets`.`id`, `tickets`.`member_id`, `tickets`.`title`, `tickets`.`status`, `tickets`.`admin_read`, `tickets`.`user_read`, `reg_users`.`username` FROM `tickets`, `reg_users` WHERE `reg_users`.`id` = `tickets`.`member_id` ORDER BY `id` DESC;");
    }
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $dateresult = $db->query("SELECT MIN(`date`) AS `date` FROM `tickets_replies` WHERE `ticket_id` = ".intval($row["id"])." AND `admin_reply` = 0;");
            if ($rDate = $dateresult->fetch_assoc()["date"]) {
                $row["created"] = date("Y-m-d H:i", $rDate);
            } else {
                $row["created"] = "";
            }
            $dateresult = $db->query("SELECT MAX(`date`) AS `date` FROM `tickets_replies` WHERE `ticket_id` = ".intval($row["id"])." AND `admin_reply` = 1;");
            if ($rDate = $dateresult->fetch_assoc()["date"]) {
                $row["last_reply"] = date("Y-m-d H:i", $rDate);
            } else {
                $row["last_reply"] = "";
            }
            if ($row["status"] <> 0) {
                if ($row["user_read"] == 0) {
                    $row["status"] = 2;
                }
                if ($row["admin_read"] == 1) {
                    $row["status"] = 3;
                }
            }
            $return[] = $row;
        }
    }
    return $return;
}

function checkTrials() {
    global $db, $rPermissions, $rUserInfo;
    $rTotal = $rPermissions["total_allowed_gen_trials"];
    if ($rTotal > 0) {
        $rTotalIn = $rPermissions["total_allowed_gen_in"];
        if ($rTotalIn == "hours") {
            $rTime = time() - (intval($rTotal) * 3600);
        } else {
            $rTime = time() - (intval($rTotal) * 3600 * 24);
        }
        $result = $db->query("SELECT COUNT(`id`) AS `count` FROM `users` WHERE `member_id` = ".intval($rUserInfo["id"])." AND `created_at` >= ".$rTime." AND `is_trial` = 1;");
        return $result->fetch_assoc()["count"] < $rTotal;
    }
    return false;
}

function cryptPassword($password, $salt="xtreamcodes", $rounds=20000) {
    if ($salt == "") {
        $salt = substr(bin2hex(openssl_random_pseudo_bytes(16)),0,16);
    }
    $hash = crypt($password, sprintf('$6$rounds=%d$%s$', $rounds, $salt));
    return $hash;
}

function getIP(){
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } else if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function getID() {
	if (file_exists(MAIN_DIR."adtools/settings.json")) {
		return json_decode(file_get_contents(MAIN_DIR."adtools/settings.json"), True)["rid"];
	}
	return 0;
}

function getPermissions($rID) {
    global $db;
    static $requestCache = array();
    $id = intval($rID);
    if ($id <= 0) return null;
    if (array_key_exists($id, $requestCache)) return $requestCache[$id];
    $stmt = $db->prepare("SELECT * FROM `member_groups` WHERE `group_id` = ? LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = ($result && $result->num_rows === 1) ? $result->fetch_assoc() : null;
    $stmt->close();
    if (is_array($row)) {
        // Normaliza flags sem alterar o banco. Evita que NULL/string cause bloqueio indevido.
        foreach (["is_admin", "is_reseller", "is_banned", "delete_users", "allow_download", "create_sub_resellers", "reseller_can_select_bouquets"] as $flag) {
            if (array_key_exists($flag, $row)) $row[$flag] = intval($row[$flag]);
        }
        $allowed = json_decode((string)($row["allowed_pages"] ?? "[]"), true);
        $row["advanced"] = is_array($allowed) ? $allowed : [];
    }
    $requestCache[$id] = $row;
    return $requestCache[$id];
}

/**
 * Determina o bloqueio efetivo do grupo para acesso ao painel.
 *
 * Compatibilidade CS Player/Xtream: no schema oficial deste projeto o grupo
 * 3 (Banned) é o grupo de bloqueio, enquanto o grupo 4 (Resellers) é o papel
 * padrão de revenda. Algumas versões antigas do editor de grupos puderam
 * persistir is_banned=1 no grupo 4; isso bloquearia TODOS os revendedores.
 * Mantemos o valor bruto no banco e neutralizamos somente essa combinação
 * canônica em tempo de execução, sem alterar schema ou dados.
 */
function csIsPanelGroupBanned($permissions) {
    if (!is_array($permissions)) {
        return true;
    }

    $rawBanned = intval($permissions['is_banned'] ?? 0) === 1;
    if (!$rawBanned) {
        return false;
    }

    $groupId = intval($permissions['group_id'] ?? 0);
    $isAdmin = intval($permissions['is_admin'] ?? 0) === 1;
    $isReseller = intval($permissions['is_reseller'] ?? 0) === 1;
    $groupName = strtolower(trim((string)($permissions['group_name'] ?? '')));

    // Compatibilidade específica com o grupo padrão de revendas do schema.
    // O grupo Banned continua bloqueado normalmente.
    if ($groupId === 4 && !$isAdmin && $isReseller && in_array($groupName, ['resellers', 'revendas', 'revendedores', 'reseller'], true)) {
        return false;
    }

    return true;
}

function csVerifyPanelPassword($plainPassword, $storedHash) {
    $plainPassword = (string)$plainPassword;
    $storedHash = (string)$storedHash;
    if ($storedHash === "") return false;

    // Hash padrão histórico do Xtream/CS Player.
    if (hash_equals($storedHash, (string)cryptPassword($plainPassword))) return true;

    // Compatibilidade com contas que já tenham sido gravadas por password_hash().
    if ((strpos($storedHash, '$2y$') === 0 || strpos($storedHash, '$2a$') === 0 || strpos($storedHash, '$argon2') === 0)
        && function_exists('password_verify') && password_verify($plainPassword, $storedHash)) {
        return true;
    }
    return false;
}

function csClientEmailAliasFile() {
    return __DIR__ . '/player/data/client_email_aliases.json';
}

function csClientEmailAliases() {
    $file = csClientEmailAliasFile();
    if (!is_file($file)) return array();
    $data = json_decode((string)@file_get_contents($file), true);
    return is_array($data) ? $data : array();
}

function csGetClientLoginEmail($userId) {
    $aliases = csClientEmailAliases();
    return trim((string)($aliases[(string)intval($userId)] ?? ''));
}

function csSaveClientLoginEmail($userId, $email) {
    $userId = intval($userId);
    $email = strtolower(trim((string)$email));
    if ($userId <= 0) return false;
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) return false;
    $aliases = csClientEmailAliases();
    if ($email !== '') {
        foreach ($aliases as $id => $value) {
            if ((int)$id !== $userId && strtolower(trim((string)$value)) === $email) return false;
        }
        $aliases[(string)$userId] = $email;
    } else {
        unset($aliases[(string)$userId]);
    }
    $file = csClientEmailAliasFile();
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) return false;
    $tmp = $file . '.tmp';
    $json = json_encode($aliases, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    return @rename($tmp, $file);
}

function doLogin($rUsername, $rPassword) {
    global $db;
    $login = trim((string)$rUsername);
    $stmt = $db->prepare("SELECT `id`, `username`, `email`, `password`, `member_group_id`, `google_2fa_sec`, `status` FROM `reg_users` WHERE `username` = ? OR LOWER(`email`) = LOWER(?) LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param("ss", $login, $login);
    $stmt->execute();
    $result = $stmt->get_result();
    $rRow = ($result && $result->num_rows === 1) ? $result->fetch_assoc() : null;
    $stmt->close();
    if ($rRow && csVerifyPanelPassword($rPassword, $rRow["password"] ?? "")) return $rRow;
    return null;
}

function getSubresellerSetups() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `subreseller_setup` ORDER BY `id` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["id"])] = $row;
        }
    }
    return $return;
}

function getSubresellerSetup($rID) {
    global $db;
    $result = $db->query("SELECT * FROM `subreseller_setup` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        return $result->fetch_assoc();
    }
    return null;
}

function getEpisodeParents() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT `series_episodes`.`stream_id`, `series`.`id`, `series`.`title` FROM `series_episodes` LEFT JOIN `series` ON `series`.`id` = `series_episodes`.`series_id`;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["stream_id"])] = $row;
        }
    }
    return $return;
}

function getSeriesList() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT `id`, `title` FROM `series` ORDER BY `title` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[intval($row["id"])] = $row;
        }
    }
    return $return;
}

function checkTable($rTable) {
    global $db;
    $rTableQuery = Array(
        "subreseller_setup" => Array("CREATE TABLE `subreseller_setup` (`id` int(11) NOT NULL AUTO_INCREMENT, `reseller` int(8) NOT NULL DEFAULT '0', `subreseller` int(8) NOT NULL DEFAULT '0', `status` int(1) NOT NULL DEFAULT '1', `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;"),
        "admin_settings" => Array("CREATE TABLE `admin_settings` (`type` varchar(128) NOT NULL DEFAULT '', `value` varchar(4096) NOT NULL DEFAULT '', PRIMARY KEY (`type`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;"),
        "watch_folders" => Array("CREATE TABLE `watch_folders` (`id` int(11) NOT NULL AUTO_INCREMENT, `type` varchar(32) NOT NULL DEFAULT '', `directory` varchar(2048) NOT NULL DEFAULT '', `server_id` int(8) NOT NULL DEFAULT '0', `category_id` int(8) NOT NULL DEFAULT '0', `bouquets` varchar(4096) NOT NULL DEFAULT '[]', `last_run` int(32) NOT NULL DEFAULT '0', `active` int(1) NOT NULL DEFAULT '1', PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;"),
        "tmdb_async" => Array("CREATE TABLE `tmdb_async` (`id` int(11) NOT NULL AUTO_INCREMENT, `type` int(1) NOT NULL DEFAULT '0', `stream_id` int(16) NOT NULL DEFAULT '0', `status` int(8) NOT NULL DEFAULT '0', `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;"),
        "watch_settings" => Array("CREATE TABLE `watch_settings` (`read_native` int(1) NOT NULL DEFAULT '1', `movie_symlink` int(1) NOT NULL DEFAULT '1', `auto_encode` int(1) NOT NULL DEFAULT '0', `transcode_profile_id` int(8) NOT NULL DEFAULT '0', `scan_seconds` int(8) NOT NULL DEFAULT '3600') ENGINE=InnoDB DEFAULT CHARSET=latin1;", "INSERT INTO `watch_settings` (`read_native`, `movie_symlink`, `auto_encode`, `transcode_profile_id`, `scan_seconds`) VALUES(1, 1, 0, 0, 3600);"),
        "watch_categories" => Array("CREATE TABLE `watch_categories` (`id` int(11) NOT NULL AUTO_INCREMENT, `type` int(1) NOT NULL DEFAULT '0', `genre_id` int(8) NOT NULL DEFAULT '0', `genre` varchar(64) NOT NULL DEFAULT '', `category_id` int(8) NOT NULL DEFAULT '0', `bouquets` varchar(4096) NOT NULL DEFAULT '[]', PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1", "INSERT INTO `watch_categories` (`id`, `type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES (1, 1, 28, 'Action', 0, '[]'), (2, 1, 12, 'Adventure', 0, '[]'), (3, 1, 16, 'Animation', 0, '[]'), (4, 1, 35, 'Comedy', 0, '[]'), (5, 1, 80, 'Crime', 0, '[]'), (6, 1, 99, 'Documentary', 0, '[]'), (7, 1, 18, 'Drama', 0, '[]'), (8, 1, 10751, 'Family', 0, '[]'), (9, 1, 14, 'Fantasy', 0, '[]'), (10, 1, 36, 'History', 0, '[]'), (11, 1, 27, 'Horror', 0, '[]'), (12, 1, 10402, 'Music', 0, '[]'), (13, 1, 9648, 'Mystery', 0, '[]'), (14, 1, 10749, 'Romance', 0, '[]'), (15, 1, 878, 'Science Fiction', 0, '[]'), (16, 1, 10770, 'TV Movie', 0, '[]'), (17, 1, 53, 'Thriller', 0, '[]'), (18, 1, 10752, 'War', 0, '[]'), (19, 1, 37, 'Western', 0, '[]');"),
        "watch_output" => Array("CREATE TABLE `watch_output` (`id` int(11) NOT NULL AUTO_INCREMENT, `type` int(1) NOT NULL DEFAULT '0', `server_id` int(8) NOT NULL DEFAULT '0', `filename` varchar(4096) NOT NULL DEFAULT '', `status` int(1) NOT NULL DEFAULT '0', `stream_id` int(8) NOT NULL DEFAULT '0', `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;"),
		"login_flood" => Array("CREATE TABLE `login_flood` (`id` int(11) NOT NULL AUTO_INCREMENT, `username` varchar(128) NOT NULL DEFAULT '', `ip` varchar(64) NOT NULL DEFAULT '', `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;"),
        //"languages" => Array("CREATE TABLE `languages` (`key` varchar(128) NOT NULL DEFAULT '', `language` varchar(4096) NOT NULL DEFAULT '', PRIMARY KEY (`key`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;", "INSERT INTO `languages`(`key`, `language`) VALUES('en', 'English'), ('es', 'Español'), ('it', 'Italiano'), ('fr', 'Français'), ('pt, 'Português');"),
		"dashboard_statistics" => Array("CREATE TABLE `dashboard_statistics` (`id` int(11) NOT NULL AUTO_INCREMENT, `type` varchar(16) NOT NULL DEFAULT '', `time` INT(16) NOT NULL DEFAULT '0', `count` INT(16) NOT NULL DEFAULT '0', PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;"),
		"panel_logs" => Array("CREATE TABLE IF NOT EXISTS `panel_logs` (`id` int(11) NOT NULL AUTO_INCREMENT, `log_message` text NOT NULL, `date` int(11) NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17221 ;"),
    );
    if ((!$db->query("DESCRIBE `".ESC($rTable)."`;")) && (isset($rTableQuery[$rTable]))) {
        // Doesn't exist! Create it.
        foreach ($rTableQuery[$rTable] as $rQuery) {
            $db->query($rQuery);
        }
    }
}

function secondsToTime($inputSeconds) {
    $secondsInAMinute = 60;
    $secondsInAnHour  = 60 * $secondsInAMinute;
    $secondsInADay    = 24 * $secondsInAnHour;
    $days = floor($inputSeconds / $secondsInADay);
    $hourSeconds = $inputSeconds % $secondsInADay;
    $hours = floor($hourSeconds / $secondsInAnHour);
    $minuteSeconds = $hourSeconds % $secondsInAnHour;
    $minutes = floor($minuteSeconds / $secondsInAMinute);
    $remainingSeconds = $minuteSeconds % $secondsInAMinute;
    $seconds = ceil($remainingSeconds);
    $obj = array(
        'd' => (int) $days,
        'h' => (int) $hours,
        'm' => (int) $minutes,
        's' => (int) $seconds,
    );
    return $obj;
}

function getWorldMapLive() {
    global $db;
         $rQuery = "SELECT geoip_country_code, count(geoip_country_code) AS total FROM user_activity_now GROUP BY geoip_country_code";
        if ($rResult = $db->query($rQuery)) {
            while ($row = $rResult->fetch_assoc()) {
				$WorldMapLive = "{\"code\":".json_encode($row["geoip_country_code"]).",\"value\":".json_encode($row["total"])."},";
                                   echo $WorldMapLive;
            }

        }
    }
    
function getWorldMapActivity() {
    global $db;
         $rQuery = "SELECT DISTINCT geoip_country_code, COUNT(DISTINCT user_id) AS total FROM user_activity GROUP BY geoip_country_code";
        if ($rResult = $db->query($rQuery)) {
            while ($row = $rResult->fetch_assoc()) {
				$WorldMapActivity = "{\"code\":".json_encode($row["geoip_country_code"]).",\"value\":".json_encode($row["total"])."},";
                                   echo $WorldMapActivity;
            }

        }
    }

function getWorldMapTotalActivity() {
    global $db;
    $rQuery = "SELECT geoip_country_code, count(geoip_country_code) AS total FROM user_activity GROUP BY geoip_country_code";
    if ($rResult = $db->query($rQuery)) {
        while ($row = $rResult->fetch_assoc()) {
			$WorldMapTotalActivity = "{\"code\":".json_encode($row["geoip_country_code"]).",\"value\":".json_encode($row["total"])."},";
             echo $WorldMapTotalActivity;
        }
    }
}

function writeAdminSettings() {
    global $rAdminSettings, $db;
    foreach ($rAdminSettings as $rKey => $rValue) {
        if (strlen($rKey) > 0) {
            $db->query("REPLACE INTO `admin_settings`(`type`, `value`) VALUES('".ESC($rKey)."', '".ESC($rValue)."');");
        }
    }
}

function writeStreamArguments() {
    global $rStreamArguments, $db;
    if (!is_array($rStreamArguments)) { return; }
    foreach ($rStreamArguments as $rKey => $rValue) {
        if (strlen((string)$rKey) === 0) { continue; }
        if (is_array($rValue)) {
            $rValue = $rValue['argument_default_value'] ?? '';
        }
        $db->query("UPDATE `streams_arguments` SET `argument_default_value`='".ESC((string)$rValue)."' WHERE `argument_key`='".ESC((string)$rKey)."';");
    }
}

function downloadImage($rImage) {
    if ((strlen($rImage) > 0) && (substr(strtolower($rImage), 0, 4) == "http")) {
        $rPathInfo = pathinfo($rImage);
        $rExt = $rPathInfo["extension"];
        if (in_array(strtolower($rExt), Array("jpg", "jpeg", "png"))) {
            $rPrevPath = MAIN_DIR . "wwwdir/images/".$rPathInfo["filename"].".".$rExt;
			if (file_exists($rPrevPath)) { 
				return getURL()."/images/".$rPathInfo["filename"].".".$rExt;
			} else {
				$rCont = stream_context_create(array('http'=> array('timeout' => 10, 'method' => "GET")));
				$rData = file_get_contents($rImage, false, $rCont);
				if (strlen($rData) > 0) {
                    $rFilename = md5($rPathInfo["filename"]);
                    $rPath = MAIN_DIR . "wwwdir/images/".$rFilename.".".$rExt;
					file_put_contents($rPath, $rData);
					if (strlen(file_get_contents($rPath)) == strlen($rData)) {
						return getURL()."/images/".$rFilename.".".$rExt;
					}
				}
			}
        }
    }
    return $rImage;
}

function updateSeries($rID) {
    global $db, $rSettings, $rAdminSettings;
    require_once("tmdb.php");
    $result = $db->query("SELECT `tmdb_id` FROM `series` WHERE `id` = ".intval($rID).";");
    if (($result) && ($result->num_rows == 1)) {
        $rTMDBID = $result->fetch_assoc()["tmdb_id"];
        if (strlen($rTMDBID) > 0) {
            if (strlen($rAdminSettings["tmdb_language"]) > 0) {
                $rTMDB = new TMDB($rSettings["tmdb_api_key"], $rAdminSettings["tmdb_language"]);
            } else {
                $rTMDB = new TMDB($rSettings["tmdb_api_key"]);
            }
            $rReturn = Array();
            $rSeasons = json_decode($rTMDB->getTVShow($rTMDBID)->getJSON(), True)["seasons"];
            foreach ($rSeasons as $rSeason) {
                if ($rAdminSettings["download_images"]) {
                    $rSeason["cover"] = downloadImage("https://image.tmdb.org/t/p/w600_and_h900_bestv2".$rSeason["poster_path"]);
                } else {
                    $rSeason["cover"] = "https://image.tmdb.org/t/p/w600_and_h900_bestv2".$rSeason["poster_path"];
                }
                $rSeason["cover_big"] = $rSeason["cover"];
                unset($rSeason["poster_path"]);
                $rReturn[] = $rSeason;
            }
            $db->query("UPDATE `series` SET `seasons` = '".ESC(json_encode($rReturn))."', `last_modified` = ".intval(time())." WHERE `id` = ".intval($rID).";");
        }
    }
}

function getFooter() {
    // Don't be a dick. Leave it.
    global $rAdminSettings, $rPermissions, $rSettings, $rRelease, $_;
    if ($rPermissions["is_admin"]) {
		return "CS PLAYER &copy; 2022 - " . date("Y") . " &middot; Painel de gerenciamento";
    } else {
        return $rSettings["copyrights_text"];
    }
}


function getURL() {
    global $rServers, $_INFO;
    if (strlen($rServers[$_INFO["server_id"]]["domain_name"]) > 0) {
        return "http://".$rServers[$_INFO["server_id"]]["domain_name"].":".$rServers[$_INFO["server_id"]]["http_broadcast_port"];
    } else if (strlen($rServers[$_INFO["server_id"]]["vpn_ip"]) > 0) {
        return "http://".$rServers[$_INFO["server_id"]]["vpn_ip"].":".$rServers[$_INFO["server_id"]]["http_broadcast_port"];
    } else {
        return "http://".$rServers[$_INFO["server_id"]]["server_ip"].":".$rServers[$_INFO["server_id"]]["http_broadcast_port"];
    }
}

function scanBouquets() {
    global $db;
    $rStreamIDs = Array(0 => Array(), 1 => Array());
    $result = $db->query("SELECT `id` FROM `streams`;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $rStreamIDs[0][] = intval($row["id"]);
        }
    }
    $result = $db->query("SELECT `id` FROM `series`;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $rStreamIDs[1][] = intval($row["id"]);
        }
    }
    foreach (getBouquets() as $rID => $rBouquet) {
        $rUpdate = Array(0 => Array(), 1 => Array());
        foreach (json_decode($rBouquet["bouquet_channels"], True) as $rID) {
            if (in_array(intval($rID), $rStreamIDs[0])) {
                $rUpdate[0][] = intval($rID);
            }
        }
        foreach (json_decode($rBouquet["bouquet_series"], True) as $rID) {
            if (in_array(intval($rID), $rStreamIDs[1])) {
                $rUpdate[1][] = intval($rID);
            }
        }
        $db->query("UPDATE `bouquets` SET `bouquet_channels` = '".ESC(json_encode($rUpdate[0]))."', `bouquet_series` = '".ESC(json_encode($rUpdate[1]))."' WHERE `id` = ".intval($rBouquet["id"]).";");
    }
}

function scanBouquet($rID) {
    global $db;
    $rBouquet = getBouquet($rID);
    if ($rBouquet) {
        $rStreamIDs = Array();
        $result = $db->query("SELECT `id` FROM `streams`;");
        if (($result) && ($result->num_rows > 0)) {
            while ($row = $result->fetch_assoc()) {
                $rStreamIDs[0][] = intval($row["id"]);
            }
        }
        $result = $db->query("SELECT `id` FROM `series`;");
        if (($result) && ($result->num_rows > 0)) {
            while ($row = $result->fetch_assoc()) {
                $rStreamIDs[1][] = intval($row["id"]);
            }
        }
        $rUpdate = Array(0 => Array(), 1 => Array());
        foreach (json_decode($rBouquet["bouquet_channels"], True) as $rID) {
            if (in_array(intval($rID), $rStreamIDs[0])) {
                $rUpdate[0][] = intval($rID);
            }
        }
        foreach (json_decode($rBouquet["bouquet_series"], True) as $rID) {
            if (in_array(intval($rID), $rStreamIDs[1])) {
                $rUpdate[1][] = intval($rID);
            }
        }
        $db->query("UPDATE `bouquets` SET `bouquet_channels` = '".ESC(json_encode($rUpdate[0]))."', `bouquet_series` = '".ESC(json_encode($rUpdate[1]))."' WHERE `id` = ".intval($rBouquet["id"]).";");
    }
}

function getNextOrder() {
    global $db;
    $result = $db->query("SELECT MAX(`order`) AS `order` FROM `streams`;");
    if (($result) && ($result->num_rows == 1)) {
        return intval($result->fetch_assoc()["order"]) + 1;
    }
    return 0;
}

function generateSeriesPlaylist($rSeriesNo) {
    global $db, $rServers, $rSettings;
    $rReturn = Array("success" => false, "sources" => Array(), "server_id" => 0);
    $result = $db->query("SELECT `stream_id` FROM `series_episodes` WHERE `series_id` = ".intval($rSeriesNo)." ORDER BY `season_num` ASC, `sort` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $resultB = $db->query("SELECT `stream_source` FROM `streams` WHERE `id` = ".intval($row["stream_id"]).";");
            if (($resultB) && ($resultB->num_rows > 0)) {
                $rSource = json_decode($resultB->fetch_assoc()["stream_source"], True)[0];
                $rSplit = explode(":", $rSource);
                $rFilename = join(":", array_slice($rSplit, 2, count($rSplit)-2));
                $rServerID = intval($rSplit[1]);
                if ($rReturn["server_id"] == 0) {
                    $rReturn["server_id"] = $rServerID;
                    $rReturn["success"] = true;
                }
                if ($rReturn["server_id"] <> $rServerID) {
                    $rReturn["success"] = false;
                    break;
                }
                $rReturn["sources"][] = $rFilename;
            }
        }
    }
    return $rReturn;
}

function flushIPs() {
    global $db, $rServers;
    $rCommand = "sudo /sbin/iptables -P INPUT ACCEPT && sudo /sbin/iptables -P OUTPUT ACCEPT && sudo /sbin/iptables -P FORWARD ACCEPT && sudo /sbin/iptables -F";
    foreach ($rServers as $rServer) {
        sexec($rServer["id"], $rCommand);
    }
    $db->query("DELETE FROM `blocked_ips`;");
}

function flushLogins() {
    global $db;
    $db->query("DELETE FROM `login_flood`;");
}

function flushActivity() {
    global $db;
    $db->query("DELETE FROM `user_activity`;");
}

function flushActivitynow() {
    global $db;
    $db->query("DELETE FROM `user_activity_now`;");
}

function flushPanelogs() {
    global $db;
    $db->query("DELETE FROM `panel_logs`;");
}

function flushStlogs() {
    global $db;
    $db->query("DELETE FROM `stream_logs`;");
}

function flushClientlogs() {
    global $db;
    $db->query("DELETE FROM `client_logs`;");
}

function flushMagclaims() {
    global $db;
    $db->query("DELETE FROM `mag_claims`;");
}

function flushMaglogs() {
    global $db;
    $db->query("DELETE FROM `mag_logs`;");
}

function flushEvents() {
    global $db;
    $db->query("DELETE FROM `mag_events`;");
}

function lockIsp() {
    global $db;
    $db->query("UPDATE `users` SET `is_isplock` = 1;");
}

function unlockIsp() {
    global $db;
    $db->query("UPDATE `users` SET `is_isplock` = 0;");
}

function lockStb() {
    global $db;
    $db->query("UPDATE `mag_devices` SET `lock_device` = 1;");
}

function unlockStb() {
    global $db;
    $db->query("UPDATE `mag_devices` SET `lock_device` = 0;");
}

function clearIsp() {
    global $db;
    $db->query("UPDATE `users` SET `isp_desc` = NULL;");
}

function flushLoginlogs() {
    global $db;
    $db->query("DELETE FROM `login_users`;");
}

/*function flushDuplicateMovies() {
    global $db;
    return $db->query("DELETE from streams where type = 2 and exists ( select 1 from ( select stream_display_name as display_name, count(1) as c from streams as d where type = 2 group by stream_display_name ) as a where c > 1  and a.display_name = stream_display_name) and id not in (select max(x.id) from ( select stream_display_name as display_name, count(1) as c from streams as d where type = 2 group by stream_display_name ) as a inner join (select * from streams where type= 2) as x on x.stream_display_name = a.display_name where c > 1  and a.display_name = streams.stream_display_name);");
}*/

function flushWatchFolder() {
    global $db;
    $db->query("DELETE FROM `watch_output`;");
}

function flushTmdbAsync() {
    global $db;
    $db->query("DELETE FROM `tmdb_async`;");
}

function updateTables() {
    global $db;
    // Update table settings etc.
    checkTable("tmdb_async");
    checkTable("subreseller_setup");
    checkTable("admin_settings");
    checkTable("watch_folders");
    checkTable("watch_settings");
    checkTable("watch_categories");
    checkTable("watch_output");
	checkTable("login_flood");
	checkTable("panel_logs");
//    checkTable("languages");
	checkTable("settings");
    // R19 Early Access
    $rResult = $db->query("SHOW COLUMNS FROM `watch_folders` LIKE 'bouquets';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `watch_folders` ADD COLUMN `category_id` int(8) NOT NULL DEFAULT '0';");
        $db->query("ALTER TABLE `watch_folders` ADD COLUMN `bouquets` varchar(4096) NOT NULL DEFAULT '[]';");
    }
    $rResult = $db->query("SHOW COLUMNS FROM `watch_settings` LIKE 'percentage_match';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `watch_settings` ADD COLUMN `percentage_match` int(3) NOT NULL DEFAULT '70';");
        $db->query("ALTER TABLE `watch_settings` ADD COLUMN `ffprobe_input` int(1) NOT NULL DEFAULT '0';");
    }
    $rResult = $db->query("SHOW COLUMNS FROM `watch_folders` LIKE 'disable_tmdb';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `watch_folders` ADD COLUMN `disable_tmdb` int(1) NOT NULL DEFAULT '0';");
        $db->query("ALTER TABLE `watch_folders` ADD COLUMN `ignore_no_match` int(1) NOT NULL DEFAULT '0';");
        $db->query("ALTER TABLE `watch_folders` ADD COLUMN `auto_subtitles` int(1) NOT NULL DEFAULT '0';");
    }
    $rResult = $db->query("SHOW COLUMNS FROM `watch_folders` LIKE 'fb_bouquets';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `watch_folders` ADD COLUMN `fb_bouquets` VARCHAR(4096) NOT NULL DEFAULT '[]';");
        $db->query("ALTER TABLE `watch_folders` ADD COLUMN `fb_category_id` int(8) NOT NULL DEFAULT '0';");
    }
    // R19 Official
    $rResult = $db->query("SHOW COLUMNS FROM `watch_folders` LIKE 'allowed_extensions';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `watch_folders` ADD COLUMN `allowed_extensions` VARCHAR(4096) NOT NULL DEFAULT '[]';");
    }
	// R20 Official
	$db->query("UPDATE `streams_arguments` SET `argument_cmd` = '-cookies \'%s\'' WHERE `id` = 17;");
	// R21 Early Access
	$db->query("INSERT IGNORE INTO `streams_arguments` VALUES (19, 'fetch', 'Headers', 'Set Custom Headers', 'http', 'headers', '-headers \"%s\"', 'text', NULL);");
	$rResult = $db->query("SHOW COLUMNS FROM `reg_users` LIKE 'dark_mode';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `reg_users` ADD COLUMN `dark_mode` int(1) NOT NULL DEFAULT '0';");
		$db->query("ALTER TABLE `reg_users` ADD COLUMN `sidebar` int(1) NOT NULL DEFAULT '0';");
    }
	$rResult = $db->query("SHOW COLUMNS FROM `member_groups` LIKE 'minimum_trial_credits';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `member_groups` ADD COLUMN `minimum_trial_credits` int(16) NOT NULL DEFAULT '0';");
    }
    // R22 Early Access
    $rResult = $db->query("SHOW COLUMNS FROM `bouquets` LIKE 'bouquet_order';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `bouquets` ADD COLUMN `bouquet_order` int(16) NOT NULL DEFAULT '0';");
    }
	$rResult = $db->query("SHOW COLUMNS FROM `reg_users` LIKE 'expanded_sidebar';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `reg_users` ADD COLUMN `expanded_sidebar` int(1) NOT NULL DEFAULT '0';");
    }
    $rResult = $db->query("SELECT * FROM `admin_settings` WHERE `type` = 'auto_refresh';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("INSERT INTO `admin_settings`(`type`, `value`) VALUES('auto_refresh', 1);");
    }
	//logo sidebar
	$rResult = $db->query("SHOW COLUMNS FROM `settings` LIKE 'logo_url_sidebar';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `settings` ADD COLUMN `logo_url_sidebar` mediumtext NOT NULL DEFAULT '';");
    }	
	//page mannuals
	$rResult = $db->query("SHOW COLUMNS FROM `settings` LIKE 'page_mannuals';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `settings` ADD COLUMN `page_mannuals` mediumtext NOT NULL DEFAULT '';");
    }
	$rResult = $db->query("SELECT * FROM `admin_settings` WHERE `type` = 'active_mannuals';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("INSERT INTO `admin_settings`(`type`, `value`) VALUES('active_mannuals', 1);");
    }
	//resellers isplock e resetisp
	$rResult = $db->query("SELECT * FROM `admin_settings` WHERE `type` = 'reseller_can_isplock';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("INSERT INTO `admin_settings`(`type`, `value`) VALUES('reseller_can_isplock', 1);");
    }
	$rResult = $db->query("SELECT * FROM `admin_settings` WHERE `type` = 'reseller_reset_isplock';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("INSERT INTO `admin_settings`(`type`, `value`) VALUES('reseller_reset_isplock', 1);");
    }
	//disable enable show tickets on dashboard
	$rResult = $db->query("SELECT * FROM `admin_settings` WHERE `type` = 'show_tickets';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("INSERT INTO `admin_settings`(`type`, `value`) VALUES('show_tickets', 1);");
    }
	//reselers bouquets
	$rResult = $db->query("SHOW COLUMNS FROM `member_groups` LIKE 'reseller_can_select_bouquets';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `member_groups` ADD COLUMN `reseller_can_select_bouquets` int(16) NOT NULL DEFAULT '0';");
    }
	//update table streaming_servers isp
	$rResult = $db->query("SHOW COLUMNS FROM `streaming_servers` LIKE 'http_isp_port';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `streaming_servers` ADD COLUMN `http_isp_port` int(11) NOT NULL DEFAULT '8805';");
    }
	//update panel version
	$rResult = $db->query("SELECT * FROM `admin_settings` WHERE `type` = 'panel_version';");
	if (($rResult) && ($rResult->num_rows == 0)) {
	    $db->query("INSERT INTO `admin_settings`(`type`, `value`) VALUES('panel_version', 01);");
	}
	//
	$rResult = $db->query("SHOW COLUMNS FROM `settings` LIKE 'sucessedit';");
    if (($rResult) && ($rResult->num_rows == 0)) {
	    $db->query("ALTER TABLE `settings` ADD COLUMN `sucessedit` tinyint(4) NOT NULL DEFAULT '1';");
	}
    $rResult = $db->query("SHOW COLUMNS FROM `streaming_servers` LIKE 'enable_duplex';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `streaming_servers` ADD COLUMN `enable_duplex` int(11) NOT NULL DEFAULT '0';");
    }	
	//login logs delete column and add new
	$db->query("DROP TABLE IF EXISTS `login_userlogs`");
	
	$db->query("CREATE TABLE IF NOT EXISTS `login_users` (`id` int(11) NOT NULL AUTO_INCREMENT, `owner` int(11) NOT NULL, `date` int(30) NOT NULL, `login_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL, `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
	
	$db->query("CREATE TABLE IF NOT EXISTS `streams_providers` (`provider_id` int(11) NOT NULL AUTO_INCREMENT, `provider_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL, `provider_dns` varchar(255) COLLATE utf8_unicode_ci NOT NULL, `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL, `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL, PRIMARY KEY (`provider_id`), KEY `provider_name` (`provider_name`), KEY `provider_dns` (`provider_dns`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
	
    $rResult = $db->query("SHOW COLUMNS FROM `stream_categories` LIKE 'is_adult';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `stream_categories` ADD `is_adult` INT NULL DEFAULT '0' AFTER `cat_order`;");
    }
	
    $rResult = $db->query("SHOW COLUMNS FROM `settings` LIKE 'encrypt_playlist';");
    if (($rResult) && ($rResult->num_rows == 0)) {
        $db->query("ALTER TABLE `settings` ADD `encrypt_playlist` TINYINT NULL DEFAULT '1' AFTER `sucessedit`, ADD `encrypt_playlist_restreamer` TINYINT NULL DEFAULT '1' AFTER `encrypt_playlist`;");
    }
	
	//update panel http port
	$rResult = $db->query("SELECT * FROM `admin_settings` WHERE `type` = 'http_port';");
	if (($rResult) && ($rResult->num_rows == 0)) {
	    $db->query("INSERT INTO `admin_settings`(`type`, `value`) VALUES('http_port', 25500);");
	}
	
	// Update Categories
	updateTMDbCategories();
}

function updateTMDbCategories() {
    global $db, $rAdminSettings, $rSettings;
    include "tmdb.php";
    if (strlen($rAdminSettings["tmdb_language"]) > 0) {
        $rTMDB = new TMDB($rSettings["tmdb_api_key"], $rAdminSettings["tmdb_language"]);
    } else {
        $rTMDB = new TMDB($rSettings["tmdb_api_key"]);
    }
    $rCurrentCats = Array(1 => Array(), 2 => Array());
    $rResult = $db->query("SELECT `id`, `type`, `genre_id` FROM `watch_categories`;");
    if (($rResult) && ($rResult->num_rows > 0)) {
        while ($rRow = $rResult->fetch_assoc()) {
			if (in_array($rRow["genre_id"], $rCurrentCats[$rRow["type"]])) {
				$db->query("DELETE FROM `watch_categories` WHERE `id` = ".intval($rRow["id"]).";");
			}
            $rCurrentCats[$rRow["type"]][] = $rRow["genre_id"];
        }
    }
    $rMovieGenres = $rTMDB->getMovieGenres();
    foreach ($rMovieGenres as $rMovieGenre) {
        if (!in_array($rMovieGenre->getID(), $rCurrentCats[1])) {
            $db->query("INSERT INTO `watch_categories`(`type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES(1, ".intval($rMovieGenre->getID()).", '".ESC($rMovieGenre->getName())."', 0, '[]');");
        }
        if (!in_array($rMovieGenre->getID(), $rCurrentCats[2])) {
            $db->query("INSERT INTO `watch_categories`(`type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES(2, ".intval($rMovieGenre->getID()).", '".ESC($rMovieGenre->getName())."', 0, '[]');");
        }
    }
    $rTVGenres = $rTMDB->getTVGenres();
    foreach ($rTVGenres as $rTVGenre) {
        if (!in_array($rTVGenre->getID(), $rCurrentCats[1])) {
            $db->query("INSERT INTO `watch_categories`(`type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES(1, ".intval($rTVGenre->getID()).", '".ESC($rTVGenre->getName())."', 0, '[]');");
        }
        if (!in_array($rTVGenre->getID(), $rCurrentCats[2])) {
            $db->query("INSERT INTO `watch_categories`(`type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES(2, ".intval($rTVGenre->getID()).", '".ESC($rTVGenre->getName())."', 0, '[]');");
        }
    }
}

function forceSecurity() {
    global $db;
    $db->query("UPDATE `settings` SET `double_auth` = 1, `mag_security` = 1;");
    $db->query("UPDATE `admin_settings` SET `pass_length` = 8 WHERE `pass_length` < 8;");
}

if (file_exists("/home/xtreamcodes/iptv_xtream_codes/admin/.update")) {
    unlink("/home/xtreamcodes/iptv_xtream_codes/admin/.update");
    if (!file_exists("/home/xtreamcodes/iptv_xtream_codes/admin/.update")) {
        updateTables();
        forceSecurity();
    }
}

$rTableSearch = strtolower(basename($_SERVER["SCRIPT_FILENAME"], '.php')) === "table_search";
$_GET = XSSRow($_GET, $rTableSearch); $_POST = XSSRow($_POST, $rTableSearch); // Parse user input.

if (isset($_SESSION['hash'])) {
    $rUserInfo = getRegisteredUserHash($_SESSION['hash']);
    $rPermissions = is_array($rUserInfo) ? getPermissions($rUserInfo['member_group_id'] ?? 0) : null;
    if ((!$rUserInfo) || (!$rPermissions) || csIsPanelGroupBanned($rPermissions) || (intval($rUserInfo["status"] ?? 0) !== 1) || ((!$rPermissions["is_admin"]) && (!$rPermissions["is_reseller"])) || ((($_SESSION['ip'] ?? '') <> getIP()) && !empty($rAdminSettings["ip_logout"]))) {
        unset($rUserInfo);
        unset($rPermissions);
        session_unset();
        session_destroy();
        header("Location: ./index.php");
        exit;
    }
    $rAdminSettings["dark_mode"] = intval($rUserInfo["dark_mode"] ?? 0);
    $rAdminSettings["expanded_sidebar"] = intval($rUserInfo["expanded_sidebar"] ?? 0);
    $rSettings["sidebar"] = intval($rUserInfo["sidebar"] ?? 0);
    if (!empty($rPermissions["is_admin"])) {
        $rPermissions["is_reseller"] = 0;
    }
    if (!isset($rPermissions["advanced"]) || !is_array($rPermissions["advanced"])) {
        $rPermissions["advanced"] = [];
    }
    $rCategories = getCategories();
    $rServers = getStreamingServers();
    $rServerError = False;
	$TokenTelegram = $rAdminSettings["token_telegram"];
    $ChatID = $rAdminSettings["chat_id"];	   
    foreach ($rServers as $rServer) {
        if (((((time() - $rServer["last_check_ago"]) > 360)) OR ($rServer["status"] == 2)) AND ($rServer["can_delete"] == 1) AND ($rServer["status"] <> 3)) { $rServerError = True;
		if ((time() - LastCheck("Servers")) > 1800 ){
                $data = array(
                    'chat_id' => $ChatID,
                    'text' => "❌ Server ".$rServer["server_name"]." - ".$rServer["server_ip"]." - Offline"
                );
                LastCheckNew(time(),"Servers");
                $response = file_get_contents("https://api.telegram.org/bot$TokenTelegram/sendMessage?" . http_build_query($data) );
            }
        }
        if (($rServer["status"] == 3) && ($rServer["last_check_ago"] > 0)) {
            $db->query("UPDATE `streaming_servers` SET `status` = 1 WHERE `id` = ".intval($rServer["id"]).";");
            $rServers[intval($rServer["id"])]["status"] = 1;
			$data = [
                'chat_id' => $ChatID,
                'text' => "✅ Server ".$rServer["server_name"]." - ".$rServer["server_ip"]." - Added"
            ];
            $response = file_get_contents("https://api.telegram.org/bot$TokenTelegram/sendMessage?" . http_build_query($data) );			  
        }
    }
}
function LastCheckNew($valor, $CheckType){
    $fp = fopen($CheckType, "w");
    fwrite($fp, $valor);
    fclose($fp);
}
function LastCheck($CheckType){
    $fp = fopen($CheckType, "r");
    $conteudo = fread($fp, filesize($CheckType));
    fclose($fp);
    return $conteudo;
}
/* Google Drive Function */
function create_google_file ( $file_name ) {
		global $db, $access_token, $folder_id, $mime_type;
	
		// todo: make mimeType universal
		if( $folder_id=="" ) {
			$post_fields = "{\"title\":\"{$file_name}\",
		                     \"mimeType\":\"{$mime_type}\"}" ;
		} else {
			$post_fields = "{\"title\":\"{$file_name}\",
		                     \"mimeType\":\"{$mime_type}\",
		                     \"parents\": [{\"kind\":\"drive#fileLink\",\"id\":\"{$folder_id}\"}]}" ;
		}
	
		$ch = curl_init() ;
		curl_setopt( $ch, CURLOPT_URL, "https://www.googleapis.com/upload/drive/v2/files?uploadType=resumable" ) ;
		curl_setopt( $ch, CURLOPT_PORT , 443 ) ;
		curl_setopt( $ch, CURLOPT_POST, 1 ) ;
		curl_setopt( $ch, CURLOPT_POSTFIELDS, $post_fields ) ;
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 ) ;
		curl_setopt( $ch, CURLOPT_HEADER, true ) ;
		curl_setopt( $ch, CURLOPT_HTTPHEADER, array("Authorization: Bearer {$access_token}",
		    										"Content-Length: " . strlen($post_fields),
												    "X-Upload-Content-Type: {$mime_type}",
												    "X-Upload-Content-Length: " . filesize($file_name),	
												    "Content-Type: application/json; charset=UTF-8") ) ;
		$response = curl_exec($ch) ;
		$response = parse_response($response) ;
		if(is_null($response)){ return NULL;}
		
		// access token expired, let's get a new one and try again
		if( $response['code']=="401" ) { // todo: make sure that we also got an invalid credential response
			$access_token = get_access_token( true ) ;
			return create_google_file( $file_name ) ; // todo: implement recursion depth limit so we don't rescurse to hell
		}
	
		// error checking
		if( $response['code']!="200" ) {
			$message = "GoogleDrive ERROR: could not create resumable file\n" ;
			$db->query("INSERT INTO `panel_logs`(`log_message`, `date`) VALUES('".ESC($message)."', ".intval(time()).");");
			return NULL;
		}
		if( !isset($response['headers']['location']) ) {
			$message = "GoogleDrive ERROR: not location header gotten back\n";
			$db->query("INSERT INTO `panel_logs`(`log_message`, `date`) VALUES('".ESC($message)."', ".intval(time()).");");
			return NULL;
		}
		
		return $response['headers']['location'] ;
}

	/* Google Drive Function */
function get_access_token( $force_refresh=false ) {
	    global $db, $client_id, $client_secret, $refresh_token, $verbose;
	
	    if( $verbose ) { echo "> retrieving access token\n" ; }
	
	    $token_filename = "/tmp/access_token_" . md5( $client_id . $client_secret . $refresh_token ) ;
	    $access_token = "" ;
	    if( !file_exists($token_filename) || $force_refresh===true ) {
		    // no previous access token, let's get one
		    if( $verbose ) { echo ">   getting new one\n" ; }
	
		    $ch = curl_init() ;
		    curl_setopt( $ch, CURLOPT_URL, "https://accounts.google.com/o/oauth2/token" ) ;
		    curl_setopt( $ch, CURLOPT_PORT , 443 ) ;
		    curl_setopt( $ch, CURLOPT_POST, 1 ) ;
		    curl_setopt( $ch, CURLOPT_POSTFIELDS, "client_id={$client_id}&client_secret={$client_secret}&refresh_token={$refresh_token}&grant_type=refresh_token" ) ;
		    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 ) ;
		    curl_setopt( $ch, CURLOPT_HEADER, true ) ;
		    curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded') ) ;
	
		    $response = curl_exec( $ch ) ;
		    $response = parse_response( $response ) ;
			if(is_null($response)){ return NULL;}
	
		    // todo: make sure that we got a valid response before retrieving the access token from it
	
		    $access_token = json_decode( $response['body'] ) ;
		    $access_token = $access_token->access_token ;
		    file_put_contents( $token_filename, $access_token ) ;
		} else {
			// we already have something cached, with some luck it's still valid
		    $access_token = file_get_contents( $token_filename ) ;
		    if( $verbose ) { echo ">   from cache\n" ; }
		}
	
		if( $access_token=="" ) {
			$message = "GoogleDrive ERROR: problems getting an access token\n" ;
			$db->query("INSERT INTO `panel_logs`(`log_message`, `date`) VALUES('".ESC($message)."', ".intval(time()).");");
			return NULL;
		}
	
	    return  $access_token ;
}
	
	/* Google Drive Function */
function parse_response( $raw_data ) {
		global $db;
		$parsed_response = array( 'code'=>-1, 'headers'=>array(), 'body'=>"" ) ;
	
		$raw_data = explode( "\r\n", $raw_data ) ;
	
		$parsed_response['code'] = explode( " ", $raw_data[0] ) ;
		$parsed_response['code'] = $parsed_response['code'][1] ;
	
		for( $i=1 ; $i<count($raw_data) ; $i++ ) {
			$raw_datum = $raw_data[$i] ;
	
			$raw_datum = trim( $raw_datum ) ;
			if( $raw_datum!="" ) {
				if( substr_count($raw_datum, ':')>=1 ) {
					$raw_datum = explode( ':', $raw_datum, 2 ) ;
					$parsed_response['headers'][strtolower($raw_datum[0])] = trim( $raw_datum[1] ) ;
				}  else {
					$message = "Google Drive ERROR: we're in the headers section of parsing an HTTP section and no colon was found for line: {$raw_datum}\n" ;
					$db->query("INSERT INTO `panel_logs`(`log_message`, `date`) VALUES('".ESC($message)."', ".intval(time()).");");
					return NULL;
				}
			} else {
				// we've moved to the body section
				if( ($i+1)<count($raw_data) ) {
					for( $j=($i+1) ; $j<count($raw_data) ; $j++ ) {
						$parsed_response['body'] .= $raw_data[$j] . "\n" ;
					}
				}
	
				// we don't need to continue the $i loop
				break ;
			}
		}
	
	return $parsed_response ;
}

	/* Google Drive Function */
function get_mime_type( $file_name ) {
	global $file_binary ;
	$result = exec( "{$file_binary} -i -b {$file_name}" ) ;
	$result = trim( $result ) ;
	$result = explode( ";", $result ) ;
	$result = $result[0] ;
	return $result ;
}

function outputJson($Return=array()){
    /*Set response header*/
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
	header('Content-Type: application/json');
    /*Final JSON response*/
    exit(json_encode($Return,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}


?>
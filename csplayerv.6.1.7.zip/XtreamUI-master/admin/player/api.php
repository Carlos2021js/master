<?php
require __DIR__ . '/bootstrap.php';
if (empty($_SESSION['cs_player_auth'])) cs_player_json(['ok'=>false,'message'=>'Sessão expirada'],401);
$cfg = cs_player_load_config();
$dnsRow = cs_player_session_dns($cfg);
if (!$dnsRow) {
    cs_player_write_log('web_player_dns_unavailable', ['action' => (string)($_GET['action'] ?? 'home')], 'error');
    cs_player_json(['ok'=>false,'message'=>'DNS indisponível'],503);
}
$dns = $dnsRow['url']; $u=(string)$_SESSION['cs_player_username']; $p=(string)$_SESSION['cs_player_password'];
$local = !empty($_SESSION['cs_player_local_api']);
$action=(string)($_GET['action']??'home');
if ($action==='home') {
    if ($local) {
        $batch = [
            'live_categories' => cs_player_local_api($u,$p,'get_live_categories') ?? [],
            'vod_categories' => cs_player_local_api($u,$p,'get_vod_categories') ?? [],
            'series_categories' => cs_player_local_api($u,$p,'get_series_categories') ?? [],
            'live_streams' => cs_player_local_api($u,$p,'get_live_streams') ?? [],
            'vod_streams' => cs_player_local_api($u,$p,'get_vod_streams') ?? [],
            'series' => cs_player_local_api($u,$p,'get_series') ?? [],
        ];
    } else {
        $batch = cs_player_api_batch($dns, $u, $p, [
            'live_categories' => ['get_live_categories', []],
            'vod_categories' => ['get_vod_categories', []],
            'series_categories' => ['get_series_categories', []],
            'live_streams' => ['get_live_streams', []],
            'vod_streams' => ['get_vod_streams', []],
            'series' => ['get_series', []],
        ]);
    }
    $liveCats = $batch['live_categories'] ?? [];
    $vodCats = $batch['vod_categories'] ?? [];
    $seriesCats = $batch['series_categories'] ?? [];
    $live = $batch['live_streams'] ?? [];
    $vod = $batch['vod_streams'] ?? [];
    $series = $batch['series'] ?? [];
    $failed = [];
    foreach (['live_categories'=>$liveCats, 'vod_categories'=>$vodCats, 'series_categories'=>$seriesCats, 'live_streams'=>$live, 'vod_streams'=>$vod, 'series'=>$series] as $name => $value) {
        if ($value === []) $failed[] = $name;
    }
    if ($failed) {
        cs_player_write_log('web_player_home_partial', ['host' => (string)($dnsRow['url'] ?? ''), 'failed_actions' => $failed], 'warning');
    }
    cs_player_json(['ok'=>true,'server'=>['name'=>$dnsRow['name']??'Servidor'],'user'=>$_SESSION['cs_player_user_info']??[], 'categories'=>['live'=>$liveCats,'movies'=>$vodCats,'series'=>$seriesCats], 'content'=>['live'=>array_slice($live,0,120),'movies'=>array_slice($vod,0,120),'series'=>array_slice($series,0,120)], 'features'=>['pip'=>(bool)$cfg['pip_enabled'],'failover'=>(bool)$cfg['dns_failover'],'stall_timeout'=>(int)$cfg['stall_timeout'],'retries'=>(int)$cfg['hls_retries']]]);
}
if ($action==='series_info') {
    $id=(int)($_GET['id']??0); if(!$id) cs_player_json(['ok'=>false,'message'=>'Série inválida'],400);
    $data=$local ? cs_player_local_api($u,$p,'get_series_info',['series_id'=>$id]) : cs_player_api_call($dns,$u,$p,'get_series_info',['series_id'=>$id]);
    if ($data === null) {
        cs_player_write_log('web_player_series_info_failed', ['host' => (string)($dnsRow['url'] ?? ''), 'series_id' => $id], 'error');
        cs_player_json(['ok'=>false,'message'=>'Não foi possível carregar os episódios.'],502);
    }
    cs_player_json(['ok'=>true,'data'=>$data]);
}
if ($action==='category') {
    $type=(string)($_GET['type']??'live'); $cat=(string)($_GET['category_id']??'');
    $map=['live'=>'get_live_streams','movies'=>'get_vod_streams','series'=>'get_series']; if(!isset($map[$type])) cs_player_json(['ok'=>false],400);
    $extra=$cat!==''?['category_id'=>$cat]:[]; $data=$local ? cs_player_local_api($u,$p,$map[$type],$extra) : cs_player_api_call($dns,$u,$p,$map[$type],$extra);
    if ($data === null) {
        cs_player_write_log('web_player_category_failed', ['host' => (string)($dnsRow['url'] ?? ''), 'type' => $type, 'category_id' => $cat], 'error');
        cs_player_json(['ok'=>false,'message'=>'Não foi possível carregar esta categoria.'],502);
    }
    cs_player_json(['ok'=>true,'data'=>$data]);
}
if ($action==='failover') {
    if ($local) cs_player_json(['ok'=>false,'message'=>'Servidor interno usa API local; failover Xtream não é necessário.']);
    if (empty($cfg['dns_failover'])) cs_player_json(['ok'=>false,'message'=>'Failover desativado']);
    $active=cs_player_session_dns_list($cfg); $current=(string)($_SESSION['cs_player_dns_index']??''); $start=0;
    foreach($active as $i=>$row){ if((string)$row['_index']===$current){$start=$i+1;break;} }
    for($step=0;$step<count($active);$step++){
        $row=$active[($start+$step)%count($active)]; if((string)$row['_index']===$current) continue;
        $data=cs_player_api_call($row['url'],$u,$p);
        if(cs_player_is_authenticated_response($data)){$_SESSION['cs_player_dns_index']=(string)$row['_index'];$_SESSION['cs_player_dns_name']=$row['name']??'Servidor';cs_player_json(['ok'=>true,'server'=>$_SESSION['cs_player_dns_name']]);}
    }
    cs_player_write_log('web_player_failover_failed', ['current_dns' => $current, 'dns_count' => count($active)], 'error');
    cs_player_json(['ok'=>false,'message'=>'Nenhum DNS alternativo respondeu']);
}
cs_player_json(['ok'=>false,'message'=>'Ação inválida'],400);

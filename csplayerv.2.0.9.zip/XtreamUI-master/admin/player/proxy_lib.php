<?php
require_once __DIR__ . '/bootstrap.php';

function cs_proxy_config(?array $cfg = null): array {
    $cfg = $cfg ?? cs_player_load_config();
    return [
        'enabled' => !empty($cfg['proxy_enabled']),
        'hls' => !empty($cfg['proxy_hls']),
        'vod' => !empty($cfg['proxy_vod']),
        'cast' => !empty($cfg['proxy_cast']),
        'log' => !empty($cfg['proxy_log_enabled']),
        'retries' => max(0, min(6, (int)($cfg['proxy_retries'] ?? 4))),
        'connect_timeout' => max(2, min(20, (int)($cfg['proxy_connect_timeout'] ?? 5))),
        'read_timeout' => max(10, min(120, (int)($cfg['proxy_read_timeout'] ?? 24))),
        'manifest_cache' => max(0, min(15, (int)($cfg['proxy_manifest_cache'] ?? 1))),
    ];
}


function cs_proxy_ipresolve(): int {
    $mode = function_exists('cs_player_transport_ip_mode') ? cs_player_transport_ip_mode($_SESSION['cs_player_ip_mode_selected'] ?? 'auto') : 'auto';
    if ($mode === 'ipv4' && defined('CURL_IPRESOLVE_V4')) return CURL_IPRESOLVE_V4;
    if ($mode === 'ipv6' && defined('CURL_IPRESOLVE_V6')) return CURL_IPRESOLVE_V6;
    return defined('CURL_IPRESOLVE_WHATEVER') ? CURL_IPRESOLVE_WHATEVER : 0;
}

function cs_proxy_request_headers(?array $cfg = null): array {
    $cfg = $cfg ?? cs_player_load_config();
    $ua = trim((string)($cfg['m3u_user_agent'] ?? 'IPTVSmartersPro'));
    if ($ua === '') $ua = 'IPTVSmartersPro';
    return [
        'Accept: */*',
        'Accept-Language: pt-BR,pt;q=0.9,en;q=0.5',
        'Connection: keep-alive',
        'X-CS-Player-Request: 1',
        'User-Agent: ' . preg_replace('/[\r\n]+/', ' ', $ua),
    ];
}

function cs_proxy_should_use(string $type, ?array $cfg = null): bool {
    $p = cs_proxy_config($cfg);
    if (!$p['enabled']) return false;
    return $type === 'live' ? $p['hls'] : $p['vod'];
}

function cs_proxy_log(string $event, array $context = [], string $level = 'info'): void {
    $p = cs_proxy_config();
    if (!$p['log']) return;
    $safe = [];
    foreach ($context as $k => $v) {
        $key = preg_replace('/[^a-zA-Z0-9_.-]/', '_', (string)$k);
        if (preg_match('/pass|password|token|secret|api[_-]?key|url/i', $key)) {
            if ($key === 'origin_host') $safe[$key] = (string)$v;
            else $safe[$key] = '[REDACTED]';
        } elseif (is_scalar($v) || $v === null) {
            $safe[$key] = $v;
        }
    }
    $path = dirname(__DIR__) . '/logs/cs-player/web-player-proxy.log';
    $dir = dirname($path);
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $line = json_encode([
        'time'=>date('c'), 'level'=>$level, 'event'=>$event,
        'request_id'=>substr(hash('sha256', session_id().'|'.microtime(true).'|'.random_int(0, PHP_INT_MAX)),0,12),
        'context'=>$safe,
    ], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    if (is_string($line)) @file_put_contents($path, $line.PHP_EOL, FILE_APPEND|LOCK_EX);
}

function cs_proxy_media_headers(): void {
    $p = cs_proxy_config();
    header('X-CS-Player-Proxy: 1');
    header('X-Content-Type-Options: nosniff');
    header('X-Accel-Buffering: no');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    if ($p['cast']) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, HEAD, OPTIONS');
        header('Access-Control-Allow-Headers: Range, Content-Type, Accept, Origin');
        header('Access-Control-Expose-Headers: Content-Length, Content-Range, Accept-Ranges, Content-Type');
    }
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function cs_abs_url(string $base,string $ref): string {
    if (preg_match('~^https?://~i',$ref)) return $ref;
    $b=parse_url($base); if(!$b) return $ref; $scheme=$b['scheme']??'http'; $host=$b['host']??''; $port=isset($b['port'])?':'.$b['port']:'';
    if(isset($ref[0]) && $ref[0]==='/') return "$scheme://$host$port$ref";
    $path=$b['path']??'/'; $dir=preg_replace('~/[^/]*$~','/',$path); return "$scheme://$host$port".$dir.$ref;
}

function cs_proxy_register(string $url): string {
    if(!isset($_SESSION['cs_player_proxy_map'])||!is_array($_SESSION['cs_player_proxy_map'])) $_SESSION['cs_player_proxy_map']=[];
    $key=substr(hash('sha256',$url.session_id()),0,24); $_SESSION['cs_player_proxy_map'][$key]=['url'=>$url,'ts'=>time()];
    if(count($_SESSION['cs_player_proxy_map'])>5000){ foreach($_SESSION['cs_player_proxy_map'] as $k=>$v){if(($v['ts']??0)<time()-7200)unset($_SESSION['cs_player_proxy_map'][$k]);} }
    return $key;
}

function cs_rewrite_manifest(string $body,string $base): string {
    $lines=preg_split('/\r?\n/',$body); $out=[];
    foreach($lines as $line){
        if($line!=='' && $line[0]!=='#'){$u=cs_abs_url($base,trim($line));$line='segment.php?k='.rawurlencode(cs_proxy_register($u));}
        elseif(strpos($line,'URI="') !== false){$line=preg_replace_callback('/URI="([^"]+)"/',function($m)use($base){$u=cs_abs_url($base,$m[1]);return 'URI="segment.php?k='.rawurlencode(cs_proxy_register($u)).'"';},$line);}
        $out[]=$line;
    }
    return implode("\n",$out);
}

function cs_fetch_small(string $url): array {
    $p = cs_proxy_config();
    $ttl = $p['manifest_cache'];
    $cacheKey = hash('sha256', $url);
    if ($ttl > 0 && isset($_SESSION['cs_player_manifest_cache'][$cacheKey])) {
        $cached = $_SESSION['cs_player_manifest_cache'][$cacheKey];
        if (is_array($cached) && (int)($cached['ts'] ?? 0) >= time() - $ttl) {
            return [(int)$cached['code'], (string)$cached['body'], (string)$cached['ct'], (string)$cached['effective']];
        }
    }
    $attempts = max(1, $p['retries'] + 1);
    $last = [0, '', '', $url]; $lastError = '';
    for ($attempt=1; $attempt <= $attempts; $attempt++) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 4,
            CURLOPT_CONNECTTIMEOUT => $p['connect_timeout'],
            CURLOPT_TIMEOUT => $p['read_timeout'],
            CURLOPT_HTTPHEADER => cs_proxy_request_headers(),
            CURLOPT_TCP_KEEPALIVE => 1,
            CURLOPT_TCP_KEEPIDLE => 15,
            CURLOPT_TCP_KEEPINTVL => 10,
            CURLOPT_IPRESOLVE => cs_proxy_ipresolve(),
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_ENCODING => '',
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $ct = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $effective = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $error = (string)curl_error($ch);
        curl_close($ch);
        $last = [$code, is_string($body) ? $body : '', $ct, $effective ?: $url];
        $lastError = $error;
        if ($code >= 200 && $code < 400 && is_string($body)) {
            if ($ttl > 0) {
                if (!isset($_SESSION['cs_player_manifest_cache']) || !is_array($_SESSION['cs_player_manifest_cache'])) $_SESSION['cs_player_manifest_cache']=[];
                $_SESSION['cs_player_manifest_cache'][$cacheKey]=['ts'=>time(),'code'=>$code,'body'=>$body,'ct'=>$ct,'effective'=>$effective ?: $url];
                if (count($_SESSION['cs_player_manifest_cache']) > 100) array_shift($_SESSION['cs_player_manifest_cache']);
            }
            if ($attempt > 1) cs_proxy_log('proxy_manifest_recovered', ['origin_host'=>(string)(parse_url($url,PHP_URL_HOST)??''),'attempt'=>$attempt,'http_code'=>$code]);
            return $last;
        }
        if ($attempt < $attempts) usleep(min(600000, 150000 * $attempt));
    }
    cs_proxy_log('proxy_manifest_failed', [
        'origin_host'=>(string)(parse_url($url,PHP_URL_HOST)??''),
        'http_code'=>(int)$last[0], 'attempts'=>$attempts, 'curl_error'=>$lastError,
    ], ((int)$last[0]===404?'error':'warning'));
    return $last;
}

function cs_stream_binary(string $url) {
    $p = cs_proxy_config();
    cs_proxy_media_headers();
    $range = isset($_SERVER['HTTP_RANGE']) ? trim((string)$_SERVER['HTTP_RANGE']) : '';
    $attempts = max(1, $p['retries'] + 1);
    $lastCode = 0; $lastError = '';
    for ($attempt=1; $attempt <= $attempts; $attempt++) {
        $headers = cs_proxy_request_headers();
        if ($range !== '') $headers[] = 'Range: ' . $range;
        $bytes = 0;
        $statusSent = false;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 4,
            CURLOPT_CONNECTTIMEOUT => $p['connect_timeout'],
            CURLOPT_TIMEOUT => 0,
            CURLOPT_LOW_SPEED_LIMIT => 256,
            CURLOPT_LOW_SPEED_TIME => $p['read_timeout'],
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_HTTPHEADER => cs_proxy_request_headers(),
            CURLOPT_TCP_KEEPALIVE => 1,
            CURLOPT_TCP_KEEPIDLE => 15,
            CURLOPT_TCP_KEEPINTVL => 10,
            CURLOPT_IPRESOLVE => cs_proxy_ipresolve(),
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_ENCODING => '',
            CURLOPT_HEADERFUNCTION => function($ch, $header) use (&$statusSent) {
                $trim = trim($header);
                if (preg_match('~^HTTP/\S+\s+(\d{3})~i', $trim, $m)) {
                    $code=(int)$m[1];
                    if ($code >= 200 && $code < 400 && !headers_sent()) { http_response_code($code); $statusSent=true; }
                }
                $line = strtolower($header);
                if (strpos($line, 'content-type:') === 0 || strpos($line, 'content-length:') === 0 || strpos($line, 'content-range:') === 0 || strpos($line, 'accept-ranges:') === 0 || strpos($line,'last-modified:')===0 || strpos($line,'etag:')===0) {
                    if (!headers_sent()) header(trim($header), true);
                }
                return strlen($header);
            },
            CURLOPT_WRITEFUNCTION => function($ch, $data) use (&$bytes) {
                $bytes += strlen($data);
                echo $data;
                if (function_exists('fastcgi_finish_request')) { /* não finalizar: apenas disponibilidade detectada */ }
                flush();
                return strlen($data);
            },
        ]);
        if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
        curl_exec($ch);
        $lastCode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $lastError = (string)curl_error($ch);
        curl_close($ch);
        if (($lastCode >= 200 && $lastCode < 400) && $lastError === '') {
            if ($attempt > 1) cs_proxy_log('proxy_binary_recovered', ['origin_host'=>(string)(parse_url($url,PHP_URL_HOST)??''),'attempt'=>$attempt,'http_code'=>$lastCode,'bytes'=>$bytes]);
            exit;
        }
        // Nunca repete depois de já entregar bytes, para não corromper MP4/TS.
        if ($bytes > 0 || $attempt >= $attempts) break;
        usleep(min(600000, 150000 * $attempt));
    }
    cs_proxy_log('proxy_binary_failed', [
        'origin_host'=>(string)(parse_url($url,PHP_URL_HOST)??''), 'http_code'=>$lastCode,
        'curl_error'=>$lastError, 'range'=>$range !== '' ? 'yes' : 'no', 'attempts'=>$attempts,
    ], $lastCode===404?'error':'warning');
    if (!headers_sent()) http_response_code($lastCode ?: 502);
    exit;
}

function cs_proxy_direct_redirect(string $url): void {
    cs_proxy_log('proxy_bypassed', ['origin_host'=>(string)(parse_url($url,PHP_URL_HOST)??'')], 'info');
    header('Cache-Control: no-store');
    header('Location: '.$url, true, 302);
    exit;
}

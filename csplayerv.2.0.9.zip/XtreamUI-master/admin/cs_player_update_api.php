<?php
/**
 * CS PLAYER - Atualizador remoto resiliente por manifesto JSON (PHP 7.4+)
 * Dropbox principal, GitHub reserva. Não altera o banco de dados.
 */
include __DIR__ . '/session.php';
include __DIR__ . '/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (!isset($rPermissions) || empty($rPermissions['is_admin'])) {
    http_response_code(403);
    echo json_encode(array('ok'=>false,'message'=>'Acesso restrito ao administrador.'));
    exit;
}
if (!hasPermissions('adv', 'settings') && !hasPermissions('adv', 'database')) {
    http_response_code(403);
    echo json_encode(array('ok'=>false,'message'=>'Sem permissão para atualizar o CS PLAYER.'));
    exit;
}

const CS_PLAYER_UPDATE_MANIFEST = 'https://www.dropbox.com/scl/fi/4scts71fqjhffh7310pta/update.json?rlkey=7wherup4r2sudy1lgsoqqqrj4&st=dpgrn4li&dl=1';
const CS_PLAYER_UPDATE_MANIFEST_FALLBACK = 'https://raw.githubusercontent.com/Carlos2021js/master/main/update.json';
const CS_PLAYER_ROOT = '/home/xtreamcodes/iptv_xtream_codes';
const CS_PLAYER_UPDATER_UA = 'CS-PLAYER-Updater/2.0.8';

function csu_json($data, $status) {
    http_response_code((int)$status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function csu_allowed_url($url) {
    if (!is_string($url) || stripos($url, 'https://') !== 0 || !filter_var($url, FILTER_VALIDATE_URL)) return false;
    $host = strtolower((string)parse_url($url, PHP_URL_HOST));
    return in_array($host, array('www.dropbox.com','dropbox.com','dl.dropboxusercontent.com','raw.githubusercontent.com','github.com'), true);
}
function csu_disabled_functions() {
    $raw = trim((string)ini_get('disable_functions'));
    return $raw === '' ? array() : array_map('trim', explode(',', $raw));
}
function csu_function_enabled($name) {
    return function_exists($name) && !in_array($name, csu_disabled_functions(), true);
}
function csu_run_command($command, &$output, &$code) {
    $output = array(); $code = 127;
    if (csu_function_enabled('exec')) {
        exec($command . ' 2>&1', $output, $code);
        return true;
    }
    if (csu_function_enabled('proc_open')) {
        $desc = array(1=>array('pipe','w'), 2=>array('pipe','w'));
        $pipes = array();
        $proc = @proc_open($command, $desc, $pipes);
        if (is_resource($proc)) {
            $stdout = stream_get_contents($pipes[1]); fclose($pipes[1]);
            $stderr = stream_get_contents($pipes[2]); fclose($pipes[2]);
            $code = proc_close($proc);
            $text = trim((string)$stdout . "\n" . (string)$stderr);
            $output = $text === '' ? array() : preg_split('/\r?\n/', $text);
            return true;
        }
    }
    return false;
}
function csu_unzip_binary() {
    foreach (array('/usr/bin/unzip','/bin/unzip') as $bin) {
        if (is_file($bin) && is_executable($bin)) return $bin;
    }
    return '';
}
function csu_extractor_capabilities() {
    $bin = csu_unzip_binary();
    $cmd = csu_function_enabled('exec') || csu_function_enabled('proc_open');
    return array(
        'ziparchive'=>class_exists('ZipArchive'),
        'unzip'=>($bin !== '' && $cmd),
        'unzip_path'=>$bin,
        'command_runner'=>$cmd,
    );
}
function csu_fetch_string($url, $maxBytes) {
    if (!csu_allowed_url($url)) return false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 12);
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_USERAGENT, CS_PLAYER_UPDATER_UA);
        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTPS')) curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
        if (defined('CURLOPT_REDIR_PROTOCOLS') && defined('CURLPROTO_HTTPS')) curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300 || !is_string($raw) || strlen($raw) > $maxBytes) return false;
        return $raw;
    }
    $ctx = stream_context_create(array('http'=>array('timeout'=>25,'follow_location'=>1,'max_redirects'=>5,'user_agent'=>CS_PLAYER_UPDATER_UA)));
    $raw = @file_get_contents($url, false, $ctx, 0, $maxBytes + 1);
    if (!is_string($raw) || strlen($raw) > $maxBytes) return false;
    return $raw;
}
function csu_state_paths() {
    return array(CS_PLAYER_ROOT.'/admin/logs/cs-player/update-state.json', CS_PLAYER_ROOT.'/CS_PLAYER_UPDATE_VERSION.json');
}
function csu_local_state() {
    $defaults = array('product'=>'CS PLAYER','version'=>'2.0.8','build'=>208,'channel'=>'stable');
    foreach (csu_state_paths() as $path) {
        if (!is_file($path)) continue;
        $raw=@file_get_contents($path); $data=is_string($raw)?json_decode($raw,true):null;
        if (is_array($data) && !empty($data['version'])) return array_merge($defaults,$data);
    }
    return $defaults;
}
function csu_manifest() {
    $sources=array(CS_PLAYER_UPDATE_MANIFEST,CS_PLAYER_UPDATE_MANIFEST_FALLBACK);
    foreach ($sources as $source) {
        $raw=csu_fetch_string($source,1048576); if ($raw===false) continue;
        $m=json_decode($raw,true); if (!is_array($m)||empty($m['version'])) continue;
        $url=''; $sha='';
        if (isset($m['download'])&&is_array($m['download'])) {
            $url=trim((string)($m['download']['url']??'')); $sha=strtolower(trim((string)($m['download']['sha256']??'')));
        }
        if ($url===''&&isset($m['download_url'])) $url=trim((string)$m['download_url']);
        if ($sha===''&&isset($m['sha256'])) $sha=strtolower(trim((string)$m['sha256']));
        if (!csu_allowed_url($url)) continue;
        if ($sha!==''&&!preg_match('/^[a-f0-9]{64}$/',$sha)) return array(false,'SHA-256 do manifesto é inválido.');
        $m['_manifest_url']=$source; $m['_download_url']=$url; $m['_sha256']=$sha;
        return array($m,null);
    }
    return array(false,'Não foi possível consultar um update.json válido no Dropbox nem no canal reserva GitHub.');
}
function csu_is_newer($remote,$local,$remoteBuild,$localBuild) {
    if ($remoteBuild>0&&$localBuild>0&&$remoteBuild!==$localBuild) return $remoteBuild>$localBuild;
    return version_compare((string)$remote,(string)$local,'>');
}
function csu_download_file($url,$target) {
    if (!csu_allowed_url($url)) return false;
    $fp=@fopen($target,'wb'); if(!$fp) return false; $ok=false;
    if (function_exists('curl_init')) {
        $ch=curl_init($url); curl_setopt($ch,CURLOPT_FILE,$fp); curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true); curl_setopt($ch,CURLOPT_MAXREDIRS,5);
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,15); curl_setopt($ch,CURLOPT_TIMEOUT,600); curl_setopt($ch,CURLOPT_USERAGENT,CS_PLAYER_UPDATER_UA);
        if (defined('CURLOPT_PROTOCOLS')&&defined('CURLPROTO_HTTPS')) curl_setopt($ch,CURLOPT_PROTOCOLS,CURLPROTO_HTTPS);
        if (defined('CURLOPT_REDIR_PROTOCOLS')&&defined('CURLPROTO_HTTPS')) curl_setopt($ch,CURLOPT_REDIR_PROTOCOLS,CURLPROTO_HTTPS);
        $exec=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $ok=($exec===true&&$code>=200&&$code<300); curl_close($ch);
    } else {
        fclose($fp); $fp=null;
        $ctx=stream_context_create(array('http'=>array('timeout'=>600,'follow_location'=>1,'max_redirects'=>5,'user_agent'=>CS_PLAYER_UPDATER_UA)));
        $in=@fopen($url,'rb',false,$ctx); $fp=@fopen($target,'wb');
        if($in&&$fp){$ok=(stream_copy_to_stream($in,$fp)!==false);fclose($in);}
    }
    if(is_resource($fp))fclose($fp);
    return $ok&&is_file($target)&&filesize($target)>1024;
}
function csu_zip_safe($zip) {
    for($i=0;$i<$zip->numFiles;$i++){
        $name=(string)$zip->getNameIndex($i);
        if($name===''||strpos($name,"\0")!==false||$name[0]==='/'||preg_match('#(^|/)\.\.(/|$)#',$name))return false;
    }
    return true;
}
function csu_safe_archive_names($names) {
    if(!is_array($names)||!$names)return false;
    foreach($names as $name){$name=(string)$name;if($name===''||strpos($name,"\0")!==false||$name[0]==='/'||preg_match('#(^|/)\.\.(/|$)#',$name))return false;}
    return true;
}
function csu_extract_package($zipPath,$extract,&$engine,&$detail) {
    $engine='';$detail='';
    if(class_exists('ZipArchive')){
        $zip=new ZipArchive(); $opened=$zip->open($zipPath);
        if($opened===true&&csu_zip_safe($zip)&&$zip->extractTo($extract)){ $zip->close();$engine='ZipArchive';return true; }
        if($opened===true)@$zip->close(); $detail='ZipArchive não conseguiu extrair o pacote.';
    }
    $bin=csu_unzip_binary();
    if($bin!==''){
        $out=array();$code=0;
        if(csu_run_command(escapeshellarg($bin).' -Z1 '.escapeshellarg($zipPath),$out,$code)&&$code===0&&csu_safe_archive_names($out)){
            $out2=array();$code2=0;
            if(csu_run_command(escapeshellarg($bin).' -oq '.escapeshellarg($zipPath).' -d '.escapeshellarg($extract),$out2,$code2)&&$code2===0){$engine=$bin;return true;}
            $detail='unzip retornou código '.(int)$code2.'.';
        } elseif($detail==='') $detail='Não foi possível validar a lista interna do ZIP com unzip.';
    }
    if($detail==='')$detail='Nenhum extrator ZIP utilizável. ZipArchive e /usr/bin/unzip estão indisponíveis para o PHP do painel.';
    return false;
}
function csu_copy_tree($src,$dst) {
    if(!is_dir($src))return false;if(!is_dir($dst)&&!@mkdir($dst,0755,true)&&!is_dir($dst))return false;
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($src,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
    foreach($it as $item){$rel=substr($item->getPathname(),strlen($src)+1);$to=$dst.'/'.$rel;if($item->isDir()){if(!is_dir($to)&&!@mkdir($to,0755,true)&&!is_dir($to))return false;}else{$parent=dirname($to);if(!is_dir($parent)&&!@mkdir($parent,0755,true)&&!is_dir($parent))return false;if(!@copy($item->getPathname(),$to))return false;}}
    return true;
}
function csu_remove_tree($path) {
    if(!file_exists($path))return true;if(is_file($path)||is_link($path))return @unlink($path);
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
    foreach($it as $item){if($item->isDir())@rmdir($item->getPathname());else @unlink($item->getPathname());}return @rmdir($path);
}
function csu_backup_targets($srcRoot,$dstRoot,$backupRoot) {
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($srcRoot,FilesystemIterator::SKIP_DOTS));
    foreach($it as $item){if(!$item->isFile())continue;$rel=substr($item->getPathname(),strlen($srcRoot)+1);$current=$dstRoot.'/'.$rel;if(!is_file($current))continue;$to=$backupRoot.'/files/'.$rel;if(!is_dir(dirname($to))&&!@mkdir(dirname($to),0755,true)&&!is_dir(dirname($to)))return false;if(!@copy($current,$to))return false;}return true;
}
function csu_restore_targets($backupRoot,$dstRoot){$src=$backupRoot.'/files';return !is_dir($src)||csu_copy_tree($src,$dstRoot);}
function csu_update_log($event,$ctx=array()){$dir=CS_PLAYER_ROOT.'/admin/logs/cs-player';if(!is_dir($dir))@mkdir($dir,0755,true);$line=json_encode(array('time'=>date('c'),'event'=>$event,'context'=>$ctx),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if(is_string($line))@file_put_contents($dir.'/update.log',$line.PHP_EOL,FILE_APPEND|LOCK_EX);}
function csu_write_state($m){$dir=CS_PLAYER_ROOT.'/admin/logs/cs-player';if(!is_dir($dir))@mkdir($dir,0755,true);$state=array('product'=>'CS PLAYER','version'=>(string)$m['version'],'build'=>(int)($m['build']??0),'channel'=>(string)($m['channel']??'stable'),'updated_at'=>date('c'),'manifest'=>(string)($m['_manifest_url']??CS_PLAYER_UPDATE_MANIFEST));return @file_put_contents($dir.'/update-state.json',json_encode($state,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX)!==false;}
function csu_lint_tree($root,&$badFile) {
    $badFile=''; $phpBin=CS_PLAYER_ROOT.'/php/bin/php'; if(!is_executable($phpBin))return true;
    if(!csu_function_enabled('exec')&&!csu_function_enabled('proc_open'))return true;
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
    foreach($it as $file){if(!$file->isFile()||strtolower($file->getExtension())!=='php')continue;$out=array();$code=0;if(!csu_run_command(escapeshellarg($phpBin).' -l '.escapeshellarg($file->getPathname()),$out,$code)||$code!==0){$badFile=$file->getPathname();return false;}}
    return true;
}

$action=isset($_GET['action'])?(string)$_GET['action']:(isset($_POST['action'])?(string)$_POST['action']:'check');
if($action==='check'){
    list($manifest,$error)=csu_manifest();if($manifest===false)csu_json(array('ok'=>false,'message'=>$error,'manifest_url'=>CS_PLAYER_UPDATE_MANIFEST,'extractors'=>csu_extractor_capabilities()),502);
    $local=csu_local_state();$rb=(int)($manifest['build']??0);$lb=(int)($local['build']??0);$available=csu_is_newer($manifest['version'],$local['version'],$rb,$lb);
    csu_json(array('ok'=>true,'available'=>$available,'installed'=>$local,'remote'=>array('product'=>(string)($manifest['product']??'CS PLAYER'),'version'=>(string)$manifest['version'],'build'=>$rb,'channel'=>(string)($manifest['channel']??'stable'),'published_at'=>(string)($manifest['published_at']??''),'changelog'=>(isset($manifest['changelog'])&&is_array($manifest['changelog']))?$manifest['changelog']:array(),'required'=>(bool)($manifest['update']['required']??false),'database_changes'=>(bool)($manifest['update']['database_changes']??false)),'manifest_url'=>(string)($manifest['_manifest_url']??CS_PLAYER_UPDATE_MANIFEST),'extractors'=>csu_extractor_capabilities()),200);
}
if($action!=='install'||$_SERVER['REQUEST_METHOD']!=='POST')csu_json(array('ok'=>false,'message'=>'Ação inválida.'),400);

$lockFp=@fopen(sys_get_temp_dir().'/cs-player-update.lock','c');
if(!$lockFp||!@flock($lockFp,LOCK_EX|LOCK_NB))csu_json(array('ok'=>false,'message'=>'Já existe uma atualização em andamento.'),409);
register_shutdown_function(function()use($lockFp){if(is_resource($lockFp)){@flock($lockFp,LOCK_UN);@fclose($lockFp);}});

list($manifest,$error)=csu_manifest();if($manifest===false)csu_json(array('ok'=>false,'message'=>$error),502);
$local=csu_local_state();$rb=(int)($manifest['build']??0);$lb=(int)($local['build']??0);
if(!csu_is_newer($manifest['version'],$local['version'],$rb,$lb))csu_json(array('ok'=>true,'updated'=>false,'message'=>'CS PLAYER já está atualizado.','installed'=>$local),200);
if(!empty($manifest['update']['database_changes']))csu_json(array('ok'=>false,'message'=>'Atualização bloqueada: o manifesto informa alteração de banco de dados.'),409);
$caps=csu_extractor_capabilities();if(empty($caps['ziparchive'])&&empty($caps['unzip']))csu_json(array('ok'=>false,'message'=>'Nenhum extrator ZIP disponível. Instale ZipArchive ou habilite /usr/bin/unzip para o PHP do painel.','extractors'=>$caps),500);

$tmp=sys_get_temp_dir().'/cs-player-web-update-'.bin2hex(random_bytes(5));$zipPath=$tmp.'/update.zip';$extract=$tmp.'/extract';@mkdir($extract,0755,true);
register_shutdown_function(function()use($tmp){if(is_dir($tmp))csu_remove_tree($tmp);});
if(!csu_download_file($manifest['_download_url'],$zipPath))csu_json(array('ok'=>false,'message'=>'Falha ao baixar o pacote de atualização.'),502);
if($manifest['_sha256']!==''){$actual=strtolower((string)hash_file('sha256',$zipPath));if(!hash_equals($manifest['_sha256'],$actual))csu_json(array('ok'=>false,'message'=>'SHA-256 do pacote não confere. Atualização cancelada.'),409);}
$engine='';$detail='';if(!csu_extract_package($zipPath,$extract,$engine,$detail)){csu_update_log('extract_failed',array('detail'=>$detail));csu_json(array('ok'=>false,'message'=>'Falha ao extrair atualização: '.$detail,'extractors'=>$caps),500);}
$root=$extract.'/XtreamUI-master';if(!is_dir($root)||!is_file($root.'/admin/settings.php')||!is_file($root.'/admin/player/bootstrap.php'))csu_json(array('ok'=>false,'message'=>'Pacote incompatível: XtreamUI-master/ ou arquivos críticos ausentes.'),409);
$bad='';if(!csu_lint_tree($root.'/admin',$bad))csu_json(array('ok'=>false,'message'=>'Pacote contém PHP incompatível com o runtime interno.','file'=>substr($bad,strlen($root)+1)),409);

$stamp=date('Y-m-d_H-i-s');$backup=CS_PLAYER_ROOT.'/admin/backups/remote-updates/'.$stamp;if(!@mkdir($backup,0755,true)&&!is_dir($backup))csu_json(array('ok'=>false,'message'=>'Não foi possível criar diretório de backup.'),500);
if(!csu_backup_targets($root,CS_PLAYER_ROOT,$backup))csu_json(array('ok'=>false,'message'=>'Não foi possível criar backup transacional dos arquivos que serão substituídos.'),500);
$persist=array('config','admin/logs/cs-player/web-player-config.php','admin/logs/cs-player/web-player-config.bak.php','admin/logs/cs-player/web-player-dns.json','admin/logs/cs-player/web-player-dns-health.php','admin/logs/cs-player/dns-health.json','admin/logs/cs-player/update-state.json');$persistData=array();
foreach($persist as $rel){$path=CS_PLAYER_ROOT.'/'.$rel;if(is_file($path))$persistData[$rel]=@file_get_contents($path);}
csu_update_log('install_started',array('version'=>(string)$manifest['version'],'build'=>$rb,'extractor'=>$engine,'backup'=>$backup));
if(!csu_copy_tree($root,CS_PLAYER_ROOT)){csu_restore_targets($backup,CS_PLAYER_ROOT);csu_update_log('rollback_copy_failure',array('backup'=>$backup));csu_json(array('ok'=>false,'message'=>'Falha ao copiar arquivos. Rollback automático executado.','backup'=>$backup),500);}
foreach($persistData as $rel=>$contents){if(!is_string($contents))continue;$path=CS_PLAYER_ROOT.'/'.$rel;if(!is_dir(dirname($path)))@mkdir(dirname($path),0755,true);@file_put_contents($path,$contents,LOCK_EX);}
$bad='';if(!csu_lint_tree(CS_PLAYER_ROOT.'/admin/player',$bad)){csu_restore_targets($backup,CS_PLAYER_ROOT);foreach($persistData as $rel=>$contents){if(is_string($contents))@file_put_contents(CS_PLAYER_ROOT.'/'.$rel,$contents,LOCK_EX);}csu_update_log('rollback_post_lint_failure',array('file'=>$bad,'backup'=>$backup));csu_json(array('ok'=>false,'message'=>'Validação pós-atualização falhou. Rollback automático executado.','file'=>$bad,'backup'=>$backup),500);}
csu_write_state($manifest);csu_update_log('install_completed',array('version'=>(string)$manifest['version'],'build'=>$rb,'extractor'=>$engine,'backup'=>$backup));
csu_json(array('ok'=>true,'updated'=>true,'message'=>'CS PLAYER atualizado para '.(string)$manifest['version'].'.','version'=>(string)$manifest['version'],'build'=>$rb,'backup'=>$backup,'database_changed'=>false,'extractor'=>$engine,'rollback_ready'=>true),200);

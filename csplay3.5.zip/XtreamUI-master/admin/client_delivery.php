<?php
if (!isset($_GET['created']) || (string)$_GET['created'] !== '1' || empty($rUser) || empty($rUser['username'])) return;

$deliveryServer = $rServers[$_INFO['server_id']] ?? [];
$deliveryDns = !empty($rUserInfo['reseller_dns']) ? $rUserInfo['reseller_dns'] : (!empty($deliveryServer['domain_name']) ? $deliveryServer['domain_name'] : ($deliveryServer['server_ip'] ?? ''));
$deliveryHttps = !empty($rAdminSettings['use_https_main']);
$deliveryScheme = $deliveryHttps ? 'https' : 'http';
$deliveryPort = $deliveryHttps ? ($deliveryServer['https_broadcast_port'] ?? 443) : ($deliveryServer['http_broadcast_port'] ?? 80);
$deliveryBase = $deliveryScheme . '://' . $deliveryDns . ':' . $deliveryPort;
$deliveryUser = (string)$rUser['username'];
$deliveryPass = (string)$rUser['password'];
$deliveryQuery = 'username=' . rawurlencode($deliveryUser) . '&password=' . rawurlencode($deliveryPass);
$deliveryHls = $deliveryBase . '/get.php?' . $deliveryQuery . '&type=m3u_plus&output=hls';
$deliveryM3u = $deliveryBase . '/get.php?' . $deliveryQuery . '&type=m3u_plus&output=mpegts';
$deliveryApi = $deliveryBase . '/player_api.php?' . $deliveryQuery;
$deliveryBouquetNames = [];
$deliveryBouquetIds = json_decode((string)($rUser['bouquet'] ?? '[]'), true);
if (is_array($deliveryBouquetIds) && !empty($deliveryBouquetIds)) {
    $deliveryIds = array_values(array_unique(array_map('intval', $deliveryBouquetIds)));
    $deliveryIdList = implode(',', $deliveryIds);
    $deliveryResult = $db->query("SELECT `bouquet_name` FROM `bouquets` WHERE `id` IN (" . $deliveryIdList . ") ORDER BY `bouquet_order` ASC, `id` ASC;");
    if ($deliveryResult) while ($deliveryRow = $deliveryResult->fetch_assoc()) $deliveryBouquetNames[] = $deliveryRow['bouquet_name'];
}
$deliveryPlan = !empty($deliveryBouquetNames) ? implode(', ', $deliveryBouquetNames) : 'Plano configurado';
$deliveryExpires = !empty($rUser['exp_date']) ? date('d/m/Y H:i:s', (int)$rUser['exp_date']) : 'Sem expiração';

// FORMATO PROFISSIONAL (ESTILO FOTO)
$deliveryMessage = "✅ *Usuário:* " . $deliveryUser . "\n";
$deliveryMessage .= "✅ *Senha:* " . $deliveryPass . "\n";
$deliveryMessage .= "📦 *Plano:* " . $deliveryPlan . "\n";
$deliveryMessage .= "🗓 *Vencimento:* " . $deliveryExpires . "\n\n";
$deliveryMessage .= "🟢 *Link HLS [MAIS RECOMENDADO] (M3U):*\n" . $deliveryHls . "\n\n";
$deliveryMessage .= "🟡 *Link (M3U):*\n" . $deliveryM3u . "\n\n";
$deliveryMessage .= "🔴 *Link (SSIPTV):*\n" . $deliveryBase . "/p/" . $deliveryUser . "/" . $deliveryPass . "/ssiptv\n\n";
$deliveryMessage .= "🟠 *XCIPTV:*\n";
$deliveryMessage .= "✅ " . $deliveryBase . "\n";
$deliveryMessage .= "✅ " . $deliveryUser . "\n";
$deliveryMessage .= "✅ " . $deliveryPass . "\n\n";
$deliveryMessage .= "📺 *Att. Equipe Iptv*";

$deliveryJson = json_encode($deliveryMessage, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>
<div class="modal fade client-delivery-modal" id="clientDeliveryModal" tabindex="-1" role="dialog" aria-labelledby="clientDeliveryTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content text-center">
      <div class="modal-header client-delivery-header bg-primary text-white">
          <h5 class="modal-title w-100" id="clientDeliveryTitle">Detalhes do Cliente</h5>
          <button type="button" class="close text-white" data-dismiss="modal" aria-label="Fechar"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body p-4">
        <div class="alert alert-info border-info bg-transparent text-left mb-4" style="border: 2px solid #35b8e0 !important; border-radius: 10px; color: #fff;">
            <div class="mb-1">✅ <strong>Usuário:</strong> <?=htmlspecialchars($deliveryUser)?></div>
            <div class="mb-1">✅ <strong>Senha:</strong> <?=htmlspecialchars($deliveryPass)?></div>
            <div class="mb-1">📦 <strong>Plano:</strong> <?=htmlspecialchars($deliveryPlan)?></div>
            <div class="mb-1">🗓 <strong>Vencimento:</strong> <?=htmlspecialchars($deliveryExpires)?></div>
        </div>
        
        <div class="row mt-3">
            <div class="col-6">
                <button type="button" class="btn btn-success btn-block" id="clientDeliveryWhatsApp"><i class="mdi mdi-whatsapp mr-1"></i> WhatsApp</button>
            </div>
            <div class="col-6">
                <button type="button" class="btn btn-primary btn-block" id="clientDeliveryCopy"><i class="mdi mdi-content-copy mr-1"></i> Copiar</button>
            </div>
        </div>
        <div class="mt-3">
            <button type="button" class="btn btn-light btn-block text-dark" data-dismiss="modal">Fechar</button>
        </div>
        <div class="mt-2">
            <button type="button" class="btn btn-primary btn-block" id="clientDeliveryCopyClose"><i class="mdi mdi-content-copy mr-1"></i> Copiar e fechar</button>
        </div>
      </div>
    </div>
  </div>
</div>
<style>
.client-delivery-header{border-bottom:0}.client-delivery-text{width:100%;min-height:200px;padding:15px;border:1px solid #2563eb;border-radius:10px;color:#fff;background:#1a2234;resize:vertical;font-size:13px;line-height:1.55}
</style>
<script>
(function(){
  var text = <?=$deliveryJson ?: '""'?>;
  var modal = $('#clientDeliveryModal');
  function copyDelivery(closeAfter){
    var done=function(){if(window.jQuery && $.toast)$.toast({heading:'Copiado',text:'Dados do cliente copiados.',icon:'success',position:'top-right'});if(closeAfter)modal.modal('hide');};
    if(navigator.clipboard && window.isSecureContext){navigator.clipboard.writeText(text).then(done).catch(function(){
        var area = $('<textarea>').val(text).appendTo('body').select();
        document.execCommand('copy');
        area.remove();
        done();
    });}
    else{
        var area = $('<textarea>').val(text).appendTo('body').select();
        document.execCommand('copy');
        area.remove();
        done();
    }
  }
  $('#clientDeliveryCopy').on('click',function(){copyDelivery(false);});
  $('#clientDeliveryCopyClose').on('click',function(){copyDelivery(true);});
  $('#clientDeliveryWhatsApp').on('click',function(){window.open('https://wa.me/?text='+encodeURIComponent(text),'_blank','noopener');});
  $(function(){modal.modal({backdrop:'static',keyboard:false}).modal('show');});
}());
</script>

# CS Player v6.10 — Web Player / DNS Sync / 404

## Correções aplicadas

- Web Player publicado exclusivamente em `admin/player/`, que é o único caminho oficial da instalação.
- A antiga pasta duplicada `player/` foi removida para evitar divergência de código, configuração e manutenção.
- A configuração compartilhada fica em `admin/player/storage/config.php`, protegida contra acesso direto por HTTP.
- DNS dos servidores do próprio CS Player são agora FIXOS e lidos/sincronizados automaticamente da tabela existente `streaming_servers`, sem alteração de schema.
- Somente servidores ativos (`status = 1`) entram no login/failover do player.
- Nome de domínio é priorizado quando cadastrado; caso contrário é usado `server_ip` + `http_broadcast_port`.
- Novos servidores adicionados em Admin > Servidores passam automaticamente a integrar a lista do Web Player sem precisar cadastrá-los outra vez no Player.
- A opção “Adicionar DNS” agora é explicitamente para DNS externos/outros projetos.
- DNS externo aceita IP ou domínio, com/sem porta e com/sem esquema (`http://` ou `https://`).
- DNS fixos não são gravados no arquivo de configuração e não podem ser apagados na tela do Web Player.
- Tela de Settings separada em “DNS fixos do CS Player” e “DNS externos / outros projetos”.
- Botão “Sincronizar agora” relê os servidores ativos em tempo real.
- Teste de DNS passou a testar `player_api.php` com credenciais de probe e considera a resposta HTTP/end-point, sem exigir autenticação válida para marcar o endpoint como alcançável.
- Índices de DNS internos/externos passaram a usar identificadores string estáveis para login e failover.
- Revendas continuam sem acesso ao `player_admin_api.php`: administração do Web Player permanece exclusiva do Admin.

## Banco de dados

- Nenhuma tabela criada.
- Nenhuma coluna criada/alterada.
- Nenhum índice criado/alterado.
- A tabela `streaming_servers` é somente lida pelo Web Player para sincronização.

## URL pública esperada

Em instalação onde o painel abre como `http://IP:PORTA/dashboard.php`, o player passa a estar em:

`http://IP:PORTA/admin/player/`

O arquivo físico correspondente fica em `admin/player/index.php`, que também é o caminho público oficial.

## Observação sobre DNS

O “teste” verifica se o endpoint Xtream `player_api.php` responde naquele DNS. Se o host/porta não publicar esse endpoint, ele continuará mostrando falha — isso é diferente do antigo erro de cadastro/sincronização.

<?php
include 'session.php'; include 'functions.php';
if ((int)($rPermissions['is_admin'] ?? 0) !== 1 || !hasPermissions('adv','settings')) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'Acesso restrito ao administrador.'], JSON_UNESCAPED_UNICODE);
    exit;
}
require_once __DIR__ . '/player/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function out($a,$s=200){http_response_code($s);echo json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}

function cs_admin_fixed_player_dns(): array {
    $servers = function_exists('getStreamingServers') ? getStreamingServers(true) : [];
    return cs_player_server_dns_from_rows(array_values(is_array($servers) ? $servers : []));
}

function cs_admin_probe_dns(string $url, int $timeout = 5): array {
    $url = cs_player_normalize_dns($url);
    if ($url === '') return ['ok'=>false,'latency_ms'=>0,'http_code'=>0,'message'=>'DNS inválido'];
    if (!function_exists('curl_init')) return ['ok'=>false,'latency_ms'=>0,'http_code'=>0,'message'=>'cURL indisponível'];
    $probe = rtrim($url,'/') . '/player_api.php?username=__csplayer_probe__&password=__csplayer_probe__';
    $ch = curl_init($probe);
    $start = microtime(true);
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_FOLLOWLOCATION=>true,
        CURLOPT_MAXREDIRS=>3,
        CURLOPT_CONNECTTIMEOUT=>min(4,$timeout),
        CURLOPT_TIMEOUT=>$timeout,
        CURLOPT_USERAGENT=>'CSPlayer-DNS-Probe/1.1',
        CURLOPT_SSL_VERIFYPEER=>false,
        CURLOPT_SSL_VERIFYHOST=>false,
    ]);
    $body=curl_exec($ch);
    $err=(string)curl_error($ch);
    $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
    $effective=(string)curl_getinfo($ch,CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    $ms=(int)round((microtime(true)-$start)*1000);
    $json=is_string($body)?json_decode($body,true):null;
    $endpointOk = $code >= 200 && $code < 500 && (is_array($json) || (is_string($body) && trim($body)!==''));
    if ($endpointOk) {
        $message = 'player_api.php respondeu';
    } elseif ($code > 0) {
        $message = 'HTTP '.$code.' em '.$url.'; confirme a porta pública e a publicação de /player_api.php.';
    } else {
        $message = $err !== '' ? $err : 'Sem resposta em '.$url.'; confirme firewall, DNS e porta pública.';
    }
    return [
        'ok'=>$endpointOk,
        'latency_ms'=>$ms,
        'http_code'=>$code,
        'effective_url'=>$effective ?: $probe,
        'message'=>$message,
    ];
}

if($_SERVER['REQUEST_METHOD']==='GET'){
    $cfg=cs_player_load_config();
    $fixed = cs_admin_fixed_player_dns();
    if(($_GET['action']??'')==='test'){
        $url=cs_player_normalize_dns((string)($_GET['url']??''));
        if(!$url) out(['ok'=>false,'message'=>'DNS inválido'],400);
        out(cs_admin_probe_dns($url, max(3,min(15,(int)($cfg['request_timeout']??8)))));
    }
    if(($_GET['action']??'')==='sync'){
        out(['ok'=>true,'fixed_dns'=>$fixed,'count'=>count($fixed),'message'=>'Servidores sincronizados em tempo real.']);
    }
    out([
        'ok'=>true,
        'config'=>$cfg,
        'fixed_dns'=>$fixed,
        'player_url'=>'admin/player/',
        'player_public_path'=>'/admin/player/',
        'document_root_hint'=>$_SERVER['DOCUMENT_ROOT']??'',
    ]);
}
if($_SERVER['REQUEST_METHOD']!=='POST')out(['ok'=>false],405);
$raw=json_decode((string)file_get_contents('php://input'),true);
if(!is_array($raw))out(['ok'=>false,'message'=>'JSON inválido'],400);
$cfg=cs_player_default_config();
foreach(['enabled','smart_login','dns_failover','pip_enabled','autoplay_next','remember_position'] as $k)$cfg[$k]=!empty($raw[$k]);
foreach(['brand','login_title','login_subtitle','home_title'] as $k)$cfg[$k]=mb_substr(trim((string)($raw[$k]??$cfg[$k])),0,160);
$cfg['hls_retries']=max(1,min(10,(int)($raw['hls_retries']??4)));
$cfg['stall_timeout']=max(5,min(60,(int)($raw['stall_timeout']??12)));
$cfg['request_timeout']=max(3,min(30,(int)($raw['request_timeout']??8)));
$cfg['dns']=[];
foreach(($raw['dns']??[]) as $i=>$row){
    if(!is_array($row))continue;
    // DNS fixos nunca são gravados aqui; eles são lidos de streaming_servers em tempo real.
    if(!empty($row['fixed']) || (($row['source']??'')==='streaming_servers')) continue;
    $url=cs_player_normalize_dns((string)($row['url']??''));
    if(!$url)continue;
    $cfg['dns'][]=[
        'id'=>(string)($row['id']??('external_'.($i+1))),
        'name'=>mb_substr(trim((string)($row['name']??('DNS Externo '.($i+1)))),0,80),
        'url'=>$url,
        'enabled'=>!empty($row['enabled']),
        'priority'=>max(1,min(999,(int)($row['priority']??($i+1)))),
        'fixed'=>false,
        'source'=>'external',
    ];
}
if(!cs_player_save_config($cfg))out(['ok'=>false,'message'=>'Não foi possível salvar admin/player/storage/config.php'],500);
out(['ok'=>true,'message'=>'Configurações do Web Player salvas. DNS internos continuam sincronizados automaticamente.','config'=>$cfg,'fixed_dns'=>cs_admin_fixed_player_dns()]);

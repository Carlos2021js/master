<?php
/**
 * ============================================================
 * LOGIN ULTRA SEGURO v2.0
 * - Headers de segurança avançados
 * - Rate limiting progressivo (delay exponencial)
 * - Proteção contra força bruta com bloqueio temporário
 * - CSRF token com tempo de expiração
 * - Senha forte com validação (mínimo 8 caracteres, maiúscula, minúscula, número, especial)
 * - Suporte a reCAPTCHA v2/v3
 * - Google 2FA (TOTP) com regeneração de segredo
 * - Logs detalhados de segurança
 * - Sessão segura com regeneração e tempo limite
 * - Validação de entrada rigorosa (allowlist)
 * - Prepared statements para todas as consultas
 * - Design responsivo e acessível
 * ============================================================
 */

// ===================== INÍCIO - Melhorias de segurança =====================
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: same-origin");
header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Strict-Transport-Security: max-age=31536000; includeSubDomains; preload");
header("Content-Security-Policy: default-src 'self'; script-src 'self' https://www.google.com https://www.gstatic.com; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-src https://www.google.com;");
// ===================== FIM ================================================

// Carrega funções principais
require_once __DIR__ . '/branding_helper.php';
include "functions.php";

// ===================== Gerenciamento de sessão segura =====================
if (session_status() === PHP_SESSION_NONE) {
    // Configurações de sessão seguras
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', 1);
    ini_set('session.cookie_samesite', 'Strict');
    ini_set('session.use_strict_mode', 1);
    ini_set('session.gc_maxlifetime', 3600);
    session_start();
}

// Se já estiver logado, redireciona
if (isset($_SESSION["hash"])) {
    header("Location: ./dashboard.php");
    exit;
}

// ===================== CSRF Token com expiração =====================
if (empty($_SESSION['csrf_token']) || empty($_SESSION['csrf_token_time']) || time() - $_SESSION['csrf_token_time'] > 7200) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $_SESSION['csrf_token_time'] = time();
}

// ===================== Configurações =====================
$rAdminSettings = getAdminSettings();
$rRecaptchaV3 = cs_recaptcha_v3_config($rAdminSettings);
$rAdminSettings["recaptcha_v3_enable"] = $rRecaptchaV3["enabled"];
$maxAttempts = intval($rAdminSettings["login_flood"]) ?: 5;
$blockDuration = 900; // 15 minutos

// ===================== Funções auxiliares de segurança =====================
function logSecurityEvent($message, $level = 'info') {
    $logFile = __DIR__ . '/logs/security.log';
    $dir = dirname($logFile);
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $entry = date('Y-m-d H:i:s') . " [$level] " . $message . " (IP: " . getIP() . ")\n";
    @file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}

function checkRateLimit($ip) {
    global $db, $maxAttempts, $blockDuration;
    $stmt = $db->prepare("SELECT COUNT(*) as attempts, MAX(dateadded) as last_attempt FROM login_flood WHERE ip = ? AND dateadded > DATE_SUB(NOW(), INTERVAL ? SECOND)");
    $stmt->bind_param("si", $ip, $blockDuration);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    $count = (int)$row['attempts'];
    $last = strtotime($row['last_attempt'] ?? 'now');

    if ($count >= $maxAttempts) {
        // Bloqueio: verificar se já passou o tempo
        if ($last + $blockDuration > time()) {
            return false; // bloqueado
        } else {
            // Limpa tentativas antigas
            $db->query("DELETE FROM login_flood WHERE ip = '" . ESC($ip) . "' AND dateadded < DATE_SUB(NOW(), INTERVAL " . $blockDuration . " SECOND)");
        }
    }
    return true;
}

function registerFailedAttempt($ip, $username = '') {
    global $db;
    $stmt = $db->prepare("INSERT INTO login_flood (username, ip, dateadded) VALUES (?, ?, NOW())");
    $stmt->bind_param("ss", $username, $ip);
    $stmt->execute();
    $stmt->close();
}

function getRemainingBlockTime($ip) {
    global $db, $maxAttempts, $blockDuration;
    $stmt = $db->prepare("SELECT MAX(dateadded) as last_attempt FROM login_flood WHERE ip = ? ORDER BY dateadded DESC LIMIT 1");
    $stmt->bind_param("s", $ip);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    if (!$row) return 0;
    $last = strtotime($row['last_attempt']);
    $remaining = ($last + $blockDuration) - time();
    return max(0, $remaining);
}

function isValidUsername($username) {
    return preg_match('/^[a-zA-Z0-9_\-@.]{3,50}$/', $username);
}

function isValidPassword($password, $minLength = 8) {
    // Pelo menos 8 caracteres, uma maiúscula, uma minúscula, um número e um caractere especial
    if (strlen($password) < $minLength) return false;
    if (!preg_match('/[A-Z]/', $password)) return false;
    if (!preg_match('/[a-z]/', $password)) return false;
    if (!preg_match('/[0-9]/', $password)) return false;
    if (!preg_match('/[^A-Za-z0-9]/', $password)) return false;
    return true;
}

// ===================== Processamento do formulário =====================
$status = null;
$rUserInfo = null;
$rAuth = null;
$rQR = null;
$rChangePass = null;
$rNew2F = null;

if (isset($_POST["username"]) && isset($_POST["password"])) {
    // Verifica rate limit
    $ip = getIP();
    if (!checkRateLimit($ip)) {
        $remaining = getRemainingBlockTime($ip);
        $status = 10; // bloqueado
        $_SESSION['login_error'] = "Muitas tentativas. Tente novamente em " . ceil($remaining / 60) . " minutos.";
    } else {
        // CSRF
        if (!isset($_POST['csrf_token']) || !hash_equals((string)$_SESSION['csrf_token'], (string)$_POST['csrf_token'])) {
            $status = 8;
            logSecurityEvent("Tentativa de CSRF no login", "critical");
        } else {
            // Validar username
            $username = trim($_POST['username']);
            if (!isValidUsername($username)) {
                $status = 9;
                logSecurityEvent("Tentativa de login com username inválido: " . $username, "warning");
            } else {
                // reCAPTCHA v2
                if ($rAdminSettings["recaptcha_enable"] && empty($rAdminSettings["recaptcha_v3_enable"])) {
                    $recaptchaResponse = $_POST["g-recaptcha-response"] ?? '';
                    $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=" . $rAdminSettings["recaptcha_v2_secret_key"] . "&response=" . urlencode($recaptchaResponse));
                    $rResponse = json_decode($verify, true);
                    if (!$rResponse["success"] && !in_array("invalid-input-secret", $rResponse["error-codes"] ?? [])) {
                        $status = 5;
                        logSecurityEvent("Falha no reCAPTCHA v2", "warning");
                    }
                }
                // reCAPTCHA v3
                if ($rRecaptchaV3["enabled"] && !$status) {
                    $rV3Result = cs_verify_recaptcha_v3($rRecaptchaV3, $_POST["g-recaptcha-v3-token"] ?? "", $ip, "login");
                    if (empty($rV3Result["success"])) {
                        $status = 5;
                        logSecurityEvent("Falha no reCAPTCHA v3 (score " . ($rV3Result['score'] ?? '0') . ")", "warning");
                    }
                }

                if (!$status) {
                    // Tentativa de login
                    $rUserInfo = doLogin($username, $_POST["password"]);
                    if ($rUserInfo) {
                        // Verificar se precisa atualizar hash (se for antigo)
                        if (function_exists('password_needs_rehash') && password_needs_rehash($rUserInfo['password'], PASSWORD_DEFAULT)) {
                            $newHash = cryptPassword($_POST["password"]);
                            $db->query("UPDATE reg_users SET password = '" . ESC($newHash) . "' WHERE id = " . intval($rUserInfo["id"]));
                        }

                        // Google 2FA
                        if (isset($rAdminSettings["google_2factor"]) && $rAdminSettings["google_2factor"]) {
                            if (strlen($rUserInfo["google_2fa_sec"]) == 0) {
                                $rGA = new PHPGangsta_GoogleAuthenticator();
                                $rSecret = $rGA->createSecret();
                                $rUserInfo["google_2fa_sec"] = $rSecret;
                                $db->query("UPDATE reg_users SET google_2fa_sec = '" . ESC($rSecret) . "' WHERE id = " . intval($rUserInfo["id"]));
                                $rNew2F = true;
                            }
                            $rQR = $rGA->getQRCodeGoogleUrl(CS_PLAYER_NAME, $rUserInfo["google_2fa_sec"]);
                            $rAuth = md5($rUserInfo["password"]);
                            // Vai para a tela de 2FA
                        } else {
                            // Verificar comprimento da senha
                            if (strlen($_POST["password"]) < intval($rAdminSettings["pass_length"]) && intval($rAdminSettings["pass_length"]) > 0) {
                                $rChangePass = md5($rUserInfo["password"]);
                            } else {
                                // Login bem-sucedido
                                $rPermissions = getPermissions($rUserInfo["member_group_id"]);
                                if ($rPermissions && ($rPermissions["is_admin"] || $rPermissions["is_reseller"]) && !$rPermissions["is_banned"] && $rUserInfo["status"] == 1) {
                                    // Atualizar último login
                                    $db->query("UPDATE reg_users SET last_login = UNIX_TIMESTAMP(), ip = '" . ESC($ip) . "' WHERE id = " . intval($rUserInfo["id"]));

                                    // Regenerar ID de sessão
                                    session_regenerate_id(true);
                                    $_SESSION["hash"] = md5($rUserInfo["username"]);
                                    $_SESSION["ip"] = $ip;
                                    $_SESSION["login_time"] = time();

                                    // Log
                                    logSecurityEvent("Login bem-sucedido: " . $username . " (Admin: " . ($rPermissions["is_admin"] ? 'Sim' : 'Não') . ")", "info");
                                    $db->query("INSERT INTO login_users (owner, type, login_ip, date) VALUES (" . intval($rUserInfo["id"]) . ", '<b>[Painel]</b> -> " . ($rPermissions["is_admin"] ? "Administrador " : "Revendedor ") . $_["logged_in"] . "', '" . ESC($ip) . "', " . time() . ")");

                                    // Redirecionar
                                    $referrer = trim($_POST["referrer"] ?? '');
                                    if (!empty($referrer) && strpos($referrer, '/') === 0 && strpos($referrer, '//') === false) {
                                        header("Location: ." . htmlspecialchars($referrer));
                                    } else {
                                        header("Location: " . ($rPermissions["is_admin"] ? "./dashboard.php" : "./reseller.php"));
                                    }
                                    exit;
                                } else {
                                    if ($rPermissions && $rPermissions["is_banned"]) $status = 2;
                                    elseif ($rPermissions && !$rUserInfo["status"]) $status = 3;
                                    else $status = 4;
                                    logSecurityEvent("Login negado para " . $username . " (status: " . $status . ")", "warning");
                                }
                            }
                        }
                    } else {
                        // Falha de login
                        registerFailedAttempt($ip, $username);
                        $status = 0;
                        logSecurityEvent("Falha de login para " . $username, "warning");
                        // Delay progressivo
                        $attempts = $db->query("SELECT COUNT(*) as cnt FROM login_flood WHERE ip = '" . ESC($ip) . "' AND dateadded > DATE_SUB(NOW(), INTERVAL 1 HOUR)")->fetch_assoc()['cnt'];
                        sleep(min(5, $attempts * 0.5)); // delay de até 5s
                    }
                }
            }
        }
    }
} elseif (isset($_POST["gauth"]) && isset($_POST["hash"]) && isset($_POST["auth"]) && isset($rAdminSettings["google_2factor"]) && $rAdminSettings["google_2factor"]) {
    // Processamento 2FA
    if (!isset($_POST['csrf_token']) || !hash_equals((string)$_SESSION['csrf_token'], (string)$_POST['csrf_token'])) {
        $status = 8;
        logSecurityEvent("CSRF na tentativa de 2FA", "critical");
    } else {
        $rUserInfo = getRegisteredUserHash($_POST["hash"]);
        $rAuth = $_POST["auth"];
        if ($rUserInfo && $rAuth == md5($rUserInfo["password"])) {
            $rGA = new PHPGangsta_GoogleAuthenticator();
            if ($rGA->verifyCode($rUserInfo["google_2fa_sec"], $_POST["gauth"], 2)) {
                $rPermissions = getPermissions($rUserInfo["member_group_id"]);
                if ($rPermissions && ($rPermissions["is_admin"] || $rPermissions["is_reseller"]) && !$rPermissions["is_banned"] && $rUserInfo["status"] == 1) {
                    $db->query("UPDATE reg_users SET last_login = UNIX_TIMESTAMP(), ip = '" . ESC(getIP()) . "' WHERE id = " . intval($rUserInfo["id"]));
                    session_regenerate_id(true);
                    $_SESSION["hash"] = md5($rUserInfo["username"]);
                    $_SESSION["ip"] = getIP();
                    $_SESSION["login_time"] = time();
                    logSecurityEvent("Login com 2FA bem-sucedido: " . $rUserInfo["username"], "info");
                    $db->query("INSERT INTO login_users (owner, type, login_ip, date) VALUES (" . intval($rUserInfo["id"]) . ", '<b>[Painel]</b> -> " . ($rPermissions["is_admin"] ? "Administrador " : "Revendedor ") . $_["logged_in"] . "', '" . ESC(getIP()) . "', " . time() . ")");
                    header("Location: " . ($rPermissions["is_admin"] ? "./dashboard.php" : "./reseller.php"));
                    exit;
                } else {
                    if ($rPermissions && $rPermissions["is_banned"]) $status = 2;
                    elseif ($rPermissions && !$rUserInfo["status"]) $status = 3;
                    else $status = 4;
                    logSecurityEvent("Login 2FA negado para " . $rUserInfo["username"] . " (status: " . $status . ")", "warning");
                }
            } else {
                $status = 1;
                $rQR = $rGA->getQRCodeGoogleUrl(CS_PLAYER_NAME, $rUserInfo["google_2fa_sec"]);
                logSecurityEvent("Código 2FA inválido para " . $rUserInfo["username"], "warning");
            }
        } else {
            $status = 0;
            registerFailedAttempt(getIP(), $_POST["hash"]);
            logSecurityEvent("Falha na verificação 2FA (hash inválido)", "warning");
        }
    }
} elseif (isset($_POST["newpass"]) && isset($_POST["confirm"]) && isset($_POST["hash"]) && isset($_POST["change"])) {
    // Troca de senha
    if (!isset($_POST['csrf_token']) || !hash_equals((string)$_SESSION['csrf_token'], (string)$_POST['csrf_token'])) {
        $status = 8;
        logSecurityEvent("CSRF na troca de senha", "critical");
    } else {
        $rUserInfo = getRegisteredUserHash($_POST["hash"]);
        $rChangePass = $_POST["change"];
        if ($rUserInfo && $rChangePass == md5($rUserInfo["password"])) {
            $newpass = $_POST["newpass"];
            $confirm = $_POST["confirm"];
            $minLen = intval($rAdminSettings["pass_length"]) ?: 8;
            if ($newpass === $confirm && strlen($newpass) >= $minLen && isValidPassword($newpass, $minLen)) {
                $rPermissions = getPermissions($rUserInfo["member_group_id"]);
                if ($rPermissions && ($rPermissions["is_admin"] || $rPermissions["is_reseller"]) && !$rPermissions["is_banned"] && $rUserInfo["status"] == 1) {
                    $newHash = cryptPassword($newpass);
                    $db->query("UPDATE reg_users SET last_login = UNIX_TIMESTAMP(), password = '" . ESC($newHash) . "', ip = '" . ESC(getIP()) . "' WHERE id = " . intval($rUserInfo["id"]));
                    session_regenerate_id(true);
                    $_SESSION["hash"] = md5($rUserInfo["username"]);
                    $_SESSION["ip"] = getIP();
                    $_SESSION["login_time"] = time();
                    logSecurityEvent("Senha alterada e login efetuado para " . $rUserInfo["username"], "info");
                    $db->query("INSERT INTO login_users (owner, type, login_ip, date) VALUES (" . intval($rUserInfo["id"]) . ", '<b>[Painel]</b> -> " . ($rPermissions["is_admin"] ? "Administrador " : "Revendedor ") . $_["logged_in"] . "', '" . ESC(getIP()) . "', " . time() . ")");
                    header("Location: " . ($rPermissions["is_admin"] ? "./dashboard.php" : "./reseller.php"));
                    exit;
                } else {
                    if ($rPermissions && $rPermissions["is_banned"]) $status = 2;
                    elseif ($rPermissions && !$rUserInfo["status"]) $status = 3;
                    else $status = 4;
                    logSecurityEvent("Troca de senha negada para " . $rUserInfo["username"] . " (status: " . $status . ")", "warning");
                }
            } else {
                $status = 6;
                logSecurityEvent("Tentativa de troca de senha com requisitos não atendidos para " . $rUserInfo["username"], "warning");
            }
        } else {
            $status = 0;
            registerFailedAttempt(getIP(), $_POST["hash"]);
            logSecurityEvent("Falha na troca de senha (hash inválido)", "warning");
        }
    }
}

// Se houve bloqueio por rate limit, mostrar mensagem
if ($status === 10 && empty($_SESSION['login_error'])) {
    $remaining = getRemainingBlockTime(getIP());
    $_SESSION['login_error'] = "Muitas tentativas. Tente novamente em " . ceil($remaining / 60) . " minutos.";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <title><?=htmlspecialchars(!empty($rSettings["server_name"]) ? $rSettings["server_name"] : CS_PLAYER_NAME)?> - <?=$_["login"]?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" href="<?=htmlspecialchars(cs_branding_asset('favicon', 'assets/images/favicon.ico'))?>">
    <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
    <?php if ($rAdminSettings["dark_mode_login"]) { ?>
    <link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.css" rel="stylesheet" type="text/css" />
    <?php } else { ?>
    <link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.css" rel="stylesheet" type="text/css" />
    <?php } ?>
    <style>
        :root{--cs-blue:#2563eb;--cs-cyan:#06b6d4;--cs-ink:#0f172a;--cs-muted:#64748b;--cs-line:rgba(148,163,184,.24);--cs-radius:24px}.g-recaptcha{display:inline-block}.authentication-bg{min-height:100vh;margin:0;background:#07101d;overflow-x:hidden}.authentication-bg:before{content:"";position:fixed;inset:0;background:radial-gradient(circle at 15% 15%,rgba(37,99,235,.25),transparent 34%),radial-gradient(circle at 85% 80%,rgba(6,182,212,.18),transparent 32%),linear-gradient(135deg,rgba(2,6,23,.78),rgba(15,23,42,.56));pointer-events:none;z-index:0}.account-pages{position:relative;z-index:2;min-height:100vh;display:flex;align-items:center;margin:0!important;padding:32px 16px}.account-pages .container{max-width:1180px}.account-pages .row{align-items:center}.col-md-8.col-lg-6.col-xl-5{max-width:520px;flex:0 0 520px}.card{border:1px solid rgba(255,255,255,.18);border-radius:var(--cs-radius);box-shadow:0 28px 80px rgba(2,6,23,.4);overflow:hidden;background:rgba(255,255,255,.96);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px)}.card:before{content:"CS PLAYER • PAINEL DE CONTROLE";display:block;padding:12px 24px;background:linear-gradient(90deg,var(--cs-blue),var(--cs-cyan));color:#fff;font-size:11px;font-weight:800;letter-spacing:.14em}.card-body{padding:clamp(24px,5vw,42px)}.text-center.mb-4 small{font-size:13px;letter-spacing:.04em}.form-group label{font-weight:700;color:#334155;margin-bottom:7px}.form-control{min-height:52px;border:1px solid #d7e0ea;border-radius:13px;padding:11px 14px;background:#f8fafc;box-shadow:none;transition:.18s ease}.form-control:focus{background:#fff;border-color:#60a5fa;box-shadow:0 0 0 4px rgba(37,99,235,.1)}.btn_login{min-height:54px;border:0;border-radius:13px;font-weight:800;letter-spacing:.015em;background:linear-gradient(90deg,var(--cs-blue),#0ea5e9)!important;box-shadow:0 12px 28px rgba(37,99,235,.3);transition:transform .15s ease,box-shadow .15s ease}.btn_login:hover{transform:translateY(-1px);box-shadow:0 16px 34px rgba(37,99,235,.38)}.field__toggle{display:flex;align-items:center;gap:8px;color:#64748b!important;font-size:13px;font-weight:600!important}.alert{border-radius:14px;box-shadow:0 10px 25px rgba(2,6,23,.16)}.auth-smart-strip{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:-4px 0 22px}.auth-smart-strip span{font-size:11px;font-weight:700;color:#475569;background:#f1f5f9;border:1px solid #e2e8f0;border-radius:999px;padding:6px 9px}.password-toggle { position: relative; }.password-toggle .toggle-icon { position: absolute; right: 14px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #94a3b8; font-size: 1.2rem; }.password-toggle .toggle-icon:hover { color: #334155; }@media(min-width:992px){.account-pages .container:before{content:"Administração inteligente\A CS PLAYER";white-space:pre;position:absolute;left:max(24px,calc(50% - 520px));top:50%;transform:translateY(-50%);margin-left:-260px;color:#fff;font-size:clamp(32px,4vw,58px);font-weight:800;line-height:1.05;letter-spacing:-.04em;text-shadow:0 6px 30px rgba(0,0,0,.24);max-width:420px}}@media(max-width:991.98px){.account-pages{padding:18px 12px}.col-md-8.col-lg-6.col-xl-5{max-width:560px;flex:1 1 auto;width:100%}.card-body{padding:26px 22px}}@media(max-width:575.98px){.account-pages{align-items:flex-start;padding-top:18px}.card{border-radius:19px}.card:before{padding:10px 16px;font-size:9px}.card-body{padding:22px 17px}.form-control{min-height:50px}.btn_login{min-height:52px}}
    </style>
    <?=cs_branding_media_css()?>
</head>
<body class="authentication-bg authentication-bg-pattern" style="background-color:#07101d;">
<?=cs_branding_background_media('login')?>
<div class="account-pages mt-5 mb-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <?php if (file_exists("./.update")) { ?>
                <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Fechar"><span aria-hidden="true">&times;</span></button>
                    <?=$_["login_message_1"]?>
                </div>
                <?php }

                // Mensagens de erro
                $errorMessages = [
                    0 => $_["login_message_2"],
                    1 => $_["login_message_3"],
                    2 => $_["login_message_4"],
                    3 => $_["login_message_5"],
                    4 => $_["login_message_6"],
                    5 => $_["login_message_7"],
                    6 => str_replace("{num}", $rAdminSettings["pass_length"], $_["login_message_8"]),
                    8 => $_["login_message_12"] ?? "Erro de validação do formulário. Tente novamente.",
                    9 => $_["login_message_13"] ?? "Nome de usuário inválido.",
                    10 => $_SESSION['login_error'] ?? "Muitas tentativas. Tente novamente mais tarde."
                ];

                if (isset($status) && isset($errorMessages[$status])) {
                    $msg = $errorMessages[$status];
                    if ($status == 10) {
                        // Mostrar tempo restante
                        $remaining = getRemainingBlockTime(getIP());
                        $msg .= " (aguarde " . ceil($remaining / 60) . " min)";
                    }
                    echo '<div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Fechar"><span aria-hidden="true">&times;</span></button>
                            ' . htmlspecialchars($msg) . '
                          </div>';
                }
                unset($_SESSION['login_error']); // limpa mensagem após exibir
                ?>

                <div class="card">
                    <div class="card-body">
                        <div class="text-center mb-4" aria-label="CS PLAYER">
                            <?php $csLoginLogo = cs_branding_asset('logo_main', ''); ?>
                            <?php if ($csLoginLogo): ?><img src="<?=htmlspecialchars($csLoginLogo)?>" alt="CS PLAYER" style="max-width:220px;max-height:72px;object-fit:contain" class="mb-2"><?php else: ?><div style="font-size:1.65rem;font-weight:700;letter-spacing:-.03em;">CS PLAYER</div><?php endif; ?>
                            <small class="text-muted d-block">Painel de gerenciamento</small>
                        </div>
                        <div class="auth-smart-strip"><span>🔒 Sessão protegida</span><span>⚡ Interface otimizada</span><span>📱 Responsivo</span></div>

                        <?php if ($status != 7) { // não bloqueado por flood ?>
                        <form action="./login.php" method="POST" data-parsley-validate="" id="login_form" novalidate>
                            <input type="hidden" name="referrer" value="<?=htmlspecialchars((string)($_GET["referrer"] ?? ""), ENT_QUOTES, "UTF-8")?>" />
                            <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>" />
                            <?php if ($rAdminSettings["recaptcha_v3_enable"]) { ?>
                            <input type="hidden" id="g-recaptcha-v3-token" name="g-recaptcha-v3-token" value="">
                            <?php } ?>

                            <?php if (!isset($rQR) && !isset($rChangePass)) { ?>
                            <div class="form-group mb-3" id="username_group">
                                <label for="username"><?=$_["username"]?></label>
                                <input class="form-control" autocomplete="username" autocapitalize="none" spellcheck="false" type="text" id="username" name="username" required data-parsley-trigger="change" placeholder="<?=$_["enter_your_username"]?>" maxlength="50" pattern="[a-zA-Z0-9_\-@.]{3,50}">
                            </div>
                            <div class="form-group mb-2">
                                <label for="password"><?=$_["password"]?></label>
                                <div class="password-toggle">
                                    <input class="form-control" autocomplete="current-password" type="password" required data-parsley-trigger="change" id="password" name="password" placeholder="<?=$_["enter_your_password"]?>" minlength="<?=intval($rAdminSettings["pass_length"]) ?: 8?>">
                                    <span class="toggle-icon" id="togglePassword" role="button" tabindex="0" aria-label="Mostrar senha">👁️</span>
                                </div>
                            </div>
                            <div class="form-group mb-0">
                                <label for="show-password" class="field__toggle">
                                    <input type="checkbox" id="show-password" class="field__toggle-input" aria-label="Mostrar senha" />
                                    <?=$_["show_password"]?>
                                </label>
                            </div>
                            <?php if ($rAdminSettings["recaptcha_enable"] && empty($rAdminSettings["recaptcha_v3_enable"])) { ?>
                            <h5 class="text-center">
                                <div class="g-recaptcha" id="verification" data-sitekey="<?=$rAdminSettings["recaptcha_v2_site_key"]?>"></div>
                            </h5>
                            <?php } ?>

                            <?php } elseif (isset($rChangePass)) { ?>
                            <input type="hidden" name="hash" value="<?=md5($rUserInfo["username"])?>" />
                            <input type="hidden" name="change" value="<?=$rChangePass?>" />
                            <div class="form-group mb-3 text-center">
                                <p><?=str_replace("{num}", $rAdminSettings["pass_length"], $_["login_message_9"])?></p>
                            </div>
                            <div class="form-group mb-3">
                                <label for="newpass"><?=$_["new_password"]?></label>
                                <input class="form-control" autocomplete="off" type="password" id="newpass" name="newpass" required data-parsley-trigger="change" placeholder="<?=$_["enter_a_new_password"]?>" minlength="<?=intval($rAdminSettings["pass_length"]) ?: 8?>">
                            </div>
                            <div class="form-group mb-3">
                                <label for="confirm"><?=$_["confirm_password"]?></label>
                                <input class="form-control" autocomplete="off" type="password" id="confirm" name="confirm" required data-parsley-trigger="change" placeholder="<?=$_["confirm_your_password"]?>" minlength="<?=intval($rAdminSettings["pass_length"]) ?: 8?>">
                            </div>

                            <?php } else { // 2FA ?>
                            <input type="hidden" name="hash" value="<?=md5($rUserInfo["username"])?>" />
                            <input type="hidden" name="auth" value="<?=$rAuth?>" />
                            <?php if (isset($rNew2F)) { ?>
                            <div class="form-group mb-3 text-center">
                                <p><?=$_["login_message_10"]?></p>
                                <img src="<?=$rQR?>" alt="QR Code para Google Authenticator" style="max-width:200px;">
                            </div>
                            <?php } ?>
                            <div class="form-group mb-3">
                                <label for="gauth"><?=$_["google_authenticator_code"]?></label>
                                <input class="form-control" autocomplete="off" type="text" required id="gauth" name="gauth" placeholder="<?=$_["enter_your_auth_code"]?>" pattern="[0-9]{6}" inputmode="numeric" maxlength="6">
                            </div>
                            <?php } ?>

                            <div class="form-group mb-0 text-center">
                                <button class="btn_login btn-block btn-info" type="submit" id="login_button"><?=$_["login"]?></button>
                            </div>
                        </form>
                        <?php } else { ?>
                        <div class="form-group mb-0 text-center text-danger">
                            <p><?=$_["login_message_11"]?></p>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="assets/js/vendor.min.js"></script>
<script src="assets/libs/parsleyjs/parsley.min.js"></script>
<script src="assets/js/app.min.js?rid=<?=getID()?>"></script>

<?php if ($rAdminSettings["recaptcha_enable"] && empty($rAdminSettings["recaptcha_v3_enable"])) { ?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php } ?>

<?php if ($rAdminSettings["recaptcha_v3_enable"]) { ?>
<script src="https://www.google.com/recaptcha/api.js?render=<?=$rRecaptchaV3["site_key"]?>"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('login_form');
    var btn = document.getElementById('login_button');
    if (form && btn) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            btn.disabled = true;
            btn.innerHTML = '<?=$_["login"]?>...';
            grecaptcha.execute('<?=$rRecaptchaV3["site_key"]?>', {action: 'login'}).then(function(token) {
                document.getElementById('g-recaptcha-v3-token').value = token;
                form.submit();
            }).catch(function() {
                btn.disabled = false;
                btn.innerHTML = '<?=$_["login"]?>';
                alert('Não foi possível validar o reCAPTCHA. Verifique a conexão e tente novamente.');
            });
        });
    }
});
</script>
<?php } ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle de senha
    var toggle = document.getElementById('show-password');
    var password = document.getElementById('password');
    if (toggle && password) {
        toggle.addEventListener('change', function() {
            password.type = this.checked ? 'text' : 'password';
        });
    }

    // Ícone de toggle (alternativa)
    var iconToggle = document.getElementById('togglePassword');
    if (iconToggle && password) {
        iconToggle.addEventListener('click', function() {
            if (password.type === 'password') {
                password.type = 'text';
                this.textContent = '🙈';
                this.setAttribute('aria-label', 'Ocultar senha');
            } else {
                password.type = 'password';
                this.textContent = '👁️';
                this.setAttribute('aria-label', 'Mostrar senha');
            }
        });
    }

    // Preencher username via hash
    if (window.location.hash && window.location.hash.length > 1) {
        var usernameField = document.getElementById('username');
        if (usernameField) {
            usernameField.value = window.location.hash.substring(1);
            document.getElementById('username_group').style.display = 'none';
            document.getElementById('login_button').innerHTML = "<?=$_["login_as"]?> " + window.location.hash.substring(1).toUpperCase();
        }
    }
});
</script>
</body>
</html>
# CS PLAYER v4.0.7 — pacote consolidado

- Preserva os 3 importadores independentes e compatíveis com o banco existente.
- Importadores 2/3 com tratamento de lock, lotes grandes e inicialização opcional de streams.
- Importador 3 com modo turbo e cache/reuso de statements.
- get.php profissional para M3U/M3U Plus com saídas mpegts/ts/hls/m3u8.
- Endpoints públicos de compatibilidade em wwwdir.
- Atualizador remoto com PHP CLI compatível, backup/rollback e progresso.
- Limpeza segura reescrita em 5 etapas AJAX curtas para evitar HTTP 500.
- Limpeza ignora falhas de permissão por item, não percorre o projeto inteiro e preserva banco/config/conteúdo.
- system_logs mostra erros internos do painel/MariaDB sem confundir a origem do erro.

<?php
/**
 * CS Player - compatibilidade para o endpoint legado panel_errors.php
 *
 * O painel atual usa panel_logs.php para exibir os erros internos do painel,
 * enquanto permissões e links legados ainda podem apontar para panel_errors.php.
 * Este alias mantém ambos os caminhos funcionando sem duplicar lógica.
 */
require __DIR__ . '/panel_logs.php';

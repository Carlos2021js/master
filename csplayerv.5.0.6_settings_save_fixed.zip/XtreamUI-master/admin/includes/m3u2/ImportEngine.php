<?php
/** Núcleo de importação M3U2: Live, Filmes, Séries/Episódios, EPG, TMDB, buquês e anti-duplicidade. */
class CSM3U2ImportEngine
{
    private $db;
    private $jobStore;
    private $jobId;
    private $categories = array();
    private $existing = array('url' => array(), 'name' => array());
    private $series = array();
    private $seriesSeasons = array();
    private $touchedSeries = array();
    private $bouquets = array();
    private $tmdbAsyncAvailable = false;
    private $queuedTmdb = array();
    private $stats = array();
    private $lastCancelCheck = 0.0;
    private $lastJobSync = 0.0;

    public function __construct(mysqli $db, CSM3U2JobStore $jobStore = null, $jobId = null)
    {
        // O engine também pode ser chamado por endpoints, CLI ou cron.
        // A importação não deve herdar um limite HTTP de 60 segundos.
        @ignore_user_abort(true);
        @set_time_limit(0);
        @ini_set('max_execution_time', '0');
        $this->db = $db;
        $this->jobStore = $jobStore;
        $this->jobId = $jobId;
        $this->resetStats();
    }

    public function analyzeSources(array $sources, array $options)
    {
        $aggregate = $this->emptyAnalysis();
        $perSource = array();
        $seenGlobal = array();
        foreach ($sources as $sourceId => $meta) {
            $a = $this->emptyAnalysis();
            $a['source_id'] = $sourceId;
            $a['name'] = (string)($meta['name'] ?? $sourceId);
            $a['file_size'] = (int)($meta['size'] ?? @filesize($meta['path']));
            $seenLocal = array();
            foreach (CSM3U2PlaylistParser::iterate($meta['path']) as $item) {
                $a['total']++;
                $group = trim((string)($item['group-title'] ?? 'Sem categoria'));
                if ($group === '') $group = 'Sem categoria';
                $c = CSM3U2Classifier::classify((string)$item['url'], (string)$item['name'], $group, $options);
                $kind = $c['kind'];
                if ($kind === 'live') $a['live']++;
                elseif ($kind === 'movie') $a['movies']++;
                elseif ($kind === 'series') {
                    $a['episodes']++;
                    $seriesKey = CSM3U2PlaylistParser::normalize($c['series']['title']);
                    $a['_series'][$seriesKey] = true;
                    $a['_seasons'][$seriesKey][(int)$c['series']['season']] = true;
                } else $a['unknown']++;

                $catKey = CSM3U2PlaylistParser::normalize($group);
                if (!isset($a['categories'][$catKey])) {
                    $a['categories'][$catKey] = array('name'=>$group,'total'=>0,'live'=>0,'movies'=>0,'episodes'=>0,'unknown'=>0);
                }
                $a['categories'][$catKey]['total']++;
                if ($kind === 'live') $a['categories'][$catKey]['live']++;
                elseif ($kind === 'movie') $a['categories'][$catKey]['movies']++;
                elseif ($kind === 'series') $a['categories'][$catKey]['episodes']++;
                else $a['categories'][$catKey]['unknown']++;

                $dupKey = hash('sha256', CSM3U2PlaylistParser::normalize((string)$item['url']));
                if (isset($seenLocal[$dupKey])) $a['duplicates_in_source']++; else $seenLocal[$dupKey] = true;
                if (isset($seenGlobal[$dupKey])) $aggregate['duplicates_across_sources']++; else $seenGlobal[$dupKey] = true;
            }
            $a['series_titles'] = count($a['_series']);
            $seasonCount = 0;
            foreach ($a['_seasons'] as $seasons) $seasonCount += count($seasons);
            $a['seasons'] = $seasonCount;
            unset($a['_series'], $a['_seasons']);
            uasort($a['categories'], function($x,$y){ return $y['total'] <=> $x['total']; });
            $a['categories'] = array_values($a['categories']);
            $perSource[] = $a;
            foreach (array('total','live','movies','episodes','unknown','duplicates_in_source','series_titles','seasons') as $k) $aggregate[$k] += (int)$a[$k];
            $aggregate['file_size'] += $a['file_size'];
        }
        $aggregate['sources'] = count($sources);
        $aggregate['per_source'] = $perSource;
        return $aggregate;
    }

    private function reconnectDatabase($reason = '')
    {
        if (@$this->db->ping()) return true;
        if (function_exists('csPlayerOpenDatabase') && isset($GLOBALS['_INFO']) && is_array($GLOBALS['_INFO'])) {
            $newDb = @csPlayerOpenDatabase($GLOBALS['_INFO']);
            if ($newDb instanceof mysqli && !$newDb->connect_errno) {
                $this->db = $newDb;
                @$this->db->query('SET SESSION innodb_lock_wait_timeout = 8');
                @$this->db->query('SET SESSION lock_wait_timeout = 8');
                @$this->db->query('SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED');
                $this->stats['reconnects'] = (int)($this->stats['reconnects'] ?? 0) + 1;
                $this->setJob(array('reconnects'=>$this->stats['reconnects']));
                $this->log('warning', 'reconexão', 'Conexão MariaDB restabelecida automaticamente' . ($reason !== '' ? ': ' . $reason : '.'));
                return true;
            }
        }
        return false;
    }

    private function isConnectionError(Throwable $e)
    {
        $code = (int)$e->getCode();
        $msg = strtolower($e->getMessage());
        return in_array($code, array(2006, 2013, 2055), true)
            || strpos($msg, 'server has gone away') !== false
            || strpos($msg, 'lost connection') !== false
            || strpos($msg, 'connection') !== false && strpos($msg, 'closed') !== false;
    }

    private function phaseMeta($phase)
    {
        if ($phase === 'live') return array('type'=>1,'label'=>'canais','expected_key'=>'phase_live_expected','processed_key'=>'phase_live_processed','percent_key'=>'phase_live_percent');
        if ($phase === 'movie') return array('type'=>2,'label'=>'filmes','expected_key'=>'phase_movies_expected','processed_key'=>'phase_movies_processed','percent_key'=>'phase_movies_percent');
        return array('type'=>5,'label'=>'séries','expected_key'=>'phase_series_expected','processed_key'=>'phase_series_processed','percent_key'=>'phase_series_percent');
    }

    private function setPhaseProgress($phase, $processed, $expected)
    {
        $m = $this->phaseMeta($phase);
        $pct = $expected > 0 ? min(100, (int)floor(($processed * 100) / $expected)) : 100;
        $patch = array(
            'phase_current'=>$phase, 'phase_expected'=>$expected, 'phase_processed'=>$processed, 'phase_percent'=>$pct,
            $m['processed_key']=>$processed, $m['percent_key']=>$pct, 'stage'=>'importando ' . $m['label'], 'status'=>'executando'
        );
        $this->setJob($patch);
    }

    public function importSources(array $sources, $serverId, array $bouquetIds, array $options)
    {
        $serverId = (int)$serverId;
        if ($serverId <= 0) throw new InvalidArgumentException('Servidor de streaming inválido.');
        $this->loadCaches();
        $this->loadBouquets($bouquetIds);
        $this->tmdbAsyncAvailable = $this->tableExists('tmdb_async');
        if (!empty($options['queue_tmdb']) && !$this->tmdbAsyncAvailable) {
            $this->stats['warnings']++;
            $this->log('warning', 'TMDB', 'Fila TMDB solicitada, mas a tabela tmdb_async não está disponível. A importação continuará sem fila TMDB.');
        }
        $batchSize = max(10, min(500, (int)($options['batch_size'] ?? 100)));
        $batchNo = 0;
        @$this->db->query('SET SESSION innodb_lock_wait_timeout = 8');
        @$this->db->query('SET SESSION lock_wait_timeout = 8');
        @$this->db->query('SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED');

        $jobState = array();
        if ($this->jobStore && $this->jobId) { try { $jobState = $this->jobStore->get($this->jobId); } catch (Throwable $ignored) {} }
        $phaseExpected = array(
            'live'=>(int)($jobState['phase_live_expected'] ?? 0),
            'movie'=>(int)($jobState['phase_movies_expected'] ?? 0),
            'series'=>(int)($jobState['phase_series_expected'] ?? 0)
        );

        foreach (array('live','movie','series') as $phase) {
            $metaPhase = $this->phaseMeta($phase);
            $phaseProcessed = 0;
            $inBatch = 0;
            $expected = (int)$phaseExpected[$phase];
            $this->setPhaseProgress($phase, 0, $expected);
            $this->log('info', 'fase ' . $metaPhase['label'], 'Iniciando fase isolada: ' . strtoupper($metaPhase['label']) . '. Nenhum outro tipo será gravado nesta etapa.');
            $this->db->begin_transaction();
            $transaction = true;
            try {
                foreach ($sources as $sourceId => $sourceMeta) {
                    $this->setJob(array('current_source'=>(string)($sourceMeta['name'] ?? $sourceId)));
                    $sourceOptions = $options;
                    foreach (CSM3U2PlaylistParser::iterate($sourceMeta['path']) as $item) {
                        $this->assertNotCancelled();
                        $name = trim((string)($item['name'] ?? ''));
                        $url = trim((string)($item['url'] ?? ''));
                        if ($name === '' || $url === '') continue;
                        $group = trim((string)($item['group-title'] ?? 'Importação Automática'));
                        if ($group === '') $group = 'Importação Automática';
                        $classification = CSM3U2Classifier::classify($url, $name, $group, $sourceOptions);
                        if ((int)($classification['type'] ?? 0) !== (int)$metaPhase['type']) continue;

                        $phaseProcessed++;
                        $this->stats['processed']++;
                        $savepoint = 'm3u2_phase_item';
                        $attempt = 0;
                        while (true) {
                            $attempt++;
                            try {
                                $this->db->query('SAVEPOINT ' . $savepoint);
                                $result = $this->processItem($item, $serverId, $sourceOptions);
                                $this->db->query('RELEASE SAVEPOINT ' . $savepoint);
                                if ($result === 'inserted') $this->stats['inserted']++;
                                elseif ($result === 'updated') $this->stats['updated']++;
                                else $this->stats['skipped']++;
                                break;
                            } catch (Throwable $itemError) {
                                try { $this->db->query('ROLLBACK TO SAVEPOINT ' . $savepoint); } catch (Throwable $ignored) {}
                                if ($this->isConnectionError($itemError) && $attempt <= 3 && $this->reconnectDatabase($itemError->getMessage())) {
                                    $transaction = false;
                                    $this->db->begin_transaction();
                                    $transaction = true;
                                    usleep(250000 * $attempt);
                                    continue;
                                }
                                $this->stats['errors']++;
                                $this->log('error', 'item/' . $metaPhase['label'], $name . ': ' . $itemError->getMessage());
                                break;
                            }
                        }
                        $inBatch++;
                        if (($phaseProcessed % 25) === 0) $this->setPhaseProgress($phase, $phaseProcessed, $expected);
                        $this->syncJobCounters();
                        if ($inBatch >= $batchSize) {
                            $this->db->commit();
                            $transaction = false;
                            $batchNo++;
                            $this->stats['batches'] = $batchNo;
                            $this->setPhaseProgress($phase, $phaseProcessed, $expected);
                            $this->syncJobCounters(true);
                            $this->log('success', 'lote/' . $metaPhase['label'], 'Lote ' . $batchNo . ' confirmado: ' . $phaseProcessed . '/' . ($expected ?: $phaseProcessed) . ' ' . $metaPhase['label'] . '.');
                            $this->db->begin_transaction();
                            $transaction = true;
                            $inBatch = 0;
                        }
                    }
                }
                if ($transaction) { $this->db->commit(); $transaction = false; }
                $this->setPhaseProgress($phase, $phaseProcessed, $expected ?: $phaseProcessed);
                $this->log('success', 'fase ' . $metaPhase['label'], 'Fase ' . strtoupper($metaPhase['label']) . ' concluída.');
            } catch (Throwable $phaseError) {
                if ($transaction) { try { $this->db->rollback(); } catch (Throwable $ignored) {} }
                throw $phaseError;
            }
        }

        $this->setJob(array('stage'=>'finalização','phase_current'=>'finalizing','phase_percent'=>100));
        $this->flushSeriesSeasons();
        $this->saveBouquets();
        foreach ($bouquetIds as $bouquetId) {
            try { if (function_exists('scanBouquet')) scanBouquet((int)$bouquetId); }
            catch (Throwable $e) { $this->stats['warnings']++; $this->log('warning','buquê','Scan do buquê ' . (int)$bouquetId . ' falhou: ' . $e->getMessage()); }
        }
        $this->syncJobCounters(true);
        return $this->stats;
    }

    private function processItem(array $item, $serverId, array $options)
    {
        $name = trim((string)($item['name'] ?? ''));
        $url = trim((string)($item['url'] ?? ''));
        if ($name === '' || $url === '' || !preg_match('#^https?://#i', $url)) return 'skipped';
        $group = trim((string)($item['group-title'] ?? 'Importação Automática'));
        if ($group === '') $group = 'Importação Automática';
        $classification = CSM3U2Classifier::classify($url, $name, $group, $options);
        $type = (int)$classification['type'];
        if ($type === 0) return 'skipped';
        $categoryId = $this->resolveCategory($group, $type, !isset($options['create_categories']) || !empty($options['create_categories']));
        $icon = trim((string)($item['tvg-logo'] ?? ''));
        if ($icon !== '' && (!filter_var($icon, FILTER_VALIDATE_URL) || strlen($icon) > 4096)) $icon = '';
        $epg = array('epg_id'=>null,'channel_id'=>null,'epg_lang'=>null);
        if ($type === 1 && !empty($options['auto_epg'])) {
            $epgKey = trim((string)($item['tvg-id'] ?? ''));
            if ($epgKey === '') $epgKey = trim((string)($item['tvg-name'] ?? ''));
            if ($epgKey !== '' && function_exists('findEPG')) {
                try {
                    $found = findEPG($epgKey);
                    if (is_array($found)) {
                        $epg['epg_id'] = isset($found['epg_id']) ? (int)$found['epg_id'] : null;
                        $epg['channel_id'] = isset($found['channel_id']) ? (string)$found['channel_id'] : null;
                        $epg['epg_lang'] = isset($found['epg_lang']) ? (string)$found['epg_lang'] : null;
                    }
                } catch (Throwable $e) { $this->stats['warnings']++; $this->log('warning', 'EPG', 'Falha ao localizar EPG para ' . $name . ': ' . $e->getMessage()); }
            }
        }
        $existingId = $this->findExisting($type, $url, $name);
        $properties = $this->properties($type, $name, $icon, $group);
        $container = json_encode(array($classification['ext'] ?: ($type === 1 ? 'ts' : 'mp4')), JSON_UNESCAPED_SLASHES);
        $source = json_encode(array($url), JSON_UNESCAPED_SLASHES);
        $direct = !empty($options['direct_source']) ? 1 : 0;
        $streamId = 0;
        $status = 'inserted';
        if ($existingId && !empty($options['update_existing'])) {
            $stmt = $this->db->prepare('UPDATE streams SET category_id=?, stream_display_name=?, stream_source=?, stream_icon=?, movie_propeties=?, target_container=?, epg_id=?, channel_id=?, epg_lang=? WHERE id=?');
            $stmt->bind_param('isssssissi', $categoryId, $name, $source, $icon, $properties, $container, $epg['epg_id'], $epg['channel_id'], $epg['epg_lang'], $existingId);
            $stmt->execute();
            $streamId = (int)$existingId;
            $status = 'updated';
            $this->ensureServerLink($streamId, $serverId);
        } elseif ($existingId) {
            $streamId = (int)$existingId;
            $this->ensureServerLink($streamId, $serverId);
            $status = 'skipped';
        } else {
            $streamId = $this->insertStream($type, $categoryId, $name, $source, $icon, $properties, $container, $epg, $direct);
            $this->ensureServerLink($streamId, $serverId);
            $this->existing['name'][$type][CSM3U2PlaylistParser::normalize($name)] = $streamId;
            $this->existing['url'][$type][CSM3U2PlaylistParser::normalize($url)] = $streamId;
        }

        if ($type === 1) $this->stats['live']++;
        elseif ($type === 2) {
            $this->stats['movies']++;
            if (!empty($options['queue_tmdb'])) $this->queueTmdb(1, $streamId);
        } elseif ($type === 5) {
            $this->stats['episodes']++;
            $seriesId = $this->upsertSeriesEpisode($classification['series'], $categoryId, $group, $streamId, $icon, $options);
            $this->addSeriesToBouquets($seriesId);
        }
        if ($type !== 5) $this->addStreamToBouquets($streamId);
        return $status;
    }

    private function insertStream($type, $categoryId, $name, $source, $icon, $properties, $container, array $epg, $direct)
    {
        $sql = "INSERT INTO streams (type, category_id, stream_display_name, stream_source, stream_icon, notes, created_channel_location, enable_transcode, transcode_attributes, custom_ffmpeg, movie_propeties, movie_subtitles, read_native, target_container, stream_all, remove_subtitles, custom_sid, epg_id, channel_id, epg_lang, `order`, auto_restart, transcode_profile_id, pids_create_channel, cchannel_rsources, gen_timestamps, added, series_no, direct_source, tv_archive_duration, tv_archive_server_id, tv_archive_pid, movie_symlink, redirect_stream, rtmp_output, number, allow_record, probesize_ondemand, custom_map, external_push, delay_minutes) VALUES (?, ?, ?, ?, ?, '', NULL, 0, '[]', '', ?, '', 0, ?, 0, 0, NULL, ?, ?, ?, 0, '', 0, '', '', 1, ?, 0, ?, 0, 0, 0, ?, ?, 0, 0, 0, 128000, '', '', 0)";
        $stmt = $this->db->prepare($sql);
        $added = time();
        $movieSymlink = $direct;
        $redirect = $direct;
        $stmt->bind_param('iisssssissiiii', $type, $categoryId, $name, $source, $icon, $properties, $container, $epg['epg_id'], $epg['channel_id'], $epg['epg_lang'], $added, $direct, $movieSymlink, $redirect);
        $stmt->execute();
        $id = (int)$this->db->insert_id;
        if ($id <= 0) throw new RuntimeException('O banco não retornou ID após inserir o stream.');
        return $id;
    }

    private function ensureServerLink($streamId, $serverId)
    {
        $stmt = $this->db->prepare("INSERT IGNORE INTO streams_sys (stream_id, server_id, parent_id, pid, to_analyze, stream_status, stream_started, stream_info, monitor_pid, current_source, bitrate, progress_info, on_demand, delay_pid, delay_available_at) VALUES (?, ?, NULL, NULL, 0, 0, NULL, '', NULL, NULL, NULL, '', 0, NULL, NULL)");
        $stmt->bind_param('ii', $streamId, $serverId);
        $stmt->execute();
    }

    private function properties($type, $name, $icon, $group)
    {
        if ($type === 1) return '{}';
        return json_encode(array(
            'movie_image' => $icon,
            'cover_big' => $icon,
            'name' => $name,
            'o_name' => $name,
            'backdrop_path' => array(),
            'youtube_trailer' => '',
            'genre' => $group,
            'plot' => '',
            'description' => '',
            'cast' => '',
            'actors' => '',
            'rating' => '',
            'director' => '',
            'releasedate' => '',
            'tmdb_id' => '',
            'video' => array(),
            'audio' => array(),
            'bitrate' => 0
        ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    private function resolveCategory($name, $type, $create)
    {
        $categoryType = $type === 1 ? 'live' : ($type === 2 ? 'movie' : 'series');
        $key = CSM3U2PlaylistParser::normalize($name);
        if (isset($this->categories[$categoryType][$key])) {
            $this->stats['categories_reused']++;
            return $this->categories[$categoryType][$key];
        }
        if (!$create) {
            $this->stats['warnings']++;
            $this->log('warning', 'categoria', 'Categoria não encontrada e criação automática desativada: ' . $name . '. O item será salvo sem categoria.');
            return null;
        }
        $stmt = $this->db->prepare('INSERT INTO stream_categories (category_type, category_name, parent_id, cat_order) VALUES (?, ?, 0, 0)');
        $stmt->bind_param('ss', $categoryType, $name);
        $stmt->execute();
        $id = (int)$this->db->insert_id;
        $this->categories[$categoryType][$key] = $id;
        $this->stats['categories_created']++;
        return $id;
    }

    private function findExisting($type, $url, $name)
    {
        $u = CSM3U2PlaylistParser::normalize($url);
        $n = CSM3U2PlaylistParser::normalize($name);
        if (isset($this->existing['url'][$type][$u])) return $this->existing['url'][$type][$u];
        if (isset($this->existing['name'][$type][$n])) return $this->existing['name'][$type][$n];
        return null;
    }

    private function upsertSeriesEpisode(array $info, $categoryId, $group, $streamId, $icon, array $options)
    {
        $title = trim((string)$info['title']);
        $season = max(0, (int)$info['season']);
        $episode = max(1, (int)$info['episode']);
        $key = CSM3U2PlaylistParser::normalize($title) . '|' . (int)$categoryId;
        if (isset($this->series[$key])) {
            $seriesId = $this->series[$key];
        } else {
            $stmtFind = $this->db->prepare('SELECT id, seasons FROM series WHERE title=? AND (category_id <=> ?) LIMIT 1');
            $stmtFind->bind_param('si', $title, $categoryId);
            $stmtFind->execute();
            $row = $stmtFind->get_result()->fetch_assoc();
            if ($row) {
                $seriesId = (int)$row['id'];
                $decoded = json_decode((string)$row['seasons'], true);
                $this->seriesSeasons[$seriesId] = array_fill_keys(array_map('intval', is_array($decoded) ? $decoded : array()), true);
            } else {
                $stmt = $this->db->prepare("INSERT INTO series (title, category_id, cover, cover_big, genre, plot, cast, rating, director, releaseDate, last_modified, tmdb_id, seasons, episode_run_time, backdrop_path, youtube_trailer) VALUES (?, ?, ?, ?, ?, '', '', 0, '', '', ?, 0, '[]', 0, '', '')");
                $now = time();
                $stmt->bind_param('sisssi', $title, $categoryId, $icon, $icon, $group, $now);
                $stmt->execute();
                $seriesId = (int)$this->db->insert_id;
                $this->seriesSeasons[$seriesId] = array();
                $this->stats['series_created']++;
                if (!empty($options['queue_tmdb'])) $this->queueTmdb(2, $seriesId);
            }
            $this->series[$key] = $seriesId;
        }
        $stmt = $this->db->prepare('SELECT id FROM series_episodes WHERE series_id=? AND season_num=? AND sort=? LIMIT 1');
        $stmt->bind_param('iii', $seriesId, $season, $episode);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if ($row) {
            $episodeId = (int)$row['id'];
            $up = $this->db->prepare('UPDATE series_episodes SET stream_id=? WHERE id=?');
            $up->bind_param('ii', $streamId, $episodeId);
            $up->execute();
        } else {
            $ins = $this->db->prepare('INSERT INTO series_episodes (season_num, series_id, stream_id, sort) VALUES (?, ?, ?, ?)');
            $ins->bind_param('iiii', $season, $seriesId, $streamId, $episode);
            $ins->execute();
        }
        $this->seriesSeasons[$seriesId][$season] = true;
        $this->touchedSeries[$seriesId] = true;
        return $seriesId;
    }

    private function flushSeriesSeasons()
    {
        foreach (array_keys($this->touchedSeries) as $seriesId) {
            $seasons = array_keys($this->seriesSeasons[$seriesId] ?? array());
            $seasons = array_map('intval', $seasons);
            sort($seasons, SORT_NUMERIC);
            $json = json_encode($seasons);
            $now = time();
            $stmt = $this->db->prepare('UPDATE series SET seasons=?, last_modified=? WHERE id=?');
            $stmt->bind_param('sii', $json, $now, $seriesId);
            $stmt->execute();
        }
    }

    private function queueTmdb($type, $id)
    {
        if (!$this->tmdbAsyncAvailable) return;
        $key = (int)$type . ':' . (int)$id;
        if (isset($this->queuedTmdb[$key])) return;
        $check = $this->db->prepare('SELECT id FROM tmdb_async WHERE type=? AND stream_id=? AND status=0 LIMIT 1');
        $check->bind_param('ii', $type, $id);
        $check->execute();
        if (!$check->get_result()->fetch_assoc()) {
            $ins = $this->db->prepare('INSERT INTO tmdb_async (type, stream_id, status) VALUES (?, ?, 0)');
            $ins->bind_param('ii', $type, $id);
            $ins->execute();
        }
        $this->queuedTmdb[$key] = true;
    }

    private function loadCaches()
    {
        $res = $this->db->query('SELECT id, category_type, category_name FROM stream_categories');
        while ($res && ($row = $res->fetch_assoc())) {
            $this->categories[strtolower((string)$row['category_type'])][CSM3U2PlaylistParser::normalize($row['category_name'])] = (int)$row['id'];
        }
        $res = $this->db->query('SELECT id, type, stream_display_name, stream_source FROM streams WHERE type IN (1,2,5)');
        while ($res && ($row = $res->fetch_assoc())) {
            $type = (int)$row['type'];
            $this->existing['name'][$type][CSM3U2PlaylistParser::normalize($row['stream_display_name'])] = (int)$row['id'];
            $sources = json_decode((string)$row['stream_source'], true);
            if (is_array($sources)) {
                foreach ($sources as $url) if ((string)$url !== '') $this->existing['url'][$type][CSM3U2PlaylistParser::normalize($url)] = (int)$row['id'];
            }
        }
        $res = $this->db->query('SELECT id, title, category_id, seasons FROM series');
        while ($res && ($row = $res->fetch_assoc())) {
            $key = CSM3U2PlaylistParser::normalize($row['title']) . '|' . (int)$row['category_id'];
            $id = (int)$row['id'];
            $this->series[$key] = $id;
            $seasons = json_decode((string)$row['seasons'], true);
            $this->seriesSeasons[$id] = array_fill_keys(array_map('intval', is_array($seasons) ? $seasons : array()), true);
        }
    }

    private function loadBouquets(array $ids)
    {
        $this->bouquets = array();
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        if (!$ids) return;
        $stmt = $this->db->prepare('SELECT id, bouquet_channels, bouquet_series FROM bouquets WHERE id=?');
        foreach ($ids as $id) {
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            if (!$row) continue;
            $channels = json_decode((string)$row['bouquet_channels'], true);
            $series = json_decode((string)$row['bouquet_series'], true);
            $this->bouquets[$id] = array(
                'streams' => array_values(array_unique(array_map('intval', is_array($channels) ? $channels : array()))),
                'series' => array_values(array_unique(array_map('intval', is_array($series) ? $series : array())))
            );
        }
    }

    private function addStreamToBouquets($id)
    {
        foreach ($this->bouquets as &$b) if (!in_array((int)$id, $b['streams'], true)) $b['streams'][] = (int)$id;
        unset($b);
    }

    private function addSeriesToBouquets($id)
    {
        foreach ($this->bouquets as &$b) if (!in_array((int)$id, $b['series'], true)) $b['series'][] = (int)$id;
        unset($b);
    }

    private function saveBouquets()
    {
        $stmt = $this->db->prepare('UPDATE bouquets SET bouquet_channels=?, bouquet_series=? WHERE id=?');
        foreach ($this->bouquets as $id => $b) {
            $channels = json_encode(array_values(array_unique(array_map('intval', $b['streams']))));
            $series = json_encode(array_values(array_unique(array_map('intval', $b['series']))));
            $stmt->bind_param('ssi', $channels, $series, $id);
            $stmt->execute();
        }
    }

    private function tableExists($table)
    {
        $safe = $this->db->real_escape_string($table);
        $res = $this->db->query("SHOW TABLES LIKE '" . $safe . "'");
        return $res && $res->num_rows > 0;
    }

    private function assertNotCancelled()
    {
        if (!$this->jobStore || !$this->jobId) return;
        $now = microtime(true);
        if (($now - $this->lastCancelCheck) < 0.35) return;
        $this->lastCancelCheck = $now;
        if ($this->jobStore->isCancelled($this->jobId)) {
            throw new RuntimeException('Importação cancelada pelo usuário.');
        }
    }

    private function resetStats()
    {
        $this->stats = array('processed'=>0,'inserted'=>0,'updated'=>0,'skipped'=>0,'errors'=>0,'warnings'=>0,'live'=>0,'movies'=>0,'episodes'=>0,'series_created'=>0,'categories_created'=>0,'categories_reused'=>0,'batches'=>0);
    }

    private function emptyAnalysis()
    {
        return array('file_size'=>0,'sources'=>0,'total'=>0,'live'=>0,'movies'=>0,'episodes'=>0,'unknown'=>0,'duplicates_in_source'=>0,'duplicates_across_sources'=>0,'series_titles'=>0,'seasons'=>0,'categories'=>array(),'_series'=>array(),'_seasons'=>array());
    }

    private function setJob(array $patch)
    {
        if ($this->jobStore && $this->jobId) $this->jobStore->update($this->jobId, $patch);
    }

    private function syncJobCounters($force = false)
    {
        if (!$this->jobStore || !$this->jobId) return;
        $now = microtime(true);
        if (!$force && ($now - $this->lastJobSync) < 0.35) return;
        $this->lastJobSync = $now;
        $this->jobStore->update($this->jobId, array(
            'processed'=>$this->stats['processed'],'inserted'=>$this->stats['inserted'],'updated'=>$this->stats['updated'],'skipped'=>$this->stats['skipped'],'errors'=>$this->stats['errors'],'warnings'=>$this->stats['warnings'],'live'=>$this->stats['live'],'movies'=>$this->stats['movies'],'episodes'=>$this->stats['episodes'],'series_created'=>$this->stats['series_created'],'categories_created'=>$this->stats['categories_created'],'categories_reused'=>$this->stats['categories_reused'],'batches'=>$this->stats['batches']
        ));
    }

    private function log($level, $stage, $message)
    {
        if ($this->jobStore && $this->jobId) $this->jobStore->log($this->jobId, $level, $stage, $message);
    }
}

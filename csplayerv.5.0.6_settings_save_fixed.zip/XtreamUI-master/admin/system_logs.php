<?php
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
cs_admin_only('os logs e diagnósticos do sistema');
if ((!hasPermissions('adv', 'settings')) && (!hasPermissions('adv', 'database'))) { http_response_code(403); exit; }

if (empty($_SESSION['cs_system_logs_csrf'])) $_SESSION['cs_system_logs_csrf'] = bin2hex(random_bytes(32));
$csLogsCsrf=(string)$_SESSION['cs_system_logs_csrf']; $csLogsFlash=''; $csLogsFlashType='success';

function cs_logs_h($value) { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function cs_logs_redact($text) {
    $text = preg_replace('~(://[^:/\s]+:)[^@/\s]+@~', '$1[REDACTED]@', (string)$text);
    $text = preg_replace('~([?&](?:username|password|user|pass|token|api_key)=)[^&\s]+~i', '$1[REDACTED]', (string)$text);
    $text = preg_replace('~("?(?:password|passwd|token|api_key)"?\s*[:=]\s*)"?[^",\s}]+~i', '$1[REDACTED]', (string)$text);
    return (string)$text;
}
function cs_logs_tail($path, $maxBytes = 524288, $maxLines = 700) {
    if (!is_file($path) || !is_readable($path)) return ['ok'=>false, 'text'=>'Arquivo ausente ou sem permissão de leitura.', 'lines'=>[]];
    $size = @filesize($path);
    $fh = @fopen($path, 'rb');
    if (!$fh) return ['ok'=>false, 'text'=>'Não foi possível abrir o arquivo.', 'lines'=>[]];
    $start = max(0, (int)$size - (int)$maxBytes);
    if ($start > 0) @fseek($fh, $start);
    $data = (string)stream_get_contents($fh); fclose($fh);
    if ($start > 0) { $newline = strpos($data, "\n"); if ($newline !== false) $data = substr($data, $newline + 1); }
    $lines = preg_split('/\r\n|\r|\n/', $data) ?: [];
    $lines = array_values(array_filter(array_slice($lines, -(int)$maxLines), static function($line){ return trim((string)$line) !== ''; }));
    foreach ($lines as &$line) $line = cs_logs_redact($line); unset($line);
    return ['ok'=>true, 'text'=>implode("\n", $lines), 'lines'=>$lines, 'truncated'=>$start > 0];
}
function cs_logs_sources() {
    $sources = [
        'php' => ['label'=>'PHP / PHP-FPM', 'paths'=>['/tmp/php.log']],
        'nginx' => ['label'=>'Nginx', 'paths'=>['/var/log/nginx/error.log']],
        'system' => ['label'=>'Sistema', 'paths'=>['/var/log/syslog', '/var/log/messages']],
        'auth' => ['label'=>'SSH / Autenticação', 'paths'=>['/var/log/auth.log', '/var/log/secure']],
        'panel' => ['label'=>'Painel / auditoria', 'paths'=>[__DIR__.'/logs/security.log']],
        'web_player' => ['label'=>'Web Player / testes de servidor', 'paths'=>[__DIR__.'/logs/cs-player/web-player.log', __DIR__.'/logs/cs-player/web-player-proxy.log']],
        'm3u' => ['label'=>'Importador M3U', 'paths'=>[__DIR__.'/storage/import_jobs']],
        'm3u2' => ['label'=>'Importador M3U 2 Ultra', 'paths'=>[__DIR__.'/storage/m3u2/logs', __DIR__.'/storage/m3u2/jobs']],
        'update' => ['label'=>'Atualizador remoto', 'paths'=>[__DIR__.'/logs/cs-player/update.log', __DIR__.'/logs/cs-player/remote-update.log']],
    ];
    $errorLog = (string)ini_get('error_log');
    if ($errorLog !== '' && isset($errorLog[0]) && $errorLog[0] === '/') $sources['php']['paths'][] = $errorLog;
    foreach (glob('/var/log/php*-fpm.log') ?: [] as $path) $sources['php']['paths'][] = $path;
    foreach (glob('/var/log/php/*fpm*.log') ?: [] as $path) $sources['php']['paths'][] = $path;
    return $sources;
}
function cs_logs_files($paths) {
    $files = [];
    foreach ((array)$paths as $path) {
        if (is_file($path)) $files[] = $path;
        elseif (is_dir($path)) foreach (glob(rtrim($path, '/').'/*') ?: [] as $child) if (is_file($child) && !preg_match('/\.(?:lock|tmp)(?:\.|$)/i', basename($child))) $files[] = $child;
    }
    $files = array_values(array_unique($files));
    usort($files, static function($a,$b){ return ((int)@filemtime($b)) <=> ((int)@filemtime($a)); });
    return $files;
}
function cs_logs_timestamp($line) {
    $line = (string)$line; $m=[];
    if (preg_match('/\[(\d{1,2}-[A-Za-z]{3}-\d{4}\s+\d{2}:\d{2}:\d{2})(?:\s+[^\]]+)?\]/', $line, $m)) { $t=@strtotime($m[1]); if ($t) return $t; }
    if (preg_match('/"time"\s*:\s*"([^"]+)"/', $line, $m)) { $t=@strtotime($m[1]); if ($t) return $t; }
    if (preg_match('/\b(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:[+-]\d{2}:?\d{2}|Z)?)\b/', $line, $m)) { $t=@strtotime($m[1]); if ($t) return $t; }
    return 0;
}
function cs_logs_severity($line) {
    $l = strtolower((string)$line);
    if (preg_match('/\b(critical|fatal|parse error|uncaught|exception|error|failed|failure)\b/', $l)) return 'error';
    if (preg_match('/\b(warning|warn|deprecated|notice)\b/', $l)) return 'warning';
    if (preg_match('/\b(info|success|successful|bem-sucedido|completed)\b/', $l)) return 'info';
    return 'other';
}
function cs_logs_period_seconds($period) {
    $map=['1h'=>3600,'6h'=>21600,'24h'=>86400,'7d'=>604800];
    return isset($map[$period]) ? $map[$period] : 0;
}
function cs_logs_filter_lines($lines, $period, $severity, $query, $fileMtime) {
    $out=[]; $seconds=cs_logs_period_seconds($period); $cutoff=$seconds ? time()-$seconds : 0; $query=trim((string)$query);
    foreach ((array)$lines as $line) {
        $ts=cs_logs_timestamp($line); if (!$ts) $ts=(int)$fileMtime;
        $sev=cs_logs_severity($line);
        if ($cutoff && $ts && $ts < $cutoff) continue;
        if ($severity !== 'all' && $sev !== $severity) continue;
        if ($query !== '' && stripos($line,$query) === false) continue;
        $out[]=['text'=>$line,'time'=>$ts,'severity'=>$sev];
    }
    return $out;
}

function cs_logs_clearable_files($sources) {
    $allowKeys=['php','panel','web_player','m3u','m3u2','update']; $files=[]; $adminRoot=realpath(__DIR__);
    foreach($allowKeys as $key){ if(!isset($sources[$key])) continue; foreach(cs_logs_files($sources[$key]['paths']) as $path){
        if(!is_file($path)) continue; $real=realpath($path); if($real===false) continue;
        if($real==='/tmp/php.log' || ($adminRoot && strpos($real,$adminRoot.DIRECTORY_SEPARATOR)===0)) $files[$real]=true;
    }} return array_keys($files);
}
function cs_logs_truncate_file($path) {
    if(!is_file($path)) return false; $fh=@fopen($path,'c'); if(!$fh) return false;
    $locked=@flock($fh,LOCK_EX); $ok=$locked ? @ftruncate($fh,0) : false; if($locked) @flock($fh,LOCK_UN); @fclose($fh); return (bool)$ok;
}

$sources=cs_logs_sources();
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['clear_logs'])) {
    $provided=(string)($_POST['csrf']??'');
    if($provided==='' || !hash_equals($csLogsCsrf,$provided)){ $csLogsFlash='Token de segurança inválido. Recarregue a página.'; $csLogsFlashType='danger'; }
    else {
        $mode=(string)($_POST['clear_logs']??'all'); $allFiles=cs_logs_clearable_files($sources); $targets=$allFiles;
        if($mode==='visible'){
            $requested=(string)($_POST['source']??'all');
            if($requested!=='all' && isset($sources[$requested])){ $visible=[]; foreach(cs_logs_files($sources[$requested]['paths']) as $vp){$vr=realpath($vp);if($vr)$visible[$vr]=true;} $targets=array_values(array_filter($allFiles,function($f)use($visible){return isset($visible[$f]);})); }
        }
        $cleared=0;$failed=0; foreach($targets as $target){if(cs_logs_truncate_file($target))$cleared++;else$failed++;}
        $audit=__DIR__.'/logs/security.log'; @file_put_contents($audit,date('Y-m-d H:i:s').' [info] Logs limpos pelo administrador ('.$cleared.' arquivo(s), falhas: '.$failed.")\n",FILE_APPEND|LOCK_EX);
        $csLogsFlash=$cleared.' arquivo(s) de log foram limpos.'.($failed?' '.$failed.' arquivo(s) não puderam ser alterados por permissão.':''); $csLogsFlashType=$failed?'warning':'success';
    }
}
$selected=(string)(isset($_GET['source'])?$_GET['source']:'all'); if ($selected!=='all' && !isset($sources[$selected])) $selected='all';
$period=(string)(isset($_GET['period'])?$_GET['period']:'24h'); if (!in_array($period,['1h','6h','24h','7d','all'],true)) $period='24h';
$severity=(string)(isset($_GET['severity'])?$_GET['severity']:'all'); if (!in_array($severity,['all','error','warning','info','other'],true)) $severity='all';
$query=trim((string)(isset($_GET['q'])?$_GET['q']:'')); if (strlen($query)>120) $query=substr($query,0,120);
function cs_logs_panel_db_rows($period, $severity, $query, $limit=300) {
    global $db;
    $rows=[];
    if (!($db instanceof mysqli) || $db->connect_errno) return $rows;
    $check=@$db->query("SHOW TABLES LIKE 'panel_logs'");
    if (!$check || $check->num_rows < 1) return $rows;
    $limit=max(1,min(500,(int)$limit));
    $where=[];
    $seconds=cs_logs_period_seconds($period);
    if ($seconds) $where[]='`date` >= '.intval(time()-$seconds);
    $sql='SELECT `id`,`log_message`,`date` FROM `panel_logs`'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY `id` DESC LIMIT '.$limit;
    $q=@$db->query($sql); if (!$q) return $rows;
    while ($r=$q->fetch_assoc()) {
        $id=intval($r['id']??0); $ts=intval($r['date']??0);
        $code='ERR-'.str_pad((string)$id,6,'0',STR_PAD_LEFT);
        $text='['.date('Y-m-d H:i:s',$ts).'] ['.$code.'] '.cs_logs_redact(strip_tags((string)($r['log_message']??'')));
        $sev=cs_logs_severity($text);
        if ($severity!=='all' && $sev!==$severity) continue;
        if ($query!=='' && stripos($text,$query)===false) continue;
        $rows[]=['text'=>$text,'time'=>$ts,'severity'=>$sev];
    }
    return $rows;
}

$sections=[]; $recent24Errors=0; $recent24Warnings=0; $visibleCount=0;
foreach ($sources as $key=>$source) {
    if ($selected!=='all' && $selected!==$key) continue;
    foreach (cs_logs_files($source['paths']) as $path) {
        $tail=cs_logs_tail($path); $mtime=(int)@filemtime($path); $filtered=[];
        if ($tail['ok']) {
            $filtered=cs_logs_filter_lines($tail['lines'],$period,$severity,$query,$mtime); $visibleCount+=count($filtered);
            $last24=cs_logs_filter_lines($tail['lines'],'24h','all','',$mtime);
            foreach ($last24 as $row) { if ($row['severity']==='error') $recent24Errors++; elseif ($row['severity']==='warning') $recent24Warnings++; }
        }
        $sections[]=['key'=>$key,'label'=>$source['label'],'path'=>$path,'tail'=>$tail,'filtered'=>$filtered,'mtime'=>$mtime];
    }
}
if ($selected==='all' || $selected==='panel') {
    $panelDbFiltered=cs_logs_panel_db_rows($period,$severity,$query,300);
    $panelDb24=cs_logs_panel_db_rows('24h','all','',300);
    $visibleCount+=count($panelDbFiltered);
    foreach($panelDb24 as $row){ if($row['severity']==='error')$recent24Errors++; elseif($row['severity']==='warning')$recent24Warnings++; }
    $sections[]=['key'=>'panel','label'=>'Painel / erros internos (banco)','path'=>'panel_logs (MariaDB) — somente leitura','tail'=>['ok'=>true,'text'=>'','lines'=>[],'truncated'=>false],'filtered'=>$panelDbFiltered,'mtime'=>time()];
}
$m3uJobs=count(cs_logs_files([__DIR__.'/storage/import_jobs'])); $m3u2Jobs=count(glob(__DIR__.'/storage/m3u2/jobs/*.json') ?: []); $generatedAt=date('Y-m-d H:i:s');
include $rSettings['sidebar'] ? 'header_sidebar.php' : 'header.php';
?>
<style>
.cslog-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:18px}.cslog-stat{border-radius:16px;padding:16px 18px;background:var(--card-bg,#151b27);border:1px solid rgba(120,145,180,.22);min-width:0}.cslog-stat strong{display:block;font-size:1.45rem}.cslog-stat small{opacity:.75}.cslog-ok{border-left:4px solid #1abc9c}.cslog-bad{border-left:4px solid #ff5b5b}.cslog-warn{border-left:4px solid #f7b84b}.cslog-source-head{gap:10px}.cslog-path{max-width:68%;overflow-wrap:anywhere;word-break:break-word}.cslog-pre{white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;max-height:440px;overflow:auto;background:#10151d;color:#d7e1ee;padding:14px;border-radius:10px;font-size:12.5px;line-height:1.5}.cslog-empty{padding:14px;border-radius:10px;background:rgba(86,195,214,.08);color:#8aa1ba}.cslog-filters{display:grid;grid-template-columns:1.1fr .8fr .8fr 1.4fr auto;gap:10px;align-items:end}.cslog-filters label{display:block;margin:0 0 5px;font-weight:600}.cslog-meta{margin-top:10px;overflow-wrap:anywhere}.cslog-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.cslog-actions form{margin:0}.cslog-danger-note{font-size:12px;opacity:.78;margin-top:6px}
@media(max-width:900px){.cslog-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.cslog-filters{grid-template-columns:1fr 1fr}.cslog-filters .cslog-search{grid-column:1/-1}.cslog-filters .cslog-submit{grid-column:1/-1}.cslog-path{max-width:100%}}
@media(max-width:576px){.cslog-grid{grid-template-columns:1fr}.cslog-filters{grid-template-columns:1fr}.cslog-filters .cslog-search,.cslog-filters .cslog-submit{grid-column:auto}.cslog-source-head{display:block!important}.cslog-source-head h5{margin-bottom:8px}.cslog-path{display:block;font-size:11px}.cslog-pre{max-height:360px;padding:12px;font-size:11.5px}.card-body{overflow:hidden}}
</style>
<div class="wrapper"><div class="container-fluid">
<div class="row"><div class="col-12"><div class="page-title-box"><h4 class="page-title"><i class="mdi mdi-file-search"></i> Logs e erros do sistema</h4></div></div></div>
<div class="alert alert-info"><strong>Diagnóstico seguro:</strong> detalhes técnicos ficam restritos a esta tela administrativa. Credenciais encontradas em URLs são mascaradas. Erros históricos não são tratados como falhas atuais.</div>
<?php if ($csLogsFlash!==''): ?><div class="alert alert-<?=cs_logs_h($csLogsFlashType)?>"><?=cs_logs_h($csLogsFlash)?></div><?php endif; ?>
<div class="cslog-grid">
 <div class="cslog-stat <?=$recent24Errors?'cslog-bad':'cslog-ok'?>"><small>Estado atual · 24h</small><strong><?=$recent24Errors?intval($recent24Errors).' erro(s)':'Operacional'?></strong><span><?=$recent24Errors?'Há erros recentes para revisar.':'Nenhum erro detectado nas fontes acessíveis.'?></span></div>
 <div class="cslog-stat cslog-warn"><small>Avisos · 24h</small><strong><?=intval($recent24Warnings)?></strong><span>Warnings/notices nas fontes carregadas.</span></div>
 <div class="cslog-stat"><small>Resultados visíveis</small><strong><?=intval($visibleCount)?></strong><span>Após aplicar os filtros atuais.</span></div>
 <div class="cslog-stat"><small>Jobs</small><strong><?=intval($m3uJobs+$m3u2Jobs)?></strong><span>M3U <?=intval($m3uJobs)?> · M3U 2 <?=intval($m3u2Jobs)?></span></div>
</div>
<div class="card"><div class="card-body"><form method="get" class="cslog-filters">
<div><label for="source">Fonte</label><select name="source" id="source" class="form-control"><option value="all">Todas as fontes</option><?php foreach($sources as $key=>$source): ?><option value="<?=cs_logs_h($key)?>" <?=$selected===$key?'selected':''?>><?=cs_logs_h($source['label'])?></option><?php endforeach; ?></select></div>
<div><label for="period">Período</label><select name="period" id="period" class="form-control"><?php foreach(['1h'=>'1 hora','6h'=>'6 horas','24h'=>'24 horas','7d'=>'7 dias','all'=>'Todo histórico'] as $k=>$v): ?><option value="<?=$k?>" <?=$period===$k?'selected':''?>><?=$v?></option><?php endforeach; ?></select></div>
<div><label for="severity">Severidade</label><select name="severity" id="severity" class="form-control"><?php foreach(['all'=>'Todas','error'=>'Erros','warning'=>'Avisos','info'=>'Informações','other'=>'Outros'] as $k=>$v): ?><option value="<?=$k?>" <?=$severity===$k?'selected':''?>><?=$v?></option><?php endforeach; ?></select></div>
<div class="cslog-search"><label for="q">Buscar</label><input type="search" name="q" id="q" class="form-control" value="<?=cs_logs_h($query)?>" placeholder="arquivo, evento, código, mensagem..."></div>
<div class="cslog-submit"><button class="btn btn-primary btn-block"><i class="mdi mdi-filter-variant"></i> Aplicar</button></div>
</form><div class="text-muted cslog-meta">Atualizado em <?=cs_logs_h($generatedAt)?> · O filtro padrão mostra somente as últimas 24 horas. Selecione <strong>Todo histórico</strong> para consultar registros antigos.</div>
<div class="cslog-actions">
<form method="post" onsubmit="return confirm('Limpar os logs da fonte selecionada? Esta ação não altera o banco.');"><input type="hidden" name="csrf" value="<?=cs_logs_h($csLogsCsrf)?>"><input type="hidden" name="clear_logs" value="visible"><input type="hidden" name="source" value="<?=cs_logs_h($selected)?>"><button type="submit" class="btn btn-outline-warning"><i class="mdi mdi-broom"></i> Limpar logs visíveis</button></form>
<form method="post" onsubmit="return confirm('ATENÇÃO: limpar TODOS os logs gerenciados pelo CS PLAYER? Os arquivos serão esvaziados, não excluídos.');"><input type="hidden" name="csrf" value="<?=cs_logs_h($csLogsCsrf)?>"><input type="hidden" name="clear_logs" value="all"><button type="submit" class="btn btn-danger"><i class="mdi mdi-delete-sweep"></i> Limpar todos os logs</button></form>
</div><div class="cslog-danger-note">A limpeza usa uma lista segura do CS PLAYER; não remove logs arbitrários do Ubuntu/MariaDB e não altera o banco.</div></div></div>
<?php if (!$sections): ?><div class="alert alert-warning">Nenhum arquivo de log acessível foi encontrado. Confira as permissões e os caminhos configurados.</div><?php endif; ?>
<?php foreach($sections as $section): ?><div class="card"><div class="card-body"><div class="d-flex justify-content-between align-items-center flex-wrap cslog-source-head"><h5 class="header-title"><i class="mdi mdi-file-document-outline"></i> <?=cs_logs_h($section['label'])?></h5><code class="cslog-path"><?=cs_logs_h($section['path'])?></code></div>
<?php if (!$section['tail']['ok']): ?><div class="alert alert-warning mb-0"><?=cs_logs_h($section['tail']['text'])?></div><?php elseif (!$section['filtered']): ?><div class="cslog-empty">Nenhum registro corresponde aos filtros selecionados neste arquivo. Isso não apaga nem modifica o histórico.</div><?php else: ?><pre class="cslog-pre" tabindex="0"><?php foreach($section['filtered'] as $row) echo cs_logs_h($row['text'])."\n"; ?></pre><?php if (!empty($section['tail']['truncated'])): ?><small class="text-muted">Leitura limitada à parte mais recente do arquivo para proteger memória e desempenho.</small><?php endif; ?><?php endif; ?></div></div><?php endforeach; ?>
</div></div>
<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-md-12 copyright text-center"><?=getFooter()?></div></div></div></footer>
<script src="assets/js/vendor.min.js"></script><script src="assets/js/app.min.js"></script></body></html>

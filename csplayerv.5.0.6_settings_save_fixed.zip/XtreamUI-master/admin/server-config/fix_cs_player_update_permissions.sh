#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/home/xtreamcodes/iptv_xtream_codes"
WEB_USER="${1:-www-data}"
WEB_GROUP="${2:-$WEB_USER}"

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Execute como root: bash admin/server-config/fix_cs_player_update_permissions.sh [usuario-web] [grupo-web]" >&2
  exit 1
fi

if ! id "$WEB_USER" >/dev/null 2>&1; then
  echo "Usuário web inexistente: $WEB_USER" >&2
  exit 2
fi
if ! getent group "$WEB_GROUP" >/dev/null 2>&1; then
  echo "Grupo web inexistente: $WEB_GROUP" >&2
  exit 3
fi
if [[ ! -d "$ROOT" ]]; then
  echo "Diretório CS Player não encontrado: $ROOT" >&2
  exit 4
fi

# Mantém o proprietário atual e concede ao grupo do PHP-FPM escrita controlada
# apenas na árvore do aplicativo. Não toca no banco MariaDB nem em /etc.
chgrp -R "$WEB_GROUP" "$ROOT"
find "$ROOT" -xdev -type d -exec chmod 2775 {} +
find "$ROOT" -xdev -type f -exec chmod 0664 {} +

# Scripts executáveis conhecidos continuam executáveis.
find "$ROOT" -xdev -type f \( -name '*.sh' -o -path '*/pytools/*' \) -exec chmod g+x {} + 2>/dev/null || true

install -d -o "$WEB_USER" -g "$WEB_GROUP" -m 2775 \
  "$ROOT/admin/logs/cs-player" \
  "$ROOT/admin/logs/cs-player/update-progress" \
  "$ROOT/admin/backups/remote-updates"

printf 'Permissões de atualização preparadas.\nRoot: %s\nUsuário PHP-FPM: %s\nGrupo: %s\nBanco de dados: não alterado.\n' "$ROOT" "$WEB_USER" "$WEB_GROUP"

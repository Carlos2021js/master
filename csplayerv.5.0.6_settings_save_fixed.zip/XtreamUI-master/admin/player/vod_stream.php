<?php
// CS PLAYER 4.0.4 — endpoint exclusivo de Filmes/Séries.
require __DIR__ . '/bootstrap.php';
$cfg = cs_player_load_config();
$type = strtolower((string)($_GET['type'] ?? 'movie'));
$_GET['type'] = $type === 'series' ? 'series' : 'movie';
$ext = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string)($_GET['ext'] ?? '')));
if ($ext === 'mkv' && !empty($cfg['vod_mkv_remux'])) {
    $_GET['format'] = 'remux';
}
if (empty($_GET['delivery']) || $_GET['delivery'] === 'auto') {
    $_GET['delivery'] = (string)($cfg['vod_proxy_mode'] ?? 'proxy');
}
require __DIR__ . '/stream.php';

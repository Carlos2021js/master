CS PLAYER — Smart Delivery Extreme

Correção para Canais, Filmes e Séries quando o modo Direct não toca no navegador.

- Direct continua como primeira tentativa quando selecionado.
- Em falha de CORS, HLS, MPEG-TS, redirect ou container direto, o player troca sozinho para o proxy interno.
- Canais: HLS/M3U8 e MPEG-TS/TS com fallback automático.
- Filmes: MP4/MKV/HLS com fallback automático.
- Séries/Episódios: MP4/MKV/HLS com fallback automático.
- A troca é por reprodução e não muda o banco de dados nem a configuração global.
- Erros de autoplay (NotAllowedError) não acionam proxy desnecessariamente.

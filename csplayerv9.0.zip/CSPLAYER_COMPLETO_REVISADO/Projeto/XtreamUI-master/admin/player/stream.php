<?php
require __DIR__ . '/proxy_lib.php';
cs_player_require_login();
$cfg=cs_player_load_config();$requested=isset($_GET['dns'])?(int)$_GET['dns']:null;$row=cs_player_session_dns($cfg,$requested);if(!$row){http_response_code(503);exit;}
$type=(string)($_GET['type']??'live');$id=(int)($_GET['id']??0);$ext=preg_replace('/[^a-zA-Z0-9]/','',(string)($_GET['ext']??''));if(!$id){http_response_code(400);exit;}
$u=rawurlencode((string)$_SESSION['cs_player_username']);$p=rawurlencode((string)$_SESSION['cs_player_password']);$base=rtrim($row['url'],'/');
if($type==='live'){$ext='m3u8';$url="$base/live/$u/$p/$id.$ext";}elseif($type==='movie'){$ext=$ext?:'mp4';$url="$base/movie/$u/$p/$id.$ext";}else{$ext=$ext?:'mp4';$url="$base/series/$u/$p/$id.$ext";}
if($type!=='live'){cs_stream_binary($url);}[$code,$body,$ct,$effective]=cs_fetch_small($url);if($code<200||$code>=400){http_response_code($code?:502);exit('Falha no stream');}header('Content-Type: application/vnd.apple.mpegurl');header('Cache-Control: no-store');echo cs_rewrite_manifest($body,$effective);

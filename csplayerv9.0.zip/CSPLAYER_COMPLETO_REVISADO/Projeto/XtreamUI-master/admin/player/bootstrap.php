<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('CSPLAYER_WEB');
    session_start();
}

define('CS_PLAYER_ROOT', __DIR__);
if (!defined('CS_PLAYER_INTERNAL')) { define('CS_PLAYER_INTERNAL', true); }
define('CS_PLAYER_SHARED_STORAGE', CS_PLAYER_ROOT . '/storage');
define('CS_PLAYER_CONFIG_FILE', CS_PLAYER_SHARED_STORAGE . '/config.php');
define('CS_PLAYER_LEGACY_CONFIG_FILE', CS_PLAYER_SHARED_STORAGE . '/config.json');

function cs_player_default_config(): array {
    return [
        'enabled' => true,
        'brand' => 'CS Player',
        'login_title' => 'CS Player',
        'login_subtitle' => 'Entre com sua assinatura para continuar',
        'home_title' => 'Início',
        'smart_login' => true,
        'dns_failover' => true,
        'pip_enabled' => true,
        'autoplay_next' => false,
        'remember_position' => true,
        'hls_retries' => 4,
        'stall_timeout' => 12,
        'request_timeout' => 8,
        'dns' => [],
    ];
}

function cs_player_load_config(): array {
    $default = cs_player_default_config();
    $data = null;

    if (is_file(CS_PLAYER_CONFIG_FILE)) {
        $loaded = include CS_PLAYER_CONFIG_FILE;
        if (is_array($loaded)) {
            $data = $loaded;
        }
    } elseif (is_file(CS_PLAYER_LEGACY_CONFIG_FILE)) {
        $raw = file_get_contents(CS_PLAYER_LEGACY_CONFIG_FILE);
        $legacy = json_decode((string)$raw, true);
        if (is_array($legacy)) {
            $data = $legacy;
            // Migração transparente: preserva a configuração existente sem banco de dados.
            if (cs_player_save_config($legacy)) {
                @unlink(CS_PLAYER_LEGACY_CONFIG_FILE);
            }
        }
    }

    if (!is_array($data)) {
        return $default;
    }
    $cfg = array_replace($default, $data);
    $cfg['dns'] = is_array($cfg['dns'] ?? null) ? array_values($cfg['dns']) : [];
    return $cfg;
}

function cs_player_save_config(array $config): bool {
    $dir = dirname(CS_PLAYER_CONFIG_FILE);
    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
        return false;
    }
    $tmp = CS_PLAYER_CONFIG_FILE . '.tmp';
    $php = "<?php\nif (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }\nreturn " . var_export($config, true) . ";\n";
    if (file_put_contents($tmp, $php, LOCK_EX) === false) {
        return false;
    }
    @chmod($tmp, 0640);
    if (!rename($tmp, CS_PLAYER_CONFIG_FILE)) {
        @unlink($tmp);
        return false;
    }
    @chmod(CS_PLAYER_CONFIG_FILE, 0640);
    return true;
}

function cs_player_normalize_dns(string $url): string {
    $url = trim($url);
    if ($url === '') return '';
    if (!preg_match('~^https?://~i', $url)) {
        // IPv6 sem colchetes é ambíguo para parse_url; trate-o como host puro.
        if (substr_count($url, ':') >= 2 && strpos($url, '/') === false && $url[0] !== '[') {
            $url = 'http://[' . trim($url, '[]') . ']';
        } else {
            $url = 'http://' . $url;
        }
    }
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) return '';
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    if (!in_array($scheme, ['http', 'https'], true)) return '';
    $host = strtolower(trim((string)$parts['host']));
    if ($host === '') return '';
    if (strpos($host, ':') !== false && $host[0] !== '[') $host = '[' . $host . ']';
    $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
    $path = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
    return $scheme . '://' . $host . $port . $path;
}

function cs_player_with_port(string $url, int $port): string {
    $url = cs_player_normalize_dns($url);
    if ($url === '' || $port < 1 || $port > 65535) return $url;
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['host']) || isset($parts['port'])) return $url;
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    $host = (string)$parts['host'];
    $path = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
    return $scheme . '://' . $host . ':' . $port . $path;
}

function cs_player_build_server_url(array $server): string {
    $domain = trim((string)($server['domain_name'] ?? ''));
    $ip = trim((string)($server['server_ip'] ?? ''));
    $httpPort = (int)($server['http_broadcast_port'] ?? 0);
    $httpsPort = (int)($server['https_broadcast_port'] ?? 0);

    // Domínio/IP podem ser cadastrados com esquema e porta. Quando a porta
    // não está presente, ela é anexada explicitamente, inclusive 80/443,
    // para que a sincronização e o diagnóstico mostrem o endpoint real.
    $source = $domain !== '' ? $domain : $ip;
    if ($source === '') return '';
    $candidate = cs_player_normalize_dns($source);
    if ($candidate === '') return '';
    $parts = parse_url($candidate);
    if (!is_array($parts)) return '';
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    $port = $scheme === 'https' ? $httpsPort : $httpPort;
    return isset($parts['port']) ? $candidate : cs_player_with_port($candidate, $port > 0 ? $port : ($scheme === 'https' ? 443 : 80));
}

function cs_player_server_dns_from_rows(array $servers): array {
    $out = [];
    foreach ($servers as $server) {
        if (!is_array($server)) continue;
        if (isset($server['status']) && (int)$server['status'] !== 1) continue;
        $url = cs_player_build_server_url($server);
        if ($url === '') continue;
        $id = (int)($server['id'] ?? 0);
        $httpPort = (int)($server['http_broadcast_port'] ?? 0);
        $httpsPort = (int)($server['https_broadcast_port'] ?? 0);
        $name = trim((string)($server['server_name'] ?? ''));
        if ($name === '') $name = $id > 0 ? 'Servidor #' . $id : 'Servidor CS Player';
        $out[] = [
            'id' => 'server_' . ($id > 0 ? $id : substr(sha1($url), 0, 8)),
            'server_id' => $id,
            'name' => $name,
            'url' => $url,
            'http_port' => $httpPort,
            'https_port' => $httpsPort,
            'enabled' => true,
            'priority' => max(1, $id > 0 ? $id : count($out) + 1),
            'fixed' => true,
            'source' => 'streaming_servers',
        ];
    }
    return $out;
}

function cs_player_decode_main_config(string $path): ?array {
    if (!is_file($path)) return null;
    $raw = file_get_contents($path);
    if (!is_string($raw) || $raw === '') return null;
    $decoded = base64_decode($raw, true);
    if ($decoded === false) return null;
    $key = '5709650b0d7806074842c6de575025b1';
    $out = '';
    $keyLen = strlen($key);
    for ($i = 0, $len = strlen($decoded); $i < $len; $i++) {
        $out .= chr(ord($decoded[$i]) ^ ord($key[$i % $keyLen]));
    }
    $data = json_decode($out, true);
    return is_array($data) ? $data : null;
}

function cs_player_internal_server_dns(): array {
    static $cache = null;
    if (is_array($cache)) return $cache;
    $cache = [];

    $cfgPath = '/home/xtreamcodes/iptv_xtream_codes/config';
    $info = cs_player_decode_main_config($cfgPath);
    if (!is_array($info)) return $cache;
    if (!class_exists('mysqli')) return $cache;

    mysqli_report(MYSQLI_REPORT_OFF);
    $db = @new mysqli(
        (string)($info['host'] ?? 'localhost'),
        (string)($info['db_user'] ?? 'root'),
        (string)($info['db_pass'] ?? ''),
        (string)($info['db_name'] ?? 'xtream_iptvpro'),
        (int)($info['db_port'] ?? 3306)
    );
    if ($db->connect_errno) return $cache;
    $db->set_charset('utf8mb4');
    $result = @$db->query("SELECT `id`,`server_name`,`domain_name`,`server_ip`,`http_broadcast_port`,`https_broadcast_port`,`status` FROM `streaming_servers` WHERE `status` = 1 ORDER BY `id` ASC");
    if ($result) {
        $rows = [];
        while ($row = $result->fetch_assoc()) $rows[] = $row;
        $cache = cs_player_server_dns_from_rows($rows);
        $result->free();
    }
    $db->close();
    return $cache;
}

function cs_player_active_dns(array $cfg): array {
    // Servidores do próprio CS Player são sempre fixos e sincronizados com streaming_servers.
    $rows = cs_player_internal_server_dns();
    $seen = [];
    foreach ($rows as $row) $seen[strtolower(rtrim((string)$row['url'], '/'))] = true;

    // DNS adicionados manualmente são destinados a outros projetos/servidores externos.
    foreach (($cfg['dns'] ?? []) as $idx => $row) {
        if (!is_array($row) || empty($row['enabled'])) continue;
        $url = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($url === '') continue;
        $key = strtolower(rtrim($url, '/'));
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $row['url'] = $url;
        $row['_index'] = 'external:' . $idx;
        $row['fixed'] = false;
        $row['source'] = 'external';
        // Servidores internos têm precedência; externos começam depois.
        $row['_sort'] = 10000 + (int)($row['priority'] ?? 100);
        $rows[] = $row;
    }
    foreach ($rows as $i => &$row) {
        if (!isset($row['_index'])) $row['_index'] = 'server:' . (int)($row['server_id'] ?? $i);
        if (!isset($row['_sort'])) $row['_sort'] = (int)($row['priority'] ?? ($i + 1));
    }
    unset($row);
    usort($rows, static fn($a,$b) => (int)$a['_sort'] <=> (int)$b['_sort']);
    return array_values($rows);
}
function cs_player_http_json(string $url, int $timeout = 8): ?array {
    if (!function_exists('curl_init')) return null;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_USERAGENT => 'CSPlayer-Web/1.0',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if (!is_string($body) || $code < 200 || $code >= 400) return null;
    $data = json_decode($body, true);
    return is_array($data) ? $data : null;
}

function cs_player_api_call(string $dns, string $username, string $password, string $action = '', array $extra = []): ?array {
    $params = array_merge(['username' => $username, 'password' => $password], $extra);
    if ($action !== '') $params['action'] = $action;
    $cfg = cs_player_load_config();
    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));
    return cs_player_http_json(rtrim($dns, '/') . '/player_api.php?' . http_build_query($params), $timeout);
}

function cs_player_is_authenticated_response(?array $data): bool {
    if (!$data || !isset($data['user_info']) || !is_array($data['user_info'])) return false;
    $ui = $data['user_info'];
    if (isset($ui['auth']) && (int)$ui['auth'] !== 1) return false;
    if (isset($ui['status']) && !in_array(strtolower((string)$ui['status']), ['active','1'], true)) return false;
    return !empty($ui['username']) || isset($ui['auth']);
}

function cs_player_require_login(): void {
    if (empty($_SESSION['cs_player_auth']) || empty($_SESSION['cs_player_username']) || !isset($_SESSION['cs_player_dns_index'])) {
        header('Location: index.php');
        exit;
    }
}

function cs_player_json(array $payload, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function cs_player_session_dns(array $cfg, $requested = null): ?array {
    $active = cs_player_active_dns($cfg);
    if (!$active) return null;
    $index = $requested ?? ($_SESSION['cs_player_dns_index'] ?? '');
    foreach ($active as $row) {
        if ((string)$row['_index'] === (string)$index) return $row;
    }
    return $active[0];
}

const PlayerUI = (() => {
  const themeKey = 'csplayer_theme';
  let data = { content: { live: [], movies: [], series: [] }, categories: {}, server: { name: 'DNS' } };
  let currentType = 'home';
  let currentItem = null;
  let hls = null;
  let stallTimer = null;
  let lastProgress = 0;
  let retries = 0;

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (match) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[match]));
  const imageOf = (item) => item?.stream_icon || item?.cover || item?.cover_big || item?.movie_image || item?.backdrop_path?.[0] || '';
  const titleOf = (item) => item?.name || item?.title || item?.stream_display_name || 'Sem título';
  const typeOf = (item, type) => type === 'mixed' ? (item?._type || 'movie') : type;

  function safeRead(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch (error) { return fallback; }
  }

  function themeFromStorage() {
    try {
      const stored = localStorage.getItem(themeKey);
      if (stored === 'light' || stored === 'dark') return stored;
    } catch (error) {}
    return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }

  function setTheme(theme) {
    const next = theme === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem(themeKey, next); } catch (error) {}
    const button = document.getElementById('themeToggle');
    if (button) {
      button.textContent = next === 'dark' ? '☀' : '☾';
      button.title = next === 'dark' ? 'Ativar modo claro' : 'Ativar modo escuro';
      button.setAttribute('aria-label', button.title);
      button.setAttribute('aria-pressed', String(next === 'dark'));
    }
  }

  function toggleTheme() {
    setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  }

  async function fetchJSON(url) {
    const response = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
    let payload = {};
    try { payload = await response.json(); } catch (error) {}
    if (response.status === 401) {
      location.href = 'index.php';
      throw new Error('Sessão expirada.');
    }
    if (!response.ok || payload.ok === false) {
      throw new Error(payload.error || `Falha na comunicação (${response.status}).`);
    }
    return payload;
  }

  function card(item, type, poster = false) {
    const cardType = typeOf(item, type);
    const id = item?.stream_id || item?.series_id || item?.id || 0;
    const image = imageOf(item);
    return `<article class="media-card ${poster ? 'poster' : ''}" data-type="${esc(cardType)}" data-source="${type === 'mixed' ? 'favorites' : esc(cardType)}" data-id="${esc(id)}" tabindex="0" role="button" aria-label="Abrir ${esc(titleOf(item))}">${image ? `<img loading="lazy" src="${esc(image)}" alt="" onerror="this.remove()">` : `<div class="fallback">${esc(titleOf(item))}</div>`}<div class="caption">${esc(titleOf(item))}</div></article>`;
  }

  function rail(title, items, type, poster = false) {
    if (!Array.isArray(items) || !items.length) return '';
    return `<section class="rail" data-type="${esc(type)}"><h2>${esc(title)}</h2><div class="rail-track ${poster ? 'poster-track' : ''}">${items.slice(0, 80).map((item) => card(item, type, poster)).join('')}</div></section>`;
  }

  function currentList(type) {
    if (type === 'live') return data.content.live || [];
    if (type === 'movie') return data.content.movies || [];
    if (type === 'series') return data.content.series || [];
    return safeRead('csplayer_favorites', []);
  }

  function render() {
    const rails = document.getElementById('rails');
    if (!rails) return;
    let html = '';
    if (currentType === 'home') {
      html += rail('TV ao vivo', data.content.live, 'live');
      html += rail('Filmes para você', data.content.movies, 'movie', true);
      html += rail('Séries em destaque', data.content.series, 'series', true);
    } else if (currentType === 'favorites') {
      const favorites = safeRead('csplayer_favorites', []);
      html = rail('Minha Lista', favorites, 'mixed', true) || '<div class="empty-state">Sua lista ainda está vazia.</div>';
    } else {
      const map = {
        live: ['Canais', data.content.live, 'live', false],
        movies: ['Filmes', data.content.movies, 'movie', true],
        series: ['Séries', data.content.series, 'series', true]
      };
      const selected = map[currentType];
      html = selected ? rail(selected[0], selected[1], selected[2], selected[3]) : '';
    }
    rails.innerHTML = html || '<div class="empty-state">Nenhum conteúdo disponível no momento.</div>';
    bindCards();
    fillCategories();
  }

  function bindCards() {
    document.querySelectorAll('.media-card').forEach((element) => {
      const open = () => {
        const type = element.dataset.type;
        const source = element.dataset.source;
        const id = String(element.dataset.id);
        const list = source === 'favorites' ? safeRead('csplayer_favorites', []) : currentList(type);
        const item = list.find((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === id);
        if (item) showInfo(item, typeOf(item, type));
      };
      element.addEventListener('click', open);
      element.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(); }
      });
    });
  }

  function fillCategories() {
    const select = document.getElementById('categoryFilter');
    if (!select) return;
    const key = currentType === 'movies' ? 'movies' : currentType === 'series' ? 'series' : 'live';
    const categories = currentType === 'favorites' ? [] : (data.categories?.[key] || []);
    select.disabled = !categories.length;
    select.innerHTML = '<option value="">Todas as categorias</option>' + categories.map((category) => `<option value="${esc(category.category_id)}">${esc(category.category_name)}</option>`).join('');
  }

  function setHero(item, type) {
    if (!item) return;
    currentItem = { item, type: typeOf(item, type) };
    const title = document.getElementById('heroTitle');
    const meta = document.getElementById('heroMeta');
    const description = document.getElementById('heroDesc');
    const hero = document.getElementById('hero');
    if (title) title.textContent = titleOf(item);
    if (meta) meta.textContent = [item.releaseDate || item.release_date || item.year, item.rating ? `★ ${item.rating}` : ''].filter(Boolean).join(' · ');
    if (description) description.textContent = item.plot || item.description || 'Assista agora no CS Player.';
    const image = Array.isArray(item.backdrop_path) ? item.backdrop_path[0] : (item.backdrop_path || imageOf(item));
    if (hero && image) hero.style.backgroundImage = `url("${String(image).replace(/["\\]/g, '')}")`;
  }

  async function showInfo(item, type) {
    const normalizedType = typeOf(item, type);
    setHero(item, normalizedType);
    const body = document.getElementById('infoBody');
    if (!body) return;
    const isFavorite = safeRead('csplayer_favorites', []).some((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === String(item?.stream_id || item?.series_id || item?.id));
    body.innerHTML = `${imageOf(item) ? `<img src="${esc(imageOf(item))}" alt="" onerror="this.remove()">` : ''}<span class="eyebrow">${normalizedType === 'live' ? 'TV AO VIVO' : normalizedType === 'movie' ? 'FILME' : 'SÉRIE'}</span><h2>${esc(titleOf(item))}</h2><p>${esc(item.plot || item.description || 'Conteúdo disponível para reprodução.')}</p><div class="hero-buttons"><button class="light-btn" id="infoPlay" type="button">▶ Assistir</button><button class="dark-btn" id="favoriteBtn" type="button">${isFavorite ? '✓ Remover da lista' : '＋ Minha Lista'}</button></div>`;
    document.getElementById('infoModal')?.classList.remove('hidden');
    document.getElementById('infoPlay')?.addEventListener('click', () => play(item, normalizedType));
    document.getElementById('favoriteBtn')?.addEventListener('click', () => {
      const added = favorite(item, normalizedType);
      const button = document.getElementById('favoriteBtn');
      if (button) button.textContent = added ? '✓ Remover da lista' : '＋ Minha Lista';
    });
  }

  function favorite(item, type) {
    const favorites = safeRead('csplayer_favorites', []);
    const id = String(item?.stream_id || item?.series_id || item?.id);
    const index = favorites.findIndex((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === id);
    if (index >= 0) { favorites.splice(index, 1); localStorage.setItem('csplayer_favorites', JSON.stringify(favorites)); return false; }
    favorites.push({ ...item, _type: type });
    localStorage.setItem('csplayer_favorites', JSON.stringify(favorites.slice(-100)));
    return true;
  }

  async function play(item, type) {
    let normalizedType = typeOf(item, type);
    if (normalizedType === 'series') {
      const seriesInfo = await fetchJSON(`api.php?action=series_info&id=${encodeURIComponent(item.series_id)}`);
      const episodes = seriesInfo.data?.episodes || {};
      const seasons = Object.keys(episodes).sort((a, b) => Number(a) - Number(b));
      const first = seasons.length ? episodes[seasons[0]]?.[0] : null;
      if (!first) { setHealth('Nenhum episódio disponível.', false); return; }
      item = { ...first, stream_id: first.id || first.stream_id };
    }
    currentItem = { item, type: normalizedType };
    closeInfo();
    document.getElementById('playerModal')?.classList.remove('hidden');
    document.getElementById('playerTitle').textContent = titleOf(item);
    document.getElementById('playerStatus').textContent = data.server?.name || 'DNS';
    retries = 0;
    startStream();
  }

  function streamUrl() {
    const item = currentItem.item;
    const id = item.stream_id || item.id;
    const ext = item.container_extension || item.container || '';
    return `stream.php?type=${encodeURIComponent(currentItem.type)}&id=${encodeURIComponent(id)}&ext=${encodeURIComponent(ext)}&v=${Date.now()}`;
  }

  function startStream() {
    const video = document.getElementById('video');
    if (!video || !currentItem) return;
    const url = streamUrl();
    destroyHls();
    setHealth('Conectando...', false);
    if (currentItem.type === 'live' && window.Hls && Hls.isSupported()) {
      hls = new Hls({ enableWorker: true, lowLatencyMode: true, backBufferLength: 30, maxBufferLength: 25, maxBufferHole: .6 });
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => { video.play().catch(() => {}); setHealth('Online', true); });
      hls.on(Hls.Events.ERROR, (_, error) => { if (error.fatal) recover(); });
    } else {
      video.src = url;
      video.play().catch(() => {});
    }
    attachHealth();
    restorePosition();
  }

  function attachHealth() {
    const video = document.getElementById('video');
    if (!video) return;
    video.onplaying = () => setHealth('Reproduzindo', true);
    video.onwaiting = () => setHealth('Bufferizando...', false);
    video.onerror = () => recover();
    video.ontimeupdate = () => { lastProgress = Date.now(); savePosition(); };
    clearInterval(stallTimer);
    lastProgress = Date.now();
    stallTimer = setInterval(() => {
      const timeout = Number(window.CS_PLAYER_CONFIG?.stall || 12) * 1000;
      if (!video.paused && Date.now() - lastProgress > timeout) recover();
    }, 3000);
  }

  async function recover() {
    if (!currentItem) return;
    const limit = Number(window.CS_PLAYER_CONFIG?.retries || 4);
    if (retries < limit) {
      retries += 1;
      const position = document.getElementById('video')?.currentTime || 0;
      setHealth(`Reconectando ${retries}/${limit}...`, false);
      startStream();
      try { document.getElementById('video').currentTime = position; } catch (error) {}
      return;
    }
    if (window.CS_PLAYER_CONFIG?.failover) {
      setHealth('Testando DNS alternativo...', false);
      try {
        const response = await fetchJSON('api.php?action=failover');
        if (response.ok) {
          data.server.name = response.server;
          document.getElementById('serverBadge').textContent = response.server;
          document.getElementById('playerStatus').textContent = response.server;
          retries = 0;
          startStream();
          return;
        }
      } catch (error) {}
    }
    setHealth('Não foi possível recuperar o stream.', false);
  }

  function destroyHls() {
    if (hls) { hls.destroy(); hls = null; }
    const video = document.getElementById('video');
    if (video) { video.pause(); video.removeAttribute('src'); video.load(); }
  }

  function setHealth(text, online) {
    const label = document.getElementById('healthText');
    const dot = document.getElementById('healthDot');
    if (label) label.textContent = text;
    if (dot) { dot.style.background = online ? 'var(--success)' : 'var(--warning)'; dot.style.boxShadow = online ? '0 0 0 4px color-mix(in srgb, var(--success) 18%, transparent)' : '0 0 0 4px color-mix(in srgb, var(--warning) 18%, transparent)'; }
  }

  function closePlayer() { savePosition(); destroyHls(); clearInterval(stallTimer); document.getElementById('playerModal')?.classList.add('hidden'); }
  function closeInfo() { document.getElementById('infoModal')?.classList.add('hidden'); }
  function retry() { retries = 0; startStream(); }
  function keyForPos() { if (!currentItem) return ''; const item = currentItem.item; return `cspos:${currentItem.type}:${item.stream_id || item.id || item.series_id}`; }
  function savePosition() { if (!window.CS_PLAYER_CONFIG?.remember || !currentItem || currentItem.type === 'live') return; const video = document.getElementById('video'); if (video?.currentTime > 10) localStorage.setItem(keyForPos(), String(video.currentTime)); }
  function restorePosition() { if (!window.CS_PLAYER_CONFIG?.remember || currentItem?.type === 'live') return; const position = Number(localStorage.getItem(keyForPos()) || 0); if (position > 10) document.getElementById('video')?.addEventListener('loadedmetadata', () => { try { document.getElementById('video').currentTime = position; } catch (error) {} }, { once: true }); }

  function search(query) {
    const normalized = query.trim().toLowerCase();
    document.querySelectorAll('.media-card').forEach((cardElement) => { cardElement.style.display = !normalized || cardElement.textContent.toLowerCase().includes(normalized) ? '' : 'none'; });
  }

  async function filterCategory(event) {
    const id = event.target.value;
    if (!id) { render(); return; }
    const type = currentType === 'movies' ? 'movies' : currentType === 'series' ? 'series' : 'live';
    try {
      const response = await fetchJSON(`api.php?action=category&type=${type}&category_id=${encodeURIComponent(id)}`);
      data.content[type] = response.data || [];
      render();
    } catch (error) { setHealth(error.message, false); }
  }

  function focusSearch() { document.getElementById('globalSearch')?.focus(); }

  async function init() {
    setTheme(document.documentElement.dataset.theme || themeFromStorage());
    document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
    const rails = document.getElementById('rails');
    if (rails) rails.innerHTML = '<div class="skeleton"></div><div class="skeleton"></div>';
    try {
      data = await fetchJSON('api.php?action=home');
      const server = data.server?.name || 'DNS';
      const serverBadge = document.getElementById('serverBadge');
      if (serverBadge) serverBadge.textContent = server;
      const hero = data.content?.movies?.[0] || data.content?.series?.[0] || data.content?.live?.[0];
      setHero(hero, data.content?.movies?.[0] ? 'movie' : data.content?.series?.[0] ? 'series' : 'live');
      document.getElementById('heroPlay')?.addEventListener('click', () => currentItem && play(currentItem.item, currentItem.type));
      document.getElementById('heroInfo')?.addEventListener('click', () => currentItem && showInfo(currentItem.item, currentItem.type));
      render();
      document.querySelectorAll('[data-view]').forEach((button) => button.addEventListener('click', () => {
        currentType = button.dataset.view;
        document.querySelectorAll('[data-view]').forEach((element) => element.classList.toggle('active', element.dataset.view === currentType));
        render();
      }));
      document.getElementById('globalSearch')?.addEventListener('input', (event) => search(event.target.value));
      document.getElementById('categoryFilter')?.addEventListener('change', filterCategory);
      document.getElementById('pipBtn')?.addEventListener('click', async () => { try { if (document.pictureInPictureElement) await document.exitPictureInPicture(); else if (document.pictureInPictureEnabled) await document.getElementById('video').requestPictureInPicture(); } catch (error) {} });
      window.addEventListener('beforeunload', savePosition);
    } catch (error) {
      if (rails) rails.innerHTML = `<div class="empty-state">${esc(error.message || 'Não foi possível carregar o conteúdo.')}</div>`;
    }
  }

  return { init, showInfo, play, closePlayer, closeInfo, retry, focusSearch, toggleTheme };
})();
document.addEventListener('DOMContentLoaded', PlayerUI.init);

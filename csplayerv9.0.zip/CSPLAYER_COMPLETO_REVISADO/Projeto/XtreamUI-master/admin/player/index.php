<?php
require __DIR__ . '/bootstrap.php';
$cfg = cs_player_load_config();
if (empty($cfg['enabled'])) { http_response_code(503); exit('Web Player temporariamente indisponível.'); }
if (!empty($_SESSION['cs_player_auth'])) { header('Location: home.php'); exit; }
$error = $_SESSION['cs_player_error'] ?? '';
unset($_SESSION['cs_player_error']);
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#080b12"><title><?=htmlspecialchars($cfg['brand'])?> · Web Player</title><script>try{document.documentElement.dataset.theme=localStorage.getItem('csplayer_theme')||(window.matchMedia&&window.matchMedia('(prefers-color-scheme: light)').matches?'light':'dark')}catch(e){document.documentElement.dataset.theme='dark'}</script><link rel="stylesheet" href="assets/player.css"></head>
<body class="login-page"><div class="login-backdrop"></div><header class="login-header"><div class="brand-mark">CS</div><div class="brand-name"><?=htmlspecialchars($cfg['brand'])?></div><button id="themeToggle" class="theme-toggle" type="button" title="Ativar modo claro" aria-label="Ativar modo claro" aria-pressed="true">☀</button></header>
<main class="login-shell"><section class="login-card"><span class="eyebrow">WEB PLAYER</span><h1><?=htmlspecialchars($cfg['login_title'])?></h1><p><?=htmlspecialchars($cfg['login_subtitle'])?></p>
<?php if ($error): ?><div class="alert error"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="post" action="auth.php" autocomplete="on"><label>Usuário<input name="username" required autocomplete="username" placeholder="Seu usuário"></label><label>Senha<div class="password-wrap"><input id="password" type="password" name="password" required autocomplete="current-password" placeholder="Sua senha"><button type="button" class="ghost-icon" onclick="togglePass()" aria-label="Mostrar senha">Ver</button></div></label><button class="primary-btn" type="submit"><span>Entrar</span><small>detecção inteligente de DNS</small></button></form>
<div class="login-features"><span>✓ Multi-DNS</span><span>✓ Reconexão</span><span>✓ PiP</span></div></section></main>
<script>function togglePass(){const i=document.getElementById('password');const b=document.querySelector('.password-wrap .ghost-icon');i.type=i.type==='password'?'text':'password';if(b)b.textContent=i.type==='password'?'Ver':'Ocultar';}document.getElementById('themeToggle')?.addEventListener('click',()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;try{localStorage.setItem('csplayer_theme',next)}catch(e){}const b=document.getElementById('themeToggle');if(b){b.textContent=next==='dark'?'☀':'☾';b.title=next==='dark'?'Ativar modo claro':'Ativar modo escuro';b.setAttribute('aria-label',b.title);b.setAttribute('aria-pressed',String(next==='dark'));}});</script></body></html>

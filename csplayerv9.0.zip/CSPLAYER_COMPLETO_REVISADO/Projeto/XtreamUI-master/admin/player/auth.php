<?php
require __DIR__ . '/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
$cfg = cs_player_load_config();
$username = trim((string)($_POST['username'] ?? ''));
$password = (string)($_POST['password'] ?? '');
if ($username === '' || $password === '') { $_SESSION['cs_player_error'] = 'Informe usuário e senha.'; header('Location: index.php'); exit; }
$dnsList = cs_player_active_dns($cfg);
if (!$dnsList) { $_SESSION['cs_player_error'] = 'Nenhum DNS do Web Player foi configurado pelo administrador.'; header('Location: index.php'); exit; }
$attempts = 0;
foreach ($dnsList as $row) {
    $attempts++;
    $data = cs_player_api_call($row['url'], $username, $password);
    if (cs_player_is_authenticated_response($data)) {
        session_regenerate_id(true);
        $_SESSION['cs_player_auth'] = true;
        $_SESSION['cs_player_username'] = $username;
        $_SESSION['cs_player_password'] = $password;
        $_SESSION['cs_player_dns_index'] = (string)$row['_index'];
        $_SESSION['cs_player_dns_name'] = (string)($row['name'] ?? 'Servidor');
        $_SESSION['cs_player_user_info'] = $data['user_info'] ?? [];
        header('Location: home.php'); exit;
    }
}
$_SESSION['cs_player_error'] = 'Usuário não localizado nos DNS ativos ou assinatura sem acesso.';
header('Location: index.php');

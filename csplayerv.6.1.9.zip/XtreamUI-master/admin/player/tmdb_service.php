<?php
/** CS Player - TMDB enrichment service (server side only). */
if (!defined('CS_PLAYER_TMDB_API_KEY')) {
    define('CS_PLAYER_TMDB_API_KEY', '25fd37f463eaf2bda3d7309a62db248a');
}

function cs_player_tmdb_log(string $event, array $context = [], string $level = 'warning'): void {
    if (function_exists('cs_player_write_log')) cs_player_write_log($event, $context, $level);
}

function cs_player_tmdb_cache_dir(): string {
    $dir = __DIR__ . '/cache/tmdb';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}

function cs_player_tmdb_http(string $path, array $query = []): ?array {
    $query['api_key'] = CS_PLAYER_TMDB_API_KEY;
    $query['language'] = $query['language'] ?? 'pt-BR';
    $url = 'https://api.themoviedb.org/3/' . ltrim($path, '/') . '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 2,
        CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_HTTPHEADER => ['Accept: application/json'],
        CURLOPT_USERAGENT => 'CS-Player-TMDB/1.0',
    ]);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = (string)curl_error($ch);
    curl_close($ch);
    if (!is_string($raw) || $code < 200 || $code >= 300) {
        cs_player_tmdb_log('tmdb_request_failed', ['path'=>$path,'http_code'=>$code,'curl_error'=>$error]);
        return null;
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

function cs_player_tmdb_image(?string $path, string $size = 'w1280'): string {
    $path = trim((string)$path);
    if ($path === '') return '';
    return 'https://image.tmdb.org/t/p/' . $size . $path;
}

function cs_player_tmdb_best_video(array $videos): string {
    foreach (($videos['results'] ?? []) as $video) {
        if (($video['site'] ?? '') === 'YouTube' && in_array(($video['type'] ?? ''), ['Trailer','Teaser'], true) && !empty($video['key'])) {
            return 'https://www.youtube.com/watch?v=' . rawurlencode((string)$video['key']);
        }
    }
    return '';
}

function cs_player_tmdb_enrich(string $type, string $title, int $year = 0, int $tmdbId = 0): ?array {
    $type = $type === 'series' ? 'series' : 'movie';
    $title = trim($title);
    if ($title === '' && $tmdbId <= 0) return null;
    $cacheKey = sha1($type . '|' . mb_strtolower($title, 'UTF-8') . '|' . $year . '|' . $tmdbId . '|pt-BR');
    $cacheFile = cs_player_tmdb_cache_dir() . '/' . $cacheKey . '.json';
    if (is_file($cacheFile) && (time() - (int)@filemtime($cacheFile)) < 604800) {
        $cached = json_decode((string)@file_get_contents($cacheFile), true);
        if (is_array($cached)) return $cached;
    }

    $apiType = $type === 'series' ? 'tv' : 'movie';
    if ($tmdbId <= 0) {
        $query = ['query'=>$title, 'include_adult'=>'false', 'page'=>1, 'language'=>'pt-BR'];
        if ($year > 0) $query[$type === 'series' ? 'first_air_date_year' : 'primary_release_year'] = $year;
        $search = cs_player_tmdb_http('search/' . $apiType, $query);
        $first = is_array($search['results'] ?? null) ? ($search['results'][0] ?? null) : null;
        if (!is_array($first) && $year > 0) {
            unset($query[$type === 'series' ? 'first_air_date_year' : 'primary_release_year']);
            $search = cs_player_tmdb_http('search/' . $apiType, $query);
            $first = is_array($search['results'] ?? null) ? ($search['results'][0] ?? null) : null;
        }
        if (!is_array($first) || empty($first['id'])) return null;
        $tmdbId = (int)$first['id'];
    }

    $details = cs_player_tmdb_http($apiType . '/' . $tmdbId, [
        'append_to_response'=>'videos,credits,images',
        'include_image_language'=>'pt,en,null',
        'language'=>'pt-BR',
    ]);
    if (!is_array($details)) return null;
    $genres = [];
    foreach (($details['genres'] ?? []) as $genre) if (!empty($genre['name'])) $genres[] = (string)$genre['name'];
    $cast = [];
    foreach (array_slice($details['credits']['cast'] ?? [], 0, 8) as $person) if (!empty($person['name'])) $cast[] = (string)$person['name'];
    $yearValue = (string)($details[$type === 'series' ? 'first_air_date' : 'release_date'] ?? '');
    $runtime = $type === 'series' ? (int)(($details['episode_run_time'][0] ?? 0)) : (int)($details['runtime'] ?? 0);
    $payload = [
        'tmdb_id'=>$tmdbId,
        'type'=>$type,
        'title'=>(string)($details[$type === 'series' ? 'name' : 'title'] ?? $title),
        'original_title'=>(string)($details[$type === 'series' ? 'original_name' : 'original_title'] ?? ''),
        'overview'=>(string)($details['overview'] ?? ''),
        'poster'=>cs_player_tmdb_image($details['poster_path'] ?? '', 'w500'),
        'backdrop'=>cs_player_tmdb_image($details['backdrop_path'] ?? '', 'original'),
        'year'=>preg_match('/^(\d{4})/', $yearValue, $m) ? (int)$m[1] : 0,
        'rating'=>round((float)($details['vote_average'] ?? 0), 1),
        'genres'=>$genres,
        'runtime'=>$runtime,
        'cast'=>$cast,
        'trailer'=>cs_player_tmdb_best_video($details['videos'] ?? []),
        'tagline'=>(string)($details['tagline'] ?? ''),
        'status'=>(string)($details['status'] ?? ''),
    ];
    @file_put_contents($cacheFile, json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), LOCK_EX);
    return $payload;
}

const PlayerUI = (() => {
  const themeKey = 'csplayer_theme';
  let data = { content: { live: [], movies: [], series: [] }, categories: {}, server: { name: 'DNS' } };
  let currentType = 'home';
  let currentItem = null;
  let hls = null;
  let stallTimer = null;
  let lastProgress = 0;
  let retries = 0;
  const tmdbCache = new Map();

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (match) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[match]));
  const imageOf = (item) => item?.stream_icon || item?.cover || item?.cover_big || item?.movie_image || item?.backdrop_path?.[0] || '';
  const titleOf = (item) => item?.name || item?.title || item?.stream_display_name || 'Sem título';
  const typeOf = (item, type) => (type === 'mixed' || type === 'continue') ? (item?._type || 'movie') : type;
  const categoryIdOf = (item) => String(item?.category_id ?? item?.categoryId ?? '');
  const yearOf = (item) => {
    const value = String(item?.releaseDate || item?.release_date || item?.year || item?.added || '');
    const match = value.match(/(19|20)\d{2}/);
    return match ? Number(match[0]) : 0;
  };
  const dateScoreOf = (item) => {
    const value = item?.added || item?.last_modified || item?.releaseDate || item?.release_date || item?.year || 0;
    const numeric = Number(value);
    if (Number.isFinite(numeric) && numeric > 0) return numeric;
    const parsed = Date.parse(String(value));
    return Number.isFinite(parsed) ? parsed / 1000 : 0;
  };
  const newest = (items) => [...(Array.isArray(items) ? items : [])].sort((a, b) => (yearOf(b) - yearOf(a)) || (dateScoreOf(b) - dateScoreOf(a)) || titleOf(a).localeCompare(titleOf(b), 'pt-BR'));
  const currentYear = () => new Date().getFullYear();
  const tmdbIdOf = (item) => Number(item?.tmdb_id || item?.info?.tmdb_id || 0) || 0;
  const runtimeLabel = (minutes) => {
    const n = Number(minutes || 0); if (!n) return '';
    const h = Math.floor(n / 60), m = n % 60;
    return h ? `${h}h ${m ? `${m}min` : ''}`.trim() : `${m}min`;
  };
  async function tmdbMetadata(item, type) {
    if (!item || !['movie','series'].includes(type)) return null;
    const cacheKey = `${type}:${tmdbIdOf(item)}:${titleOf(item)}:${yearOf(item)}`;
    if (tmdbCache.has(cacheKey)) return tmdbCache.get(cacheKey);
    try {
      const qs = new URLSearchParams({ action:'tmdb_enrich', type, title:titleOf(item), year:String(yearOf(item)||0), tmdb_id:String(tmdbIdOf(item)||0) });
      const payload = await fetchJSON(`api.php?${qs.toString()}`);
      const meta = payload?.data || null;
      tmdbCache.set(cacheKey, meta);
      return meta;
    } catch (error) {
      tmdbCache.set(cacheKey, null);
      reportClientError(error, 'tmdb.enrich');
      return null;
    }
  }

  function safeRead(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch (error) { return fallback; }
  }

  function reportClientError(error, context = '') {
    try {
      const payload = JSON.stringify({
        message: String(error?.message || error || 'Erro não especificado'),
        stack: String(error?.stack || ''),
        context: String(context || '').slice(0, 160),
      });
      const blob = new Blob([payload], { type: 'application/json' });
      if (navigator.sendBeacon) {
        navigator.sendBeacon('client_error.php', blob);
      } else {
        fetch('client_error.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: payload, keepalive: true }).catch(() => {});
      }
    } catch (ignored) {}
  }

  window.addEventListener('error', (event) => reportClientError(event.error || event.message, 'window.error'));
  window.addEventListener('unhandledrejection', (event) => reportClientError(event.reason, 'unhandledrejection'));

  function themeFromStorage() {
    try {
      const stored = localStorage.getItem(themeKey);
      if (stored === 'light' || stored === 'dark') return stored;
    } catch (error) {}
    return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }

  function setTheme(theme) {
    const next = theme === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem(themeKey, next); } catch (error) {}
    const button = document.getElementById('themeToggle');
    if (button) {
      button.textContent = next === 'dark' ? '☀' : '☾';
      button.title = next === 'dark' ? 'Ativar modo claro' : 'Ativar modo escuro';
      button.setAttribute('aria-label', button.title);
      button.setAttribute('aria-pressed', String(next === 'dark'));
    }
  }

  function toggleTheme() {
    setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  }

  async function fetchJSON(url) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 35000);
    let response;
    try {
      response = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' }, signal: controller.signal });
    } catch (error) {
      reportClientError(error, `fetch:${url}`);
      if (error?.name === 'AbortError') throw new Error('O servidor demorou demais para responder. Tente novamente.');
      throw error;
    } finally {
      window.clearTimeout(timer);
    }
    let payload = {};
    try { payload = await response.json(); } catch (error) {}
    if (response.status === 401) {
      location.href = 'index.php';
      throw new Error('Sessão expirada.');
    }
    if (!response.ok || payload.ok === false) {
      throw new Error(payload.error || payload.message || `Falha na comunicação (${response.status}).`);
    }
    return payload;
  }

  function card(item, type, poster = false) {
    const cardType = typeOf(item, type);
    const id = item?.stream_id || item?.series_id || item?.id || 0;
    const image = imageOf(item);
    const progress = type === 'continue' && Number.isFinite(Number(item?._progress)) ? Math.max(0, Math.min(100, Number(item._progress))) : 0;
    const progressBar = progress > 0 ? `<span class="card-progress" aria-label="${Math.round(progress)}% assistido"><i style="width:${progress}%"></i></span>` : '';
    const badge = cardType === 'live' ? '<span class="card-badge live-badge">AO VIVO</span>' : (item?.rating ? `<span class="card-badge">★ ${esc(item.rating)}</span>` : '');
    return `<article class="media-card ${poster ? 'poster' : ''}" data-type="${esc(cardType)}" data-source="${type === 'mixed' ? 'favorites' : type === 'continue' ? 'continue' : esc(cardType)}" data-id="${esc(id)}" tabindex="0" role="button" aria-label="Abrir ${esc(titleOf(item))}">${image ? `<img loading="lazy" src="${esc(image)}" alt="" onerror="this.remove()">` : `<div class="fallback">${esc(titleOf(item))}</div>`}${badge}<div class="card-hover"><span class="card-play">▶</span><span class="card-title">${esc(titleOf(item))}</span><small>${[yearOf(item)||'', categoryNameOf(item,cardType)].filter(Boolean).map(esc).join(' · ')}</small></div><div class="caption">${esc(titleOf(item))}</div>${progressBar}</article>`;
  }

  function rail(title, items, type, poster = false) {
    if (!Array.isArray(items) || !items.length) return '';
    return `<section class="rail" data-type="${esc(type)}"><h2>${esc(title)}</h2><div class="rail-track ${poster ? 'poster-track' : ''}">${items.slice(0, 80).map((item) => card(item, type, poster)).join('')}</div></section>`;
  }

  function currentList(type) {
    if (type === 'live') return data.content.live || [];
    if (type === 'movie') return data.content.movies || [];
    if (type === 'series') return data.content.series || [];
    if (type === 'continue') return safeRead('csplayer_continue', []);
    return safeRead('csplayer_favorites', []);
  }

  function categoryRails(items, type, categories, poster) {
    if (!Array.isArray(categories)) return '';
    return categories.slice(0, 16).map((category) => {
      const id = String(category?.category_id ?? '');
      const filtered = (Array.isArray(items) ? items : []).filter((item) => categoryIdOf(item) === id);
      return rail(category?.category_name || 'Categoria', newest(filtered), type, poster);
    }).join('');
  }

  function render() {
    const rails = document.getElementById('rails');
    if (!rails) return;
    let html = '';
    const live = newest(data.content.live);
    const movies = newest(data.content.movies);
    const series = newest(data.content.series);
    const year = currentYear();
    if (currentType === 'home') {
      const continueItems = safeRead('csplayer_continue', []).sort((a, b) => Number(b?._updatedAt || 0) - Number(a?._updatedAt || 0));
      const releases = movies.filter((item) => yearOf(item) === year);
      html += rail('Continue assistindo', continueItems, 'continue', true);
      html += rail(`Lançamentos ${year}`, releases.length ? releases : movies, 'movie', true);
      html += rail('Canais ao vivo', live, 'live');
      html += categoryRails(live, 'live', data.categories?.live, false);
      html += categoryRails(movies, 'movie', data.categories?.movies, true);
      html += categoryRails(series, 'series', data.categories?.series, true);
    } else if (currentType === 'favorites') {
      const favorites = safeRead('csplayer_favorites', []);
      html = rail('Minha Lista', favorites, 'mixed', true) || '<div class="empty-state">Sua lista ainda está vazia.</div>';
    } else {
      const map = {
        live: ['Canais', live, 'live', false, data.categories?.live],
        movies: ['Filmes', movies, 'movie', true, data.categories?.movies],
        series: ['Séries', series, 'series', true, data.categories?.series]
      };
      const selected = map[currentType];
      if (selected) {
        html += rail(selected[0], selected[1], selected[2], selected[3]);
        html += categoryRails(selected[1], selected[2], selected[4], selected[3]);
      }
    }
    rails.innerHTML = html || '<div class="empty-state">Nenhum conteúdo disponível no momento.</div>';
    bindCards();
    fillCategories();
  }

  function bindCards() {
    document.querySelectorAll('.media-card').forEach((element) => {
      const open = () => {
        const type = element.dataset.type;
        const source = element.dataset.source;
        const id = String(element.dataset.id);
        const list = source === 'favorites' ? safeRead('csplayer_favorites', []) : source === 'continue' ? safeRead('csplayer_continue', []) : currentList(type);
        const item = list.find((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === id);
        if (item) showInfo(item, typeOf(item, type));
      };
      element.addEventListener('click', open);
      element.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(); }
      });
    });
  }

  function fillCategories() {
    const select = document.getElementById('categoryFilter');
    if (!select) return;
    const key = currentType === 'movies' ? 'movies' : currentType === 'series' ? 'series' : 'live';
    const categories = currentType === 'favorites' ? [] : (data.categories?.[key] || []);
    select.disabled = !categories.length;
    select.innerHTML = '<option value="">Todas as categorias</option>' + categories.map((category) => `<option value="${esc(category.category_id)}">${esc(category.category_name)}</option>`).join('');
  }

  function categoryNameOf(item, type) {
    const key = type === 'movie' ? 'movies' : type === 'series' ? 'series' : 'live';
    const category = (data.categories?.[key] || []).find((entry) => String(entry?.category_id ?? '') === categoryIdOf(item));
    return category?.category_name || '';
  }

  function setHero(item, type) {
    if (!item) return;
    currentItem = { item, type: typeOf(item, type) };
    const normalizedType = currentItem.type;
    const title = document.getElementById('heroTitle');
    const meta = document.getElementById('heroMeta');
    const description = document.getElementById('heroDesc');
    const hero = document.getElementById('hero');
    if (title) title.textContent = titleOf(item);
    if (meta) meta.textContent = [normalizedType === 'live' ? 'Ao vivo' : normalizedType === 'movie' ? 'Filme' : 'Série', categoryNameOf(item, normalizedType), yearOf(item) || '', item.rating ? `★ ${item.rating}` : ''].filter(Boolean).join(' · ');
    if (description) description.textContent = item.plot || item.description || 'Assista agora no CS Player.';
    const image = Array.isArray(item.backdrop_path) ? item.backdrop_path[0] : (item.backdrop_path || imageOf(item));
    if (hero && image) hero.style.backgroundImage = `url("${String(image).replace(/["\\]/g, '')}")`;
  }

  async function enrichHero(item, type) {
    const normalizedType = typeOf(item, type);
    if (!['movie','series'].includes(normalizedType)) return;
    const meta = await tmdbMetadata(item, normalizedType);
    if (!meta || !currentItem || String(currentItem.item?.stream_id || currentItem.item?.series_id || '') !== String(item?.stream_id || item?.series_id || '')) return;
    const hero = document.getElementById('hero');
    if (hero && meta.backdrop) hero.style.backgroundImage = `url("${String(meta.backdrop).replace(/["\\]/g, '')}")`;
    const desc = document.getElementById('heroDesc'); if (desc && meta.overview) desc.textContent = meta.overview;
    const title = document.getElementById('heroTitle'); if (title && meta.title) title.textContent = meta.title;
    const pieces = [normalizedType === 'movie' ? 'Filme' : 'Série', meta.year || '', ...(meta.genres || []).slice(0,3), runtimeLabel(meta.runtime)].filter(Boolean);
    const metaEl = document.getElementById('heroMeta'); if (metaEl) metaEl.textContent = pieces.join(' · ');
    const score = document.getElementById('heroMatch'); if (score) score.textContent = meta.rating ? `★ ${meta.rating}` : '';
    const eye = document.getElementById('heroEyebrow'); if (eye) eye.textContent = normalizedType === 'movie' ? 'FILME EM DESTAQUE' : 'SÉRIE EM DESTAQUE';
  }

  async function showInfo(item, type) {
    const normalizedType = typeOf(item, type);
    setHero(item, normalizedType);
    enrichHero(item, normalizedType);
    const body = document.getElementById('infoBody');
    if (!body) return;
    const isFavorite = safeRead('csplayer_favorites', []).some((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === String(item?.stream_id || item?.series_id || item?.id));
    const initialImage = imageOf(item);
    body.innerHTML = `<div class="detail-hero" ${initialImage ? `style="background-image:url('${esc(initialImage)}')"` : ''}><div class="detail-gradient"></div><div class="detail-copy"><span class="eyebrow">${normalizedType === 'live' ? 'TV AO VIVO' : normalizedType === 'movie' ? 'FILME' : 'SÉRIE'}</span><h2>${esc(titleOf(item))}</h2><div class="detail-meta" id="detailMeta">${[yearOf(item)||'', item.rating ? `★ ${item.rating}` : '', categoryNameOf(item, normalizedType)].filter(Boolean).map(esc).join(' · ')}</div><p id="detailOverview">${esc(item.plot || item.description || 'Conteúdo disponível para reprodução.')}</p><div class="hero-buttons"><button class="light-btn" id="infoPlay" type="button">▶ Assistir</button><button class="round-action" id="favoriteBtn" type="button" title="Minha Lista">${isFavorite ? '✓' : '＋'}</button><a class="round-action hidden" id="trailerBtn" target="_blank" rel="noopener" title="Trailer">▶</a></div><div class="detail-extra" id="detailExtra"></div></div></div>`;
    document.getElementById('infoModal')?.classList.remove('hidden');
    document.getElementById('infoPlay')?.addEventListener('click', () => play(item, normalizedType));
    document.getElementById('favoriteBtn')?.addEventListener('click', () => {
      const added = favorite(item, normalizedType);
      const button = document.getElementById('favoriteBtn'); if (button) button.textContent = added ? '✓' : '＋';
    });
    if (['movie','series'].includes(normalizedType)) {
      const meta = await tmdbMetadata(item, normalizedType);
      if (meta) {
        const heroNode = body.querySelector('.detail-hero'); if (heroNode && meta.backdrop) heroNode.style.backgroundImage = `url("${String(meta.backdrop).replace(/["\\]/g,'')}")`;
        const title = body.querySelector('h2'); if (title && meta.title) title.textContent = meta.title;
        const overview = document.getElementById('detailOverview'); if (overview && meta.overview) overview.textContent = meta.overview;
        const metaLine = document.getElementById('detailMeta'); if (metaLine) metaLine.textContent = [meta.rating ? `★ ${meta.rating}` : '', meta.year || '', runtimeLabel(meta.runtime), ...(meta.genres || []).slice(0,3)].filter(Boolean).join(' · ');
        const extra = document.getElementById('detailExtra'); if (extra) extra.innerHTML = `${meta.cast?.length ? `<p><b>Elenco:</b> ${esc(meta.cast.join(', '))}</p>` : ''}${meta.tagline ? `<p class="tagline">${esc(meta.tagline)}</p>` : ''}`;
        const trailer = document.getElementById('trailerBtn'); if (trailer && meta.trailer) { trailer.href = meta.trailer; trailer.classList.remove('hidden'); }
      }
    }
  }

  function favorite(item, type) {
    const favorites = safeRead('csplayer_favorites', []);
    const id = String(item?.stream_id || item?.series_id || item?.id);
    const index = favorites.findIndex((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === id);
    if (index >= 0) { favorites.splice(index, 1); localStorage.setItem('csplayer_favorites', JSON.stringify(favorites)); return false; }
    favorites.push({ ...item, _type: type });
    localStorage.setItem('csplayer_favorites', JSON.stringify(favorites.slice(-100)));
    return true;
  }

  async function play(item, type) {
    let normalizedType = typeOf(item, type);
    if (normalizedType === 'series') {
      const seriesInfo = await fetchJSON(`api.php?action=series_info&id=${encodeURIComponent(item.series_id)}`);
      const episodes = seriesInfo.data?.episodes || {};
      const seasons = Object.keys(episodes).sort((a, b) => Number(a) - Number(b));
      const first = seasons.length ? episodes[seasons[0]]?.[0] : null;
      if (!first) { setHealth('Nenhum episódio disponível.', false); return; }
      item = { ...first, stream_id: first.id || first.stream_id };
    }
    currentItem = { item, type: normalizedType };
    closeInfo();
    document.getElementById('playerModal')?.classList.remove('hidden');
    document.getElementById('playerTitle').textContent = titleOf(item);
    document.getElementById('playerStatus').textContent = data.server?.name || 'DNS';
    retries = 0;
    startStream();
  }

  function streamUrl() {
    const item = currentItem.item;
    const id = item.stream_id || item.id;
    const ext = item.container_extension || item.container || '';
    return `stream.php?type=${encodeURIComponent(currentItem.type)}&id=${encodeURIComponent(id)}&ext=${encodeURIComponent(ext)}&v=${Date.now()}`;
  }

  function startStream() {
    const video = document.getElementById('video');
    if (!video || !currentItem) return;
    const url = streamUrl();
    destroyHls();
    setHealth('Conectando...', false);
    if (currentItem.type === 'live' && window.Hls && Hls.isSupported()) {
      hls = new Hls({ enableWorker: true, lowLatencyMode: true, backBufferLength: 30, maxBufferLength: 25, maxBufferHole: .6 });
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => { video.play().catch(() => {}); setHealth('Online', true); });
      hls.on(Hls.Events.ERROR, (_, error) => { if (error.fatal) recover(); });
    } else {
      video.src = url;
      video.play().catch(() => {});
    }
    attachHealth();
    restorePosition();
  }

  function attachHealth() {
    const video = document.getElementById('video');
    if (!video) return;
    video.onplaying = () => setHealth('Reproduzindo', true);
    video.onwaiting = () => setHealth('Bufferizando...', false);
    video.onerror = () => recover();
    video.ontimeupdate = () => { lastProgress = Date.now(); savePosition(); };
    clearInterval(stallTimer);
    lastProgress = Date.now();
    stallTimer = setInterval(() => {
      const timeout = Number(window.CS_PLAYER_CONFIG?.stall || 12) * 1000;
      if (!video.paused && Date.now() - lastProgress > timeout) recover();
    }, 3000);
  }

  async function recover() {
    if (!currentItem) return;
    const limit = Number(window.CS_PLAYER_CONFIG?.retries || 4);
    if (retries < limit) {
      retries += 1;
      const position = document.getElementById('video')?.currentTime || 0;
      setHealth(`Reconectando ${retries}/${limit}...`, false);
      startStream();
      try { document.getElementById('video').currentTime = position; } catch (error) {}
      return;
    }
    if (window.CS_PLAYER_CONFIG?.failover) {
      setHealth('Testando DNS alternativo...', false);
      try {
        const response = await fetchJSON('api.php?action=failover');
        if (response.ok) {
          data.server.name = response.server;
          document.getElementById('serverBadge').textContent = response.server;
          document.getElementById('playerStatus').textContent = response.server;
          retries = 0;
          startStream();
          return;
        }
      } catch (error) {}
    }
    reportClientError(new Error('Não foi possível recuperar o stream.'), 'stream.recover');
    setHealth('Não foi possível recuperar o stream.', false);
  }

  function destroyHls() {
    if (hls) { hls.destroy(); hls = null; }
    const video = document.getElementById('video');
    if (video) { video.pause(); video.removeAttribute('src'); video.load(); }
  }

  function setHealth(text, online) {
    const label = document.getElementById('healthText');
    const dot = document.getElementById('healthDot');
    if (label) label.textContent = text;
    if (dot) { dot.style.background = online ? 'var(--success)' : 'var(--warning)'; dot.style.boxShadow = online ? '0 0 0 4px color-mix(in srgb, var(--success) 18%, transparent)' : '0 0 0 4px color-mix(in srgb, var(--warning) 18%, transparent)'; }
  }

  function setAppLoading(active, title = 'Carregando seu conteúdo...', text = 'Conectando ao servidor e organizando canais, filmes e séries.') {
    const overlay = document.getElementById('appLoading');
    if (!overlay) return;
    overlay.classList.toggle('hidden', !active);
    overlay.setAttribute('aria-hidden', active ? 'false' : 'true');
    const titleNode = document.getElementById('appLoadingTitle');
    const textNode = document.getElementById('appLoadingText');
    if (titleNode) titleNode.textContent = title;
    if (textNode) textNode.textContent = text;
    document.body.classList.toggle('is-loading', active);
  }

  function closePlayer() { savePosition(); destroyHls(); clearInterval(stallTimer); document.getElementById('playerModal')?.classList.add('hidden'); }
  function closeInfo() { document.getElementById('infoModal')?.classList.add('hidden'); }
  function retry() { retries = 0; startStream(); }
  function keyForPos() { if (!currentItem) return ''; const item = currentItem.item; return `cspos:${currentItem.type}:${item.stream_id || item.id || item.series_id}`; }
  function rememberContinue(position = 0, duration = 0) {
    if (!window.CS_PLAYER_CONFIG?.remember || !currentItem || currentItem.type === 'live') return;
    const safeDuration = Number(duration || 0);
    const item = { ...currentItem.item, _type: currentItem.type, _position: Number(position || 0), _progress: safeDuration > 0 ? Math.max(0, Math.min(100, Number(position || 0) / safeDuration * 100)) : Number(currentItem.item?._progress || 0), _updatedAt: Date.now() };
    const key = String(item.stream_id || item.id || item.series_id || '');
    if (!key) return;
    const items = safeRead('csplayer_continue', []).filter((entry) => String(entry?.stream_id || entry?.id || entry?.series_id || '') !== key);
    items.unshift(item);
    try { localStorage.setItem('csplayer_continue', JSON.stringify(items.slice(0, 30))); } catch (error) {}
  }
  function savePosition() {
    if (!window.CS_PLAYER_CONFIG?.remember || !currentItem || currentItem.type === 'live') return;
    const video = document.getElementById('video');
    if (video?.currentTime > 10) {
      try { localStorage.setItem(keyForPos(), String(video.currentTime)); } catch (error) {}
      rememberContinue(video.currentTime, video.duration);
    }
  }
  function restorePosition() {
    if (!window.CS_PLAYER_CONFIG?.remember || currentItem?.type === 'live') return;
    const savedItem = safeRead('csplayer_continue', []).find((entry) => String(entry?.stream_id || entry?.id || entry?.series_id || '') === String(currentItem.item?.stream_id || currentItem.item?.id || currentItem.item?.series_id || ''));
    const position = Number(localStorage.getItem(keyForPos()) || savedItem?._position || 0);
    if (position > 10) document.getElementById('video')?.addEventListener('loadedmetadata', () => { try { document.getElementById('video').currentTime = position; } catch (error) {} }, { once: true });
  }

  function search(query) {
    const normalized = query.trim().toLowerCase();
    document.querySelectorAll('.media-card').forEach((cardElement) => { cardElement.style.display = !normalized || cardElement.textContent.toLowerCase().includes(normalized) ? '' : 'none'; });
  }

  async function filterCategory(event) {
    const id = event.target.value;
    if (!id) { render(); return; }
    const type = currentType === 'movies' ? 'movies' : currentType === 'series' ? 'series' : 'live';
    setAppLoading(true, 'Atualizando conteúdo...', 'Buscando os itens desta categoria.');
    try {
      const response = await fetchJSON(`api.php?action=category&type=${type}&category_id=${encodeURIComponent(id)}`);
      data.content[type] = response.data || [];
      render();
    } catch (error) { setHealth(error.message, false); }
    finally { setAppLoading(false); }
  }

  function focusSearch() { document.getElementById('globalSearch')?.focus(); }

  async function init() {
    setTheme(document.documentElement.dataset.theme || themeFromStorage());
    document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
    const rails = document.getElementById('rails');
    if (rails) rails.innerHTML = '<div class="skeleton"></div><div class="skeleton"></div>';
    setAppLoading(true);
    try {
      const requestStarted = (window.performance && performance.now) ? performance.now() : Date.now();
      data = await fetchJSON('api.php?action=home');
      data.content = data.content || { live: [], movies: [], series: [] };
      data.content.live = newest(data.content.live);
      data.content.movies = newest(data.content.movies);
      data.content.series = newest(data.content.series);
      const requestLatency = Math.max(0, Math.round(((window.performance && performance.now) ? performance.now() : Date.now()) - requestStarted));
      const server = data.server?.name || 'DNS';
      const dnsSource = data.server?.dns_source || 'automático';
      const totalContent = ['live', 'movies', 'series'].reduce((total, key) => total + (Array.isArray(data.content?.[key]) ? data.content[key].length : 0), 0);
      const serverBadge = document.getElementById('serverBadge');
      if (serverBadge) {
        serverBadge.textContent = `${server} · ${totalContent} itens · ${requestLatency}ms`;
        serverBadge.title = `Servidor: ${server}. Origem DNS: ${dnsSource}. Conteúdo recebido: ${totalContent}. Latência: ${requestLatency} ms.`;
      }
      const heroPool = [...(data.content?.movies || []).slice(0,12).map(item=>({item,type:'movie'})), ...(data.content?.series || []).slice(0,12).map(item=>({item,type:'series'}))];
      const heroPick = heroPool.length ? heroPool[Math.floor(Math.random()*heroPool.length)] : (data.content?.live?.[0] ? {item:data.content.live[0],type:'live'} : null);
      const hero = heroPick?.item || null;
      setHero(hero, heroPick?.type || 'live');
      if (hero) enrichHero(hero, heroPick?.type || 'live');
      document.getElementById('heroPlay')?.addEventListener('click', () => currentItem && play(currentItem.item, currentItem.type));
      document.getElementById('heroInfo')?.addEventListener('click', () => currentItem && showInfo(currentItem.item, currentItem.type));
      render();
      setAppLoading(false);
      document.querySelectorAll('[data-view]').forEach((button) => button.addEventListener('click', () => {
        currentType = button.dataset.view;
        document.querySelectorAll('[data-view]').forEach((element) => element.classList.toggle('active', element.dataset.view === currentType));
        render();
      }));
      document.getElementById('globalSearch')?.addEventListener('input', (event) => search(event.target.value));
      document.getElementById('categoryFilter')?.addEventListener('change', filterCategory);
      document.getElementById('pipBtn')?.addEventListener('click', async () => { try { if (document.pictureInPictureElement) await document.exitPictureInPicture(); else if (document.pictureInPictureEnabled) await document.getElementById('video').requestPictureInPicture(); } catch (error) {} });
      window.addEventListener('beforeunload', savePosition);
    } catch (error) {
      reportClientError(error, 'home.init');
      setAppLoading(false, 'Não foi possível carregar', error.message || 'Verifique a conexão e tente novamente.');
      if (rails) rails.innerHTML = `<div class="empty-state">${esc(error.message || 'Não foi possível carregar o conteúdo.')}</div>`;
    }
  }

  return { init, showInfo, play, closePlayer, closeInfo, retry, focusSearch, toggleTheme };
})();
document.addEventListener('DOMContentLoaded', PlayerUI.init);

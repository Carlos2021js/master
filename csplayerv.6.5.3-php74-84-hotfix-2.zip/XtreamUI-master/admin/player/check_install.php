<?php
declare(strict_types=1);
// Compatibilidade do Web Player: PHP 7.4 a 8.4.
define('CS_PLAYER_MIN_PHP', '7.4.0');
if (version_compare(PHP_VERSION, CS_PLAYER_MIN_PHP, '<')) {
    fwrite(STDERR, "PHP 7.4 ou superior e necessario para o Web Player.\n");
    exit(2);
}
if (PHP_SAPI !== 'cli') { fwrite(STDERR, "Execute somente via CLI.\n"); exit(2); }
$root=dirname(__DIR__,2);
$files=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
foreach($it as $f){if($f->isFile() && strtolower($f->getExtension())==='php')$files[]=$f->getPathname();}
$failed=0;echo "CS PLAYER - verificacao de instalacao\nPHP ".PHP_VERSION."\n";
foreach($files as $f){$cmd=escapeshellarg(PHP_BINARY).' -l '.escapeshellarg($f).' 2>&1';exec($cmd,$out,$code);if($code!==0){$failed++;echo "FALHA: $f\n".implode("\n",$out)."\n";}$out=[];}
echo "Arquivos PHP: ".count($files)." | Falhas: $failed\n";exit($failed?1:0);

<?php
/**
 * CS PLAYER - Atualizador remoto por manifesto JSON (PHP 7.4+)
 * Não altera o banco de dados.
 */
include __DIR__ . '/session.php';
include __DIR__ . '/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (!isset($rPermissions) || empty($rPermissions['is_admin'])) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'message' => 'Acesso restrito ao administrador.'));
    exit;
}
if (!hasPermissions('adv', 'settings') && !hasPermissions('adv', 'database')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'message' => 'Sem permissão para atualizar o CS PLAYER.'));
    exit;
}

const CS_PLAYER_UPDATE_MANIFEST = 'https://www.dropbox.com/scl/fi/4scts71fqjhffh7310pta/update.json?rlkey=7wherup4r2sudy1lgsoqqqrj4&st=dpgrn4li&dl=1';
const CS_PLAYER_UPDATE_MANIFEST_FALLBACK = 'https://raw.githubusercontent.com/Carlos2021js/master/main/update.json';
const CS_PLAYER_ROOT = '/home/xtreamcodes/iptv_xtream_codes';

function csu_json($data, $status) {
    http_response_code((int)$status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function csu_allowed_url($url) {
    if (!is_string($url) || stripos($url, 'https://') !== 0 || !filter_var($url, FILTER_VALIDATE_URL)) return false;
    $host = strtolower((string)parse_url($url, PHP_URL_HOST));
    return in_array($host, array('www.dropbox.com', 'dropbox.com', 'dl.dropboxusercontent.com', 'raw.githubusercontent.com', 'github.com'), true);
}

function csu_fetch_string($url, $maxBytes) {
    if (!csu_allowed_url($url)) return false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 12);
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_USERAGENT, 'CS-PLAYER-Updater/6.6.7');
        curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
        curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300 || !is_string($raw) || strlen($raw) > $maxBytes) return false;
        return $raw;
    }
    $ctx = stream_context_create(array('http' => array('timeout' => 25, 'follow_location' => 1, 'user_agent' => 'CS-PLAYER-Updater/6.6.7')));
    $raw = @file_get_contents($url, false, $ctx, 0, $maxBytes + 1);
    if (!is_string($raw) || strlen($raw) > $maxBytes) return false;
    return $raw;
}

function csu_state_paths() {
    return array(
        CS_PLAYER_ROOT . '/admin/logs/cs-player/update-state.json',
        CS_PLAYER_ROOT . '/CS_PLAYER_UPDATE_VERSION.json'
    );
}

function csu_local_state() {
    $defaults = array('product' => 'CS PLAYER', 'version' => '1.0.1', 'build' => 101, 'channel' => 'stable');
    foreach (csu_state_paths() as $path) {
        if (!is_file($path)) continue;
        $raw = @file_get_contents($path);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($data) && !empty($data['version'])) return array_merge($defaults, $data);
    }
    return $defaults;
}

function csu_manifest() {
    $sources = array(CS_PLAYER_UPDATE_MANIFEST, CS_PLAYER_UPDATE_MANIFEST_FALLBACK);
    $raw = false;
    $selected = '';
    foreach ($sources as $source) {
        $candidate = csu_fetch_string($source, 1048576);
        if ($candidate === false) continue;
        $decoded = json_decode($candidate, true);
        if (!is_array($decoded) || empty($decoded['version'])) continue;
        $raw = $candidate;
        $selected = $source;
        break;
    }
    if ($raw === false) return array(false, 'Não foi possível consultar um update.json válido no Dropbox nem no canal reserva GitHub.');
    $m = json_decode($raw, true);
    if (!is_array($m) || empty($m['version'])) return array(false, 'update.json inválido ou sem versão.');
    $m['_manifest_url'] = $selected;
    $url = '';
    $sha = '';
    if (isset($m['download']) && is_array($m['download'])) {
        $url = isset($m['download']['url']) ? trim((string)$m['download']['url']) : '';
        $sha = isset($m['download']['sha256']) ? strtolower(trim((string)$m['download']['sha256'])) : '';
    }
    if ($url === '' && isset($m['download_url'])) $url = trim((string)$m['download_url']);
    if ($sha === '' && isset($m['sha256'])) $sha = strtolower(trim((string)$m['sha256']));
    if (!csu_allowed_url($url)) return array(false, 'URL do pacote no update.json não é válida.');
    if ($sha !== '' && !preg_match('/^[a-f0-9]{64}$/', $sha)) return array(false, 'SHA-256 do manifesto é inválido.');
    $m['_download_url'] = $url;
    $m['_sha256'] = $sha;
    return array($m, null);
}

function csu_is_newer($remote, $local, $remoteBuild, $localBuild) {
    if ($remoteBuild > 0 && $localBuild > 0 && $remoteBuild !== $localBuild) return $remoteBuild > $localBuild;
    return version_compare((string)$remote, (string)$local, '>');
}

function csu_download_file($url, $target) {
    if (!csu_allowed_url($url)) return false;
    $fp = @fopen($target, 'wb');
    if (!$fp) return false;
    $ok = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        curl_setopt($ch, CURLOPT_USERAGENT, 'CS-PLAYER-Updater/6.6.7');
        curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
        curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);
        $exec = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $ok = ($exec === true && $code >= 200 && $code < 300);
        curl_close($ch);
    } else {
        fclose($fp);
        $ctx = stream_context_create(array('http' => array('timeout' => 300, 'follow_location' => 1, 'user_agent' => 'CS-PLAYER-Updater/6.6.7')));
        $in = @fopen($url, 'rb', false, $ctx);
        $fp = @fopen($target, 'wb');
        if ($in && $fp) { $ok = (stream_copy_to_stream($in, $fp) !== false); fclose($in); }
    }
    if (is_resource($fp)) fclose($fp);
    return $ok && is_file($target) && filesize($target) > 1024;
}

function csu_zip_safe($zip) {
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = (string)$zip->getNameIndex($i);
        if ($name === '' || strpos($name, "\0") !== false || $name[0] === '/' || preg_match('#(^|/)\.\.(/|$)#', $name)) return false;
    }
    return true;
}

function csu_copy_tree($src, $dst) {
    if (!is_dir($src)) return false;
    if (!is_dir($dst) && !@mkdir($dst, 0755, true) && !is_dir($dst)) return false;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($src, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
    foreach ($it as $item) {
        $rel = substr($item->getPathname(), strlen($src) + 1);
        $to = $dst . '/' . $rel;
        if ($item->isDir()) {
            if (!is_dir($to) && !@mkdir($to, 0755, true) && !is_dir($to)) return false;
        } else {
            $parent = dirname($to);
            if (!is_dir($parent) && !@mkdir($parent, 0755, true) && !is_dir($parent)) return false;
            if (!@copy($item->getPathname(), $to)) return false;
        }
    }
    return true;
}

function csu_write_state($m) {
    $dir = CS_PLAYER_ROOT . '/admin/logs/cs-player';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $state = array(
        'product' => 'CS PLAYER',
        'version' => (string)$m['version'],
        'build' => isset($m['build']) ? (int)$m['build'] : 0,
        'channel' => isset($m['channel']) ? (string)$m['channel'] : 'stable',
        'updated_at' => date('c'),
        'manifest' => isset($m['_manifest_url']) ? (string)$m['_manifest_url'] : CS_PLAYER_UPDATE_MANIFEST
    );
    return @file_put_contents($dir . '/update-state.json', json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
}

$action = isset($_GET['action']) ? (string)$_GET['action'] : (isset($_POST['action']) ? (string)$_POST['action'] : 'check');

if ($action === 'check') {
    list($manifest, $error) = csu_manifest();
    if ($manifest === false) csu_json(array('ok' => false, 'message' => $error, 'manifest_url' => CS_PLAYER_UPDATE_MANIFEST), 502);
    $local = csu_local_state();
    $rb = isset($manifest['build']) ? (int)$manifest['build'] : 0;
    $lb = isset($local['build']) ? (int)$local['build'] : 0;
    $available = csu_is_newer($manifest['version'], $local['version'], $rb, $lb);
    csu_json(array(
        'ok' => true,
        'available' => $available,
        'installed' => $local,
        'remote' => array(
            'product' => isset($manifest['product']) ? $manifest['product'] : 'CS PLAYER',
            'version' => (string)$manifest['version'],
            'build' => $rb,
            'channel' => isset($manifest['channel']) ? $manifest['channel'] : 'stable',
            'published_at' => isset($manifest['published_at']) ? $manifest['published_at'] : '',
            'changelog' => isset($manifest['changelog']) && is_array($manifest['changelog']) ? $manifest['changelog'] : array(),
            'required' => isset($manifest['update']['required']) ? (bool)$manifest['update']['required'] : false,
            'database_changes' => isset($manifest['update']['database_changes']) ? (bool)$manifest['update']['database_changes'] : false
        ),
        'manifest_url' => isset($manifest['_manifest_url']) ? (string)$manifest['_manifest_url'] : CS_PLAYER_UPDATE_MANIFEST
    ), 200);
}

if ($action !== 'install' || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    csu_json(array('ok' => false, 'message' => 'Ação inválida.'), 400);
}

list($manifest, $error) = csu_manifest();
if ($manifest === false) csu_json(array('ok' => false, 'message' => $error), 502);
if (!class_exists('ZipArchive')) csu_json(array('ok' => false, 'message' => 'Extensão ZIP do PHP não está disponível.'), 500);

$local = csu_local_state();
$rb = isset($manifest['build']) ? (int)$manifest['build'] : 0;
$lb = isset($local['build']) ? (int)$local['build'] : 0;
if (!csu_is_newer($manifest['version'], $local['version'], $rb, $lb)) {
    csu_json(array('ok' => true, 'updated' => false, 'message' => 'CS PLAYER já está atualizado.', 'installed' => $local), 200);
}
if (!empty($manifest['update']['database_changes'])) {
    csu_json(array('ok' => false, 'message' => 'Atualização bloqueada: o manifesto informa alteração de banco de dados.'), 409);
}

$tmp = sys_get_temp_dir() . '/cs-player-web-update-' . bin2hex(random_bytes(5));
$zipPath = $tmp . '/update.zip';
$extract = $tmp . '/extract';
@mkdir($extract, 0755, true);

if (!csu_download_file($manifest['_download_url'], $zipPath)) {
    csu_json(array('ok' => false, 'message' => 'Falha ao baixar o pacote de atualização.'), 502);
}
if ($manifest['_sha256'] !== '') {
    $actual = strtolower((string)hash_file('sha256', $zipPath));
    if (!hash_equals($manifest['_sha256'], $actual)) {
        @unlink($zipPath);
        csu_json(array('ok' => false, 'message' => 'SHA-256 do pacote não confere. Atualização cancelada.'), 409);
    }
}

$zip = new ZipArchive();
if ($zip->open($zipPath) !== true || !csu_zip_safe($zip)) {
    if ($zip instanceof ZipArchive) @$zip->close();
    csu_json(array('ok' => false, 'message' => 'ZIP inválido ou com estrutura insegura.'), 409);
}
if (!$zip->extractTo($extract)) { $zip->close(); csu_json(array('ok' => false, 'message' => 'Falha ao extrair atualização.'), 500); }
$zip->close();

$root = $extract . '/XtreamUI-master';
if (!is_dir($root) || !is_file($root . '/admin/settings.php') || !is_file($root . '/admin/player/bootstrap.php')) {
    csu_json(array('ok' => false, 'message' => 'Pacote incompatível: XtreamUI-master/ ou arquivos críticos ausentes.'), 409);
}

// Lint PHP usando o runtime interno do CS PLAYER quando possível.
$phpBin = CS_PLAYER_ROOT . '/php/bin/php';
$canExec = function_exists('exec') && !in_array('exec', array_map('trim', explode(',', (string)ini_get('disable_functions'))), true);
if ($canExec && is_executable($phpBin)) {
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/admin', FilesystemIterator::SKIP_DOTS));
    foreach ($iterator as $file) {
        if (!$file->isFile() || strtolower($file->getExtension()) !== 'php') continue;
        $out = array(); $code = 0;
        exec(escapeshellarg($phpBin) . ' -l ' . escapeshellarg($file->getPathname()) . ' 2>&1', $out, $code);
        if ($code !== 0) csu_json(array('ok' => false, 'message' => 'Pacote contém PHP incompatível com o runtime interno.', 'file' => substr($file->getPathname(), strlen($root) + 1)), 409);
    }
}

$stamp = date('Y-m-d_H-i-s');
$backup = CS_PLAYER_ROOT . '/admin/backups/remote-updates/' . $stamp;
@mkdir($backup, 0755, true);
// Backup mínimo dos pontos críticos e estado de versão.
foreach (array('admin/settings.php', 'admin/functions.php', 'admin/player', 'CS_PLAYER_RELEASE.txt', 'CS_PLAYER_UPDATE_VERSION.json') as $rel) {
    $src = CS_PLAYER_ROOT . '/' . $rel;
    $dst = $backup . '/' . $rel;
    if (is_dir($src)) csu_copy_tree($src, $dst);
    elseif (is_file($src)) { @mkdir(dirname($dst), 0755, true); @copy($src, $dst); }
}

$persist = array(
    'config',
    'admin/logs/cs-player/web-player-config.php',
    'admin/logs/cs-player/web-player-config.php.bak',
    'admin/logs/cs-player/dns-health.json',
    'admin/logs/cs-player/update-state.json'
);
$persistData = array();
foreach ($persist as $rel) {
    $p = CS_PLAYER_ROOT . '/' . $rel;
    if (is_file($p)) $persistData[$rel] = @file_get_contents($p);
}

if (!csu_copy_tree($root, CS_PLAYER_ROOT)) {
    csu_json(array('ok' => false, 'message' => 'Falha ao copiar arquivos. Backup disponível em ' . $backup), 500);
}
foreach ($persistData as $rel => $contents) {
    if (!is_string($contents)) continue;
    $p = CS_PLAYER_ROOT . '/' . $rel;
    @mkdir(dirname($p), 0755, true);
    @file_put_contents($p, $contents, LOCK_EX);
}
csu_write_state($manifest);

csu_json(array(
    'ok' => true,
    'updated' => true,
    'message' => 'CS PLAYER atualizado para ' . (string)$manifest['version'] . '.',
    'version' => (string)$manifest['version'],
    'build' => $rb,
    'backup' => $backup,
    'database_changed' => false
), 200);

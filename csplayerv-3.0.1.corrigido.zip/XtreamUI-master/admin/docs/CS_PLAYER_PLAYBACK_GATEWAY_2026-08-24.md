# CS PLAYER — Playback Gateway

Esta versão separa autenticação/catálogo da entrega da mídia e adiciona `wwwdir/cs_stream.php`.

Correções principais:

- Canais, filmes e episódios usam a URL original gravada em `streams.stream_source` sem alterar o banco.
- Se houver mais de uma URL em `stream_source`, todas são testadas e a primeira realmente reproduzível é usada.
- HLS/M3U8 é validado com GET real e `#EXTM3U`; um HEAD 200 seguido de GET 404 não é mais considerado origem válida.
- MP4/MKV/TS que retornam HTTP 500 ao receber `Range` são repetidos uma vez sem `Range` antes de falhar.
- A playlist gerada por `get.php` usa o gateway público `cs_stream.php`, permitindo reprodução em apps que consomem M3U.
- `player_api.php` expõe `direct_source` do gateway para clientes que respeitam esse campo.
- Para apps Xtream que constroem `/live/`, `/movie/` e `/series/`, execute como root:
  `bash /home/xtreamcodes/iptv_xtream_codes/admin/server-config/install_cs_player_public_stream_routes.sh`
  O instalador cria backup, executa `nginx -t` e faz rollback automático se a configuração for inválida.

## DNS externos

O Web Player mantém o hostname configurado e usa o IP resolvido apenas para transporte. Um domínio que responde 404 em `player_api.php`, `panel_api.php` e `get.php` está acessível, mas não expõe uma rota Xtream/M3U válida para o servidor do CS PLAYER. Isso é diferente de erro de resolução DNS. Quando o provedor só aceita clientes residenciais ou bloqueia o IP da VPS, o backend do Web Player não consegue contornar isso sem uma rota autorizada pelo provedor.

# CS Player — Smart DNS Extreme — 2026-08-24

Melhorias aplicadas ao `admin/player` sem alteração de banco de dados:

- DNS manual aceita IPv4, IPv6, domínio, com ou sem porta, HTTP/HTTPS, prefixo de caminho e URL completa `get.php`.
- Porta explícita é preservada; o sistema não troca silenciosamente a porta informada.
- Sem porta explícita, o diagnóstico e o login podem testar rotas canônicas HTTP/80 e HTTPS/443.
- Com porta explícita, o fallback testa o protocolo alternativo na mesma porta.
- Login inteligente usa até quatro rotas por DNS e mantém o DNS configurado como primeira tentativa.
- Detecção compatível com `player_api.php`, `panel_api.php` e `get.php` M3U Plus.
- Perfis HTTP existentes continuam suportados (Auto, Smarters, XCIPTV, VLC e Browser).
- Diagnóstico administrativo agora informa quando uma rota alternativa foi descoberta automaticamente.
- Indicador de saúde dos cards corrigido para usar o ID real do DNS.
- Normalização de domínio reforçada, com IDN quando a extensão `intl` estiver disponível.
- IPv6 com porta corrigido na montagem de URLs.
- Logs registram host, porta, protocolo, rota selecionada, redirecionamentos e IP remoto sem registrar senha.

Nenhuma tabela, coluna ou schema foi criado ou alterado.

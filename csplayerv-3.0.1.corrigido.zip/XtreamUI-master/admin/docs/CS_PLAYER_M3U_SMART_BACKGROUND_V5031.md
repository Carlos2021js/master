# CS Player — M3U Smart Background v5.0.3.1

Sem alteração de schema/banco:
- 3 importadores preservados e independentes.
- Ordem rígida: Canais (type 1) → Filmes (type 2) → Séries/Episódios (type 5).
- Cada fase percorre a playlist em streaming e grava apenas o seu tipo.
- Barras separadas para Canais, Filmes e Séries + progresso geral.
- Todos os 3 executam em segundo plano via PHP-FPM/FastCGI.
- Estado de job persistente em arquivos JSON existentes; nenhuma tabela/coluna nova.
- Polling do navegador com reconexão automática; M3U 2/3 retomam o acompanhamento via localStorage.
- Reconexão MariaDB para erros 2006/2013/2055 usando csPlayerOpenDatabase() já existente.
- Retentativas de deadlock/lock timeout preservadas.
- Categorias, bouquets, EPG/TMDB, detecção e anti-duplicidade preservados.

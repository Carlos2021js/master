# Instalador completo do Web Player — Ubuntu 24.04

## O que este pacote instala

O Web Player fica em `admin/webplayer` dentro do XtreamUI. O instalador cria um serviço persistente do systemd chamado `cs-player-webplayer`, usa o backend compilado `dist/index.js`, inicializa a persistência SQLite em `admin/webplayer/data`, preserva/cria um `JWT_SECRET` no arquivo `.env` e configura o Nginx embarcado do XtreamUI.

O Nginx continua atendendo publicamente na porta `25500`. O Node fica na porta interna `3100`, e o Nginx encaminha para ele as rotas `/webplayer/`, `/api/`, `/assets/`, `/manus-storage/` e `/__manus__/`. O arquivo `dist/index.js` não deve ser aberto diretamente no navegador.

## Pré-requisitos

O instalador foi projetado para Ubuntu 24.04 e exige:

- Node.js 22 ou superior;
- `systemd`, `systemctl`, `curl`, `openssl` e `ss`;
- Nginx embarcado em `/home/xtreamcodes/iptv_xtream_codes/nginx/sbin/nginx`;
- um `nginx.conf` que contenha o `server` da porta `25500`;
- os arquivos compilados `admin/webplayer/dist/index.js` e `admin/webplayer/dist/public/index.html`;
- `admin/webplayer/node_modules` presente no pacote.

O instalador interrompe antes de alterar o Nginx quando um desses requisitos não é atendido.

## Instalação manual

Na raiz do XtreamUI, execute como root:

```bash
bash admin/server-config/install_vps_manager.sh www-data
/usr/local/sbin/cs-player-adminctl webplayer-install
```

Use como primeiro argumento o usuário que executa o PHP-FPM quando ele não for `www-data`. O script deve ser executado na própria VPS onde o XtreamUI está instalado.

## Instalação pelo painel

Depois de instalar o helper com `install_vps_manager.sh`, abra `admin/servidor_ssh.php`, informe o servidor e as credenciais SSH root, e use **Instalar/Reparar Web Player**. A ação exige a confirmação `CONFIRMAR` e tem timeout SSH de 30 minutos para permitir instalação, criação do SQLite e reload do Nginx.

O `servidor_ssh.php` não aceita comandos livres. Ele chama somente `cs-player-adminctl webplayer-install`, e o sudoers permite somente o helper administrativo.

## Backup e rollback

Antes de modificar o `nginx.conf`, o instalador cria um backup com o sufixo `.bak.webplayer.AAAAMMDD-HHMMSS`. Se o teste `nginx -t` falhar, o arquivo de configuração é restaurado automaticamente. O serviço do Web Player também é reiniciado somente depois que a configuração passa no teste.

Para remover manualmente o serviço sem apagar o banco SQLite, pare-o e desabilite-o:

```bash
systemctl disable --now cs-player-webplayer
rm -f /etc/systemd/system/cs-player-webplayer.service
systemctl daemon-reload
```

O arquivo `admin/webplayer/data/webplayer.sqlite` deve ser preservado se as contas, playlists, preferências e progresso forem necessários.

## Verificação

```bash
systemctl status cs-player-webplayer --no-pager
journalctl -u cs-player-webplayer -n 80 --no-pager
ss -ltnp | grep -E ':25500|:3100'
curl -i http://127.0.0.1:3100/
curl -i http://127.0.0.1:25500/webplayer/
curl -I http://127.0.0.1:25500/assets/index-DngExJZJ.js
```

A URL pública esperada é `http://SERVIDOR:25500/webplayer/`. Um retorno `200` no Node e no Web Player confirma que o proxy está ativo. O endpoint `/api/trpc` pode retornar `401` ou `404` sem uma chamada de procedimento válida; isso não significa, sozinho, que o serviço esteja quebrado.

## Compatibilidade com o Nginx do XtreamUI

Não use `systemctl reload nginx` nesse ambiente se o Nginx principal for o binário embarcado. O comando correto usado pelo instalador é:

```bash
/home/xtreamcodes/iptv_xtream_codes/nginx/sbin/nginx \
  -t -p /home/xtreamcodes/iptv_xtream_codes/nginx \
  -c /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf

/home/xtreamcodes/iptv_xtream_codes/nginx/sbin/nginx \
  -p /home/xtreamcodes/iptv_xtream_codes/nginx \
  -c /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf \
  -s reload
```


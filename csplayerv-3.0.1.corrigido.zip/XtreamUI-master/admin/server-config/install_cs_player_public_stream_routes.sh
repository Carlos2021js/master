#!/usr/bin/env bash
set -euo pipefail

MARK_BEGIN='# BEGIN CS PLAYER PUBLIC STREAM ROUTES'
MARK_END='# END CS PLAYER PUBLIC STREAM ROUTES'
ROOT_HINT='/home/xtreamcodes/iptv_xtream_codes/wwwdir'

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo 'Execute como root: sudo bash admin/server-config/install_cs_player_public_stream_routes.sh' >&2
  exit 1
fi

find_target() {
  if [[ -n "${CS_NGINX_CONF:-}" && -f "${CS_NGINX_CONF}" ]]; then echo "$CS_NGINX_CONF"; return; fi
  local f
  for f in /etc/nginx/sites-enabled/* /etc/nginx/conf.d/*.conf /etc/nginx/nginx.conf /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf; do
    [[ -f "$f" ]] || continue
    if grep -Fq "$ROOT_HINT" "$f" 2>/dev/null; then echo "$f"; return; fi
  done
  return 1
}

TARGET="$(find_target || true)"
if [[ -z "$TARGET" ]]; then
  echo "Nao foi encontrado automaticamente o server block que usa $ROOT_HINT." >&2
  echo 'Defina CS_NGINX_CONF=/caminho/do/vhost.conf e execute novamente.' >&2
  exit 2
fi

BACKUP="${TARGET}.csplayer.$(date +%Y%m%d%H%M%S).bak"
cp -a "$TARGET" "$BACKUP"

python3 - "$TARGET" "$ROOT_HINT" "$MARK_BEGIN" "$MARK_END" <<'PY'
import sys
from pathlib import Path
path=Path(sys.argv[1]); root_hint=sys.argv[2]; begin=sys.argv[3]; end=sys.argv[4]
s=path.read_text()
if begin in s:
    print('Rotas CS PLAYER ja instaladas.')
    raise SystemExit(0)
pos=s.find(root_hint)
if pos<0: raise SystemExit('root do CS PLAYER nao localizado no arquivo alvo')
# Descobre o server { ... } que contem o root, caminhando por chaves.
stack=[]; server_start=None; i=0
while i < len(s):
    if s.startswith('server', i):
        j=i+6
        while j<len(s) and s[j].isspace(): j+=1
        if j<len(s) and s[j]=='{':
            stack.append(('server', j));
            if j < pos: server_start=j
            i=j+1; continue
    c=s[i]
    if c=='{': stack.append(('block',i))
    elif c=='}' and stack:
        typ,start=stack.pop()
        if typ=='server' and start < pos < i:
            server_start=start; server_end=i; break
    i+=1
else:
    raise SystemExit('server block do CS PLAYER nao localizado')

snippet=r'''
    # BEGIN CS PLAYER PUBLIC STREAM ROUTES
    # Compatibilidade Xtream para Canais, Filmes e Series importados.
    location ~ ^/(live|movie|series)/([^/]+)/([^/]+)/([0-9]+)\.([A-Za-z0-9]+)$ {
        rewrite ^/(live|movie|series)/([^/]+)/([^/]+)/([0-9]+)\.([A-Za-z0-9]+)$ /cs_stream.php?type=$1&username=$2&password=$3&id=$4&ext=$5 last;
    }
    # END CS PLAYER PUBLIC STREAM ROUTES
'''
s=s[:server_end]+snippet+s[server_end:]
path.write_text(s)
print('Rotas inseridas em', path)
PY

NGINX_BIN="$(command -v nginx || true)"
if [[ -z "$NGINX_BIN" && -x /home/xtreamcodes/iptv_xtream_codes/nginx/sbin/nginx ]]; then NGINX_BIN=/home/xtreamcodes/iptv_xtream_codes/nginx/sbin/nginx; fi
if [[ -z "$NGINX_BIN" ]]; then
  echo "Nginx nao encontrado. Restaurando $BACKUP" >&2
  cp -a "$BACKUP" "$TARGET"
  exit 3
fi

if ! "$NGINX_BIN" -t; then
  echo 'nginx -t falhou; restaurando configuracao anterior.' >&2
  cp -a "$BACKUP" "$TARGET"
  "$NGINX_BIN" -t || true
  exit 4
fi

if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet nginx 2>/dev/null; then
  systemctl reload nginx
else
  "$NGINX_BIN" -s reload
fi

echo 'CS PLAYER: rotas /live, /movie e /series instaladas com sucesso.'
echo "Backup: $BACKUP"

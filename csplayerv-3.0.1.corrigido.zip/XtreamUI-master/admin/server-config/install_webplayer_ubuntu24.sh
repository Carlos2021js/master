#!/usr/bin/env bash
set -Eeuo pipefail
umask 027

ROOT="${CS_PLAYER_ROOT:-/home/xtreamcodes/iptv_xtream_codes}"
WEBPLAYER="$ROOT/admin/webplayer"
DIST="$WEBPLAYER/dist"
PUBLIC="$DIST/public"
NODE_BIN="${NODE_BIN:-$(command -v node || true)}"
NGINX="$ROOT/nginx/sbin/nginx"
NGINX_CONF="$ROOT/nginx/conf/nginx.conf"
NGINX_INC="$ROOT/nginx/conf/webplayer-proxy.conf"
SERVICE_NAME="cs-player-webplayer"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
PORT="${WEBPLAYER_PORT:-3100}"
STAMP="$(date +%Y%m%d-%H%M%S)"
CONF_BACKUP="${NGINX_CONF}.bak.webplayer.${STAMP}"
INC_BACKUP="${NGINX_INC}.bak.webplayer.${STAMP}"
INC_EXISTED=0

log(){ printf '[CS Player Web Player] %s\n' "$*"; }
fatal(){ printf '[CS Player Web Player] ERRO: %s\n' "$*" >&2; exit 1; }
port_is_busy(){ ss -ltn 2>/dev/null | awk -v p=":$1" '$4 ~ p"$" {found=1} END {exit found ? 0 : 1}'; }

[[ "${EUID:-$(id -u)}" -eq 0 ]] || fatal 'execute como root.'
[[ -d "$ROOT" ]] || fatal "raiz do XtreamUI não encontrada: $ROOT"
[[ -f "$DIST/index.js" ]] || fatal "backend compilado não encontrado: $DIST/index.js"
[[ -f "$PUBLIC/index.html" ]] || fatal "frontend compilado não encontrado: $PUBLIC/index.html"
[[ -x "$NGINX" ]] || fatal "Nginx embarcado não encontrado: $NGINX"
[[ -f "$NGINX_CONF" ]] || fatal "nginx.conf não encontrado: $NGINX_CONF"
[[ -n "$NODE_BIN" && -x "$NODE_BIN" ]] || fatal 'Node.js não encontrado no PATH.'
command -v curl >/dev/null 2>&1 || fatal 'curl não encontrado.'
command -v systemctl >/dev/null 2>&1 || fatal 'systemd/systemctl não encontrado.'
command -v ss >/dev/null 2>&1 || fatal 'ss/iproute2 não encontrado.'
command -v openssl >/dev/null 2>&1 || fatal 'openssl não encontrado.'

NODE_MAJOR="$($NODE_BIN -p 'process.versions.node.split(".")[0]' 2>/dev/null || true)"
[[ "$NODE_MAJOR" =~ ^[0-9]+$ ]] && (( NODE_MAJOR >= 22 )) || fatal "Node.js 22 ou superior é necessário; encontrado: ${NODE_MAJOR:-desconhecido}."
[[ -d "$WEBPLAYER/node_modules" ]] || fatal "node_modules não encontrado em $WEBPLAYER. O pacote precisa conter as dependências compiladas."

test -f "$NGINX_INC" && { cp -a "$NGINX_INC" "$INC_BACKUP"; INC_EXISTED=1; }
cp -a "$NGINX_CONF" "$CONF_BACKUP"

RUN_USER="${WEBPLAYER_USER:-}"
if [[ -z "$RUN_USER" ]]; then
  RUN_USER="$(stat -c '%U' "$WEBPLAYER" 2>/dev/null || true)"
  [[ -n "$RUN_USER" && "$RUN_USER" != 'UNKNOWN' && "$RUN_USER" != 'root' ]] || RUN_USER='www-data'
fi
id "$RUN_USER" >/dev/null 2>&1 || fatal "usuário do Web Player não existe: $RUN_USER"
RUN_GROUP="$(id -gn "$RUN_USER")"

DATA_DIR="$WEBPLAYER/data"
mkdir -p "$DATA_DIR"
chown "$RUN_USER:$RUN_GROUP" "$DATA_DIR"
chmod 0750 "$DATA_DIR"

ENV_FILE="$WEBPLAYER/.env"
touch "$ENV_FILE"
chown "$RUN_USER:$RUN_GROUP" "$ENV_FILE"
chmod 0640 "$ENV_FILE"
if ! grep -qE '^JWT_SECRET=([^[:space:]]+)$' "$ENV_FILE"; then
  printf 'JWT_SECRET=%s\n' "$(openssl rand -hex 32)" >> "$ENV_FILE"
fi
if ! grep -qE '^WEBPLAYER_DATA_DIR=' "$ENV_FILE"; then
  printf 'WEBPLAYER_DATA_DIR=%s\n' "$DATA_DIR" >> "$ENV_FILE"
fi

cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=CS Player Web Player
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=$RUN_USER
Group=$RUN_GROUP
WorkingDirectory=$WEBPLAYER
Environment=NODE_ENV=production
Environment=PORT=$PORT
EnvironmentFile=$ENV_FILE
ExecStart=$NODE_BIN $DIST/index.js
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=false
ReadWritePaths=$DATA_DIR

[Install]
WantedBy=multi-user.target
SERVICE
chmod 0644 "$SERVICE_FILE"

cat > "$NGINX_INC" <<NGINX
# CS Player Web Player — gerado por install_webplayer_ubuntu24.sh.
# Backend local: http://127.0.0.1:$PORT

location = /webplayer {
    return 301 /webplayer/;
}

location ^~ /webplayer/dist/public/ {
    return 301 /webplayer/;
}

location ^~ /webplayer/ {
    proxy_pass http://127.0.0.1:$PORT/;
    proxy_http_version 1.1;
    proxy_set_header Host \$http_host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
}

location ^~ /api/ {
    proxy_pass http://127.0.0.1:$PORT;
    proxy_http_version 1.1;
    proxy_set_header Host \$http_host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
}

location ^~ /assets/ {
    proxy_pass http://127.0.0.1:$PORT;
    proxy_set_header Host \$http_host;
}

location ^~ /manus-storage/ {
    proxy_pass http://127.0.0.1:$PORT;
    proxy_set_header Host \$http_host;
}

location ^~ /__manus__/ {
    proxy_pass http://127.0.0.1:$PORT;
    proxy_set_header Host \$http_host;
}
NGINX

if ! grep -Fq "include $NGINX_INC;" "$NGINX_CONF"; then
  if ! grep -Eq '^[[:space:]]*listen[[:space:]]+25500[[:space:]]*;' "$NGINX_CONF"; then
    cp -a "$CONF_BACKUP" "$NGINX_CONF"
    if [[ "$INC_EXISTED" -eq 1 ]]; then cp -a "$INC_BACKUP" "$NGINX_INC"; else rm -f "$NGINX_INC"; fi
    fatal 'não encontrei o server block que escuta a porta 25500.'
  fi
  sed -i "/^[[:space:]]*listen[[:space:]]\+25500[[:space:]]*;/a\\        include $NGINX_INC;" "$NGINX_CONF"
fi

if ! "$NGINX" -t -p "$ROOT/nginx" -c "$NGINX_CONF"; then
  log 'Teste do Nginx falhou; restaurando configuração.'
  cp -a "$CONF_BACKUP" "$NGINX_CONF"
  if [[ "$INC_EXISTED" -eq 1 ]]; then cp -a "$INC_BACKUP" "$NGINX_INC"; else rm -f "$NGINX_INC"; fi
  exit 2
fi

systemctl daemon-reload
systemctl enable "$SERVICE_NAME" >/dev/null

# Encerra somente instâncias do mesmo backend, se existirem fora do systemd.
EXISTING_PIDS="$(pgrep -f "$DIST/index.js" || true)"
for pid in $EXISTING_PIDS; do
  [[ "$pid" = "$$" ]] && continue
  kill "$pid" 2>/dev/null || true
done
if [[ -n "$EXISTING_PIDS" ]]; then sleep 1; fi
port_is_busy "$PORT" && fatal "a porta $PORT já está ocupada por outro processo."

systemctl restart "$SERVICE_NAME"
sleep 3
if ! systemctl is-active --quiet "$SERVICE_NAME"; then
  journalctl -u "$SERVICE_NAME" -n 50 --no-pager >&2 || true
  fatal 'o serviço do Web Player não iniciou.'
fi

"$NGINX" -p "$ROOT/nginx" -c "$NGINX_CONF" -s reload
sleep 1

HTTP_NODE="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 10 "http://127.0.0.1:$PORT/" || true)"
HTTP_WEB="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:25500/webplayer/ || true)"
HTTP_ASSET="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:25500/assets/index-DngExJZJ.js || true)"

log "Instalação concluída. Usuário: $RUN_USER; porta interna: $PORT; Node: HTTP $HTTP_NODE; Web Player: HTTP $HTTP_WEB; asset: HTTP $HTTP_ASSET"
log "Backup do nginx.conf: $CONF_BACKUP"
log "Logs: journalctl -u $SERVICE_NAME -n 80 --no-pager"

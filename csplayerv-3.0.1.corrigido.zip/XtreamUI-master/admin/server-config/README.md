# Gerenciador seguro do servidor

A página `admin/servidor_ssh.php` não deve receber nem armazenar senha root. Ela executa somente o helper `/usr/local/sbin/cs-player-adminctl`, que possui uma lista fechada de ações e validações próprias.

## Instalação

Execute, como `root`, a partir da raiz do projeto:

```bash
bash admin/server-config/install_vps_manager.sh www-data
```

Substitua `www-data` pelo usuário real que executa o PHP-FPM. Para descobrir o usuário, consulte o pool do PHP-FPM ou execute `ps -eo user,comm | grep php-fpm`.

O instalador copia o helper com proprietário `root:root`, permissões `0755`, cria uma regra sudoers temporária, valida-a com `visudo` e somente então a ativa. A regra permite apenas o helper auditado e não permite comandos arbitrários.

## Diagnóstico do erro de senha

A mensagem `sudo: a password is required` significa que o usuário do PHP-FPM não tem uma regra `NOPASSWD` aplicável. Verifique:

```bash
sudo -l -U www-data
sudo -u www-data -n /usr/local/sbin/cs-player-adminctl status
```

Se o PHP-FPM rodar com outro usuário, reinstale passando esse usuário ao instalador. A página também evita chamar `sudo` quando o próprio PHP já estiver executando como root.

Não configure senha root no painel e não substitua `sudo -n` por `sudo` interativo: processos web não devem aguardar entrada de senha.

## Instalação e reparo do Web Player

O pacote inclui `install_webplayer_ubuntu24.sh`, que instala o Web Player compilado em `/home/xtreamcodes/iptv_xtream_codes/admin/webplayer`, cria um segredo JWT se ainda não existir, inicializa o diretório SQLite, registra o serviço persistente `cs-player-webplayer`, encaminha o Web Player pelo Nginx embarcado do XtreamUI e valida as rotas locais. O script não substitui o banco do XtreamUI e mantém backup datado do `nginx.conf` antes de alterar a configuração.

Execute, como `root`, a partir da raiz do projeto:

```bash
bash admin/server-config/install_vps_manager.sh www-data
/usr/local/sbin/cs-player-adminctl webplayer-install
```

A tela `admin/servidor_ssh.php` possui a ação protegida **Instalar/Reparar Web Player**, que chama somente essa ação pré-definida do helper. A operação exige confirmação explícita e possui timeout SSH de 30 minutos, pois a instalação e o primeiro carregamento da base SQLite podem demorar.

O Web Player usa o Node já incluído no pacote e a porta interna `3100`. A URL pública esperada é:

```text
http://SERVIDOR:25500/webplayer/
```

O arquivo `dist/index.js` não deve ser aberto diretamente no navegador. Ele é o backend Express do Web Player. Os caminhos `/api/`, `/assets/`, `/manus-storage/` e `/__manus__/` são encaminhados internamente pelo Nginx para `127.0.0.1:3100`.

Para diagnosticar uma falha:

```bash
systemctl status cs-player-webplayer --no-pager
journalctl -u cs-player-webplayer -n 80 --no-pager
/home/xtreamcodes/iptv_xtream_codes/nginx/sbin/nginx -t -p /home/xtreamcodes/iptv_xtream_codes/nginx -c /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf
curl -i http://127.0.0.1:3100/
curl -i http://127.0.0.1:25500/webplayer/
```

O instalador exige Node.js 22 ou superior, porque o backend compilado usa `node:sqlite`. Se o Node não estiver instalado ou não for compatível, o script interrompe sem alterar o Nginx.


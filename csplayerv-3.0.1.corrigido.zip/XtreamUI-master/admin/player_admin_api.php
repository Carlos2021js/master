<?php
include 'session.php'; include 'functions.php';
if ((int)($rPermissions['is_admin'] ?? 0) !== 1 || (!hasPermissions('adv','settings') && !hasPermissions('adv','database'))) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'Acesso restrito ao administrador.'], JSON_UNESCAPED_UNICODE);
    exit;
}
require_once __DIR__ . '/player/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function out($a,$s=200){http_response_code($s);echo json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
set_exception_handler(static function (\Throwable $e): void {
    if (function_exists('cs_player_write_log')) cs_player_write_log('player_admin_api_exception', [
        'class'=>get_class($e),'line'=>$e->getLine(),'file'=>basename($e->getFile()),
        'message_hash'=>substr(hash('sha256',$e->getMessage()),0,12)
    ], 'error');
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode(['ok'=>false,'message'=>'Falha interna ao processar as configurações do Web Player. Consulte os logs.'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
});

function cs_admin_fixed_player_dns(): array {
    $servers = function_exists('getStreamingServers') ? getStreamingServers(true) : [];
    return cs_player_server_dns_from_rows(array_values(is_array($servers) ? $servers : []));
}

function cs_admin_probe_request(string $target, int $timeout, string $userAgent = 'CSPlayer-DNS-Probe/1.4'): array {
    if (!function_exists('cs_player_transport_request')) {
        return ['body'=>'','curl_error'=>'transporte indisponível','curl_errno'=>-1,'http_code'=>0,'content_type'=>'','effective_url'=>$target,'remote_ip'=>'','redirects'=>0,'http_version'=>0,'response_bytes'=>0,'latency_ms'=>0];
    }
    $res=cs_player_transport_request($target,[
        'timeout'=>max(3,$timeout),
        'connect_timeout'=>min(4,$timeout),
        'user_agent'=>$userAgent,
        'accept'=>'application/json, text/plain, application/x-mpegURL, */*',
        'json'=>false,
        'classic_stream_fallback'=>true,
        'allow_legacy_tls'=>function_exists('cs_player_bool') ? cs_player_bool(cs_player_load_config()['allow_legacy_tls']??false,false) : false,
    ]);
    $body=is_string($res['body']??null)?$res['body']:'';
    return ['body'=>$body,'curl_error'=>(string)($res['curl_error']??''),'curl_errno'=>(int)($res['curl_errno']??0),'http_code'=>(int)($res['http_code']??0),'content_type'=>(string)($res['content_type']??''),
        'effective_url'=>(string)($res['effective_url']??$target),'remote_ip'=>(string)($res['remote_ip']??''),'redirects'=>(int)($res['redirects']??0),'http_version'=>0,
        'response_bytes'=>strlen($body),'latency_ms'=>(int)($res['time_ms']??0)];
}

function cs_admin_vpn_exec(string $operation, string $backend, string $profile): array {
    if (!in_array($operation, ['status','up','down','restart'], true)) return ['ok'=>false,'message'=>'Operação VPN inválida.'];
    if (!in_array($backend, ['wireguard','openvpn'], true)) return ['ok'=>false,'message'=>'Backend VPN não selecionado.'];
    if (!preg_match('/^[A-Za-z0-9._-]{1,80}$/', $profile)) return ['ok'=>false,'message'=>'Perfil VPN inválido.'];
    $helper='/usr/local/sbin/cs-player-adminctl';
    if (!is_executable($helper)) return ['ok'=>false,'message'=>'Helper administrativo não instalado.'];
    $cmd='/usr/bin/sudo -n '.escapeshellarg($helper).' '.escapeshellarg('vpn-'.$operation).' '.escapeshellarg($backend).' '.escapeshellarg($profile).' 2>&1';
    $descriptors=[1=>['pipe','w'],2=>['pipe','w']]; $proc=@proc_open($cmd,$descriptors,$pipes);
    if (!is_resource($proc)) return ['ok'=>false,'message'=>'Não foi possível iniciar o helper VPN.'];
    $stdout=stream_get_contents($pipes[1]); $stderr=stream_get_contents($pipes[2]); fclose($pipes[1]); fclose($pipes[2]);
    $status=proc_close($proc); $output=trim((string)$stdout.(($stderr!=='')?'\n'.$stderr:''));
    return ['ok'=>$status===0,'message'=>$output!==''?$output:($status===0?'Operação VPN concluída.':'Falha na operação VPN.'),'exit_code'=>$status];
}

function cs_player_sanitize_vpn_profile(string $value): string {
    return preg_replace('/[^A-Za-z0-9._-]/','',mb_substr(trim($value),0,80)) ?: '';
}

function cs_admin_vpn_boot_exec(bool $enable, string $backend, string $profile): array {
    if (!$enable) $cmd='/usr/bin/sudo -n /usr/local/sbin/cs-player-adminctl vpn-boot-disable none none 2>&1';
    else {
        if (!in_array($backend,['wireguard','openvpn'],true) || !preg_match('/^[A-Za-z0-9._-]{1,80}$/',$profile)) return ['ok'=>false,'message'=>'Backend ou perfil VPN inválido para autostart.'];
        $cmd='/usr/bin/sudo -n /usr/local/sbin/cs-player-adminctl vpn-boot-enable '.escapeshellarg($backend).' '.escapeshellarg($profile).' 2>&1';
    }
    $out=[]; $status=0; @exec($cmd,$out,$status);
    return ['ok'=>$status===0,'message'=>trim(implode("\n",$out)) ?: ($status===0?'Autostart VPN atualizado.':'Falha ao atualizar autostart VPN.'),'exit_code'=>$status];
}

function cs_admin_probe_dns(string $url, int $timeout = 5, string $providerMode = 'auto', string $m3uPath = 'get.php', string $m3uOutput = 'mpegts'): array {
    $configuredUrl = cs_player_normalize_dns($url);
    $providerMode = in_array(strtolower($providerMode), ['auto','xc','smart','xtream','m3u'], true) ? strtolower($providerMode) : 'auto';
    $m3uOutput = in_array(strtolower($m3uOutput), ['mpegts','hls'], true) ? strtolower($m3uOutput) : 'mpegts';
    $m3uPath = trim($m3uPath) !== '' ? ltrim(trim($m3uPath), '/') : 'get.php';
    if ($configuredUrl === '') {
        cs_player_write_log('server_probe_invalid_dns', ['input_hash'=>substr(hash('sha256',$url),0,12)], 'warning');
        return ['ok'=>false,'latency_ms'=>0,'http_code'=>0,'message'=>'DNS inválido'];
    }
    if (!function_exists('curl_init')) {
        cs_player_write_log('server_probe_curl_unavailable_using_stream_fallback', ['host'=>(string)(parse_url($configuredUrl,PHP_URL_HOST)??'')], 'warning');
    }

    $attempts = [];
    $routes = cs_player_dns_route_candidates($configuredUrl, 4);
    foreach ($routes as $routeIndex => $route) {
        if ($providerMode !== 'm3u') {
            foreach (cs_player_api_endpoint_candidates() as $endpoint) {
                $target = rtrim($route,'/') . '/' . $endpoint . '?username=__csplayer_probe__&password=__csplayer_probe__';
                $r = cs_admin_probe_request($target, $timeout);
                $decoded = json_decode((string)$r['body'], true);
                $attempts[] = ['route'=>$route,'endpoint'=>'/'.$endpoint,'http_code'=>$r['http_code'],'latency_ms'=>$r['latency_ms'],'json'=>is_array($decoded),'remote_ip'=>$r['remote_ip'],'redirects'=>$r['redirects'],'response_bytes'=>$r['response_bytes'],'effective_host'=>(string)(parse_url($r['effective_url'],PHP_URL_HOST)??'')];
                if ($r['http_code'] >= 200 && $r['http_code'] < 400 && is_array($decoded)) {
                    return [
                        'ok'=>true,'provider'=>($providerMode==='xc'?'xc':'xtream'),'endpoint'=>'/'.$endpoint,
                        'latency_ms'=>$r['latency_ms'],'http_code'=>$r['http_code'],'effective_url'=>$r['effective_url'],
                        'selected_route'=>$route,'route_discovered'=>$route!==$configuredUrl,'configured_url'=>$configuredUrl,
                        'message'=>($providerMode==='xc'?'API XC compatível':'Xtream').' detectado via '.$endpoint.($route!==$configuredUrl?' Rota alternativa selecionada automaticamente.':'')
                    ];
                }
            }
        }

        // XC também permite fallback M3U: muitos servidores aceitam a linha
        // get.php, mas não expõem player_api.php ou respondem 406 ao probe.
        if ($providerMode !== 'xtream') {
            $target = rtrim($route,'/') . '/' . $m3uPath . '?' . http_build_query([
                'username'=>'__csplayer_probe__','password'=>'__csplayer_probe__','type'=>'m3u_plus','output'=>$m3uOutput,
            ]);
            $r = cs_admin_probe_request($target, $timeout, 'IPTVSmartersPro');
            $trim = ltrim((string)$r['body'], "\xEF\xBB\xBF\r\n\t ");
            $isM3u = stripos(substr($trim, 0, 4096), '#EXTM3U') !== false;
            $routeExists = $r['http_code'] > 0 && $r['http_code'] !== 404;
            $attempts[] = ['route'=>$route,'endpoint'=>'/'.$m3uPath,'http_code'=>$r['http_code'],'latency_ms'=>$r['latency_ms'],'m3u'=>$isM3u,'remote_ip'=>$r['remote_ip'],'redirects'=>$r['redirects'],'response_bytes'=>$r['response_bytes'],'effective_host'=>(string)(parse_url($r['effective_url'],PHP_URL_HOST)??'')];
            if ($isM3u || $routeExists) {
                $msg = $isM3u ? 'M3U Plus respondeu corretamente.' : 'Rota M3U Plus encontrada; usuário e senha serão validados no login.';
                if ($route !== $configuredUrl) $msg .= ' Rota alternativa selecionada automaticamente.';
                return [
                    'ok'=>true,'provider'=>'m3u','endpoint'=>'/'.$m3uPath,'latency_ms'=>$r['latency_ms'],
                    'http_code'=>$r['http_code'],'effective_url'=>$r['effective_url'],'selected_route'=>$route,
                    'route_discovered'=>$route!==$configuredUrl,'configured_url'=>$configuredUrl,'message'=>$msg
                ];
            }
        }
    }

    $rootBest = ['http_code'=>0,'curl_errno'=>1,'latency_ms'=>0,'remote_ip'=>''];
    $reachable = false;
    foreach ($routes as $route) {
        $rootProbe = cs_admin_probe_request(rtrim($route,'/').'/', min($timeout,5), 'Mozilla/5.0 CSPlayer/1.5');
        if ((int)$rootProbe['http_code'] > 0 || (int)$rootProbe['curl_errno'] === 0) {
            $reachable = true; $rootBest = $rootProbe; break;
        }
        if ((int)$rootProbe['latency_ms'] > 0) $rootBest = $rootProbe;
    }
    $last = $attempts ? end($attempts) : ['http_code'=>0,'latency_ms'=>0,'endpoint'=>''];
    $code = (int)($last['http_code'] ?? 0);
    $message = $code === 404
        ? 'Servidor online, mas nenhuma rota XC/M3U foi detectada nas combinações HTTP/HTTPS testadas.'
        : ($code > 0 ? 'Servidor respondeu HTTP '.$code.', mas não foi detectada API XC ou rota M3U compatível.' : 'Sem resposta; confirme domínio/IP, porta pública, firewall e protocolo.');
    cs_player_write_log('server_probe_failed', [
        'host'=>(string)(parse_url($configuredUrl,PHP_URL_HOST)??''),'port'=>(int)(parse_url($configuredUrl,PHP_URL_PORT)??0),
        'http_code'=>$code,'latency_ms'=>(int)($last['latency_ms']??0),'provider_mode'=>$providerMode,
        'attempts'=>$attempts,'routes_tested'=>count($routes),'reachable'=>$reachable,
        'remote_ip'=>$rootBest['remote_ip'],'root_http_code'=>$rootBest['http_code'],'message'=>$message,
    ], 'warning');
    return ['ok'=>false,'reachable'=>$reachable,'status'=>$reachable?'online_no_route':'offline','latency_ms'=>(int)($last['latency_ms']??0),'http_code'=>$code,'remote_ip'=>$rootBest['remote_ip'],'root_http_code'=>$rootBest['http_code'],'message'=>$message,'attempts'=>$attempts,'routes_tested'=>$routes];
}

if($_SERVER['REQUEST_METHOD']==='GET'){
    $cfg=cs_player_load_config();
    if(($_GET['action']??'')==='preflight'){
        $checks=[];
        $add=static function(string $key,bool $ok,string $label,string $detail='') use (&$checks): void {
            $checks[]=['key'=>$key,'ok'=>$ok,'label'=>$label,'detail'=>$detail];
        };
        $phpOk=version_compare(PHP_VERSION,'7.4.0','>=');
        $add('php',$phpOk,'PHP '.PHP_VERSION,$phpOk?'Compatível com CS Player (7.4–8.4) · '.PHP_SAPI:'PHP 7.4 ou superior é necessário.');
        $add('runtime',true,'Runtime do Web Player',basename((string)PHP_BINARY).' · '.PHP_SAPI);
        foreach(['curl','json','mbstring','mysqli'] as $ext){$add('ext_'.$ext,extension_loaded($ext),'Extensão '.$ext,extension_loaded($ext)?'Carregada.':'Ausente.');}
        $essential=[
            'bootstrap.php'=>__DIR__.'/player/bootstrap.php','dns_health.php'=>__DIR__.'/player/dns_health.php','api.php'=>__DIR__.'/player/api.php',
            'stream.php'=>__DIR__.'/player/stream.php','segment.php'=>__DIR__.'/player/segment.php','player.js'=>__DIR__.'/player/assets/player.js','player.css'=>__DIR__.'/player/assets/player.css'
        ];
        foreach($essential as $name=>$path){$add('file_'.$name,is_file($path)&&is_readable($path),$name,(is_file($path)&&is_readable($path))?'OK':'Ausente ou sem leitura.');}
        // Detecta rapidamente sintaxe/funções exclusivas do PHP 8 dentro do módulo player.
        $compatIssues=[];
        $compatPatterns=[
            '/\\bmatch\\s*\\(/'=>'match() PHP 8+',
            '/\\?->/'=>'nullsafe PHP 8+',
            '/\\bstr_(?:contains|starts_with|ends_with)\\s*\\(/'=>'função PHP 8+',
            '/^\\s*#\\[/m'=>'atributo PHP 8+',
        ];
        $pit=new RecursiveIteratorIterator(new RecursiveDirectoryIterator(__DIR__.'/player',FilesystemIterator::SKIP_DOTS));
        foreach($pit as $pf){if(!$pf->isFile()||strtolower($pf->getExtension())!=='php')continue;if($pf->getFilename()==='check_install.php')continue;$src=@file_get_contents($pf->getPathname());if(!is_string($src))continue;foreach($compatPatterns as $rx=>$label){if(preg_match($rx,$src)){$compatIssues[]=basename($pf->getPathname()).': '.$label;}}}
        $add('php74_compat',count($compatIssues)===0,'Compatibilidade PHP 7.4',count($compatIssues)===0?'Nenhuma construção PHP 8 exclusiva detectada.':implode(' · ',array_slice($compatIssues,0,4)));
        $cfgDirs=[dirname(CS_PLAYER_RUNTIME_CONFIG_FILE),dirname(CS_PLAYER_RUNTIME_CONFIG_FALLBACK_FILE),dirname(CS_PLAYER_RUNTIME_CONFIG_TMP_FILE)];
        $writeOk=false;$writeDetail=[];
        foreach($cfgDirs as $dir){$ok=is_dir($dir)?is_writable($dir):is_writable(dirname($dir));$writeOk=$writeOk||$ok;$writeDetail[]=basename($dir).':'.($ok?'gravável':'sem escrita');}
        $add('config_write',$writeOk,'Persistência do Web Player',implode(' · ',$writeDetail));
        $dns=cs_player_active_dns($cfg);$add('dns_count',count($dns)>0,'DNS ativos',count($dns).' DNS manual(is) ativo(s).');
        $proxyOk=empty($cfg['proxy_enabled']) || (is_file(__DIR__.'/player/proxy_lib.php')&&is_readable(__DIR__.'/player/proxy_lib.php'));
        $add('proxy',$proxyOk,'Proxy interno',empty($cfg['proxy_enabled'])?'Desativado.':($proxyOk?'Arquivos disponíveis.':'Arquivo do proxy ausente.'));
        $failed=count(array_filter($checks,static fn($c)=>empty($c['ok'])));
        cs_player_write_log('web_player_preflight', ['checks'=>count($checks),'failed'=>$failed,'dns_active'=>count($dns)], $failed?'warning':'info');
        out(['ok'=>$failed===0,'checks'=>$checks,'failed'=>$failed,'dns_active'=>count($dns),'config_location'=>basename(CS_PLAYER_RUNTIME_CONFIG_FILE)]);
    }

    if(($_GET['action']??'')==='test'){
        $url=cs_player_normalize_dns((string)($_GET['url']??''));
        if(!$url) out(['ok'=>false,'message'=>'DNS inválido'],400);
        out(cs_admin_probe_dns(
            $url,
            max(3,min(15,(int)($cfg['request_timeout']??8))),
            (string)($_GET['provider_mode']??'auto'),
            (string)($_GET['m3u_path']??'get.php'),
            (string)($_GET['m3u_output']??'mpegts')
        ));
    }
    if(($_GET['action']??'')==='dns_health'){
        $items=[]; foreach(cs_player_active_dns($cfg) as $row){$items[]=['id'=>(string)($row['id']??''),'name'=>(string)($row['name']??''),'url'=>(string)($row['url']??''),'health'=>cs_player_dns_health_public($row)];}
        out(['ok'=>true,'items'=>$items,'strategy'=>(string)($cfg['dns_strategy']??'smart')]);
    }
    if(($_GET['action']??'')==='vpn'){
        $backend=in_array((string)($cfg['vpn_backend']??'none'),['wireguard','openvpn'],true)?(string)$cfg['vpn_backend']:'none';
        $profile=cs_player_sanitize_vpn_profile((string)($cfg['vpn_profile']??''));
        $operation=(string)($_GET['operation']??'status');
        if ($backend === 'none' || $profile === '') out(['ok'=>true,'message'=>'VPN desativada ou sem perfil configurado.','active'=>false]);
        if (in_array($operation, ['up','restart'], true) && !cs_player_bool($cfg['vpn_enabled'] ?? false, false)) out(['ok'=>false,'message'=>'Ative e salve “VPN habilitada” antes de iniciar o túnel.'],409);
        $result=cs_admin_vpn_exec($operation,$backend,$profile);
        $result['active']=$operation==='down' ? false : ($result['ok'] && $operation!=='status' ? true : null);
        out($result,$result['ok']?200:500);
    }
    if(($_GET['action']??'')==='catalog_search'){
        $q=trim((string)($_GET['q']??''));
        if(mb_strlen($q)<2) out(['ok'=>true,'items'=>[]]);
        $db=cs_player_db(); if(!$db) out(['ok'=>false,'message'=>'Banco indisponível'],503);
        $safe=$db->real_escape_string('%'.$q.'%'); $items=[];
        $rs=@$db->query("SELECT id,stream_display_name,stream_icon,type,category_id,movie_properties FROM streams WHERE type IN (1,2) AND stream_display_name LIKE '$safe' ORDER BY stream_display_name LIMIT 35");
        if($rs) while($r=$rs->fetch_assoc()){$props=json_decode((string)($r['movie_properties']??''),true);if(!is_array($props))$props=[];$items[]=['type'=>(int)$r['type']===1?'live':'movie','id'=>(int)$r['id'],'title'=>(string)$r['stream_display_name'],'image'=>(string)($r['stream_icon']?:($props['movie_image']??'')),'synopsis'=>(string)($props['plot']??$props['description']??'')];}
        $rs=@$db->query("SELECT id,title,cover,plot FROM series WHERE title LIKE '$safe' ORDER BY title LIMIT 35");
        if($rs) while($r=$rs->fetch_assoc())$items[]=['type'=>'series','id'=>(int)$r['id'],'title'=>(string)$r['title'],'image'=>(string)($r['cover']??''),'synopsis'=>(string)($r['plot']??'')];
        out(['ok'=>true,'items'=>array_slice($items,0,60)]);
    }
    out([
        'ok'=>true,
        'config'=>$cfg,
        'player_url'=>'player/',
        'player_public_path'=>'/player/',
        'document_root_hint'=>$_SERVER['DOCUMENT_ROOT']??'',
    ]);
}
if($_SERVER['REQUEST_METHOD']!=='POST')out(['ok'=>false],405);
$raw=json_decode((string)file_get_contents('php://input'),true);
if(!is_array($raw))out(['ok'=>false,'message'=>'JSON inválido'],400);
$cfg=cs_player_load_config();
foreach(['enabled','smart_login','dns_failover','pip_enabled','autoplay_next','remember_position','hero_autoplay','proxy_enabled','proxy_hls','proxy_vod','proxy_cast','proxy_log_enabled','stream_hide_origin','ads_enabled','live_player_enabled','live_hls_enabled','live_ts_enabled','live_prefer_ts','live_epg_enabled','vod_player_enabled','vod_hls_enabled','vod_ts_enabled','vod_mp4_enabled','vod_mkv_enabled','vod_mkv_remux','vod_tmdb_enabled','vod_autoplay_next','advanced_pip_enabled','pip_auto_fallback','pip_floating_enabled','pip_show_title','pip_show_status','player_autoplay','player_resume_enabled','player_keyboard_shortcuts','player_keep_awake','prefer_direct_source','client_profile_enabled','client_show_expiry','client_show_connections','vpn_enabled','vpn_autostart','vpn_killswitch'] as $k){
    $cfg[$k]=array_key_exists($k,$raw) ? cs_player_bool($raw[$k], (bool)($cfg[$k] ?? false)) : cs_player_bool($cfg[$k] ?? false, false);
}
$cfg['dns_json_compat']=array_key_exists('dns_json_compat',$raw) ? cs_player_bool($raw['dns_json_compat'], (bool)($cfg['dns_json_compat'] ?? true)) : cs_player_bool($cfg['dns_json_compat'] ?? true, true);
$cfg['dns_auto_discovery']=array_key_exists('dns_auto_discovery',$raw) ? cs_player_bool($raw['dns_auto_discovery'], (bool)($cfg['dns_auto_discovery'] ?? true)) : cs_player_bool($cfg['dns_auto_discovery'] ?? true, true);
$cfg['dns_discovery_max_candidates']=max(1,min(8,(int)($raw['dns_discovery_max_candidates']??4)));
// Compatibilidade universal: Auto sempre pode cair para M3U Plus após as APIs Xtream.
$cfg['provider_auto_fallback_m3u']=true;
foreach(['brand','login_title','login_subtitle','home_title'] as $k)$cfg[$k]=mb_substr(trim((string)($raw[$k]??$cfg[$k])),0,160);
$cfg['hls_retries']=max(1,min(12,(int)($raw['hls_retries']??7)));
$cfg['stall_timeout']=max(5,min(60,(int)($raw['stall_timeout']??15)));
$cfg['request_timeout']=max(3,min(30,(int)($raw['request_timeout']??8)));
$cfg['live_engine']=in_array((string)($raw['live_engine']??'auto'),['auto','hls','mpegts'],true)?(string)$raw['live_engine']:'auto';
$cfg['vod_engine']=in_array((string)($raw['vod_engine']??'auto'),['auto','hls','mpegts','native','remux'],true)?(string)$raw['vod_engine']:'auto';
$cfg['vpn_backend']=in_array((string)($raw['vpn_backend']??'none'),['none','wireguard','openvpn'],true)?(string)$raw['vpn_backend']:'none';
$cfg['vpn_profile']=preg_replace('/[^A-Za-z0-9._-]/','',mb_substr(trim((string)($raw['vpn_profile']??'')),0,80)) ?: '';
$cfg['vpn_route_mode']=in_array((string)($raw['vpn_route_mode']??'all'),['all','streams'],true)?(string)$raw['vpn_route_mode']:'all';
$cfg['dns_fail_threshold']=max(1,min(5,(int)($raw['dns_fail_threshold']??2)));
$cfg['dns_cooldown']=max(15,min(600,(int)($raw['dns_cooldown']??90)));
$cfg['dns_prefer_last']=!array_key_exists('dns_prefer_last',$raw)||!empty($raw['dns_prefer_last']);
$cfg['m3u_cache_ttl']=max(300,min(86400,(int)($raw['m3u_cache_ttl']??1800)));
$cfg['m3u_user_agent']=mb_substr(trim((string)($raw['m3u_user_agent']??'IPTVSmartersPro')),0,120);
$cfg['hero_interval']=max(4,min(30,(int)($raw['hero_interval']??8)));
$cfg['hero_order']=in_array(($raw['hero_order']??'manual'),['manual','random'],true)?(string)$raw['hero_order']:'manual';
$cfg['proxy_retries']=max(0,min(6,(int)($raw['proxy_retries']??4)));
$cfg['proxy_connect_timeout']=max(2,min(20,(int)($raw['proxy_connect_timeout']??5)));
$cfg['proxy_read_timeout']=max(10,min(120,(int)($raw['proxy_read_timeout']??24)));
$cfg['proxy_manifest_cache']=max(0,min(15,(int)($raw['proxy_manifest_cache']??1)));
$validDelivery=['auto','direct','proxy','proxy_hls'];
$cfg['stream_delivery_mode']=in_array((string)($raw['stream_delivery_mode']??'auto'),$validDelivery,true)?(string)$raw['stream_delivery_mode']:'auto';
foreach(['delivery_hls','delivery_ts','delivery_mp4','delivery_mkv'] as $deliveryKey){$cfg[$deliveryKey]=in_array((string)($raw[$deliveryKey]??'auto'),$validDelivery,true)?(string)$raw[$deliveryKey]:'auto';}
$cfg['ads_preroll_url']=mb_substr(trim((string)($raw['ads_preroll_url']??'')),0,1500);
$cfg['ads_click_url']=mb_substr(trim((string)($raw['ads_click_url']??'')),0,1500);
$cfg['ads_preroll_type']=in_array((string)($raw['ads_preroll_type']??'auto'),['auto','video','image'],true)?(string)$raw['ads_preroll_type']:'auto';
$cfg['ads_skip_seconds']=max(0,min(30,(int)($raw['ads_skip_seconds']??5)));
$cfg['ads_image_seconds']=max(3,min(60,(int)($raw['ads_image_seconds']??8)));
$cfg['ads_frequency']=in_array((string)($raw['ads_frequency']??'session'),['always','session','content'],true)?(string)$raw['ads_frequency']:'session';
// Configurações avançadas do player/admin/player.
foreach(['live_player_enabled','live_hls_enabled','live_ts_enabled','live_prefer_ts','live_epg_enabled','vod_player_enabled','vod_hls_enabled','vod_ts_enabled','vod_mp4_enabled','vod_mkv_enabled','vod_mkv_remux','vod_tmdb_enabled','vod_autoplay_next','vpn_enabled','vpn_autostart','vpn_killswitch','advanced_pip_enabled','pip_auto_fallback','pip_floating_enabled','pip_show_title','pip_show_status','player_autoplay','player_resume_enabled','player_keyboard_shortcuts','player_keep_awake','prefer_direct_source','client_profile_enabled','client_show_expiry','client_show_connections'] as $k){
    $cfg[$k]=array_key_exists($k,$raw) ? cs_player_bool($raw[$k], (bool)($cfg[$k] ?? true)) : cs_player_bool($cfg[$k] ?? true, true);
}
$cfg['live_proxy_mode']=in_array((string)($raw['live_proxy_mode']??'proxy'),['auto','direct','proxy','proxy_hls'],true)?(string)$raw['live_proxy_mode']:'proxy';
$cfg['vod_proxy_mode']=in_array((string)($raw['vod_proxy_mode']??'proxy'),['auto','direct','proxy'],true)?(string)$raw['vod_proxy_mode']:'proxy';
$cfg['live_epg_url']=mb_substr(trim((string)($raw['live_epg_url']??'')),0,1500);
$cfg['live_epg_cache_ttl']=max(60,min(86400,(int)($raw['live_epg_cache_ttl']??3600)));
$cfg['vod_retries']=max(1,min(12,(int)($raw['vod_retries']??7)));
$cfg['pip_floating_width']=max(220,min(900,(int)($raw['pip_floating_width']??420)));
$cfg['pip_floating_mobile_width']=max(180,min(600,(int)($raw['pip_floating_mobile_width']??320)));
$cfg['player_resume_min_seconds']=max(5,min(300,(int)($raw['player_resume_min_seconds']??15)));
$cfg['player_resume_save_interval']=max(2,min(30,(int)($raw['player_resume_save_interval']??5)));
$cfg['player_max_recovery_cycles']=max(1,min(10,(int)($raw['player_max_recovery_cycles']??4)));
$cfg['player_recovery_backoff_ms']=max(250,min(5000,(int)($raw['player_recovery_backoff_ms']??650)));
if (!cs_player_bool($cfg['proxy_enabled'] ?? false, false)) { $cfg['proxy_hls']=false; $cfg['proxy_vod']=false; $cfg['proxy_cast']=false; }
if ($cfg['vpn_backend'] === 'none') $cfg['vpn_enabled'] = false;
$vpnBoot = cs_admin_vpn_boot_exec(cs_player_bool($cfg['vpn_autostart'] ?? false, false) && cs_player_bool($cfg['vpn_enabled'] ?? false, false), (string)($cfg['vpn_backend'] ?? 'none'), cs_player_sanitize_vpn_profile((string)($cfg['vpn_profile'] ?? '')));
$cfg['manual_highlights']=[];
foreach(array_slice(is_array($raw['manual_highlights']??null)?$raw['manual_highlights']:[],0,100) as $i=>$row){
    if(!is_array($row))continue; $type=(string)($row['type']??''); $id=(int)($row['id']??0);
    if(!$id||!in_array($type,['live','movie','series'],true))continue;
    $delivery=in_array((string)($row['delivery_mode']??'inherit'),['inherit','auto','direct','proxy','proxy_hls'],true)?(string)$row['delivery_mode']:'inherit';
    $adMode=in_array((string)($row['ad_mode']??'inherit'),['inherit','on','off'],true)?(string)$row['ad_mode']:'inherit';
    $cfg['manual_highlights'][]=['type'=>$type,'id'=>$id,'title'=>mb_substr(trim((string)($row['title']??'')),0,180),'custom_image'=>mb_substr(trim((string)($row['custom_image']??'')),0,1000),'custom_synopsis'=>mb_substr(trim((string)($row['custom_synopsis']??'')),0,2000),'enabled'=>!array_key_exists('enabled',$row)||!empty($row['enabled']),'sort'=>max(1,min(999,(int)($row['sort']??($i+1)))),'delivery_mode'=>$delivery,'ad_mode'=>$adMode,'ad_url'=>mb_substr(trim((string)($row['ad_url']??'')),0,1500)];
}
usort($cfg['manual_highlights'],static fn($a,$b)=>(int)$a['sort']<=>(int)$b['sort']);
$cfg['dns']=[];
foreach(($raw['dns']??[]) as $i=>$row){
    if(!is_array($row))continue;
    $rawUrl=trim((string)($row['url']??''));
    if($rawUrl!=='' && !preg_match('~^https?://~i',$rawUrl)) $rawUrl='http://'.ltrim($rawUrl,'/');
    $rawParts=@parse_url($rawUrl); $rawPath=is_array($rawParts)?(string)($rawParts['path']??''):''; $rawQuery=[];
    if(is_array($rawParts)&&isset($rawParts['query'])) parse_str((string)$rawParts['query'],$rawQuery);
    $url=cs_player_normalize_dns($rawUrl);
    if(!$url)continue;
    $detectedM3uPath=trim((string)($row['m3u_path']??'get.php'));
    $detectedM3uOutput=strtolower(trim((string)($row['m3u_output']??'mpegts')));
    $detectedProvider=strtolower(trim((string)($row['provider_mode']??'auto')));
    if(preg_match('~/get\.php$~i',$rawPath)) {
        $detectedM3uPath=ltrim($rawPath,'/');
        if(isset($rawQuery['output']) && in_array(strtolower((string)$rawQuery['output']),['mpegts','hls'],true)) $detectedM3uOutput=strtolower((string)$rawQuery['output']);
        $detectedProvider='m3u';
        unset($rawQuery['username'],$rawQuery['password'],$rawQuery['type'],$rawQuery['output']);
    }
    $cfg['dns'][]=[
        'id'=>(string)($row['id']??('manual_'.($i+1))),
        'name'=>mb_substr(trim((string)($row['name']??('DNS Manual '.($i+1)))),0,80),
        'url'=>$url,
        'enabled'=>!empty($row['enabled']),
        'priority'=>max(1,min(999,(int)($row['priority']??($i+1)))),
        'fixed'=>false,
        'source'=>'manual',
        'provider_mode'=>in_array($detectedProvider,['auto','xc','smart','xtream','m3u'],true)?$detectedProvider:'auto',
        'm3u_output'=>in_array($detectedM3uOutput,['mpegts','hls'],true)?$detectedM3uOutput:'mpegts',
        'm3u_path'=>mb_substr($detectedM3uPath!==''?$detectedM3uPath:'get.php',0,160),
        'm3u_extra_query'=>$rawQuery,
        'user_agent'=>mb_substr(trim((string)($row['user_agent']??'')),0,120),
        'http_profile'=>in_array(strtolower((string)($row['http_profile']??'auto')),['auto','smarters','xciptv','vlc','browser'],true)?strtolower((string)$row['http_profile']):'auto',
        'ip_mode'=>in_array(strtolower((string)($row['ip_mode']??'auto')),['auto','ipv4','ipv6'],true)?strtolower((string)$row['ip_mode']):'auto',
    ];
}
if(!cs_player_save_config($cfg))out(['ok'=>false,'message'=>'Não foi possível salvar a configuração persistente do Web Player.'],500);
cs_player_write_log('web_player_config_saved', ['dns_mode'=>'manual_only', 'manual_dns_count'=>count($cfg['dns']), 'enabled_manual_dns'=>count(array_filter($cfg['dns'], static fn($r)=>function_exists('cs_player_bool') ? cs_player_bool($r['enabled'] ?? false, false) : !empty($r['enabled']))), 'highlights'=>count($cfg['manual_highlights'])], 'info');
out(['ok'=>true,'message'=>$vpnBoot['ok']?'Configurações do Web Player salvas. Somente DNS manuais ativos serão utilizados.':('Configurações salvas, mas o autostart VPN não foi aplicado: '.$vpnBoot['message']),'vpn_boot'=>$vpnBoot,'config'=>$cfg]);

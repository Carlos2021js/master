<?php
declare(strict_types=1);
/**
 * CS PLAYER - bootstrap público de reprodução/API.
 * Mantém a entrega direta baseada em streams.stream_source.
 */
if (!defined('CS_PLAYER_BOOTSTRAP')) define('CS_PLAYER_BOOTSTRAP', true);

$functions = dirname(__DIR__) . '/functions.php';
if (!is_file($functions)) throw new RuntimeException('CS PLAYER: functions.php não encontrado.');
require_once $functions;

if (!function_exists('cs_player_bool')) {
    function cs_player_bool($value, bool $default = false): bool {
        if ($value === null || $value === '') return $default;
        return in_array(strtolower(trim((string)$value)), ['1','true','yes','on'], true);
    }
}

if (!function_exists('cs_player_load_config')) {
    function cs_player_load_config(): array {
        global $rAdminSettings;
        return is_array($rAdminSettings ?? null) ? $rAdminSettings : [];
    }
}

function cs_player_public_user(string $username, string $password): ?array {
    global $db;
    if (!($db instanceof mysqli)) return null;
    $stmt = $db->prepare("SELECT * FROM users WHERE username=? AND password=? AND enabled=1 LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param('ss', $username, $password);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if (!is_array($row)) return null;
    $exp = (int)($row['exp_date'] ?? 0);
    if ($exp > 0 && $exp < time()) return null;
    return $row;
}

function cs_player_public_bouquet_ids(array $user): array {
    $raw = $user['bouquet'] ?? [];
    if (is_string($raw)) $raw = json_decode($raw, true);
    if (!is_array($raw)) return [];
    return array_values(array_unique(array_filter(array_map('intval', $raw), static function($v){ return $v > 0; })));
}

function cs_player_public_allowed_stream(array $user, int $streamId): bool {
    $bouquets = cs_player_public_bouquet_ids($user);
    if (!$bouquets) return true; // preserva instalações sem bouquet gravado.
    global $db;
    $ids = implode(',', array_map('intval', $bouquets));
    $res = $db->query("SELECT bouquet_channels, bouquet_series FROM bouquets WHERE id IN ($ids)");
    if (!$res) return false;
    while ($row = $res->fetch_assoc()) {
        foreach (['bouquet_channels','bouquet_series'] as $field) {
            $items = json_decode((string)($row[$field] ?? ''), true);
            if (is_array($items) && in_array($streamId, array_map('intval', $items), true)) return true;
        }
    }
    return false;
}

function cs_player_local_stream_sources(int $streamId, string $username, string $password): array {
    global $db;
    $user = cs_player_public_user($username, $password);
    if (!$user || $streamId <= 0) return [];
    $stmt = $db->prepare('SELECT id, type, stream_source, direct_source FROM streams WHERE id=? AND type IN (1,2,5) LIMIT 1');
    if (!$stmt) return [];
    $stmt->bind_param('i', $streamId);
    $stmt->execute();
    $stream = $stmt->get_result()->fetch_assoc();
    if (!is_array($stream) || !cs_player_public_allowed_stream($user, $streamId)) return [];
    $sources = json_decode((string)$stream['stream_source'], true);
    if (!is_array($sources)) $sources = [];
    $out = [];
    foreach ($sources as $source) {
        $source = trim((string)$source);
        if ($source !== '' && preg_match('~^https?://~i', $source)) $out[] = $source;
    }
    return array_values(array_unique($out));
}

function cs_player_public_type(string $type): int {
    return $type === 'movie' ? 2 : ($type === 'series' ? 5 : 1);
}

function cs_player_local_api(string $username, string $password, string $action, array $extra = []): ?array {
    global $db;
    $user = cs_player_public_user($username, $password);
    if (!$user) return null;
    $type = cs_player_public_type($action === 'get_vod_streams' ? 'movie' : ($action === 'get_series' ? 'series' : 'live'));

    if ($action === 'user_info') {
        return ['user_info'=>[
            'username'=>(string)$user['username'],
            'password'=>(string)$user['password'],
            'auth'=>1,
            'status'=>'Active',
            'exp_date'=>(string)($user['exp_date'] ?? 0),
            'is_trial'=>'0',
            'active_cons'=>'0',
            'max_connections'=>(string)($user['max_connections'] ?? 1),
        ], 'server_info'=>['url'=>'http://'.($_SERVER['HTTP_HOST'] ?? 'localhost'),'port'=>(string)($_SERVER['SERVER_PORT'] ?? 80)]];
    }

    if ($action === 'get_live_categories' || $action === 'get_vod_categories' || $action === 'get_series_categories') {
        $catType = $action === 'get_live_categories' ? 'live' : ($action === 'get_vod_categories' ? 'movie' : 'series');
        $stmt = $db->prepare('SELECT id AS category_id, category_name, parent_id FROM stream_categories WHERE category_type=? ORDER BY cat_order ASC, id ASC');
        $stmt->bind_param('s', $catType); $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    if ($action === 'get_live_streams' || $action === 'get_vod_streams') {
        $type = $action === 'get_live_streams' ? 1 : 2;
        $cat = isset($extra['category_id']) ? (int)$extra['category_id'] : 0;
        $sql = 'SELECT id AS stream_id, stream_display_name AS name, type AS stream_type, stream_icon, category_id, direct_source, target_container FROM streams WHERE type=?';
        if ($cat > 0) $sql .= ' AND category_id=?';
        $sql .= ' ORDER BY `order` ASC, id ASC';
        $stmt = $db->prepare($sql);
        if ($cat > 0) { $stmt->bind_param('ii', $type, $cat); } else { $stmt->bind_param('i', $type); }
        $stmt->execute(); $rows=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        foreach ($rows as &$r) { $r['stream_type']=$type===1?'live':'movie'; $r['stream_icon']=(string)$r['stream_icon']; $r['rating']='0'; $r['rating_5based']='0'; $r['added']='0'; $r['custom_sid']=''; $r['direct_source']=''; $r['container_extension']=trim((string)(json_decode((string)$r['target_container'],true)[0]??'mp4')); }
        unset($r); return $rows;
    }

    if ($action === 'get_series') {
        $stmt=$db->query('SELECT id AS series_id, title AS name, cover, cover_big, category_id, genre, plot, rating, last_modified FROM series ORDER BY title ASC');
        return $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    }

    if ($action === 'get_vod_info') {
        $id=(int)($extra['vod_id']??0); $stmt=$db->prepare('SELECT id AS stream_id, stream_display_name AS name, stream_icon, movie_propeties, target_container FROM streams WHERE id=? AND type=2 LIMIT 1'); $stmt->bind_param('i',$id); $stmt->execute(); $r=$stmt->get_result()->fetch_assoc(); if(!$r)return []; $p=json_decode((string)$r['movie_propeties'],true); return ['info'=>is_array($p)?$p:[], 'movie_data'=>['stream_id'=>$id,'name'=>$r['name'],'container_extension'=>trim((string)(json_decode((string)$r['target_container'],true)[0]??'mp4'))]];
    }

    if ($action === 'get_series_info') {
        $id=(int)($extra['series_id']??$extra['series']??0); $stmt=$db->prepare('SELECT id, title, cover, cover_big, category_id, genre, plot, rating, seasons FROM series WHERE id=? LIMIT 1'); $stmt->bind_param('i',$id); $stmt->execute(); $s=$stmt->get_result()->fetch_assoc(); if(!$s)return []; $ep=$db->prepare('SELECT se.season_num,se.sort,se.stream_id,st.stream_display_name,st.target_container FROM series_episodes se JOIN streams st ON st.id=se.stream_id WHERE se.series_id=? ORDER BY se.season_num,se.sort'); $ep->bind_param('i',$id); $ep->execute(); $epRes=$ep->get_result(); $episodes=[]; while($e=$epRes->fetch_assoc()){ $episodes[(string)$e['season_num']][]=['id'=>(int)$e['stream_id'],'episode_num'=>(int)$e['sort'],'title'=>$e['stream_display_name'],'container_extension'=>trim((string)(json_decode((string)$e['target_container'],true)[0]??'mp4'))]; } return ['seasons'=>array_map(static function($n){return ['season_number'=>(int)$n];},array_keys($episodes)),'episodes'=>$episodes,'info'=>$s];
    }

    return [];
}

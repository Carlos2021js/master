<?php
/**
 * CS PLAYER compatibility footer.
 * Kept intentionally small: legacy Premium UI pages expect this file to
 * provide the shared vendor bundle, while each page loads its own plugins.
 */
if (count(get_included_files()) === 1) { exit; }
?>
<script src="assets/js/vendor.min.js"></script>

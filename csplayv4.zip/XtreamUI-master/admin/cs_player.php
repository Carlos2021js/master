<?php
/**
 * CS Player compatibility and resilience layer.
 * Additive helpers only: no existing provider or panel feature is removed.
 */

if (!defined('CS_PLAYER_NAME')) {
    define('CS_PLAYER_NAME', 'CS Player');
}


/**
 * Tratamento global conservador: registra falhas fatais sem expor caminhos,
 * credenciais ou rastros de pilha ao usuário final.
 */
function cs_is_json_request() {
    $accept = isset($_SERVER['HTTP_ACCEPT']) ? (string) $_SERVER['HTTP_ACCEPT'] : '';
    $xhr = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) : '';
    return strpos($accept, 'application/json') !== false || $xhr === 'xmlhttprequest';
}

function cs_render_unexpected_error($requestId) {
    if (headers_sent()) {
        return;
    }
    http_response_code(500);
    header('Cache-Control: no-store, no-cache, must-revalidate');
    if (cs_is_json_request()) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('success' => false, 'error' => 'Falha interna temporária.', 'request_id' => $requestId), JSON_UNESCAPED_UNICODE);
    } else {
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><meta charset="utf-8"><title>CS Player</title><div style="font-family:system-ui;max-width:680px;margin:10vh auto;padding:24px"><h1>Não foi possível concluir a operação</h1><p>O erro foi registrado. Tente novamente e informe o código <strong>' . htmlspecialchars($requestId, ENT_QUOTES, 'UTF-8') . '</strong> ao administrador.</p></div>';
    }
}

if (!defined('CS_PLAYER_ERROR_HANDLERS')) {
    define('CS_PLAYER_ERROR_HANDLERS', true);
    set_exception_handler(function ($exception) {
        $requestId = bin2hex(random_bytes(6));
        error_log('[CS Player][' . $requestId . '] Exceção não tratada: ' . get_class($exception) . ': ' . $exception->getMessage() . ' em ' . $exception->getFile() . ':' . $exception->getLine());
        if (PHP_SAPI !== 'cli') {
            cs_render_unexpected_error($requestId);
        }
    });
    register_shutdown_function(function () {
        $error = error_get_last();
        if (!$error || !in_array($error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
            return;
        }
        $requestId = bin2hex(random_bytes(6));
        error_log('[CS Player][' . $requestId . '] Erro fatal: ' . $error['message'] . ' em ' . $error['file'] . ':' . $error['line']);
        if (PHP_SAPI !== 'cli') {
            cs_render_unexpected_error($requestId);
        }
    });
}

function cs_array_get(array $array, $key, $default = null) {
    return array_key_exists($key, $array) ? $array[$key] : $default;
}

function cs_bool($value) {
    if (is_bool($value)) {
        return $value;
    }
    return in_array(strtolower(trim((string) $value)), array('1', 'true', 'yes', 'on'), true);
}

function cs_cache_directory() {
    $configured = getenv('CS_PLAYER_CACHE_DIR');
    $candidates = array_filter(array(
        $configured,
        __DIR__ . '/cache/cs-player',
        sys_get_temp_dir() . '/cs-player-cache'
    ));

    foreach ($candidates as $directory) {
        if (!is_dir($directory)) {
            @mkdir($directory, 0775, true);
        }
        if (is_dir($directory) && is_writable($directory)) {
            return $directory;
        }
    }
    return null;
}

function cs_cache_key($namespace, $key) {
    return preg_replace('/[^a-z0-9_.-]+/i', '-', (string) $namespace) . '-' . hash('sha256', (string) $key) . '.json';
}

function cs_cache_get($namespace, $key, $default = null) {
    $directory = cs_cache_directory();
    if (!$directory) {
        return $default;
    }
    $path = $directory . DIRECTORY_SEPARATOR . cs_cache_key($namespace, $key);
    if (!is_file($path)) {
        return $default;
    }
    $payload = json_decode((string) @file_get_contents($path), true);
    if (!is_array($payload) || !isset($payload['expires_at']) || time() >= (int) $payload['expires_at']) {
        @unlink($path);
        return $default;
    }
    return array_key_exists('value', $payload) ? $payload['value'] : $default;
}

function cs_cache_prune($maxFiles = 2000, $maxAge = 604800) {
    $directory = cs_cache_directory();
    if (!$directory) return 0;
    $files = glob($directory . DIRECTORY_SEPARATOR . '*.json') ?: array();
    $removed = 0;
    $now = time();
    foreach ($files as $file) {
        if (!is_file($file)) continue;
        if (@filemtime($file) < $now - max(3600, (int) $maxAge)) {
            if (@unlink($file)) $removed++;
        }
    }
    $files = glob($directory . DIRECTORY_SEPARATOR . '*.json') ?: array();
    if (count($files) > (int) $maxFiles) {
        usort($files, function ($a, $b) { return (@filemtime($a) ?: 0) <=> (@filemtime($b) ?: 0); });
        foreach (array_slice($files, 0, count($files) - (int) $maxFiles) as $file) {
            if (@unlink($file)) $removed++;
        }
    }
    return $removed;
}

function cs_cache_set($namespace, $key, $value, $ttl = 60) {
    $directory = cs_cache_directory();
    if (!$directory) {
        return false;
    }
    $path = $directory . DIRECTORY_SEPARATOR . cs_cache_key($namespace, $key);
    $temp = $path . '.' . getmypid() . '.tmp';
    $payload = json_encode(array(
        'created_at' => time(),
        'expires_at' => time() + max(1, (int) $ttl),
        'value' => $value
    ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($payload === false || @file_put_contents($temp, $payload, LOCK_EX) === false) {
        return false;
    }
    @chmod($temp, 0664);
    $saved = @rename($temp, $path);
    if ($saved && random_int(1, 100) === 1) { cs_cache_prune(); }
    return $saved;
}

function cs_cache_remember($namespace, $key, $ttl, callable $callback, $staleTtl = 300) {
    $cached = cs_cache_get($namespace, $key, null);
    if ($cached !== null) {
        return $cached;
    }

    $staleKey = $key . ':stale';
    try {
        $value = $callback();
        if ($value !== null && $value !== false) {
            cs_cache_set($namespace, $key, $value, $ttl);
            cs_cache_set($namespace, $staleKey, $value, max($ttl, $staleTtl));
        }
        return $value;
    } catch (Throwable $exception) {
        error_log('[CS Player] Cache callback failure: ' . $exception->getMessage());
        return cs_cache_get($namespace, $staleKey, null);
    }
}

function cs_http_post_form($url, array $fields, $timeout = 8) {
    $body = http_build_query($fields, '', '&');
    if (function_exists('curl_init')) {
        $curl = curl_init($url);
        curl_setopt_array($curl, array(
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => min(5, (int) $timeout),
            CURLOPT_TIMEOUT => (int) $timeout,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER => array('Content-Type: application/x-www-form-urlencoded', 'User-Agent: CS-Player/1.0')
        ));
        $response = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $error = curl_error($curl);
        curl_close($curl);
        if ($response === false || $status < 200 || $status >= 300) {
            throw new RuntimeException('HTTP request failed (' . $status . '): ' . $error);
        }
        return $response;
    }

    $context = stream_context_create(array('http' => array(
        'method' => 'POST',
        'timeout' => (int) $timeout,
        'ignore_errors' => true,
        'header' => "Content-Type: application/x-www-form-urlencoded\r\nUser-Agent: CS-Player/1.0\r\n",
        'content' => $body
    )));
    $response = @file_get_contents($url, false, $context);
    if ($response === false) {
        throw new RuntimeException('HTTP request failed using stream transport.');
    }
    return $response;
}

function cs_recaptcha_v3_config(array $settings) {
    $siteKey = trim((string) cs_array_get($settings, 'recaptcha_v3_site_key', ''));
    $secretKey = trim((string) cs_array_get($settings, 'recaptcha_v3_secret_key', ''));
    $enabled = cs_bool(cs_array_get($settings, 'recaptcha_v3_enable', false)) && $siteKey !== '' && $secretKey !== '';
    $score = (float) cs_array_get($settings, 'recaptcha_v3_min_score', 0.5);
    return array(
        'enabled' => $enabled,
        'site_key' => $siteKey,
        'secret_key' => $secretKey,
        'min_score' => min(1.0, max(0.0, $score))
    );
}

function cs_verify_recaptcha_v3(array $config, $token, $remoteIp = null, $expectedAction = 'login') {
    if (empty($config['enabled'])) {
        return array('success' => true, 'bypassed' => true);
    }
    $token = trim((string) $token);
    if ($token === '') {
        return array('success' => false, 'reason' => 'missing-token');
    }
    try {
        $raw = cs_http_post_form('https://www.google.com/recaptcha/api/siteverify', array_filter(array(
            'secret' => $config['secret_key'],
            'response' => $token,
            'remoteip' => $remoteIp
        )), 8);
        $response = json_decode($raw, true);
        if (!is_array($response) || empty($response['success'])) {
            return array('success' => false, 'reason' => 'verification-failed');
        }
        if (isset($response['action']) && $expectedAction !== '' && !hash_equals($expectedAction, (string) $response['action'])) {
            return array('success' => false, 'reason' => 'invalid-action');
        }
        if ((float) cs_array_get($response, 'score', 0.0) < (float) $config['min_score']) {
            return array('success' => false, 'reason' => 'low-score');
        }
        return array('success' => true, 'score' => (float) cs_array_get($response, 'score', 0.0));
    } catch (Throwable $exception) {
        error_log('[CS Player] reCAPTCHA v3 unavailable: ' . $exception->getMessage());
        return array('success' => false, 'reason' => 'service-unavailable');
    }
}

function cs_detect_provider_type($source) {
    $source = strtolower(trim((string) $source));
    if (preg_match('/\.m3u8(?:\?|$)/', $source)) {
        return 'hls';
    }
    if (strpos($source, '#extm3u') !== false || preg_match('/\.m3u(?:\?|$)/', $source)) {
        return 'm3u';
    }
    if (strpos($source, 'player_api.php') !== false || strpos($source, 'get.php') !== false) {
        return 'xtream-api';
    }
    if (strpos($source, '/stalker_portal/') !== false || strpos($source, '/portal.php') !== false || strpos($source, '/server/load.php') !== false) {
        return 'stalker';
    }
    return 'auto';
}

<?php
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
require_once __DIR__ . '/cs_audit.php';
cs_admin_only('o Servidor SSH');

if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
if (empty($_SESSION['cs_vps_csrf'])) { $_SESSION['cs_vps_csrf'] = bin2hex(random_bytes(32)); }

function cs_vps_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function cs_vps_exec(array $args, int $timeout = 45): array {
    $helper = '/usr/local/sbin/cs-player-adminctl';
    if (!is_file($helper) || !is_executable($helper)) {
        return ['ok'=>false,'code'=>127,'output'=>'Helper seguro não instalado. Execute admin/server-config/install_vps_manager.sh como root.'];
    }
    // Quando o PHP-FPM já está rodando como root, não passe pelo sudo:
    // sudo pode exigir uma senha mesmo para uma chamada local autorizada.
    $isRoot = function_exists('posix_geteuid') && posix_geteuid() === 0;
    $cmd = $isRoot ? [$helper] : ['/usr/bin/sudo','-n',$helper];
    foreach ($args as $arg) { $cmd[] = (string)$arg; }
    $descriptors = [1=>['pipe','w'],2=>['pipe','w']];
    $proc = @proc_open($cmd, $descriptors, $pipes, null, ['LANG'=>'C','LC_ALL'=>'C'], ['bypass_shell'=>true]);
    if (!is_resource($proc)) return ['ok'=>false,'code'=>126,'output'=>'Não foi possível iniciar a operação.'];
    stream_set_blocking($pipes[1], false); stream_set_blocking($pipes[2], false);
    $start = microtime(true); $out = '';
    do {
        $out .= stream_get_contents($pipes[1]); $out .= stream_get_contents($pipes[2]);
        $status = proc_get_status($proc);
        if (!$status['running']) break;
        if ((microtime(true)-$start) > $timeout) { proc_terminate($proc, 15); usleep(250000); proc_terminate($proc, 9); $out .= "\nTempo limite excedido."; break; }
        usleep(100000);
    } while (true);
    $out .= stream_get_contents($pipes[1]); $out .= stream_get_contents($pipes[2]);
    fclose($pipes[1]); fclose($pipes[2]);
    $code = proc_close($proc); if ($code < 0 && isset($status['exitcode']) && $status['exitcode'] >= 0) $code = $status['exitcode'];
    $output = trim($out) ?: 'Operação concluída.';
    if (!$isRoot && $code !== 0 && preg_match('/password is required|a senha é necessária|não é possível ler a senha/i', $output)) {
        $output = 'O usuário do PHP-FPM não possui autorização sudo sem senha para o helper. Execute, como root, admin/server-config/install_vps_manager.sh ou configure a regra NOPASSWD indicada no README.';
    }
    return ['ok'=>$code===0,'code'=>$code,'output'=>$output];
}
function cs_vps_panel_cache_clear(): array {
    $targets = [__DIR__.'/cache/cs-player', __DIR__.'/storage/m3u_uploads'];
    $removed = 0; $failed = 0; $now = time();
    foreach ($targets as $dir) {
        if (!is_dir($dir)) continue;
        try {
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($it as $file) {
                if (!$file->isFile()) continue;
                if (strpos($dir, 'm3u_uploads') !== false && $file->getMTime() > $now - 86400) continue;
                if (@unlink($file->getPathname())) $removed++; else $failed++;
            }
        } catch (Throwable $e) { $failed++; }
    }
    if (function_exists('opcache_reset')) @opcache_reset();
    clearstatcache(true);
    return ['ok'=>$failed===0,'code'=>$failed?1:0,'output'=>"Cache do painel limpo. Arquivos removidos: {$removed}. Falhas: {$failed}. OPcache solicitado."];
}

$message = null; $result = null;
$allowedActions = [
    'status'=>'status', 'restart_php'=>'restart-php', 'reload_nginx'=>'reload-nginx',
    'restart_nginx'=>'restart-nginx', 'restart_vps'=>'restart-vps',
    'clear_system_cache'=>'clear-system-cache', 'rotate_logs'=>'rotate-logs',
    'disk_cleanup'=>'disk-cleanup', 'php_profile_safe'=>'php-profile-safe',
    'php_profile_large'=>'php-profile-large', 'php_profile_unlimited_time'=>'php-profile-unlimited-time',
    'test_config'=>'test-config'
];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $now = microtime(true);
    $lastAction = isset($_SESSION['cs_vps_last_action']) ? (float)$_SESSION['cs_vps_last_action'] : 0.0;
    if (($now - $lastAction) < 2.0) {
        http_response_code(429);
        $result = ['ok'=>false,'code'=>429,'output'=>'Aguarde alguns segundos antes de executar outra ação.'];
    } elseif (!hash_equals($_SESSION['cs_vps_csrf'], (string)($_POST['csrf'] ?? ''))) {
        http_response_code(419); $result = ['ok'=>false,'code'=>419,'output'=>'Token de segurança inválido. Atualize a página.'];
    } else {
        $action = (string)($_POST['action'] ?? '');
        $confirm = (string)($_POST['confirm'] ?? '');
        if ($action === 'clear_panel_cache') {
            $result = cs_vps_panel_cache_clear();
        } elseif (isset($allowedActions[$action])) {
            $critical = in_array($action, ['restart_vps','restart_nginx','php_profile_safe','php_profile_large','php_profile_unlimited_time','disk_cleanup'], true);
            if ($critical && $confirm !== 'CONFIRMAR') {
                $result = ['ok'=>false,'code'=>400,'output'=>'Digite CONFIRMAR para executar esta ação crítica.'];
            } else {
                $result = cs_vps_exec([$allowedActions[$action]], $action === 'restart_vps' ? 8 : 90);
            }
        } else {
            $result = ['ok'=>false,'code'=>400,'output'=>'Ação não permitida.'];
        }
        $_SESSION['cs_vps_last_action'] = $now;
        cs_audit_log('vps_manager.action', ['action'=>$action,'ok'=>(bool)$result['ok'],'code'=>(int)$result['code']]);
    }
}
$status = cs_vps_exec(['status'], 15);
include $rSettings['sidebar'] ? 'header_sidebar.php' : 'header.php';
?>
<div class="wrapper"><div class="container-fluid">
<div class="row"><div class="col-12"><div class="page-title-box"><h4 class="page-title"><i class="mdi mdi-server-security"></i> Servidor SSH</h4></div></div></div>
<div class="alert alert-warning"><strong>Segurança:</strong> o CS Player não armazena senha root nem credenciais SSH em texto. As ações locais usam um helper root com lista fechada de comandos. O PHP-FPM deve executar o helper diretamente quando for root ou por meio de uma regra sudo <code>NOPASSWD</code> restrita ao caminho do helper. O acesso SSH deve usar chave pública e autenticação protegida, nunca senha root salva no painel. Somente o administrador principal acessa esta página.</div>
<?php if ($result): ?><div class="alert alert-<?=$result['ok']?'success':'danger'?>"><strong><?=$result['ok']?'Concluído':'Falha'?> (código <?=intval($result['code'])?>)</strong><pre class="mt-2 mb-0" style="white-space:pre-wrap"><?=cs_vps_h($result['output'])?></pre></div><?php endif; ?>
<div class="row">
<div class="col-lg-4"><div class="card"><div class="card-body"><h4 class="header-title">Estado do servidor e SSH</h4><pre style="white-space:pre-wrap;max-height:330px;overflow:auto"><?=cs_vps_h($status['output'])?></pre><form method="post"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="status"><button class="btn btn-info btn-block"><i class="mdi mdi-refresh"></i> Atualizar estado</button></form></div></div></div>
<div class="col-lg-4"><div class="card"><div class="card-body"><h4 class="header-title">Painel e cache</h4><p>Atualiza somente componentes administrativos, sem reiniciar a VPS.</p>
<form method="post" class="mb-2"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="clear_panel_cache"><button class="btn btn-primary btn-block">Limpar cache do painel e OPcache</button></form>
<form method="post" class="mb-2"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="restart_php"><button class="btn btn-warning btn-block">Reiniciar PHP-FPM</button></form>
<form method="post"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="reload_nginx"><button class="btn btn-secondary btn-block">Recarregar Nginx sem derrubar conexões</button></form>
</div></div></div>
<div class="col-lg-4"><div class="card"><div class="card-body"><h4 class="header-title">Manutenção</h4>
<form method="post" class="mb-2"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="clear_system_cache"><button class="btn btn-light btn-block">Limpar caches seguros do sistema</button></form>
<form method="post" class="mb-2"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="rotate_logs"><button class="btn btn-light btn-block">Rotacionar logs</button></form>
<form method="post"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="test_config"><button class="btn btn-light btn-block">Validar Nginx e PHP-FPM</button></form>
</div></div></div>
</div>
<div class="row"><div class="col-lg-8"><div class="card"><div class="card-body"><h4 class="header-title">Perfis seguros do PHP 8.3</h4><p class="text-muted">Os perfis alteram somente um arquivo dedicado do CS Player e preservam o php.ini original. A configuração é validada antes de reiniciar o serviço.</p>
<div class="table-responsive"><table class="table"><thead><tr><th>Perfil</th><th>Valores principais</th><th>Ação</th></tr></thead><tbody>
<tr><td>Seguro</td><td>512M RAM, 2G upload, 3600s</td><td><form method="post"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="php_profile_safe"><input type="hidden" name="confirm" value="CONFIRMAR"><button class="btn btn-sm btn-success">Aplicar</button></form></td></tr>
<tr><td>Arquivos grandes</td><td>1G RAM, 10G upload, tempo ilimitado controlado</td><td><form method="post"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="php_profile_large"><input type="hidden" name="confirm" value="CONFIRMAR"><button class="btn btn-sm btn-warning">Aplicar</button></form></td></tr>
<tr><td>Tempo ilimitado</td><td>1G RAM, 10G upload, max_execution_time=0</td><td><form method="post"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="php_profile_unlimited_time"><input type="hidden" name="confirm" value="CONFIRMAR"><button class="btn btn-sm btn-danger">Aplicar</button></form></td></tr>
</tbody></table></div></div></div></div>
<div class="col-lg-4"><div class="card border-danger"><div class="card-body"><h4 class="header-title text-danger">Ações críticas</h4><p>Estas ações podem causar indisponibilidade temporária.</p>
<form method="post" class="mb-3"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="disk_cleanup"><input class="form-control mb-2" name="confirm" placeholder="Digite CONFIRMAR" autocomplete="off"><button class="btn btn-warning btn-block">Limpeza avançada de disco</button></form>
<form method="post"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" value="restart_vps"><input class="form-control mb-2" name="confirm" placeholder="Digite CONFIRMAR" autocomplete="off"><button class="btn btn-danger btn-block">Reiniciar a VPS</button></form>
</div></div></div></div>
</div></div>
<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-md-12 copyright text-center"><?=getFooter()?></div></div></div></footer>
<script src="assets/js/vendor.min.js"></script><script src="assets/js/app.min.js"></script></body></html>

<?php
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
cs_admin_only('os logs e diagnósticos do sistema');
if ((!hasPermissions('adv', 'settings')) && (!hasPermissions('adv', 'database'))) { http_response_code(403); exit; }

function cs_logs_h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function cs_logs_redact(string $text): string {
    $text = preg_replace('~(://[^:/\s]+:)[^@/\s]+@~', '$1[REDACTED]@', $text);
    return (string)preg_replace('~([?&](?:username|password|user|pass|token|api_key)=)[^&\s]+~i', '$1[REDACTED]', $text);
}
function cs_logs_tail(string $path, int $maxBytes = 262144, int $maxLines = 300): array {
    if (!is_file($path) || !is_readable($path)) return ['ok'=>false, 'text'=>'Arquivo ausente ou sem permissão de leitura.'];
    $size = @filesize($path);
    $fh = @fopen($path, 'rb');
    if (!$fh) return ['ok'=>false, 'text'=>'Não foi possível abrir o arquivo.'];
    $start = max(0, (int)$size - $maxBytes);
    if ($start > 0) @fseek($fh, $start);
    $data = (string)stream_get_contents($fh);
    fclose($fh);
    if ($start > 0) { $newline = strpos($data, "\n"); if ($newline !== false) $data = substr($data, $newline + 1); }
    $lines = preg_split('/\r\n|\r|\n/', $data) ?: [];
    $lines = array_slice($lines, -$maxLines);
    return ['ok'=>true, 'text'=>cs_logs_redact(implode("\n", $lines)), 'truncated'=>$start > 0];
}
function cs_logs_sources(): array {
    $sources = [
        'php' => ['label'=>'PHP / PHP-FPM', 'paths'=>[]],
        'nginx' => ['label'=>'Nginx', 'paths'=>['/var/log/nginx/error.log']],
        'system' => ['label'=>'Sistema', 'paths'=>['/var/log/syslog', '/var/log/messages']],
        'auth' => ['label'=>'SSH / Autenticação', 'paths'=>['/var/log/auth.log', '/var/log/secure']],
        'panel' => ['label'=>'CS Player / auditoria', 'paths'=>[__DIR__.'/logs/cs-player', __DIR__.'/logs']],
        'm3u' => ['label'=>'Importador M3U', 'paths'=>[__DIR__.'/storage/import_jobs']],
    ];
    $errorLog = (string)ini_get('error_log');
    if ($errorLog !== '' && $errorLog[0] === '/') $sources['php']['paths'][] = $errorLog;
    foreach (glob('/var/log/php*-fpm.log') ?: [] as $path) $sources['php']['paths'][] = $path;
    foreach (glob('/var/log/php/*fpm*.log') ?: [] as $path) $sources['php']['paths'][] = $path;
    return $sources;
}
function cs_logs_files(array $paths): array {
    $files = [];
    foreach ($paths as $path) {
        if (is_file($path)) $files[] = $path;
        elseif (is_dir($path)) {
            foreach (glob(rtrim($path, '/').'/*') ?: [] as $child) if (is_file($child)) $files[] = $child;
        }
    }
    $files = array_values(array_unique($files));
    usort($files, static fn($a, $b) => ((int)@filemtime($b)) <=> ((int)@filemtime($a)));
    return $files;
}

$sources = cs_logs_sources();
$selected = (string)($_GET['source'] ?? 'all');
if ($selected !== 'all' && !isset($sources[$selected])) $selected = 'all';
$sections = [];
foreach ($sources as $key=>$source) {
    if ($selected !== 'all' && $selected !== $key) continue;
    foreach (cs_logs_files($source['paths']) as $path) {
        $tail = cs_logs_tail($path);
        $sections[] = ['key'=>$key, 'label'=>$source['label'], 'path'=>$path, 'tail'=>$tail];
    }
}
$m3uJobs = count(cs_logs_files([__DIR__.'/storage/import_jobs']));
$generatedAt = date('Y-m-d H:i:s');
include $rSettings['sidebar'] ? 'header_sidebar.php' : 'header.php';
?>
<div class="wrapper"><div class="container-fluid">
<div class="row"><div class="col-12"><div class="page-title-box"><h4 class="page-title"><i class="mdi mdi-file-search"></i> Logs e erros do sistema</h4></div></div></div>
<div class="alert alert-info"><strong>Diagnóstico seguro:</strong> esta tela lê somente fontes predefinidas, mostra no máximo os últimos 300 registros por arquivo e mascara credenciais encontradas em URLs. Ela não apaga nem altera logs.</div>
<div class="card"><div class="card-body"><form method="get" class="form-inline">
<label for="source" class="mr-2">Fonte:</label><select name="source" id="source" class="form-control mr-2"><option value="all">Todas as fontes</option><?php foreach($sources as $key=>$source): ?><option value="<?=cs_logs_h($key)?>" <?=$selected===$key?'selected':''?>><?=cs_logs_h($source['label'])?></option><?php endforeach; ?></select>
<button class="btn btn-primary mr-2"><i class="mdi mdi-refresh"></i> Atualizar</button><span class="text-muted">Atualizado em <?=cs_logs_h($generatedAt)?> · Jobs M3U encontrados: <?=intval($m3uJobs)?></span>
</form></div></div>
<?php if (!$sections): ?><div class="alert alert-warning">Nenhum arquivo de log acessível foi encontrado para esta seleção. Confira permissões do PHP-FPM e os caminhos configurados no Ubuntu.</div><?php endif; ?>
<?php foreach($sections as $section): ?><div class="card"><div class="card-body"><div class="d-flex justify-content-between align-items-center flex-wrap"><h5 class="header-title mb-2"><i class="mdi mdi-file-document-outline"></i> <?=cs_logs_h($section['label'])?></h5><code><?=cs_logs_h($section['path'])?></code></div>
<?php if (!$section['tail']['ok']): ?><div class="alert alert-warning mb-0"><?=cs_logs_h($section['tail']['text'])?></div><?php else: ?><pre style="white-space:pre-wrap;max-height:420px;overflow:auto;background:#10151d;color:#d7e1ee;padding:14px;border-radius:6px;" tabindex="0"><?=cs_logs_h($section['tail']['text'])?></pre><?php if (!empty($section['tail']['truncated'])): ?><small class="text-muted">Exibição limitada aos últimos 256 KB e 300 linhas.</small><?php endif; ?><?php endif; ?></div></div><?php endforeach; ?>
</div></div>
<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-md-12 copyright text-center"><?=getFooter()?></div></div></div></footer>
<script src="assets/js/vendor.min.js"></script><script src="assets/js/app.min.js"></script></body></html>

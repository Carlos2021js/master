<?php
/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  IDENTIDADE VISUAL – Branding Ultra Pro                                ║
 * ║  CS Player / Xtream Codes — Compatível PHP 7.4–8.4                     ║
 * ║  Substitui imagens do projeto em /admin/assets/images e /icons         ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
cs_admin_only('a identidade visual, imagens e vídeos');
if ((!hasPermissions('adv', 'settings')) && (!hasPermissions('adv', 'database'))) exit;
require_once __DIR__ . '/branding_helper.php';
require_once __DIR__ . '/cs_audit.php';

$baseDir = __DIR__ . '/assets/uploads/branding';
$backupDir = $baseDir . '/backups';
$configFile = $baseDir . '/branding.json';
@mkdir($backupDir, 0755, true);
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
// MELHORIA: renovar token CSRF após cada POST para maior segurança
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['cs_branding_csrf'] = bin2hex(random_bytes(24));
}
if (empty($_SESSION['cs_branding_csrf'])) $_SESSION['cs_branding_csrf'] = bin2hex(random_bytes(24));
$csrf = $_SESSION['cs_branding_csrf'];
$message = ''; $messageType = 'success';

// Slots organizados por grupo
$slots = [
    'logo' => [
        'logo_main'    => ['label'=>'Logo principal', 'fallback'=>($rSettings['logo_url'] ?? 'assets/images/logo.png'), 'accept'=>'.png,.jpg,.jpeg,.webp'],
        'logo_compact' => ['label'=>'Logo compacto (sidebar)', 'fallback'=>($rSettings['logo_url_sidebar'] ?? 'assets/images/logo-back.png'), 'accept'=>'.png,.jpg,.jpeg,.webp'],
        'favicon'      => ['label'=>'Favicon', 'fallback'=>'assets/images/favicon.ico', 'accept'=>'.png,.jpg,.jpeg,.webp,.ico'],
    ],
    'login' => [
        'login_background' => ['label'=>'Fundo do Login', 'fallback'=>'assets/images/bg1.png', 'accept'=>'.png,.jpg,.jpeg,.webp', 'type'=>'image'],
        'login_video'      => ['label'=>'Vídeo do Login', 'fallback'=>'', 'accept'=>'.mp4', 'type'=>'video'],
    ],
    'dashboard' => [
        'dashboard_background' => ['label'=>'Fundo do Dashboard', 'fallback'=>'', 'accept'=>'.png,.jpg,.jpeg,.webp', 'type'=>'image'],
        'dashboard_video'      => ['label'=>'Vídeo do Dashboard', 'fallback'=>'', 'accept'=>'.mp4', 'type'=>'video'],
    ],
    'avatar' => [
        'admin_avatar' => ['label'=>'Avatar do Administrador', 'fallback'=>'', 'accept'=>'.png,.jpg,.jpeg,.webp'],
    ]
];

function cs_branding_load_config($file) {
    if (!is_file($file)) return [];
    $data = json_decode((string)@file_get_contents($file), true);
    return is_array($data) ? $data : [];
}
function cs_branding_save_config($file, array $data) {
    $tmp = $file . '.tmp';
    $json = json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    @chmod($tmp, 0644);
    return @rename($tmp, $file);
}
function cs_validate_upload($file, $allowIco = false, $allowVideo = false) {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) return [false, 'Falha no envio. Verifique também upload_max_filesize, post_max_size e client_max_body_size.'];
    $limit = $allowVideo ? 300 * 1024 * 1024 : 15 * 1024 * 1024;
    if ($file['size'] < 1 || $file['size'] > $limit) return [false, $allowVideo ? 'O vídeo deve ter no máximo 300 MB.' : 'A imagem deve ter no máximo 15 MB.'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($allowVideo) {
        if ($ext !== 'mp4') return [false, 'Envie um vídeo MP4.'];
        $finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : false;
        $mime = $finfo ? finfo_file($finfo, $file['tmp_name']) : '';
        if ($finfo) finfo_close($finfo);
        if ($mime && !in_array($mime, ['video/mp4','application/mp4','application/octet-stream'], true)) return [false, 'O arquivo não foi reconhecido como MP4 válido.'];
        return [true, 'mp4'];
    }
    $allowed = $allowIco ? ['png','jpg','jpeg','webp','ico'] : ['png','jpg','jpeg','webp'];
    if (!in_array($ext, $allowed, true)) return [false, 'Formato não permitido.'];
    if ($ext === 'ico') {
        // MELHORIA: validação de MIME type específico para ICO
        $finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : false;
        $mime = $finfo ? finfo_file($finfo, $file['tmp_name']) : '';
        if ($finfo) finfo_close($finfo);
        $allowedIcoMime = ['image/x-icon', 'image/vnd.microsoft.icon', 'image/ico', 'application/octet-stream'];
        if ($mime && !in_array($mime, $allowedIcoMime, true)) return [false, 'O arquivo ICO não é válido.'];
    } else {
        $info = @getimagesize($file['tmp_name']);
        if (!$info || !in_array($info[2], [IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_WEBP], true)) return [false, 'O arquivo não é uma imagem válida.'];
        if ($info[0] > 12000 || $info[1] > 12000) return [false, 'Dimensões máximas: 12000 × 12000 px.'];
    }
    return [true, $ext === 'jpeg' ? 'jpg' : $ext];
}

// MELHORIA: função para redimensionar logos mantendo proporção (máximo 512px)
function cs_resize_image_logo($source, $destination, $maxDim = 512) {
    $info = @getimagesize($source);
    if (!$info) return false;
    $width = $info[0];
    $height = $info[1];
    if ($width <= $maxDim && $height <= $maxDim) return false; // não precisa redimensionar

    $ratio = min($maxDim / $width, $maxDim / $height);
    $newWidth = round($width * $ratio);
    $newHeight = round($height * $ratio);

    $imageType = $info[2];
    switch ($imageType) {
        case IMAGETYPE_PNG:
            $src = imagecreatefrompng($source);
            break;
        case IMAGETYPE_JPEG:
            $src = imagecreatefromjpeg($source);
            break;
        case IMAGETYPE_WEBP:
            $src = imagecreatefromwebp($source);
            break;
        default:
            return false;
    }
    if (!$src) return false;

    $dst = imagecreatetruecolor($newWidth, $newHeight);
    if ($imageType == IMAGETYPE_PNG) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
        imagefilledrectangle($dst, 0, 0, $newWidth, $newHeight, $transparent);
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

    $ext = pathinfo($destination, PATHINFO_EXTENSION);
    switch ($ext) {
        case 'png': imagepng($dst, $destination); break;
        case 'jpg':
        case 'jpeg': imagejpeg($dst, $destination, 90); break;
        case 'webp': imagewebp($dst, $destination, 90); break;
    }
    imagedestroy($src);
    imagedestroy($dst);
    return true;
}

// Processamento de formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) { $message='Sessão expirada. Recarregue a página.'; $messageType='danger'; }
    else {
        $config = cs_branding_load_config($configFile);
        $action = $_POST['action'] ?? '';
        $allSlotsFlat = array_merge(...array_values($slots));

        if ($action === 'upload_slot') {
            $slot = (string)($_POST['slot'] ?? '');
            if (!isset($allSlotsFlat[$slot])) { $message='Tipo de imagem inválido.'; $messageType='danger'; }
            else {
                $slotInfo = $allSlotsFlat[$slot];
                $isVideo = ($slotInfo['type'] ?? '') === 'video';
                $allowIco = ($slot === 'favicon');
                [$ok,$result] = cs_validate_upload($_FILES['image'] ?? [], $allowIco, $isVideo);
                if (!$ok) { $message=$result; $messageType='danger'; }
                else {
                    $name = $slot . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $result;
                    $target = $baseDir . '/' . $name;
                    if (@move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                        @chmod($target, 0644);
                        // MELHORIA: redimensionar logos automaticamente para no máximo 512px
                        if (in_array($slot, ['logo_main', 'logo_compact', 'favicon']) && !$isVideo) {
                            cs_resize_image_logo($target, $target, $slot === 'favicon' ? 256 : 512);
                        }
                        if (!empty($config[$slot]) && is_file(__DIR__ . '/' . $config[$slot])) {
                            @copy(__DIR__ . '/' . $config[$slot], $backupDir . '/' . basename($config[$slot]));
                        }
                        $config[$slot] = 'assets/uploads/branding/' . $name;
                        if (cs_branding_save_config($configFile, $config)) {
                            $message = ($isVideo ? 'Vídeo' : 'Imagem') . ' atualizado(a) com sucesso!';
                            cs_audit_log('branding.upload', ['slot'=>$slot,'file'=>$name,'size'=>(int)($_FILES['image']['size'] ?? 0)]);
                        } else { @unlink($target); $message='Não foi possível salvar a configuração.'; $messageType='danger'; }
                    } else { $message='A pasta de branding não possui permissão de escrita.'; $messageType='danger'; }
                }
            }
        } elseif ($action === 'save_media_settings') {
            foreach (['login','dashboard'] as $ctx) {
                foreach (['muted','loop','autoplay','controls'] as $flag) $config[$ctx.'_'.$flag] = !empty($_POST[$ctx.'_'.$flag]);
                $config[$ctx.'_overlay'] = max(0, min(100, (int)($_POST[$ctx.'_overlay'] ?? 35)));
            }
            if (cs_branding_save_config($configFile, $config)) { $message='Preferências de vídeo e fundo atualizadas.'; cs_audit_log('branding.settings_update'); }
            else { $message='Não foi possível salvar as preferências.'; $messageType='danger'; }
        } elseif ($action === 'restore_slot') {
            $slot = (string)($_POST['slot'] ?? '');
            if (isset($allSlotsFlat[$slot])) {
                if (!empty($config[$slot])) @unlink(__DIR__ . '/' . $config[$slot]);
                unset($config[$slot]);
                cs_branding_save_config($configFile, $config);
                $message='Imagem restaurada para o padrão.'; cs_audit_log('branding.restore', ['slot'=>$slot]);
            }
        } elseif ($action === 'replace_project_image') {
            $relative = str_replace('\\','/', (string)($_POST['project_image'] ?? ''));
            $allowedBases = array_filter([realpath(__DIR__ . '/assets/images'), realpath(__DIR__ . '/icons')]);
            $target = realpath(__DIR__ . '/' . $relative);
            $inside = false;
            foreach ($allowedBases as $realBase) {
                if ($target && ($target === $realBase || strpos($target, $realBase . DIRECTORY_SEPARATOR) === 0)) { $inside = true; break; }
            }
            if (!$inside || !is_file($target)) { $message='Imagem do projeto inválida.'; $messageType='danger'; }
            else {
                $allowIco = strtolower(pathinfo($target, PATHINFO_EXTENSION)) === 'ico';
                [$ok,$ext] = cs_validate_upload($_FILES['image'] ?? [], $allowIco);
                if (!$ok) { $message=$ext; $messageType='danger'; }
                else {
                    $targetExt = strtolower(pathinfo($target, PATHINFO_EXTENSION));
                    if (($targetExt === 'ico') !== ($ext === 'ico')) { $message='Para favicon ICO, envie outro arquivo ICO.'; $messageType='danger'; }
                    else {
                        $backup = $backupDir . '/project-' . date('Ymd-His') . '-' . basename($target);
                        @copy($target, $backup);
                        if (@move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                            @chmod($target, 0644);
                            // MELHORIA: invalidar cache de imagens do projeto
                            @unlink($baseDir . '/project_images.cache');
                            $message='Imagem do projeto substituída com sucesso! Backup criado em ' . basename($backup);
                            cs_audit_log('branding.project_replace', ['file'=>$relative]);
                        } else {
                            @copy($backup, $target);
                            $message='Erro ao substituir a imagem. Verifique as permissões de escrita.'; $messageType='danger';
                        }
                    }
                }
            }
        // MELHORIA: ação de restaurar backup de imagem do projeto
        } elseif ($action === 'restore_project_backup') {
            $backupFile = basename((string)($_POST['backup_file'] ?? ''));
            $backupPath = $backupDir . '/' . $backupFile;
            if (!is_file($backupPath) || strpos($backupFile, 'project-') !== 0) {
                $message='Arquivo de backup inválido.'; $messageType='danger';
            } else {
                // Extrair caminho original do nome do backup: project-YYYYMMDD-HHMMSS-nomeoriginal.ext
                $parts = explode('-', $backupFile, 4);
                if (count($parts) < 4) { $message='Formato de backup não reconhecido.'; $messageType='danger'; }
                else {
                    $origName = $parts[3];
                    // Encontrar o arquivo original correspondente
                    $found = false;
                    foreach ($allowedBases as $realBase) {
                        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($realBase, FilesystemIterator::SKIP_DOTS));
                        foreach ($it as $img) {
                            if ($img->getFilename() === $origName) {
                                $origPath = $img->getPathname();
                                // Fazer backup do atual antes de restaurar
                                $safetyBackup = $backupDir . '/pre-restore-' . date('Ymd-His') . '-' . $origName;
                                @copy($origPath, $safetyBackup);
                                if (@copy($backupPath, $origPath)) {
                                    @unlink($baseDir . '/project_images.cache');
                                    $message='Backup restaurado com sucesso! O arquivo anterior foi salvo como ' . basename($safetyBackup);
                                    cs_audit_log('branding.restore_project_backup', ['file'=>$origName, 'backup'=>$backupFile]);
                                    $found = true;
                                    break 2;
                                } else {
                                    $message='Erro ao restaurar o backup. Verifique permissões.'; $messageType='danger';
                                    $found = true;
                                    break 2;
                                }
                            }
                        }
                    }
                    if (!$found) $message='Arquivo original não encontrado para este backup.'; $messageType='danger';
                }
            }
        }
    }
}

$config = cs_branding_load_config($configFile);
$allSlotsFlat = array_merge(...array_values($slots));

// MELHORIA: cache da lista de imagens do projeto para performance
$cacheFile = $baseDir . '/project_images.cache';
$projectImages = null;
if (is_file($cacheFile) && (time() - filemtime($cacheFile) < 3600)) {
    $projectImages = json_decode((string)@file_get_contents($cacheFile), true);
}
if (!is_array($projectImages)) {
    $projectImages = [];
    $scanRoots = [__DIR__ . '/assets/images', __DIR__ . '/icons'];
    foreach ($scanRoots as $scanRoot) if (is_dir($scanRoot)) {
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($scanRoot, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $img) if ($img->isFile() && preg_match('/\.(png|jpe?g|webp|gif|ico)$/i', $img->getFilename())) {
            $projectImages[] = str_replace('\\','/', substr($img->getPathname(), strlen(__DIR__) + 1));
        }
    }
    sort($projectImages);
    @file_put_contents($cacheFile, json_encode($projectImages), LOCK_EX);
}

// MELHORIA: listar backups disponíveis para cada imagem do projeto
$backups = [];
foreach (glob($backupDir . '/project-*') as $bkp) {
    $bkpName = basename($bkp);
    // Extrair nome original: project-YYYYMMDD-HHMMSS-nome.ext
    if (preg_match('/^project-\d{8}-\d{6}-(.+)$/', $bkpName, $m)) {
        $backups[$m[1]][] = ['name' => $bkpName, 'time' => filemtime($bkp), 'size' => filesize($bkp)];
    }
}
// Ordenar cada lista por data decrescente
foreach ($backups as &$list) {
    usort($list, function($a, $b) { return $b['time'] - $a['time']; });
}
unset($list);

include $rSettings['sidebar'] ? 'header_sidebar.php' : 'header.php';
?>

<style>
.branding-section { margin-bottom: 2.5rem; }
.preview-box {
    height: 180px; background-size: cover; background-position: center;
    border-radius: 8px; border: 1px solid #dee2e6; position: relative;
    overflow: hidden; display: flex; align-items: center; justify-content: center;
    background-color: #f8f9fa;
}
.preview-box.video-preview { background: #000; }
.preview-box .placeholder { color: #adb5bd; font-size: 3rem; }
.drag-area {
    border: 2px dashed #ced4da; border-radius: 8px; padding: 20px; text-align: center;
    transition: all 0.3s; cursor: pointer; background: #f8f9fa; position: relative;
}
.drag-area:hover, .drag-area.dragover { border-color: #4fc6e1; background: #e8f4f8; }
.drag-area input[type="file"] { position: absolute; inset: 0; opacity: 0; cursor: pointer; }
.drag-area .icon { font-size: 2.5rem; color: #adb5bd; margin-bottom: 10px; }
.slot-actions { margin-top: 10px; }
/* MELHORIA: estilos para botão de carregamento */
.btn-loading { pointer-events: none; opacity: 0.8; }
.btn-loading i { animation: spin 1s linear infinite; }
@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
</style>

<div class="<?= $rSettings['sidebar'] ? 'content-page' : 'wrapper' ?> boxed-layout-ext">
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title"><i class="mdi mdi-image-multiple"></i> Identidade Visual</h4>
                <p class="text-muted mb-0">Personalize logos, fundos, vídeos e substitua arquivos do projeto diretamente.</p>
            </div>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?=$messageType?> alert-dismissible fade show"><?=htmlspecialchars($message)?><button type="button" class="close" data-dismiss="alert" aria-label="Fechar">&times;</button></div>
    <?php endif; ?>

    <!-- Seção: Logo & Favicon -->
    <div class="branding-section">
        <h4 class="header-title mb-3"><i class="mdi mdi-image-filter-frames"></i> Logo & Favicon</h4>
        <div class="row">
            <?php foreach ($slots['logo'] as $key => $slot): $current = !empty($config[$key]) ? $config[$key] : $slot['fallback']; ?>
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?=htmlspecialchars($slot['label'])?></h5>
                        <div class="preview-box" id="preview-<?=$key?>" style="background-image: url('<?=htmlspecialchars($current)?>?v=<?=time()?>'); background-size: contain; background-repeat: no-repeat;">
                            <?php if (!$current): ?><i class="mdi mdi-image-outline placeholder"></i><?php endif; ?>
                        </div>
                        <form method="post" enctype="multipart/form-data" onsubmit="showLoading(this)">
                            <input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>">
                            <input type="hidden" name="action" value="upload_slot">
                            <input type="hidden" name="slot" value="<?=htmlspecialchars($key)?>">
                            <div class="drag-area mt-2" id="drag-<?=$key?>" aria-label="Área de upload para <?=htmlspecialchars($slot['label'])?>" title="Arraste uma imagem ou clique para selecionar">
                                <i class="mdi mdi-cloud-upload-outline icon"></i>
                                <p class="mb-0">Arraste ou clique para selecionar</p>
                                <small class="text-muted"><?=htmlspecialchars($slot['accept'])?></small>
                                <input type="file" name="image" accept="<?=htmlspecialchars($slot['accept'])?>" onchange="previewFile(this, 'preview-<?=$key?>', '<?=$key?>')">
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm mt-2"><i class="mdi mdi-upload"></i> Enviar</button>
                        </form>
                        <div class="slot-actions">
                            <?php if (!empty($config[$key])): ?>
                            <form method="post" class="d-inline" onsubmit="showLoading(this)"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="restore_slot"><input type="hidden" name="slot" value="<?=htmlspecialchars($key)?>"><button class="btn btn-outline-secondary btn-sm" onclick="return confirm('Restaurar padrão?')"><i class="mdi mdi-backup-restore"></i> Restaurar</button></form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Seção: Tela de Login -->
    <div class="branding-section">
        <h4 class="header-title mb-3"><i class="mdi mdi-login-variant"></i> Tela de Login</h4>
        <div class="row">
            <?php foreach ($slots['login'] as $key => $slot): $current = !empty($config[$key]) ? $config[$key] : $slot['fallback']; ?>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?=htmlspecialchars($slot['label'])?></h5>
                        <div class="preview-box <?=$slot['type']==='video'?'video-preview':''?>" id="preview-<?=$key?>">
                            <?php if ($slot['type']==='video' && $current): ?>
                                <video src="<?=htmlspecialchars($current)?>" muted loop autoplay playsinline style="width:100%;height:100%;object-fit:cover;"></video>
                            <?php elseif ($current): ?>
                                <div style="background-image:url('<?=htmlspecialchars($current)?>?v=<?=time()?>');width:100%;height:100%;background-size:cover;background-position:center;"></div>
                            <?php else: ?>
                                <i class="mdi mdi-<?=$slot['type']==='video'?'video-outline':'image-outline'?> placeholder"></i>
                            <?php endif; ?>
                        </div>
                        <form method="post" enctype="multipart/form-data" onsubmit="showLoading(this)">
                            <input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>">
                            <input type="hidden" name="action" value="upload_slot">
                            <input type="hidden" name="slot" value="<?=htmlspecialchars($key)?>">
                            <div class="drag-area mt-2" id="drag-<?=$key?>" aria-label="Área de upload para <?=htmlspecialchars($slot['label'])?>" title="Arraste um arquivo ou clique para selecionar">
                                <i class="mdi mdi-cloud-upload-outline icon"></i>
                                <p class="mb-0">Arraste ou clique para selecionar <?=$slot['type']==='video'?'o vídeo':'a imagem'?></p>
                                <small class="text-muted"><?=htmlspecialchars($slot['accept'])?></small>
                                <input type="file" name="image" accept="<?=htmlspecialchars($slot['accept'])?>" onchange="previewFile(this, 'preview-<?=$key?>', '<?=$key?>')">
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm mt-2"><i class="mdi mdi-upload"></i> Enviar</button>
                        </form>
                        <div class="slot-actions">
                            <?php if (!empty($config[$key])): ?>
                            <form method="post" class="d-inline" onsubmit="showLoading(this)"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="restore_slot"><input type="hidden" name="slot" value="<?=htmlspecialchars($key)?>"><button class="btn btn-outline-secondary btn-sm" onclick="return confirm('Restaurar padrão?')"><i class="mdi mdi-backup-restore"></i> Restaurar</button></form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Seção: Dashboard -->
    <div class="branding-section">
        <h4 class="header-title mb-3"><i class="mdi mdi-view-dashboard"></i> Dashboard</h4>
        <div class="row">
            <?php foreach ($slots['dashboard'] as $key => $slot): $current = !empty($config[$key]) ? $config[$key] : $slot['fallback']; ?>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?=htmlspecialchars($slot['label'])?></h5>
                        <div class="preview-box <?=$slot['type']==='video'?'video-preview':''?>" id="preview-<?=$key?>">
                            <?php if ($slot['type']==='video' && $current): ?>
                                <video src="<?=htmlspecialchars($current)?>" muted loop autoplay playsinline style="width:100%;height:100%;object-fit:cover;"></video>
                            <?php elseif ($current): ?>
                                <div style="background-image:url('<?=htmlspecialchars($current)?>?v=<?=time()?>');width:100%;height:100%;background-size:cover;background-position:center;"></div>
                            <?php else: ?>
                                <i class="mdi mdi-<?=$slot['type']==='video'?'video-outline':'image-outline'?> placeholder"></i>
                            <?php endif; ?>
                        </div>
                        <form method="post" enctype="multipart/form-data" onsubmit="showLoading(this)">
                            <input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>">
                            <input type="hidden" name="action" value="upload_slot">
                            <input type="hidden" name="slot" value="<?=htmlspecialchars($key)?>">
                            <div class="drag-area mt-2" id="drag-<?=$key?>" aria-label="Área de upload para <?=htmlspecialchars($slot['label'])?>" title="Arraste um arquivo ou clique para selecionar">
                                <i class="mdi mdi-cloud-upload-outline icon"></i>
                                <p class="mb-0">Arraste ou clique para selecionar <?=$slot['type']==='video'?'o vídeo':'a imagem'?></p>
                                <small class="text-muted"><?=htmlspecialchars($slot['accept'])?></small>
                                <input type="file" name="image" accept="<?=htmlspecialchars($slot['accept'])?>" onchange="previewFile(this, 'preview-<?=$key?>', '<?=$key?>')">
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm mt-2"><i class="mdi mdi-upload"></i> Enviar</button>
                        </form>
                        <div class="slot-actions">
                            <?php if (!empty($config[$key])): ?>
                            <form method="post" class="d-inline" onsubmit="showLoading(this)"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="restore_slot"><input type="hidden" name="slot" value="<?=htmlspecialchars($key)?>"><button class="btn btn-outline-secondary btn-sm" onclick="return confirm('Restaurar padrão?')"><i class="mdi mdi-backup-restore"></i> Restaurar</button></form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Avatar do Admin -->
    <div class="branding-section">
        <h4 class="header-title mb-3"><i class="mdi mdi-account-circle"></i> Avatar do Administrador</h4>
        <div class="row">
            <?php $slot = $slots['avatar']['admin_avatar']; $current = !empty($config['admin_avatar']) ? $config['admin_avatar'] : $slot['fallback']; ?>
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?=htmlspecialchars($slot['label'])?></h5>
                        <div class="preview-box" id="preview-admin_avatar" style="background-image: url('<?=htmlspecialchars($current)?>?v=<?=time()?>'); background-size: contain; background-repeat: no-repeat;">
                            <?php if (!$current): ?><i class="mdi mdi-account-circle placeholder"></i><?php endif; ?>
                        </div>
                        <form method="post" enctype="multipart/form-data" onsubmit="showLoading(this)">
                            <input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>">
                            <input type="hidden" name="action" value="upload_slot">
                            <input type="hidden" name="slot" value="admin_avatar">
                            <div class="drag-area mt-2" id="drag-admin_avatar" aria-label="Área de upload para avatar do administrador" title="Arraste uma imagem ou clique para selecionar">
                                <i class="mdi mdi-cloud-upload-outline icon"></i>
                                <p class="mb-0">Arraste ou clique para selecionar</p>
                                <small class="text-muted"><?=htmlspecialchars($slot['accept'])?></small>
                                <input type="file" name="image" accept="<?=htmlspecialchars($slot['accept'])?>" onchange="previewFile(this, 'preview-admin_avatar', 'admin_avatar')">
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm mt-2"><i class="mdi mdi-upload"></i> Enviar</button>
                        </form>
                        <?php if (!empty($config['admin_avatar'])): ?>
                        <div class="slot-actions">
                            <form method="post" class="d-inline" onsubmit="showLoading(this)"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="restore_slot"><input type="hidden" name="slot" value="admin_avatar"><button class="btn btn-outline-secondary btn-sm" onclick="return confirm('Restaurar padrão?')"><i class="mdi mdi-backup-restore"></i> Restaurar</button></form>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Preferências de Vídeo -->
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="header-title"><i class="mdi mdi-cogs"></i> Comportamento dos vídeos</h4>
            <p class="text-muted">Navegadores podem bloquear áudio automático. Configure opções de reprodução.</p>
            <form method="post" onsubmit="showLoading(this)">
                <input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>">
                <input type="hidden" name="action" value="save_media_settings">
                <div class="row">
                    <?php foreach(['login'=>'Login','dashboard'=>'Dashboard'] as $ctx=>$title): ?>
                    <div class="col-lg-6">
                        <div class="border rounded p-3 mb-3">
                            <h5><?=$title?></h5>
                            <?php foreach(['autoplay'=>'Reprodução automática','loop'=>'Repetir continuamente','muted'=>'Iniciar sem áudio','controls'=>'Mostrar controles'] as $flag=>$label): ?>
                            <div class="custom-control custom-switch mb-2">
                                <input type="checkbox" class="custom-control-input" id="<?=$ctx?>_<?=$flag?>" name="<?=$ctx?>_<?=$flag?>" <?=cs_branding_value($ctx.'_'.$flag, $flag!=='controls')?'checked':''?>>
                                <label class="custom-control-label" for="<?=$ctx?>_<?=$flag?>"><?=$label?></label>
                            </div>
                            <?php endforeach; ?>
                            <label class="mt-2">Escurecimento: <strong id="<?=$ctx?>OverlayValue"><?=(int)cs_branding_value($ctx.'_overlay',35)?>%</strong></label>
                            <input type="range" class="custom-range" min="0" max="90" name="<?=$ctx?>_overlay" value="<?=(int)cs_branding_value($ctx.'_overlay',35)?>" oninput="document.getElementById('<?=$ctx?>OverlayValue').textContent=this.value+'%'">
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="submit" class="btn btn-success"><i class="mdi mdi-content-save"></i> Salvar comportamento</button>
            </form>
        </div>
    </div>

    <!-- Biblioteca de Imagens do Projeto -->
    <div class="card">
        <div class="card-body">
            <h4 class="header-title"><i class="mdi mdi-folder-image"></i> Substituir imagens do projeto</h4>
            <p class="text-muted">Substitua qualquer imagem existente em <code>/admin/assets/images</code> ou <code>/icons</code>. O backup é criado automaticamente em <code>/admin/assets/uploads/branding/backups</code>.</p>
            <form method="post" enctype="multipart/form-data" class="row align-items-end" onsubmit="showLoading(this); return confirm('Tem certeza que deseja substituir esta imagem? Um backup será criado.')">
                <input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>">
                <input type="hidden" name="action" value="replace_project_image">
                <div class="col-md-5"><label for="project_image_select">Imagem existente</label><select name="project_image" id="project_image_select" class="form-control select2" required><?php foreach($projectImages as $img): ?><option value="<?=htmlspecialchars($img)?>"><?=htmlspecialchars($img)?></option><?php endforeach; ?></select></div>
                <div class="col-md-5"><label for="new_image_file">Nova imagem</label><input type="file" name="image" id="new_image_file" class="form-control" accept=".png,.jpg,.jpeg,.webp,.ico" required></div>
                <div class="col-md-2"><button type="submit" class="btn btn-warning btn-block"><i class="mdi mdi-image-edit"></i> Substituir</button></div>
            </form>

            <!-- MELHORIA: seção de backups do projeto -->
            <?php if (!empty($backups)): ?>
            <hr>
            <h5 class="mt-3"><i class="mdi mdi-history"></i> Backups disponíveis</h5>
            <p class="text-muted small">Clique em "Restaurar" para reverter uma imagem alterada. Um backup do arquivo atual será feito antes.</p>
            <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
                <table class="table table-sm table-hover">
                    <thead><tr><th>Imagem original</th><th>Backup</th><th>Data</th><th>Tamanho</th><th>Ação</th></tr></thead>
                    <tbody>
                    <?php foreach ($backups as $origName => $bkps): ?>
                        <?php foreach (array_slice($bkps, 0, 3) as $b): // mostra até 3 backups mais recentes ?>
                        <tr>
                            <td><code><?=htmlspecialchars($origName)?></code></td>
                            <td><code><?=htmlspecialchars($b['name'])?></code></td>
                            <td><?=date('d/m/Y H:i:s', $b['time'])?></td>
                            <td><?=round($b['size']/1024,1)?> KB</td>
                            <td>
                                <form method="post" onsubmit="showLoading(this); return confirm('Restaurar este backup? O arquivo atual será salvo como backup.')">
                                    <input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>">
                                    <input type="hidden" name="action" value="restore_project_backup">
                                    <input type="hidden" name="backup_file" value="<?=htmlspecialchars($b['name'])?>">
                                    <button class="btn btn-outline-info btn-sm"><i class="mdi mdi-backup-restore"></i> Restaurar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>

<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-md-12 copyright text-center"><?=getFooter()?></div></div></div></footer>

<script src="assets/js/vendor.min.js"></script>
<script src="assets/libs/select2/select2.min.js"></script>
<script src="assets/js/app.min.js"></script>
<script>
$(function(){
    $('.select2').select2({width:'100%'});

    // MELHORIA: função para exibir loading nos formulários
    window.showLoading = function(form) {
        var btn = $(form).find('button[type="submit"]');
        if (btn.length) {
            btn.addClass('btn-loading').prop('disabled', true);
            var icon = btn.find('i');
            if (icon.length) {
                icon.attr('class', icon.attr('class').replace(/mdi-[\w-]+/g, 'mdi mdi-loading'));
            } else {
                btn.prepend('<i class="mdi mdi-loading mr-1"></i> ');
            }
        }
    };

    // Preview imediato ao selecionar arquivo
    window.previewFile = function(input, previewId, slot) {
        const file = input.files[0];
        if (!file) return;
        const preview = document.getElementById(previewId);
        const url = URL.createObjectURL(file);
        if (file.type.startsWith('video/')) {
            preview.innerHTML = `<video src="${url}" muted loop autoplay playsinline style="width:100%;height:100%;object-fit:cover;"></video>`;
        } else {
            preview.innerHTML = '';
            preview.style.backgroundImage = `url(${url})`;
            preview.style.backgroundSize = 'contain';
            preview.style.backgroundRepeat = 'no-repeat';
            preview.style.backgroundPosition = 'center';
        }
    };

    // Drag and drop nas áreas
    $('.drag-area').on('dragover dragenter', function(e){ e.preventDefault(); $(this).addClass('dragover'); })
    .on('dragleave dragend drop', function(e){ e.preventDefault(); $(this).removeClass('dragover'); })
    .on('drop', function(e){
        const files = e.originalEvent.dataTransfer.files;
        const input = $(this).find('input[type=file]')[0];
        if (files.length) {
            input.files = files;
            const slot = $(this).attr('id').replace('drag-','');
            const previewId = 'preview-' + slot;
            previewFile(input, previewId, slot);
        }
    });
});
</script>
</body>
</html>
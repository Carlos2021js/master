<?php
include 'session.php'; include 'functions.php'; include 'notification_system.php';
cs_notify_generate_smart_alerts();
if (isset($_GET['read'])) cs_notify_mark_read(intval($_GET['read']));
if (isset($_GET['read_all'])) cs_notify_mark_read(0);
$items=cs_notify_list(100);
if ($rSettings['sidebar']) include 'header_sidebar.php'; else include 'header.php';
?>
<?php if ($rSettings['sidebar']) { ?><div class="content-page"><div class="content"><div class="container-fluid"><?php } else { ?><div class="wrapper"><div class="container-fluid"><?php } ?>
<div class="row cs-notification-page"><div class="col-12">
<div class="page-title-box"><div class="page-title-right"><a href="notifications.php?read_all=1" class="btn btn-outline-primary btn-sm"><i class="mdi mdi-check-all"></i> Marcar todas como lidas</a><?php if($rPermissions['is_admin']){ ?> <a href="notification_compose.php" class="btn btn-primary btn-sm"><i class="mdi mdi-send"></i> Nova mensagem push</a><?php } ?></div><h4 class="page-title"><i class="mdi mdi-bell-ring-outline"></i> Central de mensagens</h4></div>
<div class="card"><div class="card-body p-0">
<?php if(!$items){ ?><div class="text-center p-5"><i class="mdi mdi-bell-sleep-outline display-4 text-muted"></i><h4 class="mt-3">Nenhuma mensagem</h4><p class="text-muted">As notificações inteligentes aparecerão aqui.</p></div><?php } ?>
<?php foreach($items as $n){ $url=$n['action_url'] ?: ('notifications.php?read='.intval($n['id'])); ?>
<a href="<?=htmlspecialchars($url)?>" data-notification-id="<?=intval($n['id'])?>" class="d-block text-reset p-3 border-bottom cs-message-item <?=(!$n['is_read']?'unread':'')?>">
<div class="d-flex align-items-start"><div class="avatar-sm mr-3"><span class="avatar-title rounded-circle bg-<?=($n['category']==='danger'?'danger':($n['category']==='success'?'success':($n['category']==='warning'||$n['category']==='expiry'?'warning':'info')))?>"><i class="mdi mdi-message-text-outline"></i></span></div><div class="flex-grow-1"><div class="d-flex justify-content-between"><h5 class="mb-1"><?=htmlspecialchars($n['title'])?></h5><small class="text-muted"><?=date('d/m/Y H:i',intval($n['created_at']))?></small></div><p class="mb-1 text-muted"><?=nl2br(htmlspecialchars($n['message']))?></p><small class="badge badge-light text-uppercase"><?=htmlspecialchars($n['category'])?></small></div></div></a>
<?php } ?>
</div></div></div></div>
</div></div><?php if ($rSettings['sidebar']) echo '</div>'; ?>
<?php include 'footer.php'; ?>
<script src="assets/js/app.min.js"></script>
</body>
</html>

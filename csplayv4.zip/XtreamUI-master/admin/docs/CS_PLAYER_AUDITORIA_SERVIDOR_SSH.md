# Auditoria CS Player — Servidor SSH

Data: 2026-08-01T22:40:01Z

## Escopo

- Arquivos totais: 894
- Arquivos PHP: 188
- PHP validado com: 8.4.16
- Erros de sintaxe: 0
- Referências funcionais à identidade antiga em PHP: 0

## Correções confirmadas

1. O verificador de atualização deixou de consultar repositórios antigos. Agora usa apenas um manifesto HTTPS opcional definido por `CS_PLAYER_UPDATE_MANIFEST_URL`; sem configuração, mantém a versão instalada e não faz consulta externa.
2. O helper do Servidor SSH detecta automaticamente PHP-FPM 8.2, 8.3 ou 8.4.
3. Alterações de perfil PHP agora criam backup, validam a nova configuração e restauram a anterior em caso de falha.
4. A limpeza avançada foi tornada conservadora: não executa mais `apt autoremove` pelo painel.
5. Foi adicionado bloqueio de concorrência com `flock`, evitando duas manutenções simultâneas.
6. Ações administrativas receberam intervalo mínimo para reduzir cliques duplicados e requisições repetidas.
7. A rota legada `vps_manager.php` foi preservada, mas redireciona para a implementação única `servidor_ssh.php`.
8. O helper continua usando lista fechada de ações e não armazena senha root.

## SQL

- Chamadas a `$db->query()` catalogadas: 803
- Candidatos com construção dinâmica detectados por análise estática: 514

A lista é um inventário para migração gradual. Nem todo candidato é vulnerável: muitos valores já passam por `intval()` ou `real_escape_string()`. Alterações automáticas em massa não foram feitas para evitar mudanças de comportamento.

## Comandos de sistema

- Ocorrências catalogadas: 62
- O módulo Servidor SSH usa `proc_open()` com array de argumentos, `bypass_shell` e helper com allowlist.
- Comandos legados do painel permanecem catalogados para revisão gradual, pois fazem parte do funcionamento existente.

## Compatibilidade

O código alterado evita recursos exclusivos do PHP 8.4 e é compatível com PHP 8.2/8.3. A validação de sintaxe foi executada no PHP disponível no ambiente.

## Arquivos de evidência

- `docs/auditoria_servidor_ssh/php_lint.txt`
- `docs/auditoria_servidor_ssh/sql_dynamic_candidates.txt`
- `docs/auditoria_servidor_ssh/system_commands.txt`
- `docs/auditoria_servidor_ssh/memory_candidates.txt`
- `docs/auditoria_servidor_ssh/world_writable.txt`

# CS Player — mídia visual administrável

O menu **Identidade visual** permite trocar logos, favicon, avatar, fundos e imagens do projeto, além de vídeos MP4 no login e Dashboard.

## Vídeos
- MP4 de até 300 MB.
- Autoplay, loop, mudo, controles e intensidade da sobreposição configuráveis.
- Áudio depende da política do navegador: autoplay com som geralmente exige interação do usuário.
- Imagem de fundo funciona como poster/fallback do vídeo.

## Servidor
Para uploads grandes, ajuste `client_max_body_size` no Nginx e `upload_max_filesize`/`post_max_size` no PHP-FPM usando os exemplos em `admin/server-config/`.

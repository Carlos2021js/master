# Diagnóstico real do importador M3U

## Correção de persistência

O importador agora valida cada consulta SQL e não considera uma importação concluída quando o banco não confirma as gravações. O arquivo temporário só é removido depois de uma conclusão confirmada.

## Arquivos de diagnóstico

- Status: `admin/storage/import_jobs/<job>.json`
- Histórico: `admin/storage/import_jobs/<job>.log`
- Playlist temporária: `admin/storage/m3u_uploads/<sessão>/<token>.m3u`

Não há alteração na estrutura do banco de dados.

## Permissões

Execute:

```bash
sudo bash admin/server-config/install_import_diagnostics.sh /var/www/html/admin
```

O usuário do PHP-FPM deve conseguir escrever em `admin/storage/m3u_uploads` e `admin/storage/import_jobs`.

## Comportamento em falhas

- Erro de um canal: registra o item e continua.
- Falha SQL de um item: registra arquivo, linha e exceção; tenta continuar quando a conexão permanece válida.
- Falha estrutural: executa rollback do lote atual, mantém a playlist e apresenta relatório.
- Erro fatal: o shutdown handler registra a ocorrência no diagnóstico.

# Identidade visual do CS Player

Acesse o menu do administrador e escolha **Identidade visual**.

## Recursos gerenciados

- Logo principal
- Logo compacto/lateral
- Favicon
- Fundo da tela de login
- Imagem do administrador
- Imagens existentes da pasta `admin/assets/images`

As personalizações principais são guardadas separadamente em `admin/assets/uploads/branding`, sem apagar os arquivos originais. A opção **Restaurar padrão** remove somente a substituição selecionada.

Na biblioteca avançada, o arquivo original é copiado para `admin/assets/uploads/branding/backups` antes da substituição.

## Permissões

O usuário do PHP-FPM precisa escrever em:

```bash
sudo chown -R www-data:www-data /home/xtreamcodes/iptv_xtream_codes/admin/assets/uploads/branding
sudo find /home/xtreamcodes/iptv_xtream_codes/admin/assets/uploads/branding -type d -exec chmod 755 {} \;
sudo find /home/xtreamcodes/iptv_xtream_codes/admin/assets/uploads/branding -type f -exec chmod 644 {} \;
```

Ajuste o caminho conforme a instalação.

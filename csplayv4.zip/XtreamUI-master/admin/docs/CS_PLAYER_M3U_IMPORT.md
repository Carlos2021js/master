# Importador M3U Inteligente — CS Player

## Fluxo implementado

1. O navegador envia a playlist em blocos de 512 KB.
2. O servidor monta o arquivo em diretório temporário vinculado à sessão.
3. A playlist é analisada linha por linha, sem ser carregada integralmente na memória.
4. A tela mostra totais, categorias, canais, filmes, episódios, séries, temporadas e duplicidades.
5. A importação somente é liberada após a análise.
6. Os registros são importados em lotes de 500, reduzindo transações extensas e bloqueios.
7. Temporadas são acumuladas em memória e atualizadas uma vez por série.

O upload fragmentado funciona mesmo quando o Nginx mantém um limite pequeno por requisição. Ainda assim, recomenda-se aplicar os exemplos de configuração deste diretório.

## Limpeza temporária

Arquivos temporários ficam em `sys_get_temp_dir()/cs_player_m3u/<sessão>` e são removidos automaticamente após 24 horas. Após uma importação concluída, o arquivo e a análise são apagados imediatamente.

## Playlist validada

O importador foi validado com uma playlist de aproximadamente 77 MB e 322.123 itens, incluindo cerca de 300 mil episódios.

# CS Player — Auditoria do projeto

## Escopo validado

- Sintaxe e compatibilidade dos 185 arquivos PHP com PHP 8.4.
- Autorização administrativa das funções personalizadas e importadores.
- Fluxos de importação M3U e import_stream.
- Uploads de mídia e identidade visual.
- Chamadas a programas externos, como FFprobe, iptables e processos do monitor.
- Robustez das rotinas de atualização remota.
- Integridade do pacote ZIP.

## Correções conservadoras aplicadas

1. Argumentos enviados ao FFprobe agora usam isolamento de shell e validação de tamanho/caracteres de controle.
2. A busca por URLs duplicadas no importador legado passou de varredura linear para mapa indexado.
3. Campos opcionais de playlists usam valores padrão, evitando avisos no PHP 8+.
4. PID do monitor e endereço IP recebem validação antes de comandos do sistema.
5. Rotinas de atualização tratam falhas de rede e validam o identificador de versão.
6. Nenhum esquema de banco, rota pública, módulo ou integração foi removido.

## Recomendações de implantação

- Fazer backup do banco e do diretório atual antes da substituição.
- Manter PHP-FPM, Nginx e extensões PHP atualizados.
- Aplicar os exemplos em `admin/server-config/` para playlists e vídeos grandes.
- Confirmar proprietário e permissões das pastas de cache, logs e mídias.
- Testar primeiro em homologação, especialmente importação M3U, criação de streams e reprodução.

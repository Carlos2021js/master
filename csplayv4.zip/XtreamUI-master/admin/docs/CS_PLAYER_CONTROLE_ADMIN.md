# Controle administrativo — CS Player

As personalizações adicionadas ao projeto são exclusivas do administrador.

## O administrador pode editar

- identidade visual, logos, imagens, avatar e favicon;
- vídeos MP4 do Login e Dashboard, áudio e comportamento de reprodução;
- biblioteca avançada de imagens do projeto;
- análise e importação inteligente de playlists M3U;
- central de saúde e diagnóstico técnico.

## Revendedores e demais perfis

- visualizam normalmente logos, fundos, vídeos e demais alterações publicadas;
- não recebem os links de edição nos menus;
- recebem HTTP 403 ao tentar abrir uma rota administrativa diretamente;
- não conseguem contornar a restrição por POST, upload fragmentado ou requisição AJAX.

A autorização é validada no servidor pela flag `is_admin`; esconder botões é apenas uma camada adicional de interface.

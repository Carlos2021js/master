<?php
/**
 * Diagnóstico persistente do importador M3U.
 * Não altera o banco. Todos os arquivos ficam em admin/storage/import_jobs.
 */
final class CSM3UImportDiagnostics
{
    private string $jobId;
    private string $dir;
    private string $statusFile;
    private string $logFile;
    private array $status;

    public static function baseDir(): string
    {
        return __DIR__ . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'import_jobs';
    }

    public static function validJobId(string $jobId): bool
    {
        return (bool)preg_match('/^[a-f0-9]{32}$/', $jobId);
    }

    public static function create(string $source, string $fileName = ''): self
    {
        $jobId = bin2hex(random_bytes(16));
        $self = new self($jobId, true);
        $self->status = [
            'job_id' => $jobId,
            'status' => 'preparando',
            'stage' => 'inicialização',
            'source' => $source,
            'file_name' => $fileName,
            'started_at' => date('c'),
            'finished_at' => null,
            'elapsed_seconds' => 0,
            'memory_current' => memory_get_usage(true),
            'memory_peak' => memory_get_peak_usage(true),
            'categories_found' => 0,
            'categories_created' => 0,
            'categories_reused' => 0,
            'channels_found' => 0,
            'channels_imported' => 0,
            'channels_updated' => 0,
            'channels_skipped' => 0,
            'errors' => 0,
            'warnings' => 0,
            'sql_queries' => 0,
            'batches' => 0,
            'average_batch_seconds' => 0,
            'last_update' => date('c'),
            'message' => 'Diagnóstico iniciado.',
        ];
        $self->persist();
        $self->log('info', 'inicialização', 'Diagnóstico da importação criado.');
        return $self;
    }

    public static function open(string $jobId): self
    {
        if (!self::validJobId($jobId)) {
            throw new RuntimeException('Identificador de diagnóstico inválido.');
        }
        return new self($jobId, false);
    }

    private function __construct(string $jobId, bool $create)
    {
        $this->jobId = $jobId;
        $this->dir = self::baseDir();
        if (!is_dir($this->dir) && !@mkdir($this->dir, 0750, true) && !is_dir($this->dir)) {
            throw new RuntimeException('Não foi possível criar admin/storage/import_jobs. Verifique proprietário e permissões.');
        }
        if (!is_writable($this->dir)) {
            throw new RuntimeException('A pasta admin/storage/import_jobs não possui permissão de escrita para o PHP-FPM.');
        }
        $this->statusFile = $this->dir . DIRECTORY_SEPARATOR . $jobId . '.json';
        $this->logFile = $this->dir . DIRECTORY_SEPARATOR . $jobId . '.log';
        $this->status = [];
        if (!$create) {
            if (!is_file($this->statusFile)) {
                throw new RuntimeException('Diagnóstico não encontrado.');
            }
            $decoded = json_decode((string)file_get_contents($this->statusFile), true);
            $this->status = is_array($decoded) ? $decoded : [];
        }
    }

    public function id(): string { return $this->jobId; }

    public function setStage(string $stage, string $message = ''): void
    {
        $this->update(['stage' => $stage, 'message' => $message ?: $stage]);
        $this->log('info', $stage, $message ?: ('Etapa iniciada: ' . $stage));
    }

    public function update(array $values): void
    {
        $started = isset($this->status['started_at']) ? strtotime((string)$this->status['started_at']) : time();
        $this->status = array_merge($this->status, $values, [
            'elapsed_seconds' => max(0, microtime(true) - $started),
            'memory_current' => memory_get_usage(true),
            'memory_peak' => memory_get_peak_usage(true),
            'last_update' => date('c'),
        ]);
        $this->persist();
    }

    public function increment(string $key, int $amount = 1): void
    {
        $this->status[$key] = (int)($this->status[$key] ?? 0) + $amount;
    }

    public function flushCounters(): void
    {
        $this->update([]);
    }

    public function log(string $level, string $stage, string $message, ?Throwable $error = null, ?string $file = null, ?int $line = null): void
    {
        $allowed = ['success', 'info', 'warning', 'error'];
        if (!in_array($level, $allowed, true)) $level = 'info';
        if ($level === 'warning') $this->increment('warnings');
        if ($level === 'error') $this->increment('errors');
        $row = [
            'time' => date('c'),
            'level' => $level,
            'stage' => $stage,
            'message' => $message,
            'file' => $file ?: ($error ? $error->getFile() : null),
            'line' => $line ?: ($error ? $error->getLine() : null),
            'exception' => $error ? get_class($error) : null,
        ];
        $lineJson = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
        if (@file_put_contents($this->logFile, $lineJson, FILE_APPEND | LOCK_EX) === false) {
            error_log('CS Player: não foi possível gravar log do importador em ' . $this->logFile);
        }
        $this->update([]);
    }

    public function finish(string $status, string $message): void
    {
        $level = $status === 'sucesso' ? 'success' : ($status === 'falha' ? 'error' : 'warning');
        $this->status['finished_at'] = date('c');
        $this->status['status'] = $status;
        $this->status['stage'] = 'concluído';
        $this->status['message'] = $message;
        $this->persist();
        $this->log($level, 'conclusão', $message);
    }

    public function fail(Throwable $error, string $stage = 'falha crítica'): void
    {
        $this->status['finished_at'] = date('c');
        $this->status['status'] = 'falha';
        $this->status['stage'] = $stage;
        $this->status['message'] = $error->getMessage();
        $this->persist();
        $this->log('error', $stage, $error->getMessage(), $error);
    }

    public function snapshot(int $logLimit = 300): array
    {
        $decoded = json_decode((string)@file_get_contents($this->statusFile), true);
        $status = is_array($decoded) ? $decoded : $this->status;
        $logs = [];
        if (is_file($this->logFile)) {
            $lines = @file($this->logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
            foreach (array_slice($lines, -$logLimit) as $line) {
                $row = json_decode($line, true);
                if (is_array($row)) $logs[] = $row;
            }
        }
        $status['logs'] = $logs;
        return $status;
    }

    private function persist(): void
    {
        $json = json_encode($this->status, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        if ($json === false) throw new RuntimeException('Falha ao serializar o diagnóstico da importação.');
        $tmp = $this->statusFile . '.tmp.' . getmypid();
        if (@file_put_contents($tmp, $json, LOCK_EX) === false || !@rename($tmp, $this->statusFile)) {
            @unlink($tmp);
            throw new RuntimeException('Não foi possível persistir o diagnóstico em admin/storage/import_jobs.');
        }
        @chmod($this->statusFile, 0640);
        if (is_file($this->logFile)) @chmod($this->logFile, 0640);
    }
}

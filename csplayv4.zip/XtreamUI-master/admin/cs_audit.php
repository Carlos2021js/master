<?php
/** CS Player - auditoria leve e segura em arquivo. */
if (!function_exists('cs_audit_log')) {
    function cs_audit_log($event, array $context = []) {
        $dir = __DIR__ . '/logs/cs-player';
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $safe = [];
        foreach ($context as $key => $value) {
            if (preg_match('/pass|secret|token|key|cookie|authorization/i', (string)$key)) continue;
            if (is_scalar($value) || $value === null) $safe[(string)$key] = $value;
        }
        $row = [
            'time' => date('c'),
            'event' => preg_replace('/[^a-zA-Z0-9_.-]/', '_', (string)$event),
            'user' => isset($_SESSION['rUserInfo']['username']) ? (string)$_SESSION['rUserInfo']['username'] : (isset($GLOBALS['rUserInfo']['username']) ? (string)$GLOBALS['rUserInfo']['username'] : ''),
            'ip' => isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '',
            'context' => $safe
        ];
        $line = json_encode($row, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL;
        return @file_put_contents($dir . '/audit-' . date('Y-m') . '.log', $line, FILE_APPEND | LOCK_EX) !== false;
    }
}

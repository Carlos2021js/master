# CS Player v6.14 — correção Web Player / player_api.php / porta pública

Data da revisão: 2026-08-18/19

## Diagnóstico confirmado pelos logs

O Web Player estava tentando `169.58.140.143:80/player_api.php` e recebendo HTTP 404.
O código em `admin/player/bootstrap.php` podia descartar uma porta explicitamente presente em `domain_name` e cair em :80 quando a porta de broadcast estivesse vazia/inválida. Além disso, só havia uma URL candidata por servidor, de modo que uma configuração de porta antiga/incorreta em `streaming_servers` derrubava login, catálogo e reprodução.

## Correções aplicadas

- `cs_player_build_server_url()` não perde mais a porta explicitamente cadastrada quando não há uma porta de broadcast válida.
- Cada servidor interno agora gera uma lista deduplicada de endpoints candidatos: URL principal, porta embutida no domínio/IP, `http_broadcast_port`, `https_broadcast_port` e, quando o host é o mesmo, a porta pública atual do painel.
- A autenticação testa as alternativas do MESMO servidor automaticamente, sem transformar essas alternativas em DNS externos e sem criar registros no banco.
- Quando uma alternativa válida autentica, ela é gravada apenas na sessão (`cs_player_dns_url`) e passa a ser usada pelo catálogo e pelos streams durante aquela sessão.
- Os logs `auth_request_failed` agora incluem também a porta testada.
- Quando o Web Player encontra automaticamente uma porta alternativa funcional, registra `server_endpoint_failover_selected`.
- Nenhuma tabela, coluna, índice ou ID foi alterado.
- DNS externos continuam funcionando pela URL cadastrada pelo administrador e não recebem inferência de portas internas.

## Validação

- Todos os arquivos PHP de `admin/player/` passaram em `php -l`.
- Auditoria global do pacote: 278 arquivos PHP verificados, 0 erros de sintaxe.

## Observação importante

Esta correção elimina o erro de seleção rígida de porta. A confirmação final de funcionamento depende do servidor em produção realmente publicar `player_api.php` em pelo menos uma das portas candidatas. Se todas retornarem 404, o serviço Xtream/API não está publicado nessas portas e isso aparecerá claramente no novo log com `host`, `port` e `http_code`.

Os avisos de `/var/log/php8.3-fpm.log`, `/var/log/syslog` e `/var/log/auth.log` ausentes/sem permissão pertencem ao leitor de logs do painel e não são a causa do 404 do Web Player.

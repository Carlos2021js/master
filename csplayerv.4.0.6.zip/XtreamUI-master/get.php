<?php
/** CS PLAYER - gerador M3U compatível, sem alterar o banco. */
require_once __DIR__ . '/admin/player/bootstrap.php';
try {
    $u = trim((string)($_GET['username'] ?? ''));
    $p = (string)($_GET['password'] ?? '');
    $output = strtolower(trim((string)($_GET['output'] ?? 'mpegts')));
    if ($u === '' || $p === '' || !cs_player_local_user($u,$p)) { http_response_code(401); exit('Credenciais inválidas'); }
    $user=cs_player_local_user($u,$p); $perms=cs_player_local_permissions($user);
    header('Content-Type: audio/x-mpegurl; charset=utf-8');
    header('Content-Disposition: inline; filename="csplayer.m3u"');
    header('Cache-Control: no-store');
    echo "#EXTM3U\n";
    $emit = static function(array $item, string $type) use ($u,$p) {
        $id=(int)($item['stream_id']??$item['id']??0); if($id<=0)return;
        $name=str_replace(["\r","\n"],' ',(string)($item['name']??$item['title']??('CS PLAYER '.$id)));
        $logo=(string)($item['stream_icon']??($item['info']['movie_image']??''));
        $cat=(string)($item['category_id']??'');
        $src=cs_player_local_stream_source($id,$u,$p); if(!$src)return;
        echo '#EXTINF:-1 tvg-logo="'.str_replace('"','&quot;',$logo).'" group-title="'.str_replace('"','&quot;',$cat).'",'.$name."\n".$src."\n";
    };
    foreach(cs_player_local_streams('live',$perms) as $x) $emit($x,'live');
    foreach(cs_player_local_streams('movie',$perms) as $x) $emit($x,'movie');
    foreach(cs_player_local_series($perms) as $series) {
        $info=cs_player_local_series_info((int)$series['series_id'],$perms); if(!$info)continue;
        foreach((array)($info['episodes']??[]) as $season=>$eps) foreach((array)$eps as $ep) $emit($ep,'series');
    }
} catch (Throwable $e) {
    if (function_exists('cs_player_write_log')) cs_player_write_log('get_php_fatal',['class'=>get_class($e),'message_hash'=>substr(hash('sha256',$e->getMessage()),0,12)],'error');
    http_response_code(500); exit('CS PLAYER: falha ao gerar playlist');
}

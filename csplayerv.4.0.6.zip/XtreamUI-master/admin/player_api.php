<?php
/** CS PLAYER - endpoint de compatibilidade da API do cliente. */
require_once __DIR__ . '/admin/player/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
try {
    $u = trim((string)($_GET['username'] ?? $_POST['username'] ?? ''));
    $p = (string)($_GET['password'] ?? $_POST['password'] ?? '');
    $action = trim((string)($_GET['action'] ?? $_POST['action'] ?? ''));
    if ($u === '' || $p === '') { http_response_code(401); echo json_encode(['user_info'=>['auth'=>0,'status'=>'Disabled']], JSON_UNESCAPED_SLASHES); exit; }
    $extra = $_GET; unset($extra['username'],$extra['password'],$extra['action']);
    $data = cs_player_local_api($u,$p,$action,$extra);
    if ($data === null) { http_response_code(401); echo json_encode(['user_info'=>['auth'=>0,'status'=>'Disabled']], JSON_UNESCAPED_SLASHES); exit; }
    echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    if (function_exists('cs_player_write_log')) cs_player_write_log('public_api_fatal',['class'=>get_class($e),'message_hash'=>substr(hash('sha256',$e->getMessage()),0,12)],'error');
    http_response_code(500); echo json_encode(['error'=>'CS PLAYER API indisponível']);
}

<?php
declare(strict_types=1);

/**
 * CS PLAYER - gerador M3U compatível com qualquer app IPTV
 * ----------------------------------------------------------
 * Compatível com: TiviMate, XCIPTV, IPTV Smarters, VLC,
 * OTT Navigator, GSE Smart IPTV, e qualquer app que aceite M3U.
 */

// Evita qualquer saída acidental antes dos headers
ini_set('display_errors', '0');
error_reporting(E_ALL);

// Timeout generoso para playlists extensas
set_time_limit(0);
ignore_user_abort(false);

// ============================================================
// 1. Localiza e carrega o bootstrap do CS Player
// ============================================================
$bootstrapCandidates = [
    __DIR__ . '/admin/player/bootstrap.php',       // get.php na raiz
    __DIR__ . '/bootstrap.php',                    // get.php na mesma pasta
    dirname(__DIR__) . '/admin/player/bootstrap.php' // get.php em subpasta
];

$bootstrapLoaded = false;
foreach ($bootstrapCandidates as $candidate) {
    if (is_file($candidate)) {
        require_once $candidate;
        $bootstrapLoaded = true;
        break;
    }
}

if (!$bootstrapLoaded || !function_exists('cs_player_local_user')) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    exit('CS PLAYER: bootstrap não encontrado ou incompatível.');
}

// ============================================================
// 2. Libera a sessão para não bloquear streams paralelos
// ============================================================
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

// ============================================================
// 3. Processamento da requisição
// ============================================================
try {
    // ---------- Entrada ----------
    $username = trim((string)($_GET['username'] ?? ''));
    $password = (string)($_GET['password'] ?? '');
    $output   = strtolower(trim((string)($_GET['output'] ?? 'mpegts')));

    // Normaliza output (aceita variações comuns)
    $normalizedOutput = match ($output) {
        'ts', 'mpegts' => 'mpegts',
        'hls', 'm3u8'  => 'hls',
        default        => 'mpegts'
    };

    // ---------- Validação ----------
    if ($username === '' || $password === '') {
        http_response_code(401);
        header('Content-Type: text/plain; charset=utf-8');
        exit('Usuário e senha são obrigatórios');
    }

    // ---------- Autenticação única ----------
    $user = cs_player_local_user($username, $password);
    if (!$user) {
        http_response_code(401);
        header('Content-Type: text/plain; charset=utf-8');
        exit('Credenciais inválidas');
    }

    // ---------- Permissões ----------
    $permissions = cs_player_local_permissions($user);

    // ---------- Cabeçalhos M3U universais ----------
    header('Content-Type: audio/x-mpegurl; charset=utf-8');
    header('Content-Disposition: inline; filename="csplayer.m3u"');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    http_response_code(200);

    // ---------- Início da playlist ----------
    echo "#EXTM3U\n";

    /**
     * Emite uma entrada M3U com todos os atributos corretos.
     * @param array $item Item do stream ou episódio.
     */
    $emit = static function (array $item) use ($username, $password, $normalizedOutput): void {
        $id = (int)($item['stream_id'] ?? $item['id'] ?? 0);
        if ($id <= 0) return;

        $name = str_replace(["\r", "\n", '"'], [' ', ' ', '&quot;'], (string)($item['name'] ?? $item['title'] ?? ('CS PLAYER ' . $id)));
        $logo = (string)($item['stream_icon'] ?? ($item['info']['movie_image'] ?? ''));
        $group = (string)($item['category_id'] ?? '');

        $source = cs_player_local_stream_source($id, $username, $password);
        if (!$source) return;

        // Se o app pediu HLS, e a fonte for .ts, podemos tentar substituir a extensão
        if ($normalizedOutput === 'hls') {
            $source = preg_replace('/\.ts(\?|$)/i', '.m3u8$1', $source);
        } elseif ($normalizedOutput === 'mpegts') {
            // Garante que não fique .m3u8 se o app pediu TS
            $source = preg_replace('/\.m3u8(\?|$)/i', '.ts$1', $source);
        }

        // Escapamento seguro para atributos M3U
        $logoEscaped = htmlspecialchars($logo, ENT_QUOTES, 'UTF-8');
        $groupEscaped = htmlspecialchars($group, ENT_QUOTES, 'UTF-8');
        $nameEscaped = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');

        echo "#EXTINF:-1 tvg-logo=\"{$logoEscaped}\" group-title=\"{$groupEscaped}\",{$nameEscaped}\n";
        echo $source . "\n";
    };

    // ---------- Canais ao vivo ----------
    foreach (cs_player_local_streams('live', $permissions) as $stream) {
        $emit($stream);
    }

    // ---------- Filmes (VOD) ----------
    foreach (cs_player_local_streams('movie', $permissions) as $stream) {
        $emit($stream);
    }

    // ---------- Séries (episódios) ----------
    foreach (cs_player_local_series($permissions) as $series) {
        $info = cs_player_local_series_info((int)$series['series_id'], $permissions);
        if (!$info) continue;

        foreach ($info['episodes'] ?? [] as $seasonEpisodes) {
            foreach ($seasonEpisodes as $episode) {
                $emit($episode);
            }
        }
    }

} catch (Throwable $e) {
    // Loga o erro internamente sem expor detalhes sensíveis
    if (function_exists('cs_player_write_log')) {
        cs_player_write_log('get_php_fatal', [
            'class' => get_class($e),
            'message_hash' => substr(hash('sha256', $e->getMessage()), 0, 12),
            'line' => $e->getLine(),
        ], 'error');
    }

    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    exit('CS PLAYER: falha ao gerar playlist');
}
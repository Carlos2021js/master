# CS PLAYER 4.0.6 — correção de identidade, API e conteúdos

- Identidade pública mantida como **CS PLAYER**. A pasta `XtreamUI-master` permanece somente como estrutura técnica do instalador.
- Adicionados `player_api.php`, `panel_api.php` e `get.php` na raiz do pacote para restaurar compatibilidade de clientes e eliminar o 404 estrutural do pacote 4.0.5.
- `get.php` autentica no banco existente, respeita bouquets/permissões e gera M3U a partir das fontes já cadastradas, sem alterar schema.
- Corrigido o salvamento de DNS M3U para preservar caminhos completos como `/subpasta/get.php` e parâmetros extras não sensíveis.
- O Web Player continua aceitando modo XC/Smart/M3U, mas uma URL M3U explícita deixa de ser reduzida indevidamente a uma rota genérica.
- Falhas são registradas em log e não exibem detalhes técnicos/credenciais ao cliente.

## Observação sobre `power08121562.shop`
Os logs fornecidos mostram HTTP 404 retornado pelo próprio host/Cloudflare para `player_api.php`, `panel_api.php`, `get.php` e também para URLs de stream. Isso não é um erro de banco. O CS PLAYER agora preserva rotas M3U completas, mas se o provedor responder 404 ao IP da VPS, o proxy do servidor não consegue transformar esse 404 em vídeo válido. Nesse cenário, deve-se cadastrar exatamente a rota M3U funcional do provedor e usar modo M3U; se o provedor aplicar bloqueio por origem/IP, ele precisa liberar a VPS ou fornecer uma rota acessível ao servidor.

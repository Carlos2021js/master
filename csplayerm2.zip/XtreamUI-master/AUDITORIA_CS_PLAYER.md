# AUDITORIA CS PLAYER — csplayerm1

Data da revisão: 2026-08-14 (America/Bahia)

## Resumo

O pacote foi auditado com foco em estabilidade, importação M3U, compatibilidade PHP 8.3/8.4, segurança, logs e reversibilidade. Foram preservados os módulos existentes e aplicado o princípio de menor superfície de alteração.

## Inventário

- 973 arquivos no pacote original.
- 232 arquivos PHP incluindo cópias internas/estrutura original na extração inicial.
- 228 arquivos PHP de produção após excluir backups da contagem de lint.
- `admin/m3u_update_nodup.php` preservado byte a byte.

## Melhorias implementadas

### Importador M3U 2

- Processamento em etapas curtas via AJAX em vez de uma requisição HTTP monolítica.
- Checkpoint por offset de bytes da playlist.
- Retomada sem reler a lista inteira desde o início.
- Transação por lote e savepoint por item.
- Cancelamento consultado durante o processamento.
- Classificação rígida:
  - Live: `.m3u8`, `.ts`, `.mpegts`.
  - Filme: `.mp4`/`.mkv` sem padrão confiável de episódio.
  - Série/Episódio: VOD permitido + padrão confiável de temporada/episódio.
- Grupo/categoria não força classificação incompatível.
- Modo manual também respeita validação técnica.
- Campo de confiança e motivo da classificação.
- Pré-análise com amostra de até 100 itens para revisão.
- URLs da fila de revisão têm credenciais mascaradas.

### Upload e URL remota

- Upload em partes preservado.
- Validação SSRF reforçada.
- Protocolos remotos limitados a HTTP/HTTPS.
- Redirecionamentos são seguidos manualmente e cada destino é novamente validado antes da conexão.
- Bloqueio de localhost, redes privadas e reservadas.
- Limite máximo de tamanho mantido.

### Segurança e compatibilidade

- `branding_manager.php`: includes críticos baseados em `__DIR__`.
- `resize.php`: fallback quando GD não está disponível, evitando Fatal Error.
- `server.php`: tratamento seguro para `in_array()` com valor potencialmente nulo já presente no pacote.
- Limpeza administrativa ganhou modo de simulação antes da exclusão real.
- O importador legado não foi alterado.

## Testes realizados

- `php -l` em 228 arquivos PHP de produção: **0 erros de sintaxe**.
- 7 cenários de classificação Live/Filme/Série/ambíguo: **7 aprovados**.
- Teste de checkpoint por offset: **aprovado**; retomada iniciou no item seguinte.
- Testes SSRF: `127.0.0.1`, `10.0.0.1`, `169.254.1.2` e `ftp://`: **todos bloqueados conforme esperado**.
- Hash do importador antigo comparado antes/depois: **idêntico**.

## Banco de dados

Nenhuma tabela, coluna ou ID foi removido ou recriado nesta revisão. As alterações foram feitas na camada de aplicação. A validação completa com MariaDB real depende do ambiente da VPS.

## Pendências de validação em VPS

Devem ser testados no servidor real: PHP-FPM `request_terminate_timeout`, Nginx `client_max_body_size`/timeouts, conexão MariaDB, criação/atualização real de streams, séries, episódios e buquês, EPG, TMDB, FFmpeg e permissões de filesystem.

## Risco e reversão

Os arquivos modificados possuem cópia em `admin/backups/2026-08-14_23-26-00/`. O arquivo `changes.log` documenta as alterações realizadas.

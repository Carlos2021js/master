# CHANGELOG CS PLAYER

## Fixed
- Corrigida classificação que podia transformar grupo de séries sem padrão de episódio em episódio válido.
- Corrigido fluxo de importação longa para reduzir dependência de uma única requisição HTTP.
- Includes críticos do branding passam a usar caminho absoluto.

## Improved
- Importação M3U 2 por lotes retomáveis.
- Checkpoint por offset de bytes.
- Pré-análise com itens para revisão.
- Motivo e confiança de classificação.
- Modo de simulação na limpeza administrativa.

## Security
- Redirecionamentos de URL remota revalidados contra SSRF.
- Credenciais mascaradas na fila de revisão.
- Bloqueio de protocolos e redes não permitidos preservado/reforçado.

## Performance
- Requisições de importação menores.
- Retomada sem reler a playlist inteira.
- Transações por lote.

## UI/UX
- Tabela de itens ambíguos na etapa de pré-análise.
- Mensagens de classificação mais claras para o administrador.

## Database compatibility
- Nenhuma tabela removida.
- Nenhuma coluna removida.
- Nenhum ID alterado.
- Importador legado preservado como fallback.

<?php
/**
 * CS PLAYER — IMPORTADOR M3U 2 ULTRA
 * Arquivo independente: NÃO inclui nem altera m3u_update_nodup.php.
 * PHP 7.4–8.4 / MariaDB / XtreamUI schema.
 */
ob_start();
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);
set_time_limit(0);

if (!function_exists('cs_m3u2_emergency_log')) {
    function cs_m3u2_emergency_log($level, $stage, $message)
    {
        $dir = __DIR__ . '/storage/m3u2/logs';
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        $msg = preg_replace('/[\r\n\t]+/', ' ', (string)$message);
        $msg = preg_replace('~(://[^:/\s]+:)[^@/\s]+@~', '$1[REDACTED]@', $msg);
        $msg = preg_replace('~([?&](?:username|password|user|pass|token|api_key)=)[^&\s]+~i', '$1[REDACTED]', $msg);
        $line = '[' . date('Y-m-d H:i:s') . '] [' . strtoupper((string)$level) . '] [' . $stage . '] ' . $msg . PHP_EOL;
        @file_put_contents($dir . '/m3u2-' . date('Y-m-d') . '.log', $line, FILE_APPEND | LOCK_EX);
    }
}

register_shutdown_function(function () {
    $last = error_get_last();
    if ($last && in_array((int)$last['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
        cs_m3u2_emergency_log('fatal', 'shutdown', $last['message'] . ' em ' . $last['file'] . ':' . $last['line']);
        if (isset($_POST['m3u2_action']) || isset($_GET['m3u2_status'])) {
            while (ob_get_level() > 0) @ob_end_clean();
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('ok'=>false,'error'=>'Erro fatal no Importador M3U 2. Consulte os logs do PHP.'), JSON_UNESCAPED_UNICODE);
        }
    }
});

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/cs_admin_access.php';
require_once __DIR__ . '/includes/m3u2/bootstrap.php';

cs_admin_only('o Importador M3U 2');
if (session_status() === PHP_SESSION_NONE) @session_start();
if (empty($_SESSION['m3u2_csrf'])) $_SESSION['m3u2_csrf'] = bin2hex(random_bytes(32));
$csrf = (string)$_SESSION['m3u2_csrf'];
try {
    $owner = cs_m3u2_owner();
    $storage = cs_m3u2_storage();
    $uploadManager = new CSM3U2UploadManager($storage, $owner);
    $jobStore = new CSM3U2JobStore($storage, $owner);
    $uploadManager->cleanup(86400);
    $jobStore->cleanup(172800);
    if (!isset($_GET['m3u2_status']) && !isset($_POST['m3u2_action'])) {
        $jobStore->audit('info', 'acesso', 'Página do Importador M3U 2 aberta pelo administrador.');
    }
} catch (Throwable $bootError) {
    cs_m3u2_emergency_log('fatal', 'bootstrap', $bootError->getMessage());
    error_log('CS M3U2 bootstrap: ' . $bootError->getMessage());
    if (isset($_POST['m3u2_action']) || isset($_GET['m3u2_status'])) {
        while (ob_get_level() > 0) @ob_end_clean();
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('ok'=>false,'error'=>'Falha ao inicializar o Importador M3U 2. Consulte system_logs.php.'), JSON_UNESCAPED_UNICODE);
    } else {
        http_response_code(500);
        echo '<h1>CS PLAYER — Importador M3U 2</h1><p>Falha ao inicializar o módulo. Consulte system_logs.php.</p>';
    }
    exit;
}

function cs_m3u2_require_csrf()
{
    $provided = (string)($_POST['csrf'] ?? '');
    $expected = (string)($_SESSION['m3u2_csrf'] ?? '');
    if ($provided === '' || $expected === '' || !hash_equals($expected, $provided)) {
        cs_m3u2_json(array('ok'=>false,'error'=>'Token de segurança inválido. Atualize a página.'), 403);
    }
}
function cs_m3u2_source_ids()
{
    $ids = isset($_POST['source_ids']) ? $_POST['source_ids'] : array();
    if (!is_array($ids)) $ids = array($ids);
    return array_values(array_unique(array_filter(array_map('strval', $ids))));
}
function cs_m3u2_options_from_post()
{
    $mode = (string)($_POST['classification_mode'] ?? 'auto');
    if (!in_array($mode, array('auto','live','movie','series'), true)) $mode = 'auto';
    return array(
        'classification' => $mode,
        'legacy_vod' => cs_m3u2_bool('legacy_vod', false),
        'create_categories' => cs_m3u2_bool('create_categories', true),
        'update_existing' => cs_m3u2_bool('update_existing', true),
        'auto_epg' => cs_m3u2_bool('auto_epg', true),
        'queue_tmdb' => cs_m3u2_bool('queue_tmdb', true),
        'direct_source' => cs_m3u2_bool('direct_source', true),
        'batch_size' => max(10, min(500, (int)($_POST['batch_size'] ?? 100)))
    );
}

if (isset($_GET['m3u2_status'])) {
    try {
        $state = $jobStore->get((string)$_GET['m3u2_status']);
        cs_m3u2_json(array('ok'=>true,'job'=>$state));
    } catch (Throwable $e) {
        cs_m3u2_json(array('ok'=>false,'error'=>$e->getMessage()), 404);
    }
}

if (isset($_POST['m3u2_action'])) {
    cs_m3u2_require_csrf();
    try {
        $action = (string)$_POST['m3u2_action'];
        if ($action === 'schema') {
            $schema = (new CSM3U2Schema($db))->validate();
            $jobStore->audit($schema['ok'] ? 'success' : 'error', 'schema', $schema['ok'] ? 'Banco compatível com o Importador M3U 2.' : ('Banco incompatível: ' . implode('; ', $schema['errors'])));
            cs_m3u2_json(array('ok'=>$schema['ok'],'schema'=>$schema), $schema['ok'] ? 200 : 409);
        }
        if ($action === 'upload_chunk') {
            if (!isset($_FILES['chunk'])) throw new RuntimeException('Parte do arquivo não recebida.');
            $meta = $uploadManager->receiveChunk(
                (string)($_POST['batch_token'] ?? ''),
                (string)($_POST['source_id'] ?? ''),
                (int)($_POST['chunk_index'] ?? -1),
                (int)($_POST['chunk_total'] ?? 0),
                (int)($_POST['file_size'] ?? 0),
                (string)($_POST['file_name'] ?? 'playlist.m3u'),
                $_FILES['chunk']
            );
            if (!empty($meta['complete'])) $jobStore->audit('success', 'upload', 'Upload concluído: ' . (string)($meta['name'] ?? 'playlist M3U') . ' (' . (int)($meta['size'] ?? 0) . ' bytes).');
            cs_m3u2_json(array('ok'=>true,'source'=>$meta));
        }
        if ($action === 'fetch_remote') {
            $meta = $uploadManager->fetchRemote((string)($_POST['batch_token'] ?? ''), (string)($_POST['source_id'] ?? ''), (string)($_POST['url'] ?? ''));
            $jobStore->audit('success', 'download', 'Playlist remota recebida com sucesso (' . (int)($meta['size'] ?? 0) . ' bytes).');
            cs_m3u2_json(array('ok'=>true,'source'=>$meta));
        }
        if ($action === 'analyze') {
            $sourceIds = cs_m3u2_source_ids();
            if (!$sourceIds) throw new RuntimeException('Nenhuma fonte foi enviada para análise.');
            $sources = $uploadManager->getSources((string)($_POST['batch_token'] ?? ''), $sourceIds);
            $engine = new CSM3U2ImportEngine($db);
            $analysis = $engine->analyzeSources($sources, cs_m3u2_options_from_post());
            $jobStore->audit('success', 'análise', 'Análise concluída: ' . (int)$analysis['total'] . ' itens, ' . (int)$analysis['live'] . ' canais, ' . (int)$analysis['movies'] . ' filmes, ' . (int)$analysis['episodes'] . ' episódios.');
            cs_m3u2_json(array('ok'=>true,'analysis'=>$analysis));
        }
        if ($action === 'prepare') {
            $sourceIds = cs_m3u2_source_ids();
            if (!$sourceIds) throw new RuntimeException('Nenhuma fonte pronta para importar.');
            $sources = $uploadManager->getSources((string)($_POST['batch_token'] ?? ''), $sourceIds);
            $engine = new CSM3U2ImportEngine($db);
            $analysis = $engine->analyzeSources($sources, cs_m3u2_options_from_post());
            $job = $jobStore->create(array('expected'=>(int)$analysis['total'],'sources'=>count($sources),'status'=>'preparado','stage'=>'análise','message'=>'Análise confirmada. Pronto para importar.'));
            cs_m3u2_json(array('ok'=>true,'job_id'=>$job['id'],'analysis'=>$analysis));
        }
        if ($action === 'cancel') {
            $state = $jobStore->requestCancel((string)($_POST['job_id'] ?? ''));
            cs_m3u2_json(array('ok'=>true,'job'=>$state));
        }
        if ($action === 'clear_batch') {
            $uploadManager->removeBatch((string)($_POST['batch_token'] ?? ''));
            $jobStore->audit('info', 'limpeza', 'Lote temporário removido pelo administrador.');
            cs_m3u2_json(array('ok'=>true));
        }
        if ($action === 'start') {
            $jobId = (string)($_POST['job_id'] ?? '');
            $sourceIds = cs_m3u2_source_ids();
            if (!$sourceIds) throw new RuntimeException('Nenhuma fonte pronta para iniciar.');
            // Valida agora para garantir que o job só comece com fontes ainda disponíveis.
            $uploadManager->getSources((string)($_POST['batch_token'] ?? ''), $sourceIds);
            $serverId = (int)($_POST['servers'] ?? 0);
            if ($serverId <= 0) {
                $fallback = $db->query("SELECT id FROM streaming_servers ORDER BY (server_name = 'Main Server') DESC, id ASC LIMIT 1");
                if ($fallback && ($row = $fallback->fetch_assoc())) $serverId = (int)$row['id'];
            }
            $bouquets = isset($_POST['bouquets']) && is_array($_POST['bouquets']) ? array_values(array_unique(array_filter(array_map('intval', $_POST['bouquets'])))) : array();
            if ($serverId <= 0) throw new RuntimeException('Selecione um servidor de streaming válido.');
            $schema = (new CSM3U2Schema($db))->validate();
            if (!$schema['ok']) throw new RuntimeException('Banco incompatível: ' . implode('; ', $schema['errors']));
            $options = cs_m3u2_options_from_post();
            $jobStore->audit('info', 'inicialização', 'Importação em lotes retomáveis iniciada.', $jobId);
            $state = $jobStore->update($jobId, array(
                'status'=>'executando','stage'=>'inicialização','message'=>'Job iniciado. Processamento em lotes AJAX ativo.',
                'started_at'=>microtime(true),'batch_token'=>(string)($_POST['batch_token'] ?? ''),'source_ids'=>$sourceIds,
                'source_index'=>0,'source_offset'=>0,'server_id'=>$serverId,'bouquets'=>$bouquets,'options'=>$options
            ));
            cs_m3u2_json(array('ok'=>true,'job_id'=>$jobId,'job'=>$state));
        }
        if ($action === 'step') {
            $jobId = (string)($_POST['job_id'] ?? '');
            $state = $jobStore->get($jobId);
            if (!empty($state['cancel_requested'])) {
                $state = $jobStore->update($jobId, array('status'=>'cancelado','stage'=>'finalizado','message'=>'Importação cancelada pelo administrador.','finished_at'=>microtime(true)));
                cs_m3u2_json(array('ok'=>true,'done'=>true,'job'=>$state));
            }
            if (($state['status'] ?? '') !== 'executando') {
                cs_m3u2_json(array('ok'=>true,'done'=>in_array(($state['status'] ?? ''), array('sucesso','concluido_com_avisos','falha','cancelado'), true),'job'=>$state));
            }
            $sourceIds = isset($state['source_ids']) && is_array($state['source_ids']) ? array_values($state['source_ids']) : array();
            $sourceIndex = max(0, (int)($state['source_index'] ?? 0));
            if ($sourceIndex >= count($sourceIds)) {
                $hasIssues = ((int)($state['errors'] ?? 0) > 0 || (int)($state['warnings'] ?? 0) > 0);
                $state = $jobStore->update($jobId, array('status'=>$hasIssues?'concluido_com_avisos':'sucesso','stage'=>'finalizado','message'=>'Importação múltipla concluída.','finished_at'=>microtime(true)));
                foreach ((array)($state['bouquets'] ?? array()) as $bouquetId) {
                    try { if (function_exists('scanBouquet')) scanBouquet((int)$bouquetId); } catch (Throwable $ignored) {}
                }
                $jobStore->audit($hasIssues ? 'warning' : 'success', 'finalização', 'Importação retomável concluída.', $jobId);
                cs_m3u2_json(array('ok'=>true,'done'=>true,'job'=>$state));
            }

            $sourceId = (string)$sourceIds[$sourceIndex];
            $source = $uploadManager->getSource((string)($state['batch_token'] ?? ''), $sourceId);
            $offset = max(0, (int)($state['source_offset'] ?? 0));
            $options = isset($state['options']) && is_array($state['options']) ? $state['options'] : array();
            $limit = max(10, min(500, (int)($options['batch_size'] ?? 100)));
            $jobStore->update($jobId, array('stage'=>'importação','current_source'=>(string)($source['name'] ?? $sourceId),'message'=>'Processando lote a partir do checkpoint ' . $offset . '.'));
            if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

            $engine = new CSM3U2ImportEngine($db, $jobStore, $jobId);
            try {
                $step = $engine->importStep($source, (int)$state['server_id'], (array)($state['bouquets'] ?? array()), $options, $offset, $limit);
                $delta = $step['stats'];
                $counterKeys = array('processed','inserted','updated','skipped','errors','warnings','live','movies','episodes','series_created','categories_created','categories_reused','batches');
                $increments = array();
                foreach ($counterKeys as $key) $increments[$key] = (int)($delta[$key] ?? 0);
                $state = $jobStore->increment($jobId, $increments);
                $nextIndex = $sourceIndex;
                $nextOffset = (int)$step['next_offset'];
                if (!empty($step['source_done'])) { $nextIndex++; $nextOffset = 0; }
                $state = $jobStore->update($jobId, array(
                    'source_index'=>$nextIndex,'source_offset'=>$nextOffset,
                    'stage'=>'checkpoint','message'=>'Lote confirmado. Checkpoint salvo.',
                    'last_checkpoint'=>array('source_index'=>$nextIndex,'offset'=>$nextOffset,'time'=>microtime(true))
                ));
                $done = $nextIndex >= count($sourceIds);
                if ($done) {
                    $hasIssues = ((int)($state['errors'] ?? 0) > 0 || (int)($state['warnings'] ?? 0) > 0);
                    $state = $jobStore->update($jobId, array('status'=>$hasIssues?'concluido_com_avisos':'sucesso','stage'=>'finalizado','message'=>'Importação múltipla concluída.','finished_at'=>microtime(true)));
                    foreach ((array)($state['bouquets'] ?? array()) as $bouquetId) {
                        try { if (function_exists('scanBouquet')) scanBouquet((int)$bouquetId); } catch (Throwable $ignored) {}
                    }
                    $jobStore->audit($hasIssues ? 'warning' : 'success', 'finalização', 'Importação concluída em lotes com checkpoint.', $jobId);
                }
                cs_m3u2_json(array('ok'=>true,'done'=>$done,'job'=>$state,'step'=>$step));
            } catch (Throwable $e) {
                $status = stripos($e->getMessage(), 'cancelada') !== false ? 'cancelado' : 'falha';
                $jobStore->log($jobId, 'error', 'lote', $e->getMessage());
                $state = $jobStore->update($jobId, array('status'=>$status,'stage'=>'finalizado','message'=>$e->getMessage(),'finished_at'=>microtime(true)));
                cs_m3u2_json(array('ok'=>false,'error'=>$e->getMessage(),'job_id'=>$jobId,'job'=>$state), $status === 'cancelado' ? 409 : 500);
            }
        }
        throw new RuntimeException('Ação desconhecida do Importador M3U 2.');
    } catch (Throwable $e) {
        $jobIdForError = (string)($_POST['job_id'] ?? '');
        try { $jobStore->audit('error', 'API/' . (string)($_POST['m3u2_action'] ?? 'desconhecida'), $e->getMessage(), $jobIdForError); } catch (Throwable $ignored) { cs_m3u2_emergency_log('error','API',$e->getMessage()); }
        error_log('CS M3U2: ' . $e->getMessage());
        cs_m3u2_json(array('ok'=>false,'error'=>$e->getMessage()), 400);
    }
}

$schemaStatus = (new CSM3U2Schema($db))->validate();
$rServers = function_exists('getStreamingServers') ? getStreamingServers(true) : array();
$rBouquets = array();
$res = $db->query('SELECT id, bouquet_name FROM bouquets ORDER BY bouquet_order ASC, id ASC');
while ($res && ($row = $res->fetch_assoc())) $rBouquets[] = $row;
$rSidebar = isset($rSettings['sidebar']) ? (bool)$rSettings['sidebar'] : false;
include __DIR__ . DIRECTORY_SEPARATOR . ($rSidebar ? 'header_sidebar.php' : 'header.php');
?>
<script src="assets/js/vendor.min.js"></script>
<style>
.m3u2-wrap{max-width:1480px;margin:0 auto}.m3u2-hero{background:linear-gradient(135deg,#0b1f3a,#164c96 55%,#236ce5);color:#fff;border-radius:22px;padding:22px 24px;margin-bottom:20px;box-shadow:0 18px 50px rgba(8,35,78,.18)}
.m3u2-hero h3{margin:0;font-weight:800}.m3u2-hero p{margin:7px 0 0;opacity:.85}.m3u2-card{border:0;border-radius:18px;box-shadow:0 8px 28px rgba(15,23,42,.07);overflow:hidden}.m3u2-title{font-size:.78rem;letter-spacing:.11em;text-transform:uppercase;font-weight:800;color:#64748b;border-bottom:1px solid #eef2f7;padding-bottom:10px;margin-bottom:16px}
.m3u2-drop{border:2px dashed #cbd5e1;border-radius:16px;padding:26px 18px;text-align:center;cursor:pointer;background:#f8fafc;transition:.2s}.m3u2-drop:hover,.m3u2-drop.drag{border-color:#2f6fec;background:#eff6ff}.m3u2-drop i{font-size:38px;color:#2f6fec}.m3u2-source{display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid #e5e7eb;border-radius:12px;margin-top:8px;background:#fff}.m3u2-source .grow{flex:1;min-width:0}.m3u2-source .name{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.m3u2-source small{color:#64748b}.m3u2-progress{height:7px;background:#e5e7eb;border-radius:999px;overflow:hidden;margin-top:5px}.m3u2-progress>span{display:block;height:100%;width:0;background:linear-gradient(90deg,#22c55e,#2f6fec);transition:.2s}.m3u2-kpis{display:grid;grid-template-columns:repeat(6,minmax(110px,1fr));gap:10px;margin:14px 0}.m3u2-kpi{background:#fff;border:1px solid #e8edf5;border-radius:14px;padding:12px;text-align:center}.m3u2-kpi strong{display:block;font-size:1.35rem;color:#0f172a}.m3u2-kpi span{font-size:.72rem;text-transform:uppercase;color:#64748b;font-weight:700}
#m3u2Pip{position:fixed;right:18px;bottom:18px;width:430px;max-width:calc(100vw - 24px);background:#0f172a;color:#e2e8f0;border-radius:16px;box-shadow:0 22px 60px rgba(0,0,0,.4);z-index:10050;display:none;overflow:hidden}#m3u2Pip .head{padding:12px 14px;background:#081120;display:flex;justify-content:space-between;align-items:center;font-weight:800}#m3u2Pip .body{padding:14px}#m3u2Pip .bar{height:9px;background:#263449;border-radius:999px;overflow:hidden}#m3u2Pip .bar span{display:block;height:100%;width:0;background:linear-gradient(90deg,#22c55e,#38bdf8)}#m3u2Pip .stats{display:grid;grid-template-columns:1fr 1fr;gap:7px 14px;margin-top:12px;font-size:12px}#m3u2Pip .logs{margin-top:10px;background:#07101e;border-radius:10px;padding:8px;max-height:130px;overflow:auto;font:11px/1.5 monospace}.m3u2-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:12px}
@media(max-width:768px){.m3u2-kpis{grid-template-columns:repeat(2,1fr)}.m3u2-hero{border-radius:16px;padding:18px}.m3u2-card{border-radius:14px}#m3u2Pip{right:12px;bottom:12px;width:calc(100vw - 24px)}}
</style>
<div class="<?= $rSidebar ? 'content-page' : 'wrapper' ?> boxed-layout-ext"><div class="container-fluid m3u2-wrap">
<div class="m3u2-hero"><div class="d-flex flex-wrap justify-content-between align-items-center"><div><h3><i class="mdi mdi-cloud-upload-outline"></i> Importador M3U 2 Ultra</h3><p>Upload múltiplo • Live • Filmes • Séries/Episódios • EPG • TMDB • Anti-duplicidade • Buquês</p></div><a href="m3u_update_nodup.php" class="btn btn-light btn-sm mt-2 mt-md-0"><i class="mdi mdi-shield-check"></i> Importador original preservado</a></div></div>
<?php if (!$schemaStatus['ok']): ?><div class="alert alert-danger"><strong>Banco incompatível:</strong> <?=htmlspecialchars(implode(' | ', $schemaStatus['errors']))?></div><?php else: ?><div class="alert alert-success py-2"><i class="mdi mdi-database-check"></i> Estrutura do banco validada. Nenhuma alteração de tabela será feita por esta página.</div><?php endif; ?>
<div class="row">
<div class="col-xl-6"><div class="card m3u2-card"><div class="card-body"><div class="m3u2-title"><i class="mdi mdi-source-branch"></i> 1. Fontes múltiplas</div>
<div id="m3u2Drop" class="m3u2-drop"><i class="mdi mdi-cloud-upload"></i><h5 class="mt-2 mb-1">Selecione várias playlists</h5><div class="text-muted">.m3u, .m3u8 e .txt • upload em partes tolerante a repetição</div></div>
<input id="m3u2Files" type="file" multiple accept=".m3u,.m3u8,.txt" style="position:absolute;left:-10000px;opacity:0">
<div class="form-group mt-3"><label class="font-weight-bold">URLs remotas (uma por linha)</label><textarea id="m3u2Urls" class="form-control" rows="4" placeholder="https://servidor/lista1.m3u&#10;https://servidor/lista2.m3u"></textarea></div>
<div id="m3u2Sources"></div>
</div></div></div>
<div class="col-xl-6"><div class="card m3u2-card"><div class="card-body"><div class="m3u2-title"><i class="mdi mdi-tune"></i> 2. Destino e inteligência</div>
<div class="form-group"><label class="font-weight-bold">Servidor de Streaming</label><select id="m3u2Server" class="form-control" data-toggle="select2"><?php foreach($rServers as $s): ?><option value="<?=intval($s['id'])?>"<?php if (strcasecmp(trim((string)$s['server_name']), 'Main Server') === 0) echo ' selected'; ?>><?=htmlspecialchars($s['server_name'])?> (<?=htmlspecialchars($s['server_ip'])?>)</option><?php endforeach; ?></select></div>
<div class="form-group"><label class="font-weight-bold">Buquês de destino</label><select id="m3u2Bouquets" class="form-control select2-multiple" multiple data-toggle="select2" data-placeholder="Selecione os buquês..."><?php foreach($rBouquets as $b): ?><option value="<?=intval($b['id'])?>"><?=htmlspecialchars($b['bouquet_name'])?></option><?php endforeach; ?></select></div>
<div class="form-row"><div class="form-group col-md-8"><label class="font-weight-bold">Classificação</label><select id="m3u2Mode" class="form-control"><option value="auto">Automática rígida (recomendado)</option><option value="live">Forçar Canais</option><option value="movie">Forçar Filmes</option><option value="series">Forçar Séries/Episódios</option></select></div><div class="form-group col-md-4"><label class="font-weight-bold">Lote SQL</label><select id="m3u2BatchSize" class="form-control"><option>50</option><option selected>100</option><option>200</option><option>500</option></select></div></div>
<div class="row"><div class="col-md-6">
<div class="custom-control custom-switch mb-2"><input type="checkbox" class="custom-control-input" id="m3u2Update" checked><label class="custom-control-label" for="m3u2Update">Atualizar existentes</label></div>
<div class="custom-control custom-switch mb-2"><input type="checkbox" class="custom-control-input" id="m3u2Categories" checked><label class="custom-control-label" for="m3u2Categories">Criar categorias</label></div>
<div class="custom-control custom-switch mb-2"><input type="checkbox" class="custom-control-input" id="m3u2Direct" checked><label class="custom-control-label" for="m3u2Direct">Fonte direta</label></div>
</div><div class="col-md-6">
<div class="custom-control custom-switch mb-2"><input type="checkbox" class="custom-control-input" id="m3u2Epg" checked><label class="custom-control-label" for="m3u2Epg">Associar EPG aos canais</label></div>
<div class="custom-control custom-switch mb-2"><input type="checkbox" class="custom-control-input" id="m3u2Tmdb" checked><label class="custom-control-label" for="m3u2Tmdb">Enfileirar TMDB VOD/Séries</label></div>
<div class="custom-control custom-switch mb-2"><input type="checkbox" class="custom-control-input" id="m3u2Legacy"><label class="custom-control-label" for="m3u2Legacy">VOD legado (AVI/MOV/etc.)</label></div>
</div></div>
<div class="mt-3 d-flex flex-wrap gap-2"><button id="m3u2Analyze" class="btn btn-info mr-2"><i class="mdi mdi-magnify"></i> Enviar e analisar tudo</button><button id="m3u2Import" class="btn btn-primary" disabled><i class="mdi mdi-database-import"></i> Importar organizado</button></div>
</div></div></div></div>
<div id="m3u2Analysis" class="card m3u2-card" style="display:none"><div class="card-body"><div class="m3u2-title"><i class="mdi mdi-chart-box"></i> 3. Análise consolidada</div><div id="m3u2Kpis" class="m3u2-kpis"></div><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Fonte</th><th>Total</th><th>Live</th><th>Filmes</th><th>Episódios</th><th>Séries</th><th>Não classificados</th><th>Duplicados</th></tr></thead><tbody id="m3u2AnalysisRows"></tbody></table></div><div id="m3u2ReviewBox" class="mt-4" style="display:none"><div class="d-flex align-items-center justify-content-between flex-wrap mb-2"><div class="m3u2-title mb-0"><i class="mdi mdi-alert-circle-outline"></i> Itens para revisão</div><small class="text-muted">Amostra segura de até 100 itens. Nenhum item desta lista é gravado automaticamente.</small></div><div class="table-responsive"><table class="table table-sm table-hover"><thead><tr><th>Fonte</th><th>Título</th><th>Grupo</th><th>Ext.</th><th>Motivo</th><th>Confiança</th><th>URL mascarada</th></tr></thead><tbody id="m3u2ReviewRows"></tbody></table></div></div></div></div>
</div></div>
<div id="m3u2Pip"><div class="head"><span><i class="mdi mdi-cloud-sync"></i> Importação M3U 2</span><button id="m3u2PipHide" class="btn btn-sm btn-outline-light">—</button></div><div class="body"><div><span id="m3u2Pct">0%</span> <span id="m3u2Status" class="float-right">Preparando...</span></div><div class="bar mt-2"><span id="m3u2Bar"></span></div><div class="stats"><div>Processados <b id="m3u2Processed">0</b></div><div>Inseridos <b id="m3u2Inserted">0</b></div><div>Atualizados <b id="m3u2Updated">0</b></div><div>Ignorados <b id="m3u2Skipped">0</b></div><div>Erros <b id="m3u2Errors">0</b></div><div>Avisos <b id="m3u2Warnings">0</b></div></div><div id="m3u2Logs" class="logs"></div><div class="m3u2-actions"><button id="m3u2Cancel" class="btn btn-danger btn-sm">Cancelar</button><button id="m3u2Close" class="btn btn-secondary btn-sm">Fechar</button></div></div></div>
<script>
document.addEventListener('DOMContentLoaded',function(){
const CSRF=<?=json_encode($csrf)?>, CHUNK=1024*1024;
const $=id=>document.getElementById(id), files=$('m3u2Files'), drop=$('m3u2Drop'), sourcesBox=$('m3u2Sources'), btnAnalyze=$('m3u2Analyze'), btnImport=$('m3u2Import');
let batchToken=randomHex(16), sourceIds=[], sourceRows={}, analyzed=false, currentJob=null, pollTimer=null, sourceOrdinal=0;
function randomHex(bytes){const a=new Uint8Array(bytes);crypto.getRandomValues(a);return Array.from(a,b=>b.toString(16).padStart(2,'0')).join('')}
function size(n){n=Number(n)||0;const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return n.toFixed(i?1:0)+' '+u[i]}
function esc(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML}
function addSource(id,name,kind,total){sourceIds.push(id);sourceRows[id]={id,name,kind,total:total||0,done:0};const div=document.createElement('div');div.className='m3u2-source';div.id='src_'+id;div.innerHTML='<i class="mdi mdi-file-document-outline text-primary" style="font-size:24px"></i><div class="grow"><div class="name">'+esc(name)+'</div><small class="state">Aguardando</small><div class="m3u2-progress"><span></span></div></div><span class="badge badge-light">'+esc(kind)+'</span>';sourcesBox.appendChild(div)}
function sourceState(id,text,pct){const r=$('src_'+id);if(!r)return;r.querySelector('.state').textContent=text;r.querySelector('.m3u2-progress span').style.width=Math.max(0,Math.min(100,pct||0))+'%'}
async function post(fd){fd.append('csrf',CSRF);const r=await fetch('./m3u_update_nodup2.php',{method:'POST',body:fd,credentials:'same-origin'});let p;try{p=await r.json()}catch(e){throw new Error('Resposta inválida do servidor (HTTP '+r.status+'). Verifique logs PHP/Nginx.')}if(!r.ok||!p.ok)throw new Error(p.error||'Falha na operação.');return p}
function options(fd){fd.append('classification_mode',$('m3u2Mode').value);fd.append('batch_size',$('m3u2BatchSize').value);[['update_existing','m3u2Update'],['create_categories','m3u2Categories'],['direct_source','m3u2Direct'],['auto_epg','m3u2Epg'],['queue_tmdb','m3u2Tmdb'],['legacy_vod','m3u2Legacy']].forEach(x=>fd.append(x[0],$(x[1]).checked?'1':'0'))}
async function uploadFile(file,id){const total=Math.ceil(file.size/CHUNK);for(let i=0;i<total;i++){const blob=file.slice(i*CHUNK,Math.min(file.size,(i+1)*CHUNK));let tries=0;while(true){try{const fd=new FormData();fd.append('m3u2_action','upload_chunk');fd.append('batch_token',batchToken);fd.append('source_id',id);fd.append('chunk_index',i);fd.append('chunk_total',total);fd.append('file_size',file.size);fd.append('file_name',file.name);fd.append('chunk',blob,file.name+'.part');await post(fd);break}catch(e){tries++;if(tries>=4)throw e;await new Promise(r=>setTimeout(r,600*tries))}}const pct=Math.round((i+1)*100/total);sourceState(id,'Enviando '+pct+'% — '+size(Math.min(file.size,(i+1)*CHUNK))+' / '+size(file.size),pct)}}
async function uploadAll(){for(const file of Array.from(files.files||[])){const id=randomHex(8);addSource(id,file.name,'arquivo',file.size);sourceOrdinal++;await uploadFile(file,id);sourceState(id,'Upload concluído',100)}const urls=$('m3u2Urls').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);for(const url of urls){const id=randomHex(8);addSource(id,url,'URL',0);sourceState(id,'Baixando URL...',20);const fd=new FormData();fd.append('m3u2_action','fetch_remote');fd.append('batch_token',batchToken);fd.append('source_id',id);fd.append('url',url);await post(fd);sourceState(id,'Download concluído',100)}if(!sourceIds.length)throw new Error('Selecione pelo menos um arquivo ou informe uma URL.')}
function appendSources(fd){sourceIds.forEach(id=>fd.append('source_ids[]',id))}
function renderAnalysis(a){$('m3u2Analysis').style.display='block';const k=[['Fontes',a.sources],['Total',a.total],['Canais',a.live],['Filmes',a.movies],['Episódios',a.episodes],['Não classificados',a.unknown]];$('m3u2Kpis').innerHTML=k.map(x=>'<div class="m3u2-kpi"><strong>'+Number(x[1]||0).toLocaleString('pt-BR')+'</strong><span>'+x[0]+'</span></div>').join('');$('m3u2AnalysisRows').innerHTML=(a.per_source||[]).map(s=>'<tr><td>'+esc(s.name)+'</td><td>'+s.total+'</td><td>'+s.live+'</td><td>'+s.movies+'</td><td>'+s.episodes+'</td><td>'+s.series_titles+'</td><td>'+s.unknown+'</td><td>'+s.duplicates_in_source+'</td></tr>').join('');const review=a.unknown_samples||[];$('m3u2ReviewBox').style.display=review.length?'block':'none';$('m3u2ReviewRows').innerHTML=review.map(r=>'<tr><td>'+esc(r.source||'')+'</td><td>'+esc(r.title||'')+'</td><td>'+esc(r.group||'')+'</td><td>'+esc(r.ext||'—')+'</td><td><code>'+esc(r.reason||'')+'</code></td><td>'+Number(r.confidence||0)+'%</td><td><small>'+esc(r.url||'')+'</small></td></tr>').join('');$('m3u2Analysis').scrollIntoView({behavior:'smooth',block:'start'})}
async function analyze(){btnAnalyze.disabled=true;btnAnalyze.innerHTML='<i class="mdi mdi-loading mdi-spin"></i> Enviando...';try{if(!sourceIds.length)await uploadAll();const fd=new FormData();fd.append('m3u2_action','analyze');fd.append('batch_token',batchToken);appendSources(fd);options(fd);const p=await post(fd);renderAnalysis(p.analysis);analyzed=true;btnImport.disabled=false;btnAnalyze.innerHTML='<i class="mdi mdi-check"></i> Análise concluída'}catch(e){alert(e.message);btnAnalyze.disabled=false;btnAnalyze.innerHTML='<i class="mdi mdi-magnify"></i> Enviar e analisar tudo'}}
function pip(show){$('m3u2Pip').style.display=show?'block':'none'}
function updatePip(j){const exp=Number(j.expected||0),done=Number(j.processed||0),pct=exp?Math.min(100,Math.round(done*100/exp)):0;$('m3u2Pct').textContent=pct+'%';$('m3u2Bar').style.width=pct+'%';$('m3u2Status').textContent=(j.status||'')+' — '+(j.stage||'');['Processed','Inserted','Updated','Skipped','Errors','Warnings'].forEach(k=>{$('m3u2'+k).textContent=Number(j[k.toLowerCase()]||0).toLocaleString('pt-BR')});const logs=(j.logs||[]).slice(-30);$('m3u2Logs').innerHTML=logs.map(l=>'<div>['+esc(l.time)+'] '+esc(l.message)+'</div>').join('');$('m3u2Logs').scrollTop=$('m3u2Logs').scrollHeight;if(['sucesso','concluido_com_avisos','falha','cancelado'].includes(j.status)){clearInterval(pollTimer);$('m3u2Cancel').disabled=true}}
async function poll(){if(!currentJob)return;try{const r=await fetch('./m3u_update_nodup2.php?m3u2_status='+encodeURIComponent(currentJob),{credentials:'same-origin'});const p=await r.json();if(p.ok)updatePip(p.job)}catch(e){}}
async function startImport(){if(!analyzed)return;btnImport.disabled=true;pip(true);try{let fd=new FormData();fd.append('m3u2_action','prepare');fd.append('batch_token',batchToken);appendSources(fd);options(fd);let p=await post(fd);currentJob=p.job_id;pollTimer=setInterval(poll,800);await poll();fd=new FormData();fd.append('m3u2_action','start');fd.append('batch_token',batchToken);fd.append('job_id',currentJob);fd.append('servers',$('m3u2Server').value);Array.from($('m3u2Bouquets').selectedOptions).forEach(o=>fd.append('bouquets[]',o.value));appendSources(fd);options(fd);await post(fd);let done=false;while(!done){fd=new FormData();fd.append('m3u2_action','step');fd.append('job_id',currentJob);const step=await post(fd);done=!!step.done;if(step.job)updatePip(step.job);if(!done)await new Promise(r=>setTimeout(r,80))}await poll();btnImport.innerHTML='<i class="mdi mdi-check"></i> Importação concluída'}catch(e){await poll();alert(e.message);btnImport.disabled=false;btnImport.innerHTML='<i class="mdi mdi-database-import"></i> Tentar novamente'}}
drop.addEventListener('click',()=>files.click());drop.addEventListener('dragover',e=>{e.preventDefault();drop.classList.add('drag')});drop.addEventListener('dragleave',()=>drop.classList.remove('drag'));drop.addEventListener('drop',e=>{e.preventDefault();drop.classList.remove('drag');try{const dt=new DataTransfer();Array.from(e.dataTransfer.files).forEach(f=>dt.items.add(f));files.files=dt.files}catch(x){}drop.querySelector('h5').textContent=(files.files.length||0)+' arquivo(s) selecionado(s)'});files.addEventListener('change',()=>{drop.querySelector('h5').textContent=(files.files.length||0)+' arquivo(s) selecionado(s)';batchToken=randomHex(16);sourceIds=[];sourcesBox.innerHTML='';analyzed=false;btnImport.disabled=true});$('m3u2Urls').addEventListener('input',()=>{if(sourceIds.length){batchToken=randomHex(16);sourceIds=[];sourcesBox.innerHTML=''}analyzed=false;btnImport.disabled=true});$('m3u2Mode').addEventListener('change',()=>{analyzed=false;btnImport.disabled=true});btnAnalyze.addEventListener('click',analyze);btnImport.addEventListener('click',startImport);$('m3u2Cancel').addEventListener('click',async()=>{if(!currentJob||!confirm('Cancelar a importação em andamento?'))return;const fd=new FormData();fd.append('m3u2_action','cancel');fd.append('job_id',currentJob);try{await post(fd);await poll()}catch(e){alert(e.message)}});$('m3u2Close').addEventListener('click',()=>pip(false));$('m3u2PipHide').addEventListener('click',()=>{const body=$('m3u2Pip').querySelector('.body');body.style.display=body.style.display==='none'?'block':'none'});
});
</script>
<?php $GLOBALS['cs_player_vendor_loaded'] = true; include __DIR__ . '/footer.php'; ?>
<script src="assets/js/app.min.js"></script>
</body>
</html>

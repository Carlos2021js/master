<?php
/** Classificação rígida/inteligente conforme estrutura do CS PLAYER. */
class CSM3U2Classifier
{
    const LIVE_EXT = array('m3u8', 'ts', 'mpegts');
    const VOD_EXT = array('mp4', 'mkv');
    const LEGACY_VOD_EXT = array('avi', 'mov', 'wmv', 'flv', 'webm', 'm4v');

    public static function classify($url, $name, $group, array $options)
    {
        $mode = isset($options['classification']) ? (string)$options['classification'] : 'auto';
        if (!in_array($mode, array('auto', 'live', 'movie', 'series'), true)) $mode = 'auto';

        $ext = self::extension($url);
        $series = self::seriesInfo($name);
        $legacyVod = !empty($options['legacy_vod']);
        $isLiveExt = in_array($ext, self::LIVE_EXT, true);
        $isVodExt = in_array($ext, self::VOD_EXT, true) || ($legacyVod && in_array($ext, self::LEGACY_VOD_EXT, true));

        // Mesmo em modo manual, nunca força um tipo tecnicamente incompatível.
        if ($mode === 'live') {
            if (!$isLiveExt) return self::unknown($ext, 'modo_live_extensao_incompativel');
            return array('kind'=>'live','type'=>1,'ext'=>$ext,'series'=>null,'reason'=>'modo_live_validado','confidence'=>100);
        }
        if ($mode === 'movie') {
            if (!$isVodExt) return self::unknown($ext, 'modo_filme_extensao_incompativel');
            if ($series) return self::unknown($ext, 'modo_filme_padrao_episodio_detectado', $series);
            return array('kind'=>'movie','type'=>2,'ext'=>$ext,'series'=>null,'reason'=>'modo_filme_validado','confidence'=>100);
        }
        if ($mode === 'series') {
            if (!$isVodExt) return self::unknown($ext, 'modo_series_extensao_incompativel');
            if (!$series) return self::unknown($ext, 'modo_series_sem_padrao_episodio');
            return array('kind'=>'series','type'=>5,'ext'=>$ext,'series'=>$series,'reason'=>'modo_series_validado','confidence'=>100);
        }

        $groupKey = CSM3U2PlaylistParser::normalize($group);
        $isSeriesGroup = (bool)preg_match('/\b(series?|seriados?|novelas?|doramas?|animes?|desenhos?|temporadas?|epis[oó]dios?)\b/iu', $groupKey);
        $isMovieGroup = (bool)preg_match('/\b(filmes?|movies?|vod|cinema)\b/iu', $groupKey);
        $isLiveGroup = (bool)preg_match('/\b(live|tv|canais?|canais? ao vivo|radio|rádio)\b/iu', $groupKey);

        // Episódio exige extensão VOD permitida + padrão confiável de temporada/episódio.
        if ($series && $isVodExt) {
            return array('kind'=>'series','type'=>5,'ext'=>$ext,'series'=>$series,'reason'=>'padrao_episodio','confidence'=>100);
        }

        // Extensão de live é decisiva; o nome/grupo não transforma live em episódio.
        if ($isLiveExt) {
            return array('kind'=>'live','type'=>1,'ext'=>$ext,'series'=>null,'reason'=>$isLiveGroup ? 'grupo_live_extensao_live' : 'extensao_live','confidence'=>$isLiveGroup ? 100 : 95);
        }

        // MP4/MKV sem padrão de episódio pode ser filme. Grupo de séries sem episódio fica em revisão.
        if ($isVodExt) {
            if ($isSeriesGroup) return self::unknown($ext, 'grupo_series_sem_padrao_episodio');
            return array('kind'=>'movie','type'=>2,'ext'=>$ext,'series'=>null,'reason'=>$isMovieGroup ? 'grupo_filmes_extensao_vod' : 'extensao_vod_sem_episodio','confidence'=>$isMovieGroup ? 100 : 90);
        }

        // Grupo isolado nunca deve vencer uma extensão incompatível/ausente.
        if ($isLiveGroup || $isMovieGroup || $isSeriesGroup) {
            return self::unknown($ext, 'grupo_sugere_tipo_mas_extensao_nao_confirma');
        }
        return self::unknown($ext, 'extensao_nao_suportada');
    }

    private static function unknown($ext, $reason, $series = null)
    {
        return array('kind'=>'unknown','type'=>0,'ext'=>$ext,'series'=>$series,'reason'=>$reason,'confidence'=>0);
    }

    public static function seriesInfo($name)
    {
        $patterns = array(
            '/^(.*?)[\[\( ._\-]+S(\d{1,3})\s*E(\d{1,4})\b/i',
            '/^(.*?)[\[\( ._\-]+(\d{1,3})x(\d{1,4})\b/i',
            '/^(.*?)[._\-\s]+Season\s*(\d{1,3})[._\-\s]+Episode\s*(\d{1,4})\b/i',
            '/^(.*?)[._\-\s]+Temporada\s*(\d{1,3})[._\-\s]+(?:Epis[oó]dio|EP?)\s*(\d{1,4})\b/iu',
            '/^(.*?)[._\-\s]+T(\d{1,3})\s*(?:EP?|Epis[oó]dio)\s*(\d{1,4})\b/iu'
        );
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, (string)$name, $m)) {
                $title = CSM3U2PlaylistParser::cleanTitle($m[1]);
                if ($title === '') $title = 'Série sem nome';
                return array('title'=>$title,'season'=>max(1,(int)$m[2]),'episode'=>max(1,(int)$m[3]));
            }
        }
        return null;
    }

    public static function extension($url)
    {
        $path = (string)(parse_url((string)$url, PHP_URL_PATH) ?: '');
        return strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
    }
}

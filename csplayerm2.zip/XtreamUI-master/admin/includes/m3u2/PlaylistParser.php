<?php
/** Parser M3U streaming: não carrega playlists grandes inteiras na RAM. */
class CSM3U2PlaylistParser
{
    public static function iterate($path, $startOffset = 0)
    {
        $handle = @fopen($path, 'rb');
        if (!$handle) {
            throw new RuntimeException('Não foi possível abrir a playlist para leitura.');
        }
        $pending = null;
        $lineNo = 0;
        $startOffset = max(0, (int)$startOffset);
        if ($startOffset > 0 && fseek($handle, $startOffset, SEEK_SET) !== 0) {
            fclose($handle);
            throw new RuntimeException('Não foi possível retomar a playlist no checkpoint salvo.');
        }
        try {
            while (($line = fgets($handle)) !== false) {
                $lineNo++;
                $line = trim($line);
                if ($line === '' || stripos($line, '#EXTM3U') === 0) continue;
                if (stripos($line, '#EXTINF:') === 0) {
                    $pending = array('_line' => $lineNo);
                    if (preg_match_all('/([a-zA-Z0-9_-]+)="([^"]*)"/', $line, $m, PREG_SET_ORDER)) {
                        foreach ($m as $attr) {
                            $pending[strtolower($attr[1])] = trim($attr[2]);
                        }
                    }
                    $comma = strrpos($line, ',');
                    $pending['name'] = $comma !== false ? trim(substr($line, $comma + 1)) : '';
                    continue;
                }
                if ($pending !== null && preg_match('#^https?://#i', $line)) {
                    $pending['url'] = str_replace(' ', '%20', $line);
                    $pending['_next_offset'] = (int)ftell($handle);
                    if ($pending['name'] === '') {
                        $pending['name'] = self::nameFromUrl($line);
                    }
                    yield $pending;
                    $pending = null;
                }
            }
        } finally {
            fclose($handle);
        }
    }

    public static function normalize($value)
    {
        $value = preg_replace('/\s+/u', ' ', trim((string)$value));
        if (function_exists('mb_strtolower')) return mb_strtolower($value, 'UTF-8');
        return strtolower($value);
    }

    public static function cleanTitle($title)
    {
        $title = urldecode((string)$title);
        $title = preg_replace('/\.(m3u8|mpegts|ts|mp4|mkv|avi|mov|wmv|flv|webm|m4v)$/i', '', $title);
        $title = preg_replace('/[._]+/', ' ', $title);
        $title = preg_replace('/\s+/u', ' ', $title);
        return trim($title, " \t\n\r\0\x0B-_");
    }

    private static function nameFromUrl($url)
    {
        $path = parse_url($url, PHP_URL_PATH);
        $base = $path ? basename($path) : 'Item sem nome';
        return self::cleanTitle($base);
    }
}

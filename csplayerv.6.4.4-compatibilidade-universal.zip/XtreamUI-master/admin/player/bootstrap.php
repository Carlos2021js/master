<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('CSPLAYER_WEB');
    session_start();
}

define('CS_PLAYER_ROOT', __DIR__);
if (!defined('CS_PLAYER_INTERNAL')) { define('CS_PLAYER_INTERNAL', true); }
define('CS_PLAYER_SHARED_STORAGE', CS_PLAYER_ROOT . '/storage');
define('CS_PLAYER_CONFIG_FILE', CS_PLAYER_SHARED_STORAGE . '/config.php'); // legado/migração; não sobrescrever em atualizações
define('CS_PLAYER_RUNTIME_CONFIG_FILE', dirname(__DIR__) . '/logs/cs-player/web-player-config.php');

if (!function_exists('cs_player_write_log')) {
    function cs_player_log_path(): string {
        return dirname(__DIR__) . '/logs/cs-player/web-player.log';
    }

    function cs_player_write_log(string $event, array $context = [], string $level = 'error'): bool {
        $path = cs_player_log_path();
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $safe = [];
        foreach ($context as $key => $value) {
            $key = preg_replace('/[^a-zA-Z0-9_.-]/', '_', (string)$key);
            if (preg_match('/pass|password|token|secret|api[_-]?key/i', $key)) {
                $safe[$key] = '[REDACTED]';
            } elseif (is_scalar($value) || $value === null) {
                $safe[$key] = $value;
            } else {
                $safe[$key] = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }
        }
        $line = json_encode([
            'time' => date('c'),
            'level' => strtolower($level),
            'event' => (string)$event,
            'request_id' => substr(hash('sha256', session_id() . '|' . microtime(true) . '|' . random_int(0, PHP_INT_MAX)), 0, 12),
            'context' => $safe,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($line) && @file_put_contents($path, $line . PHP_EOL, FILE_APPEND | LOCK_EX) !== false;
    }
}

define('CS_PLAYER_LEGACY_CONFIG_FILE', CS_PLAYER_SHARED_STORAGE . '/config.json');

function cs_player_default_config(): array {
    return [
        'enabled' => true,
        'brand' => 'CS Player',
        'login_title' => 'CS Player',
        'login_subtitle' => 'Entre com sua assinatura para continuar',
        'home_title' => 'Início',
        'smart_login' => true,
        'dns_failover' => true,
        'pip_enabled' => true,
        'autoplay_next' => false,
        'remember_position' => true,
        'hls_retries' => 4,
        'stall_timeout' => 12,
        'request_timeout' => 8,
        'dns' => [],
        'provider_auto_fallback_m3u' => true,
        'm3u_cache_ttl' => 1800,
        'm3u_user_agent' => 'IPTVSmartersPro',
        'manual_highlights' => [],
        'hero_autoplay' => true,
        'hero_interval' => 8,
        'hero_order' => 'manual',
        'proxy_enabled' => true,
        'proxy_hls' => true,
        'proxy_vod' => true,
        'proxy_cast' => true,
        'proxy_log_enabled' => true,
        'proxy_retries' => 2,
        'proxy_connect_timeout' => 6,
        'proxy_read_timeout' => 30,
        'proxy_manifest_cache' => 2,
    ];
}

function cs_player_load_config(): array {
    $default = cs_player_default_config();
    $data = null;

    // Configuração dinâmica persistente: fica fora do diretório distribuído do Web Player
    // para não ser sobrescrita ao instalar uma nova versão do projeto.
    if (is_file(CS_PLAYER_RUNTIME_CONFIG_FILE)) {
        $loaded = include CS_PLAYER_RUNTIME_CONFIG_FILE;
        if (is_array($loaded)) $data = $loaded;
    }

    // Migração automática da configuração antiga. O arquivo legado permanece como fallback
    // até a gravação persistente ser concluída com sucesso.
    if (!is_array($data) && is_file(CS_PLAYER_CONFIG_FILE)) {
        $loaded = include CS_PLAYER_CONFIG_FILE;
        if (is_array($loaded)) {
            $data = $loaded;
            cs_player_save_config($loaded);
        }
    }
    if (!is_array($data) && is_file(CS_PLAYER_LEGACY_CONFIG_FILE)) {
        $raw = file_get_contents(CS_PLAYER_LEGACY_CONFIG_FILE);
        $legacy = json_decode((string)$raw, true);
        if (is_array($legacy)) {
            $data = $legacy;
            if (cs_player_save_config($legacy)) @unlink(CS_PLAYER_LEGACY_CONFIG_FILE);
        }
    }

    if (!is_array($data)) return $default;
    $cfg = array_replace($default, $data);
    $cfg['dns'] = is_array($cfg['dns'] ?? null) ? array_values($cfg['dns']) : [];
    $cfg['manual_highlights'] = is_array($cfg['manual_highlights'] ?? null) ? array_values($cfg['manual_highlights']) : [];
    return $cfg;
}

function cs_player_save_config(array $config): bool {
    $dir = dirname(CS_PLAYER_RUNTIME_CONFIG_FILE);
    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    $tmp = CS_PLAYER_RUNTIME_CONFIG_FILE . '.tmp';
    $php = "<?php\nif (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }\nreturn " . var_export($config, true) . ";\n";
    if (file_put_contents($tmp, $php, LOCK_EX) === false) return false;
    @chmod($tmp, 0640);
    if (!rename($tmp, CS_PLAYER_RUNTIME_CONFIG_FILE)) { @unlink($tmp); return false; }
    @chmod(CS_PLAYER_RUNTIME_CONFIG_FILE, 0640);
    return true;
}

function cs_player_normalize_dns(string $url): string {
    $url = trim($url);
    if ($url === '') return '';
    if (!preg_match('~^https?://~i', $url)) {
        // IPv6 sem colchetes é ambíguo para parse_url; trate-o como host puro.
        if (substr_count($url, ':') >= 2 && strpos($url, '/') === false && $url[0] !== '[') {
            $url = 'http://[' . trim($url, '[]') . ']';
        } else {
            $url = 'http://' . $url;
        }
    }
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) return '';
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    if (!in_array($scheme, ['http', 'https'], true)) return '';
    $host = strtolower(trim((string)$parts['host']));
    if ($host === '') return '';
    if (strpos($host, ':') !== false && $host[0] !== '[') $host = '[' . $host . ']';
    $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
    $path = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
    $path = preg_replace('~/player_api\\.php$~i', '', $path) ?? $path;
    return $scheme . '://' . $host . $port . rtrim($path, '/');
}

function cs_player_with_port(string $url, int $port): string {
    $url = cs_player_normalize_dns($url);
    if ($url === '' || $port < 1 || $port > 65535) return $url;
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['host']) || isset($parts['port'])) return $url;
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    $host = (string)$parts['host'];
    $path = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
    return $scheme . '://' . $host . ':' . $port . $path;
}

function cs_player_build_server_url(array $server): string {
    // Regra do CS PLAYER: o servidor interno principal conecta exclusivamente
    // por HTTP na porta 80. Portas/protocolos alternativos são permitidos
    // apenas para DNS externos cadastrados manualmente pelo administrador.
    $domain = trim((string)($server['domain_name'] ?? ''));
    $ip = trim((string)($server['server_ip'] ?? ''));
    $source = $domain !== '' ? $domain : $ip;
    if ($source === '') return '';

    $candidate = cs_player_normalize_dns($source);
    if ($candidate === '') return '';
    $parts = parse_url($candidate);
    if (!is_array($parts) || empty($parts['host'])) return '';

    $host = (string)$parts['host'];
    if (strpos($host, ':') !== false && $host[0] !== '[') $host = '[' . $host . ']';
    return 'http://' . $host . ':80';
}

function cs_player_server_url_candidates(array $server): array {
    $url = cs_player_build_server_url($server);
    return $url === '' ? [] : [$url];
}

function cs_player_server_dns_from_rows(array $servers): array {
    $out = [];
    foreach ($servers as $server) {
        if (!is_array($server)) continue;
        if (isset($server['status']) && (int)$server['status'] !== 1) continue;
        $candidates = cs_player_server_url_candidates($server);
        $url = $candidates[0] ?? '';
        if ($url === '') continue;
        $id = (int)($server['id'] ?? 0);
        $httpPort = 80;
        $httpsPort = 0;
        $name = trim((string)($server['server_name'] ?? ''));
        if ($name === '') $name = $id > 0 ? 'Servidor #' . $id : 'Servidor CS Player';
        $out[] = [
            'id' => 'server_' . ($id > 0 ? $id : substr(sha1($url), 0, 8)),
            'server_id' => $id,
            'name' => $name,
            'url' => $url,
            'fallback_urls' => $candidates,
            'http_port' => $httpPort,
            'https_port' => $httpsPort,
            'enabled' => true,
            'priority' => max(1, $id > 0 ? $id : count($out) + 1),
            'fixed' => true,
            'source' => 'streaming_servers',
        ];
    }
    return $out;
}

function cs_player_decode_main_config(string $path): ?array {
    if (!is_file($path)) return null;
    $raw = file_get_contents($path);
    if (!is_string($raw) || $raw === '') return null;
    $decoded = base64_decode($raw, true);
    if ($decoded === false) return null;
    $key = '5709650b0d7806074842c6de575025b1';
    $out = '';
    $keyLen = strlen($key);
    for ($i = 0, $len = strlen($decoded); $i < $len; $i++) {
        $out .= chr(ord($decoded[$i]) ^ ord($key[$i % $keyLen]));
    }
    $data = json_decode($out, true);
    return is_array($data) ? $data : null;
}


function cs_player_db(): ?mysqli {
    static $db = null;
    static $failed = false;
    if ($db instanceof mysqli) return $db;
    if ($failed || !class_exists('mysqli')) return null;
    $info = cs_player_decode_main_config('/home/xtreamcodes/iptv_xtream_codes/config');
    if (!is_array($info)) { $failed = true; return null; }
    mysqli_report(MYSQLI_REPORT_OFF);
    $conn = @new mysqli(
        (string)($info['host'] ?? 'localhost'),
        (string)($info['db_user'] ?? 'root'),
        (string)($info['db_pass'] ?? ''),
        (string)($info['db_name'] ?? 'xtream_iptvpro'),
        (int)($info['db_port'] ?? 3306)
    );
    if ($conn->connect_errno) { $failed = true; return null; }
    $conn->set_charset('utf8mb4');
    $db = $conn;
    return $db;
}

function cs_player_client_email_aliases(): array {
    $file = __DIR__ . '/data/client_email_aliases.json';
    if (!is_file($file)) return [];
    $data = json_decode((string)@file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function cs_player_alias_user_id(string $login): int {
    $login = strtolower(trim($login));
    if ($login === '' || strpos($login, '@') === false) return 0;
    foreach (cs_player_client_email_aliases() as $id => $email) {
        if (strtolower(trim((string)$email)) === $login) return (int)$id;
    }
    return 0;
}

function cs_player_users_has_email_column(mysqli $db): bool {
    static $has = null;
    if ($has !== null) return $has;
    $r = @$db->query("SHOW COLUMNS FROM `users` LIKE 'email'");
    $has = $r && $r->num_rows > 0;
    return $has;
}

function cs_player_local_user(string $username, string $password): ?array {
    $db = cs_player_db();
    if (!$db) return null;
    $login = trim($username);
    $aliasId = cs_player_alias_user_id($login);
    if ($aliasId > 0) {
        $stmt = $db->prepare('SELECT * FROM `users` WHERE `id`=? AND `password`=? LIMIT 1');
        if (!$stmt) return null;
        $stmt->bind_param('is', $aliasId, $password);
    } elseif (cs_player_users_has_email_column($db) && strpos($login, '@') !== false) {
        $stmt = $db->prepare('SELECT * FROM `users` WHERE (`username`=? OR LOWER(`email`)=LOWER(?)) AND `password`=? LIMIT 1');
        if (!$stmt) return null;
        $stmt->bind_param('sss', $login, $login, $password);
    } else {
        $stmt = $db->prepare('SELECT * FROM `users` WHERE `username`=? AND `password`=? LIMIT 1');
        if (!$stmt) return null;
        $stmt->bind_param('ss', $login, $password);
    }
    if (!$stmt->execute()) { $stmt->close(); return null; }
    $res = $stmt->get_result();
    $user = $res ? $res->fetch_assoc() : null;
    $stmt->close();
    if (!is_array($user)) return null;
    $now = time();
    if (isset($user['enabled']) && (int)$user['enabled'] !== 1) return null;
    if (isset($user['admin_enabled']) && (int)$user['admin_enabled'] !== 1) return null;
    if (!empty($user['exp_date']) && (int)$user['exp_date'] > 0 && (int)$user['exp_date'] < $now) return null;
    return $user;
}

function cs_player_remember_secret(): string {
    $seed = @file_get_contents('/home/xtreamcodes/iptv_xtream_codes/config');
    return hash('sha256', 'CSPLAYER-REMEMBER-V1|' . (string)$seed, true);
}

function cs_player_make_remember_token(array $user, int $days = 30): string {
    $id = (int)($user['id'] ?? 0);
    $exp = time() + max(1, $days) * 86400;
    $pwd = (string)($user['password'] ?? '');
    $payload = $id . '.' . $exp;
    $sig = hash_hmac('sha256', $payload . '|' . hash('sha256', $pwd), cs_player_remember_secret());
    return rtrim(strtr(base64_encode($payload . '.' . $sig), '+/', '-_'), '=');
}

function cs_player_user_from_remember_token(string $token): ?array {
    if ($token === '') return null;
    $raw = base64_decode(strtr($token, '-_', '+/'), true);
    if (!is_string($raw)) return null;
    $parts = explode('.', $raw, 3);
    if (count($parts) !== 3) return null;
    [$id, $exp, $sig] = $parts;
    if ((int)$id <= 0 || (int)$exp < time()) return null;
    $db = cs_player_db(); if (!$db) return null;
    $stmt = $db->prepare('SELECT * FROM `users` WHERE `id`=? LIMIT 1'); if (!$stmt) return null;
    $uid=(int)$id; $stmt->bind_param('i',$uid); $stmt->execute(); $res=$stmt->get_result(); $user=$res?$res->fetch_assoc():null; $stmt->close();
    if (!is_array($user)) return null;
    $payload = $uid . '.' . (int)$exp;
    $expected = hash_hmac('sha256', $payload . '|' . hash('sha256', (string)($user['password'] ?? '')), cs_player_remember_secret());
    if (!hash_equals($expected, (string)$sig)) return null;
    $now=time();
    if (isset($user['enabled']) && (int)$user['enabled'] !== 1) return null;
    if (isset($user['admin_enabled']) && (int)$user['admin_enabled'] !== 1) return null;
    if (!empty($user['exp_date']) && (int)$user['exp_date'] > 0 && (int)$user['exp_date'] < $now) return null;
    return $user;
}

function cs_player_json_ids($value): array {
    if (is_array($value)) $items = $value;
    else {
        $items = json_decode((string)$value, true);
        if (!is_array($items)) $items = [];
    }
    $out = [];
    foreach ($items as $id) { $id=(int)$id; if ($id>0) $out[$id]=$id; }
    return array_values($out);
}

function cs_player_local_permissions(array $user): array {
    $db = cs_player_db();
    $channels=[]; $series=[];
    $bouquets = cs_player_json_ids($user['bouquet'] ?? '[]');
    if (!$db || !$bouquets) return ['channels'=>[], 'series'=>[]];
    $in = implode(',', array_map('intval', $bouquets));
    $res = @$db->query("SELECT `bouquet_channels`,`bouquet_series` FROM `bouquets` WHERE `id` IN ($in)");
    if ($res) while ($row=$res->fetch_assoc()) {
        foreach (cs_player_json_ids($row['bouquet_channels'] ?? '[]') as $id) $channels[$id]=$id;
        foreach (cs_player_json_ids($row['bouquet_series'] ?? '[]') as $id) $series[$id]=$id;
    }
    return ['channels'=>array_values($channels), 'series'=>array_values($series)];
}

function cs_player_local_auth_response(array $user): array {
    $active = isset($user['active_cons']) ? (int)$user['active_cons'] : 0;
    return [
        'user_info'=>[
            'username'=>(string)($user['username']??''), 'auth'=>1,
            'status'=>'Active', 'exp_date'=>(string)($user['exp_date']??''),
            'is_trial'=>(string)($user['is_trial']??'0'),
            'active_cons'=>$active, 'created_at'=>(string)($user['created_at']??''),
            'max_connections'=>(string)($user['max_connections']??'1'),
            'allowed_output_formats'=>['m3u8','ts','rtmp']
        ],
        'server_info'=>[
            'url'=>(string)($_SERVER['HTTP_HOST']??''),
            'port'=>(string)($_SERVER['SERVER_PORT']??''),
            'https_port'=>'', 'server_protocol'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http',
            'timezone'=>date_default_timezone_get(), 'timestamp_now'=>time(), 'time_now'=>date('Y-m-d H:i:s')
        ]
    ];
}

function cs_player_local_categories(string $type, array $perms): array {
    $db=cs_player_db(); if(!$db) return [];
    $ids=[];
    if ($type==='series') {
        $series=$perms['series']??[]; if(!$series) return [];
        $in=implode(',',array_map('intval',$series));
        $res=@$db->query("SELECT DISTINCT sc.id,sc.category_name FROM series s JOIN stream_categories sc ON sc.id=s.category_id WHERE s.id IN ($in) AND sc.category_type='series' ORDER BY sc.cat_order,sc.category_name");
    } else {
        $channels=$perms['channels']??[]; if(!$channels) return [];
        $streamType=$type==='movie'?2:1; $catType=$type==='movie'?'movie':'live';
        $in=implode(',',array_map('intval',$channels));
        $res=@$db->query("SELECT DISTINCT sc.id,sc.category_name FROM streams s JOIN stream_categories sc ON sc.id=s.category_id WHERE s.id IN ($in) AND s.type=$streamType AND sc.category_type='$catType' ORDER BY sc.cat_order,sc.category_name");
    }
    if(!$res) return [];
    while($r=$res->fetch_assoc()) $ids[]=['category_id'=>(string)$r['id'],'category_name'=>(string)$r['category_name'],'parent_id'=>0];
    return $ids;
}

function cs_player_local_streams(string $type, array $perms, ?int $categoryId=null): array {
    $db=cs_player_db(); if(!$db) return [];
    $ids=$perms['channels']??[]; if(!$ids) return [];
    $streamType=$type==='movie'?2:1; $in=implode(',',array_map('intval',$ids));
    $where="s.id IN ($in) AND s.type=$streamType";
    if($categoryId && $categoryId>0) $where.=' AND s.category_id='.(int)$categoryId;
    $res=@$db->query("SELECT s.* FROM streams s WHERE $where ORDER BY s.stream_display_name ASC LIMIT 5000");
    if(!$res) return [];
    $out=[]; $num=0;
    while($r=$res->fetch_assoc()) {
        $props=json_decode((string)($r['movie_properties']??''),true); if(!is_array($props))$props=[];
        $ext=(string)($r['target_container']??($props['container_extension']??($type==='movie'?'mp4':'m3u8')));
        $icon=(string)($r['stream_icon']??($props['movie_image']??($props['cover_big']??'')));
        $item=['num'=>++$num,'name'=>(string)($r['stream_display_name']??''),'stream_type'=>$type==='movie'?'movie':'live','stream_id'=>(int)$r['id'],'stream_icon'=>$icon,'epg_channel_id'=>(string)($r['epg_id']??''),'added'=>(string)($r['added']??''),'category_id'=>(string)($r['category_id']??''),'custom_sid'=>(string)($r['custom_sid']??''),'tv_archive'=>(int)($r['tv_archive_duration']??0)>0?1:0,'direct_source'=>'','tv_archive_duration'=>(int)($r['tv_archive_duration']??0)];
        if($type==='movie'){$item['container_extension']=$ext;$item['rating']=(string)($props['rating']??'');$item['rating_5based']=$props['rating_5based']??0;}
        $out[]=$item;
    }
    return $out;
}

function cs_player_local_series(array $perms, ?int $categoryId=null): array {
    $db=cs_player_db(); if(!$db) return [];
    $ids=$perms['series']??[]; if(!$ids)return[]; $in=implode(',',array_map('intval',$ids));
    $where="id IN ($in)"; if($categoryId&&$categoryId>0)$where.=' AND category_id='.(int)$categoryId;
    $res=@$db->query("SELECT * FROM series WHERE $where ORDER BY title ASC LIMIT 5000"); if(!$res)return[];
    $out=[];$n=0; while($r=$res->fetch_assoc()){$out[]=['num'=>++$n,'name'=>(string)($r['title']??''),'series_id'=>(int)$r['id'],'cover'=>(string)($r['cover']??''),'plot'=>(string)($r['plot']??''),'cast'=>(string)($r['cast']??''),'director'=>(string)($r['director']??''),'genre'=>(string)($r['genre']??''),'releaseDate'=>(string)($r['releaseDate']??($r['release_date']??'')),'last_modified'=>(string)($r['last_modified']??''),'rating'=>(string)($r['rating']??''),'rating_5based'=>$r['rating_5based']??0,'backdrop_path'=>json_decode((string)($r['backdrop_path']??'[]'),true)?:[],'youtube_trailer'=>(string)($r['youtube_trailer']??''),'episode_run_time'=>(string)($r['episode_run_time']??''),'category_id'=>(string)($r['category_id']??'')];}
    return$out;
}

function cs_player_local_series_info(int $seriesId, array $perms): ?array {
    if(!in_array($seriesId,$perms['series']??[],true))return null; $db=cs_player_db(); if(!$db)return null;
    $res=@$db->query('SELECT * FROM series WHERE id='.(int)$seriesId.' LIMIT 1'); $series=$res?$res->fetch_assoc():null; if(!$series)return null;
    $eps=[];$seasons=[]; $q=@$db->query("SELECT se.*,s.stream_display_name,s.target_container,s.stream_icon,s.added FROM series_episodes se JOIN streams s ON s.id=se.stream_id WHERE se.series_id=".(int)$seriesId." ORDER BY se.season_num,se.sort");
    if($q) while($r=$q->fetch_assoc()){$season=(int)($r['season_num']??0);$eid=(int)($r['stream_id']??0);$eps[(string)$season][]=['id'=>$eid,'episode_num'=>(int)($r['sort']??0),'title'=>(string)($r['stream_display_name']??''),'container_extension'=>(string)($r['target_container']??'mp4'),'info'=>['movie_image'=>(string)($r['stream_icon']??'')],'added'=>(string)($r['added']??''),'season'=>$season,'direct_source'=>'']; if(!isset($seasons[$season]))$seasons[$season]=['air_date'=>'','episode_count'=>0,'id'=>$season,'name'=>'Temporada '.$season,'overview'=>'','season_number'=>$season,'cover'=>(string)($series['cover']??'')];$seasons[$season]['episode_count']++;}
    return ['seasons'=>array_values($seasons),'info'=>['name'=>(string)($series['title']??''),'cover'=>(string)($series['cover']??''),'plot'=>(string)($series['plot']??''),'cast'=>(string)($series['cast']??''),'director'=>(string)($series['director']??''),'genre'=>(string)($series['genre']??''),'releaseDate'=>(string)($series['releaseDate']??($series['release_date']??'')),'rating'=>(string)($series['rating']??'')],'episodes'=>$eps];
}

function cs_player_local_api(string $username,string $password,string $action='',array $extra=[]): ?array {
    $user=cs_player_local_user($username,$password); if(!$user)return null;
    if($action==='')return cs_player_local_auth_response($user);
    $perms=cs_player_local_permissions($user); $cat=isset($extra['category_id'])?(int)$extra['category_id']:null;
    if($action==='get_live_categories')return cs_player_local_categories('live',$perms);
    if($action==='get_vod_categories')return cs_player_local_categories('movie',$perms);
    if($action==='get_series_categories')return cs_player_local_categories('series',$perms);
    if($action==='get_live_streams')return cs_player_local_streams('live',$perms,$cat);
    if($action==='get_vod_streams')return cs_player_local_streams('movie',$perms,$cat);
    if($action==='get_series')return cs_player_local_series($perms,$cat);
    if($action==='get_series_info')return cs_player_local_series_info((int)($extra['series_id']??0),$perms);
    return [];
}

function cs_player_local_stream_source(int $streamId,string $username,string $password): ?string {
    $user=cs_player_local_user($username,$password); if(!$user)return null; $perms=cs_player_local_permissions($user);
    $db=cs_player_db(); if(!$db)return null;
    $allowed=in_array($streamId,$perms['channels']??[],true);
    if(!$allowed){$q=@$db->query('SELECT series_id FROM series_episodes WHERE stream_id='.(int)$streamId.' LIMIT 1');$e=$q?$q->fetch_assoc():null;$allowed=$e&&in_array((int)$e['series_id'],$perms['series']??[],true);}
    if(!$allowed)return null;
    $q=@$db->query('SELECT stream_source FROM streams WHERE id='.(int)$streamId.' LIMIT 1');$r=$q?$q->fetch_assoc():null;if(!$r)return null;
    $src=json_decode((string)($r['stream_source']??''),true); if(is_array($src)){foreach($src as $u){if(is_string($u)&&preg_match('~^https?://~i',$u))return $u;}}
    $raw=trim((string)($r['stream_source']??'')); return preg_match('~^https?://~i',$raw)?$raw:null;
}

function cs_player_internal_server_dns(): array {
    static $cache = null;
    if (is_array($cache)) return $cache;
    $cache = [];

    $cfgPath = '/home/xtreamcodes/iptv_xtream_codes/config';
    $info = cs_player_decode_main_config($cfgPath);
    if (!is_array($info)) return $cache;
    if (!class_exists('mysqli')) return $cache;

    mysqli_report(MYSQLI_REPORT_OFF);
    $db = @new mysqli(
        (string)($info['host'] ?? 'localhost'),
        (string)($info['db_user'] ?? 'root'),
        (string)($info['db_pass'] ?? ''),
        (string)($info['db_name'] ?? 'xtream_iptvpro'),
        (int)($info['db_port'] ?? 3306)
    );
    if ($db->connect_errno) return $cache;
    $db->set_charset('utf8mb4');
    $result = @$db->query("SELECT `id`,`server_name`,`domain_name`,`server_ip`,`http_broadcast_port`,`https_broadcast_port`,`status` FROM `streaming_servers` WHERE `status` = 1 ORDER BY `id` ASC");
    if ($result) {
        $rows = [];
        while ($row = $result->fetch_assoc()) $rows[] = $row;
        $cache = cs_player_server_dns_from_rows($rows);
        $result->free();
    }
    $db->close();
    return $cache;
}

function cs_player_active_dns(array $cfg): array {
    // Modo DNS 100% manual: o Web Player usa exclusivamente os DNS cadastrados
    // pelo administrador em Settings > Web Player. Nenhum streaming_server é
    // adicionado automaticamente ao login, catálogo, failover ou reprodução.
    $rows = [];
    $seen = [];
    foreach (($cfg['dns'] ?? []) as $idx => $row) {
        if (!is_array($row) || empty($row['enabled'])) continue;
        $url = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($url === '') continue;
        $key = strtolower(rtrim($url, '/'));
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $row['url'] = $url;
        $row['_index'] = 'manual:' . $idx;
        $row['fixed'] = false;
        $row['source'] = 'manual';
        $row['_sort'] = max(1, (int)($row['priority'] ?? ($idx + 1)));
        $rows[] = $row;
    }
    usort($rows, static fn($a, $b) => ((int)$a['_sort'] <=> (int)$b['_sort']));
    return array_values($rows);
}

function cs_player_manual_dns_row(string $url): ?array {
    $normalized = cs_player_normalize_dns($url);
    if ($normalized === '') return null;
    return [
        'id' => 'manual_' . substr(hash('sha256', $normalized), 0, 12),
        'server_id' => 0,
        'name' => 'DNS manual',
        'url' => $normalized,
        'enabled' => true,
        'priority' => 0,
        'fixed' => false,
        'source' => 'manual',
        '_index' => 'manual:' . substr(hash('sha256', $normalized), 0, 16),
        '_sort' => 0,
    ];
}

function cs_player_session_dns_list(array $cfg, ?string $manualUrl = null, ?bool $manualOnly = null): array {
    $manualUrl = $manualUrl !== null ? $manualUrl : (string)($_SESSION['cs_player_manual_dns'] ?? '');
    $manualOnly = $manualOnly !== null ? $manualOnly : !empty($_SESSION['cs_player_manual_only']);
    $manual = cs_player_manual_dns_row($manualUrl);
    $active = $manualOnly ? [] : cs_player_active_dns($cfg);
    if ($manual) {
        $manualKey = strtolower(rtrim($manual['url'], '/'));
        $active = array_values(array_filter($active, static fn($row) => strtolower(rtrim((string)($row['url'] ?? ''), '/')) !== $manualKey));
        array_unshift($active, $manual);
    }
    return $active;
}

function cs_player_http_json(string $url, int $timeout = 8): ?array {
    if (!function_exists('curl_init')) {
        cs_player_write_log('http_client_unavailable', ['host' => (string)(parse_url($url, PHP_URL_HOST) ?? '')], 'critical');
        return null;
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_USERAGENT => 'CSPlayer-Web/1.0',
        CURLOPT_HTTPHEADER => ['Accept: application/json', 'Cache-Control: no-cache'],
        CURLOPT_ENCODING => '',
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $error = (string)curl_error($ch);
    curl_close($ch);
    if (!is_string($body) || $code < 200 || $code >= 400) {
        cs_player_write_log('http_request_failed', ['host' => (string)(parse_url($url, PHP_URL_HOST) ?? ''), 'http_code' => $code, 'curl_error' => $error], 'error');
        return null;
    }
    $data = json_decode($body, true);
    if (!is_array($data)) {
        cs_player_write_log('http_invalid_json', ['host' => (string)(parse_url($url, PHP_URL_HOST) ?? ''), 'http_code' => $code], 'error');
        return null;
    }
    return $data;
}

function cs_player_api_call(string $dns, string $username, string $password, string $action = '', array $extra = []): ?array {
    $params = array_merge(['username' => $username, 'password' => $password], $extra);
    if ($action !== '') $params['action'] = $action;
    $cfg = cs_player_load_config();
    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));
    $endpoint = cs_player_selected_api_endpoint();
    return cs_player_http_json(rtrim($dns, '/') . '/' . $endpoint . '?' . http_build_query($params), $timeout);
}

/**
 * Consulta várias ações do Xtream em paralelo para a home do Web Player.
 * Quando curl_multi não estiver disponível, usa a mesma função sequencial
 * existente como fallback, sem alterar o contrato da API.
 */
function cs_player_api_batch(string $dns, string $username, string $password, array $requests): array {
    $cfg = cs_player_load_config();
    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));
    $result = [];
    if (!$requests) return $result;

    if (!function_exists('curl_multi_init') || !function_exists('curl_init')) {
        foreach ($requests as $key => $request) {
            $action = is_array($request) ? (string)($request[0] ?? '') : (string)$request;
            $extra = is_array($request) && isset($request[1]) && is_array($request[1]) ? $request[1] : [];
            $result[$key] = cs_player_api_call($dns, $username, $password, $action, $extra) ?? [];
        }
        return $result;
    }

    $multi = curl_multi_init();
    $handles = [];
    foreach ($requests as $key => $request) {
        $action = is_array($request) ? (string)($request[0] ?? '') : (string)$request;
        $extra = is_array($request) && isset($request[1]) && is_array($request[1]) ? $request[1] : [];
        $params = array_merge(['username' => $username, 'password' => $password], $extra);
        if ($action !== '') $params['action'] = $action;
        $endpoint = cs_player_selected_api_endpoint();
        $handle = curl_init(rtrim($dns, '/') . '/' . $endpoint . '?' . http_build_query($params));
        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT => 'CSPlayer-Web/1.0',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        curl_multi_add_handle($multi, $handle);
        $handles[(string)$key] = $handle;
    }

    $running = null;
    do {
        $status = curl_multi_exec($multi, $running);
        if ($running && $status === CURLM_OK) {
            $selected = curl_multi_select($multi, 0.25);
            if ($selected === -1) usleep(10000);
        }
    } while ($running && $status === CURLM_OK);

    foreach ($handles as $key => $handle) {
        $body = curl_multi_getcontent($handle);
        $code = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $decoded = is_string($body) ? json_decode($body, true) : null;
        $result[$key] = ($code >= 200 && $code < 400 && is_array($decoded)) ? $decoded : [];
        if ($result[$key] === []) {
            cs_player_write_log('batch_request_failed', ['host' => (string)(parse_url($dns, PHP_URL_HOST) ?? ''), 'action' => $action, 'http_code' => $code], 'error');
        }
        curl_multi_remove_handle($multi, $handle);
        curl_close($handle);
    }
    curl_multi_close($multi);
    return $result;
}

function cs_player_normalize_auth_payload(?array $data, string $username = ''): ?array {
    if (!$data) return null;
    if (isset($data['data']) && is_array($data['data']) && isset($data['data']['user_info']) && is_array($data['data']['user_info'])) {
        $data = array_merge($data, ['user_info' => $data['data']['user_info']]);
    }
    if (!isset($data['user_info']) || !is_array($data['user_info'])) {
        if (isset($data['user']) && is_array($data['user'])) {
            $data['user_info'] = $data['user'];
        } elseif (isset($data['auth']) || isset($data['status']) || isset($data['username'])) {
            $data['user_info'] = [
                'auth' => $data['auth'] ?? 1,
                'status' => $data['status'] ?? 'Active',
                'username' => $data['username'] ?? $username,
                'exp_date' => $data['exp_date'] ?? null,
                'active_cons' => $data['active_cons'] ?? null,
                'max_connections' => $data['max_connections'] ?? null,
            ];
        }
    }
    if (isset($data['user_info']) && is_array($data['user_info']) && empty($data['user_info']['username']) && $username !== '') {
        $data['user_info']['username'] = $username;
    }
    return $data;
}


function cs_player_dns_provider_mode(array $row): string {
    $mode = strtolower(trim((string)($row['provider_mode'] ?? 'auto')));
    return in_array($mode, ['auto','xtream','m3u'], true) ? $mode : 'auto';
}

function cs_player_m3u_output(array $row): string {
    $out = strtolower(trim((string)($row['m3u_output'] ?? 'mpegts')));
    return in_array($out, ['mpegts','hls'], true) ? $out : 'mpegts';
}

function cs_player_m3u_url(string $base, string $username, string $password, array $row = []): string {
    $base = rtrim(cs_player_normalize_dns($base), '/');
    if ($base === '') return '';
    $custom = trim((string)($row['m3u_path'] ?? 'get.php'));
    $custom = ltrim($custom, '/');
    if ($custom === '' || preg_match('~^https?://~i', $custom)) $custom = 'get.php';
    return $base . '/' . $custom . '?' . http_build_query([
        'username' => $username,
        'password' => $password,
        'type' => 'm3u_plus',
        'output' => cs_player_m3u_output($row),
    ]);
}

function cs_player_probe_m3u(string $base, string $username, string $password, array $row, int $timeout = 10): array {
    $url = cs_player_m3u_url($base, $username, $password, $row);
    if ($url === '' || !function_exists('curl_init')) return ['ok'=>false,'http_code'=>0,'curl_errno'=>0,'content_type'=>'','bytes'=>0];
    $sample = '';
    $limit = 131072;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_USERAGENT => trim((string)($row['user_agent'] ?? '')) ?: (string)(cs_player_load_config()['m3u_user_agent'] ?? 'IPTVSmartersPro'),
        CURLOPT_HTTPHEADER => ['Accept: application/x-mpegURL, audio/x-mpegurl, text/plain, */*'],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_WRITEFUNCTION => static function($ch, string $chunk) use (&$sample, $limit): int {
            $need = $limit - strlen($sample);
            if ($need <= 0) return 0;
            $take = substr($chunk, 0, $need);
            $sample .= $take;
            return strlen($chunk) > $need ? 0 : strlen($chunk);
        },
    ]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $ctype = (string)(curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?? '');
    $errno = (int)curl_errno($ch);
    curl_close($ch);
    $trim = ltrim($sample, "\xEF\xBB\xBF\r\n\t ");
    $ok = $code >= 200 && $code < 400 && stripos(substr($trim,0,2048), '#EXTM3U') !== false;
    return ['ok'=>$ok,'http_code'=>$code,'curl_errno'=>$errno,'content_type'=>$ctype,'bytes'=>strlen($sample),'url'=>$url];
}

function cs_player_m3u_cache_file(array $row, string $username): string {
    $dir = dirname(__DIR__) . '/logs/cs-player/m3u-cache';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $key = hash('sha256', strtolower((string)($row['url'] ?? '')) . '|' . $username);
    return $dir . '/catalog-' . $key . '.php';
}

function cs_player_m3u_clean_title(string $title): string {
    $title = preg_replace('/\s+/', ' ', trim($title)) ?? trim($title);
    return trim($title, " \t\n\r\0\x0B-|:");
}

function cs_player_m3u_episode_parts(string $title): ?array {
    $patterns = [
        '/^(.*?)[\s._-]+S(\d{1,2})\s*E(\d{1,3})(?:\b|[\s._-])/iu',
        '/^(.*?)[\s._-]+(\d{1,2})x(\d{1,3})(?:\b|[\s._-])/iu',
        '/^(.*?)[\s._-]+T(?:EMPORADA)?\s*(\d{1,2})[\s._-]*(?:EP|E|EPISODIO)\s*(\d{1,3})/iu',
    ];
    foreach ($patterns as $p) if (preg_match($p, $title, $m)) return ['series'=>cs_player_m3u_clean_title($m[1]),'season'=>(int)$m[2],'episode'=>(int)$m[3]];
    return null;
}

function cs_player_m3u_classify(string $group, string $title, string $url): string {
    $g = mb_strtolower($group, 'UTF-8');
    $plain = iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$g) ?: $g;
    if (preg_match('/(^|\b)(canais?|live|tv|radio)(\b|\s*\|)/i', $plain) || preg_match('~/live/~i', $url) || preg_match('~\.(?:ts|m3u8)(?:\?|$)~i', $url)) return 'live';
    if (cs_player_m3u_episode_parts($title) || preg_match('~/series/~i', $url) || preg_match('/\b(series?|novelas?|doramas?|temporadas?)\b/i', $plain)) return 'series';
    if (preg_match('~/movie/~i', $url) || preg_match('/\b(filmes?|movies?|vod|cinema|colec(?:ao|oes))\b/i', $plain) || preg_match('~\.(?:mp4|mkv|avi|mov)(?:\?|$)~i', $url)) return 'movie';
    return 'live';
}

function cs_player_m3u_download_catalog(array $row, string $username, string $password): ?array {
    if (!function_exists('curl_init')) return null;
    $url = cs_player_m3u_url((string)($row['url'] ?? ''), $username, $password, $row);
    if ($url === '') return null;
    $tmp = tempnam(sys_get_temp_dir(), 'csp_m3u_');
    if (!$tmp) return null;
    $fp = fopen($tmp, 'wb'); if (!$fp) { @unlink($tmp); return null; }
    $cfg = cs_player_load_config();
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_FILE=>$fp,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>min(8,(int)$cfg['request_timeout']),CURLOPT_TIMEOUT=>max(60,(int)$cfg['request_timeout']*12),CURLOPT_USERAGENT=>trim((string)($row['user_agent']??'')) ?: (string)($cfg['m3u_user_agent']??'IPTVSmartersPro'),CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>false]);
    curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); $err=(int)curl_errno($ch); curl_close($ch); fclose($fp);
    if ($code < 200 || $code >= 400 || $err) { @unlink($tmp); return null; }
    $fh=fopen($tmp,'rb'); if(!$fh){@unlink($tmp);return null;}
    $cats=['live'=>[],'movie'=>[],'series'=>[]]; $items=['live'=>[],'movie'=>[]]; $series=[]; $episodes=[]; $pending=null; $counter=1;
    while (($line=fgets($fh))!==false) {
        $line=trim($line); if($line==='')continue;
        if(str_starts_with($line,'#EXTINF:')) {
            $comma=strrpos($line,','); $title=$comma!==false?substr($line,$comma+1):''; $attrs=$comma!==false?substr($line,0,$comma):$line;
            $group='';$logo='';$tvg='';
            if(preg_match('/group-title="([^"]*)"/iu',$attrs,$m))$group=$m[1];
            if(preg_match('/tvg-logo="([^"]*)"/iu',$attrs,$m))$logo=$m[1];
            if(preg_match('/tvg-name="([^"]*)"/iu',$attrs,$m))$tvg=$m[1];
            $pending=['title'=>cs_player_m3u_clean_title($title?:$tvg),'group'=>trim($group),'logo'=>trim($logo)]; continue;
        }
        if($pending && !str_starts_with($line,'#')) {
            $mediaUrl=$line; $type=cs_player_m3u_classify($pending['group'],$pending['title'],$mediaUrl); $group=$pending['group']!==''?$pending['group']:'Sem categoria';
            $catId=substr(hash('crc32b',$type.'|'.$group),0,8); $cats[$type][$catId]=['category_id'=>$catId,'category_name'=>$group];
            $id=$counter++;
            if($type==='series') {
                $ep=cs_player_m3u_episode_parts($pending['title']); $seriesTitle=$ep['series']??$pending['title']; $sid=abs(crc32(mb_strtolower($seriesTitle,'UTF-8'))); if($sid===0)$sid=$id;
                if(!isset($series[$sid]))$series[$sid]=['series_id'=>$sid,'name'=>$seriesTitle,'cover'=>$pending['logo'],'plot'=>'','category_id'=>$catId,'releaseDate'=>''];
                $season=$ep['season']??1; $episode=$ep['episode']??(count($episodes[$sid][$season]??[])+1); $ext=pathinfo(parse_url($mediaUrl,PHP_URL_PATH)??'',PATHINFO_EXTENSION)?:'mp4';
                $episodes[$sid][$season][]=['id'=>$id,'episode_num'=>$episode,'title'=>$pending['title'],'container_extension'=>$ext,'info'=>['movie_image'=>$pending['logo'],'plot'=>''],'direct_source'=>$mediaUrl];
            } else {
                $ext=pathinfo(parse_url($mediaUrl,PHP_URL_PATH)??'',PATHINFO_EXTENSION); $record=['stream_id'=>$id,'name'=>$pending['title'],'stream_icon'=>$pending['logo'],'category_id'=>$catId,'container_extension'=>$ext,'direct_source'=>$mediaUrl,'stream_type'=>$type==='live'?'live':'movie'];
                $items[$type][]=$record;
            }
            $pending=null;
        }
    }
    fclose($fh); @unlink($tmp);
    $catalog=['generated_at'=>time(),'categories'=>['live'=>array_values($cats['live']),'movie'=>array_values($cats['movie']),'series'=>array_values($cats['series'])],'live'=>$items['live'],'movie'=>$items['movie'],'series'=>array_values($series),'episodes'=>$episodes];
    $file=cs_player_m3u_cache_file($row,$username); $php="<?php\nif (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }\nreturn ".var_export($catalog,true).";\n";
    if(@file_put_contents($file.'.tmp',$php,LOCK_EX)!==false){@chmod($file.'.tmp',0600);@rename($file.'.tmp',$file);@chmod($file,0600);} 
    cs_player_write_log('m3u_catalog_built',['host'=>(string)(parse_url((string)$row['url'],PHP_URL_HOST)??''),'live'=>count($items['live']),'movies'=>count($items['movie']),'series'=>count($series)],'info');
    return $catalog;
}

function cs_player_m3u_catalog(array $row, string $username, string $password): ?array {
    $file=cs_player_m3u_cache_file($row,$username); $ttl=max(300,min(86400,(int)(cs_player_load_config()['m3u_cache_ttl']??1800)));
    if(is_file($file) && (time()-(int)filemtime($file))<$ttl){$data=include $file;if(is_array($data))return $data;}
    return cs_player_m3u_download_catalog($row,$username,$password);
}

function cs_player_api_endpoint_candidates(): array {
    return ['player_api.php', 'panel_api.php'];
}

function cs_player_selected_api_endpoint(): string {
    $ep = basename((string)($_SESSION['cs_player_api_endpoint'] ?? 'player_api.php'));
    return in_array($ep, cs_player_api_endpoint_candidates(), true) ? $ep : 'player_api.php';
}

function cs_player_is_authenticated_response(?array $data): bool {
    $data = cs_player_normalize_auth_payload($data);
    if (!$data || !isset($data['user_info']) || !is_array($data['user_info'])) return false;
    $ui = $data['user_info'];
    if (isset($ui['auth']) && !in_array(strtolower((string)$ui['auth']), ['1','true','yes','active'], true)) return false;
    if (isset($ui['status']) && !in_array(strtolower(trim((string)$ui['status'])), ['active','1','enabled','true'], true)) return false;
    return !empty($ui['username']) || isset($ui['auth']) || isset($ui['status']);
}

/**
 * Valida o mesmo login em todos os DNS ativos em paralelo e retorna o primeiro
 * servidor na ordem de prioridade configurada que confirmou a assinatura.
 */
function cs_player_authenticate_dns(array $dnsList, string $username, string $password): ?array {
    if (!$dnsList) return null;
    $cfg=cs_player_load_config(); $timeout=max(3,min(30,(int)($cfg['request_timeout']??8))); $diagnostics=[];
    foreach($dnsList as $row){
        $base=cs_player_normalize_dns((string)($row['url']??'')); if($base==='')continue; $mode=cs_player_dns_provider_mode($row);
        if($mode!=='m3u'){
            foreach(cs_player_api_endpoint_candidates() as $endpoint){
                $params=http_build_query(['username'=>$username,'password'=>$password]);
                $target=rtrim($base,'/').'/'.$endpoint.'?'.$params;
                $ch=curl_init($target); curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>min(5,$timeout),CURLOPT_TIMEOUT=>$timeout,CURLOPT_USERAGENT=>trim((string)($row['user_agent']??''))?:'IPTVSmartersPro',CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>false]);
                $body=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$ctype=(string)(curl_getinfo($ch,CURLINFO_CONTENT_TYPE)??'');$errno=(int)curl_errno($ch);$ms=(int)round(((float)curl_getinfo($ch,CURLINFO_TOTAL_TIME))*1000);curl_close($ch);
                $decoded=is_string($body)?json_decode($body,true):null;$decoded=cs_player_normalize_auth_payload(is_array($decoded)?$decoded:null,$username);
                if($code>=200&&$code<400&&cs_player_is_authenticated_response($decoded)){$row['url']=$base;$row['api_endpoint']=$endpoint;$row['provider_mode_selected']='xtream';cs_player_write_log('external_dns_auth_selected',['host'=>(string)(parse_url($base,PHP_URL_HOST)??''),'port'=>(int)(parse_url($base,PHP_URL_PORT)??($base&&str_starts_with($base,'https')?443:80)),'endpoint'=>$endpoint,'provider'=>'xtream'],'info');return ['row'=>$row,'data'=>$decoded,'provider_mode'=>'xtream'];}
                $diagnostics[]=['host'=>(string)(parse_url($base,PHP_URL_HOST)??''),'port'=>(int)(parse_url($base,PHP_URL_PORT)??0),'http_code'=>$code,'json'=>is_array($decoded),'content_type'=>$ctype,'curl_errno'=>$errno,'time_ms'=>$ms,'endpoint'=>$endpoint,'provider'=>'xtream'];
            }
        }
        if($mode!=='xtream' && !empty($cfg['provider_auto_fallback_m3u'])){
            $probe=cs_player_probe_m3u($base,$username,$password,$row,max(8,$timeout));
            $diagnostics[]=['host'=>(string)(parse_url($base,PHP_URL_HOST)??''),'port'=>(int)(parse_url($base,PHP_URL_PORT)??0),'http_code'=>(int)($probe['http_code']??0),'json'=>false,'content_type'=>(string)($probe['content_type']??''),'curl_errno'=>(int)($probe['curl_errno']??0),'time_ms'=>0,'endpoint'=>'get.php','provider'=>'m3u_plus'];
            if(!empty($probe['ok'])){$row['url']=$base;$row['provider_mode_selected']='m3u';$row['api_endpoint']='get.php';$data=['user_info'=>['username'=>$username,'auth'=>1,'status'=>'Active']];cs_player_write_log('external_m3u_auth_selected',['host'=>(string)(parse_url($base,PHP_URL_HOST)??''),'port'=>(int)(parse_url($base,PHP_URL_PORT)??80),'output'=>cs_player_m3u_output($row)],'info');return ['row'=>$row,'data'=>$data,'provider_mode'=>'m3u'];}
        }
    }
    return ['error'=>'upstream_auth_failed','diagnostics'=>$diagnostics];
}

function cs_player_require_login(): void {
    if (empty($_SESSION['cs_player_auth']) || empty($_SESSION['cs_player_username']) || !isset($_SESSION['cs_player_dns_index'])) {
        header('Location: index.php');
        exit;
    }
}

function cs_player_json(array $payload, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function cs_player_session_dns(array $cfg, $requested = null): ?array {
    $active = cs_player_session_dns_list($cfg);
    if (!$active) return null;
    $index = $requested ?? ($_SESSION['cs_player_dns_index'] ?? '');
    foreach ($active as $row) {
        if ((string)$row['_index'] === (string)$index) {
            $sessionUrl = cs_player_normalize_dns((string)($_SESSION['cs_player_dns_url'] ?? ''));
            if ($sessionUrl !== '') {
                $allowed = [(string)($row['url'] ?? '')];
                if (is_array($row['fallback_urls'] ?? null)) $allowed = array_merge($allowed, $row['fallback_urls']);
                foreach ($allowed as $candidate) {
                    if (strtolower(rtrim(cs_player_normalize_dns((string)$candidate), '/')) === strtolower(rtrim($sessionUrl, '/'))) {
                        $row['url'] = $sessionUrl;
                        break;
                    }
                }
            }
            return $row;
        }
    }
    return $active[0];
}

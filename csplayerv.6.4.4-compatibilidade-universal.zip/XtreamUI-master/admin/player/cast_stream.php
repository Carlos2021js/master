<?php
require __DIR__ . '/cast_lib.php';
cs_cast_cors();
$token = (string)($_GET['token'] ?? ''); $entry = cs_cast_entry($token);
if (!$entry) { http_response_code(403); exit('Transmissão expirada'); }
$origin = (string)$entry['origin'];
$isHls = preg_match('~\.m3u8(?:$|\?)~i', $origin) || (($entry['type'] ?? '') === 'live' && !preg_match('~\.(?:mp4|mkv|avi|mov|webm|ts)(?:$|\?)~i', $origin));
if ($isHls) {
    [$code, $body, $ct, $effective] = cs_fetch_small($origin);
    if ($code >= 200 && $code < 400 && (stripos($ct, 'mpegurl') !== false || str_contains($body, '#EXTM3U'))) {
        header('Content-Type: application/vnd.apple.mpegurl'); header('Cache-Control: no-store');
        echo cs_cast_rewrite_manifest($body, $effective ?: $origin, $token, (string)$entry['secret']); exit;
    }
}
header('Cache-Control: no-store');
cs_stream_binary($origin);

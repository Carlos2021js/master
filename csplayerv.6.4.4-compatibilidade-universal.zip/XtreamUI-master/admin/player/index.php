<?php
require __DIR__ . '/bootstrap.php';
$cfg = cs_player_load_config();
if (empty($cfg['enabled'])) { http_response_code(503); exit('Web Player temporariamente indisponível.'); }
if (!empty($_SESSION['cs_player_auth'])) { header('Location: home.php'); exit; }
if (!empty($_COOKIE['cs_player_remember'])) {
    $remembered = cs_player_user_from_remember_token((string)$_COOKIE['cs_player_remember']);
    if ($remembered) {
        session_regenerate_id(true);
        $_SESSION['cs_player_auth'] = true;
        $_SESSION['cs_player_username'] = (string)$remembered['username'];
        $_SESSION['cs_player_password'] = (string)$remembered['password'];
        $_SESSION['cs_player_local_api'] = true;
        $_SESSION['cs_player_user_info'] = cs_player_local_auth_response($remembered)['user_info'] ?? [];
        $_SESSION['cs_player_dns_index'] = '0';
        $_SESSION['cs_player_dns_name'] = 'Servidor principal';
        $dns = cs_player_session_dns_list($cfg, '', false);
        $_SESSION['cs_player_dns_url'] = (string)($dns[0]['url'] ?? 'http://127.0.0.1');
        cs_player_write_log('remember_login_success', ['user_id'=>(int)$remembered['id']], 'info');
        header('Location: home.php'); exit;
    }
    setcookie('cs_player_remember', '', ['expires'=>time()-3600, 'path'=>dirname($_SERVER['SCRIPT_NAME'] ?? '/admin/player/') . '/', 'httponly'=>true, 'samesite'=>'Lax']);
}
$error = $_SESSION['cs_player_error'] ?? '';
unset($_SESSION['cs_player_error']);
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#080b12"><title><?=htmlspecialchars($cfg['brand'])?> · Web Player</title><script>try{document.documentElement.dataset.theme=localStorage.getItem('csplayer_theme')||(window.matchMedia&&window.matchMedia('(prefers-color-scheme: light)').matches?'light':'dark')}catch(e){document.documentElement.dataset.theme='dark'}</script><link rel="stylesheet" href="assets/player.css?v=20260819-v640"></head>
<body class="login-page"><div class="login-backdrop"></div><header class="login-header"><div class="brand-mark">CS</div><div class="brand-name"><?=htmlspecialchars($cfg['brand'])?></div><button id="themeToggle" class="theme-toggle" type="button" title="Ativar modo claro" aria-label="Ativar modo claro" aria-pressed="true">☀</button></header>
<main class="login-shell"><section class="login-card"><span class="eyebrow">WEB PLAYER</span><h1><?=htmlspecialchars($cfg['login_title'])?></h1><p><?=htmlspecialchars($cfg['login_subtitle'])?></p>
<?php if ($error): ?><div class="alert error"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form id="playerLoginForm" method="post" action="auth.php" autocomplete="on"><label>Usuário ou e-mail<input id="playerUsername" name="username" required autocomplete="username" placeholder="Seu usuário ou e-mail"></label><label>Senha<div class="password-wrap"><input id="password" type="password" name="password" required autocomplete="current-password" placeholder="Sua senha"><button type="button" class="ghost-icon" onclick="togglePass()" aria-label="Mostrar senha">Ver</button></div></label><button id="playerLoginButton" class="primary-btn" type="submit"><span>Entrar</span><small>sincronização automática de servidores</small></button></form>
<div class="login-features"><span>✓ Multi-DNS</span><span>✓ Reconexão</span><span>✓ PiP</span></div></section></main>
<script>function togglePass(){const i=document.getElementById('password');const b=document.querySelector('.password-wrap .ghost-icon');i.type=i.type==='password'?'text':'password';if(b)b.textContent=i.type==='password'?'Ver':'Ocultar';}const loginTheme=document.getElementById('themeToggle');function applyLoginTheme(theme){const next=theme==='light'?'light':'dark';document.documentElement.dataset.theme=next;document.body.dataset.theme=next;try{localStorage.setItem('csplayer_theme',next)}catch(e){}if(loginTheme){loginTheme.textContent=next==='dark'?'☀':'☾';loginTheme.title=next==='dark'?'Ativar modo claro':'Ativar modo escuro';loginTheme.setAttribute('aria-label',loginTheme.title);loginTheme.setAttribute('aria-pressed',String(next==='dark'));}}applyLoginTheme(document.documentElement.dataset.theme==='light'?'light':'dark');loginTheme?.addEventListener('click',(event)=>{event.preventDefault();applyLoginTheme(document.documentElement.dataset.theme==='dark'?'light':'dark');});const loginForm=document.getElementById('playerLoginForm'),loginButton=document.getElementById('playerLoginButton'),loginUser=document.getElementById('playerUsername');try{const savedUser=localStorage.getItem('csplayer_remembered_user')||'';if(loginUser&&!loginUser.value)loginUser.value=savedUser;}catch(e){}loginForm?.addEventListener('submit',async(event)=>{if(loginForm.dataset.submitting==='1'){event.preventDefault();return;}loginForm.dataset.submitting='1';try{if(loginUser?.value)localStorage.setItem('csplayer_remembered_user',loginUser.value.trim());}catch(e){}loginButton?.setAttribute('disabled','disabled');loginButton?.classList.add('is-loading');if(loginButton){loginButton.querySelector('span').textContent='Entrando...';loginButton.querySelector('small').textContent='validando sua assinatura';}document.body.setAttribute('aria-busy','true');const PasswordCredentialApi=window.PasswordCredential;if(PasswordCredentialApi&&navigator.credentials&&typeof navigator.credentials.store==='function'){event.preventDefault();try{await navigator.credentials.store(new PasswordCredential({id:loginUser?.value||'',password:document.getElementById('password')?.value||'',name:loginUser?.value||''}));}catch(e){}loginForm.submit();}});window.addEventListener('pageshow',event=>{if(event.persisted){loginForm?.removeAttribute('data-submitting');loginButton?.removeAttribute('disabled');document.body.removeAttribute('aria-busy');}});</script></body></html>

<?php
/** Bootstrap do Importador M3U 2 - independente do m3u_update_nodup.php */
require_once __DIR__ . '/JobStore.php';
require_once __DIR__ . '/UploadManager.php';
require_once __DIR__ . '/PlaylistParser.php';
require_once __DIR__ . '/Classifier.php';
require_once __DIR__ . '/Schema.php';
require_once __DIR__ . '/ImportEngine.php';

if (!function_exists('cs_m3u2_owner')) {
    function cs_m3u2_owner()
    {
        $sid = session_id();
        if ($sid === '') $sid = 'sem-sessao';
        return hash('sha256', $sid);
    }
}
if (!function_exists('cs_m3u2_storage')) {
    function cs_m3u2_storage()
    {
        $dir = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'm3u2';
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new RuntimeException('Não foi possível criar admin/storage/m3u2.');
        }
        return $dir;
    }
}
if (!function_exists('cs_m3u2_json')) {
    function cs_m3u2_json(array $payload, $status = 200)
    {
        while (ob_get_level() > 0) @ob_end_clean();
        http_response_code((int)$status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}
if (!function_exists('cs_m3u2_bool')) {
    function cs_m3u2_bool($key, $default = false)
    {
        if (!isset($_POST[$key])) return (bool)$default;
        return in_array((string)$_POST[$key], array('1','true','on','yes'), true);
    }
}

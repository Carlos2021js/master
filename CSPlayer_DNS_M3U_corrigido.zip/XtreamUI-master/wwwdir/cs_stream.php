<?php
/**
 * CS PLAYER - gateway publico de reproducao para M3U e apps IPTV.
 * PHP 7.4+ | sem alterar banco
 *
 * Aceita query:
 *   /cs_stream.php?type=live&username=U&password=P&id=123&ext=ts
 * e, quando Nginx reescreve, os formatos Xtream classicos:
 *   /live/U/P/123.ts
 *   /movie/U/P/123.mp4
 *   /series/U/P/123.mp4
 */
declare(strict_types=1);

@ini_set('display_errors', '0');
@ini_set('log_errors', '1');
@set_time_limit(0);
@ignore_user_abort(true);

$bootstrap = dirname(__DIR__) . '/admin/player/bootstrap.php';
if (!is_file($bootstrap)) $bootstrap = '/home/xtreamcodes/iptv_xtream_codes/admin/player/bootstrap.php';
if (!is_file($bootstrap)) { http_response_code(503); exit('CS PLAYER indisponivel'); }
require_once $bootstrap;

function cs_public_log(string $event, array $ctx = [], string $level = 'info'): void {
    if (function_exists('cs_player_write_log')) {
        $safe = [];
        foreach ($ctx as $k=>$v) {
            if (preg_match('/pass|password|token|secret/i',(string)$k)) $safe[$k]='[REDACTED]';
            elseif (is_scalar($v) || $v === null) $safe[$k]=$v;
        }
        cs_player_write_log($event,$safe,$level);
    }
}

function cs_public_headers(): void {
    header('X-CS-Player-Stream: public-v1');
    header('X-Accel-Buffering: no');
    header('Cache-Control: no-store');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, HEAD, OPTIONS');
    header('Access-Control-Allow-Headers: Range, Accept, Origin, Content-Type');
    header('Access-Control-Expose-Headers: Content-Length, Content-Range, Accept-Ranges, Content-Type');
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'OPTIONS') { http_response_code(204); exit; }
}

function cs_public_abs_url(string $base, string $ref): string {
    $ref=trim($ref);
    if ($ref==='' || preg_match('~^https?://~i',$ref)) return $ref;
    $b=parse_url($base); if(!is_array($b)) return $ref;
    $scheme=(string)($b['scheme']??'http'); $host=(string)($b['host']??''); $port=isset($b['port'])?':'.(int)$b['port']:'';
    if (isset($ref[0]) && $ref[0]==='/') return $scheme.'://'.$host.$port.$ref;
    $path=(string)($b['path']??'/'); $dir=preg_replace('~/[^/]*$~','/',$path);
    return $scheme.'://'.$host.$port.$dir.$ref;
}

function cs_public_allow_legacy_tls(): bool {
    static $value = null;
    if ($value === null) {
        $cfg = function_exists('cs_player_load_config') ? cs_player_load_config() : [];
        $value = function_exists('cs_player_bool') ? cs_player_bool($cfg['allow_legacy_tls'] ?? false, false) : !empty($cfg['allow_legacy_tls']);
    }
    return (bool)$value;
}

function cs_public_request_headers(string $ua): array {
    $headers=['Accept: */*','Connection: keep-alive','User-Agent: '.preg_replace('/[\r\n]+/',' ',$ua)];
    if (!empty($_SERVER['HTTP_REFERER'])) $headers[]='Referer: '.preg_replace('/[\r\n]+/',' ',(string)$_SERVER['HTTP_REFERER']);
    return $headers;
}

function cs_public_probe(string $url, string $ua, string $ext): array {
    $isHls=$ext==='m3u8' || (bool)preg_match('~\.m3u8(?:$|[?#])~i',$url);
    $headers=cs_public_request_headers($ua);
    if(!$isHls) $headers[]='Range: bytes=0-1';
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_TIMEOUT=>10,CURLOPT_HTTPHEADER=>$headers,CURLOPT_SSL_VERIFYPEER=>!cs_public_allow_legacy_tls(),CURLOPT_SSL_VERIFYHOST=>cs_public_allow_legacy_tls()?0:2,CURLOPT_ENCODING=>'']);
    if(defined('CURLOPT_IPRESOLVE') && defined('CURL_IPRESOLVE_V4')) curl_setopt($ch,CURLOPT_IPRESOLVE,CURL_IPRESOLVE_V4);
    if(!$isHls) curl_setopt($ch,CURLOPT_RANGE,'0-1');
    $body=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); $ct=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE); $effective=(string)curl_getinfo($ch,CURLINFO_EFFECTIVE_URL); $err=(string)curl_error($ch); curl_close($ch);
    $ok=$code>=200&&$code<400;
    if($isHls){$sample=is_string($body)?ltrim($body):'';$ok=$ok&&(stripos($ct,'mpegurl')!==false||strpos($sample,'#EXTM3U')===0);}
    return ['ok'=>$ok,'code'=>$code,'ct'=>$ct,'effective'=>$effective?:$url,'error'=>$err,'body'=>is_string($body)?$body:''];
}

function cs_public_hls(string $url, string $ua): void {
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_TIMEOUT=>25,CURLOPT_HTTPHEADER=>cs_public_request_headers($ua),CURLOPT_SSL_VERIFYPEER=>!cs_public_allow_legacy_tls(),CURLOPT_SSL_VERIFYHOST=>cs_public_allow_legacy_tls()?0:2,CURLOPT_ENCODING=>'']);
    if(defined('CURLOPT_IPRESOLVE')&&defined('CURL_IPRESOLVE_V4')) curl_setopt($ch,CURLOPT_IPRESOLVE,CURL_IPRESOLVE_V4);
    $body=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$ct=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE);$effective=(string)curl_getinfo($ch,CURLINFO_EFFECTIVE_URL);$err=(string)curl_error($ch);curl_close($ch);
    if(!is_string($body)||$code<200||$code>=400){http_response_code($code?:502);cs_public_log('public_hls_origin_failed',['http_code'=>$code,'host'=>(string)(parse_url($url,PHP_URL_HOST)??''),'curl_error'=>$err],'warning');exit('Falha HLS');}
    $base=$effective?:$url;
    $lines=preg_split('/\r?\n/',$body);$out=[];
    foreach($lines as $line){
        if($line!=='' && isset($line[0]) && $line[0]!=='#') $line=cs_public_abs_url($base,trim($line));
        elseif(strpos($line,'URI="')!==false) $line=preg_replace_callback('/URI="([^"]+)"/',function($m)use($base){return 'URI="'.cs_public_abs_url($base,$m[1]).'"';},$line);
        $out[]=$line;
    }
    http_response_code(200);header('Content-Type: application/vnd.apple.mpegurl');echo implode("\n",$out);exit;
}

function cs_public_binary(string $url, string $ua): void {
    $clientRange=trim((string)($_SERVER['HTTP_RANGE']??''));
    $modes=$clientRange!==''?[$clientRange,'']:[''];
    $lastCode=0;$lastErr='';
    foreach($modes as $rangeIndex=>$range){
        $headers=cs_public_request_headers($ua);if($range!=='')$headers[]='Range: '.$range;
        $bytes=0;$ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_TIMEOUT=>0,CURLOPT_LOW_SPEED_LIMIT=>128,CURLOPT_LOW_SPEED_TIME=>30,CURLOPT_HTTPHEADER=>$headers,CURLOPT_SSL_VERIFYPEER=>!cs_public_allow_legacy_tls(),CURLOPT_SSL_VERIFYHOST=>cs_public_allow_legacy_tls()?0:2,CURLOPT_ENCODING=>'',CURLOPT_HEADERFUNCTION=>function($ch,$header){$line=strtolower($header);$trim=trim($header);if(preg_match('~^HTTP/\S+\s+(\d{3})~i',$trim,$m)){if((int)$m[1]>=200&&(int)$m[1]<400&&!headers_sent())http_response_code((int)$m[1]);}if(strpos($line,'content-type:')===0||strpos($line,'content-length:')===0||strpos($line,'content-range:')===0||strpos($line,'accept-ranges:')===0){if(!headers_sent())header(trim($header),true);}return strlen($header);},CURLOPT_WRITEFUNCTION=>function($ch,$data)use(&$bytes){$bytes+=strlen($data);echo $data;@flush();return strlen($data);}]);
        if(defined('CURLOPT_IPRESOLVE')&&defined('CURL_IPRESOLVE_V4'))curl_setopt($ch,CURLOPT_IPRESOLVE,CURL_IPRESOLVE_V4);
        curl_exec($ch);$lastCode=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$lastErr=(string)curl_error($ch);curl_close($ch);
        if($lastCode>=200&&$lastCode<400&&$lastErr==='')exit;
        if($bytes>0)break;
        if($range!==''&&$rangeIndex===0)cs_public_log('public_stream_retry_without_range',['host'=>(string)(parse_url($url,PHP_URL_HOST)??''),'http_code'=>$lastCode],'warning');
    }
    if(!headers_sent())http_response_code($lastCode?:502);cs_public_log('public_stream_origin_failed',['host'=>(string)(parse_url($url,PHP_URL_HOST)??''),'http_code'=>$lastCode,'curl_error'=>$lastErr],'warning');exit;
}

cs_public_headers();
$username=trim((string)($_GET['username']??''));$password=(string)($_GET['password']??'');$type=strtolower((string)($_GET['type']??'live'));$id=(int)($_GET['id']??0);$ext=strtolower(preg_replace('/[^a-z0-9]/i','',(string)($_GET['ext']??'')));
if(!in_array($type,['live','movie','series'],true))$type='live';
if($username===''||$password===''||$id<=0){http_response_code(400);exit('Requisicao invalida');}
$sources=function_exists('cs_player_local_stream_sources')?cs_player_local_stream_sources($id,$username,$password):[];
if(!$sources){http_response_code(401);cs_public_log('public_stream_auth_or_source_failed',['username_hash'=>substr(hash('sha256',$username),0,12),'stream_id'=>$id,'type'=>$type],'warning');exit('Nao autorizado');}
$cfg=function_exists('cs_player_load_config')?cs_player_load_config():[];$ua=trim((string)($cfg['m3u_user_agent']??'IPTVSmartersPro'));if($ua==='')$ua='IPTVSmartersPro';
$selected='';$selectedProbe=[];
foreach($sources as $source){$probe=cs_public_probe((string)$source,$ua,$ext);if(!empty($probe['ok'])){$selected=(string)$source;$selectedProbe=$probe;break;}$selectedProbe=$probe;}
if($selected===''){http_response_code((int)($selectedProbe['code']??0)?:502);cs_public_log('public_stream_sources_exhausted',['stream_id'=>$id,'type'=>$type,'source_count'=>count($sources),'http_code'=>(int)($selectedProbe['code']??0)],'error');exit('Origem indisponivel');}
$effective=(string)($selectedProbe['effective']??$selected);$ct=(string)($selectedProbe['ct']??'');$isHls=$ext==='m3u8'||stripos($ct,'mpegurl')!==false||(bool)preg_match('~\.m3u8(?:$|[?#])~i',$effective);
cs_public_log('public_stream_selected',['stream_id'=>$id,'type'=>$type,'origin_host'=>(string)(parse_url($selected,PHP_URL_HOST)??''),'format'=>$isHls?'m3u8':($ext?:'binary')],'info');
if($isHls)cs_public_hls($selected,$ua);
cs_public_binary($selected,$ua);

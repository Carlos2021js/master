<?php
require __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/tmdb_service.php';
if (empty($_SESSION['cs_player_auth'])) cs_player_json(['ok'=>false,'message'=>'Sessão expirada'],401);
$cfg = cs_player_load_config();
$dnsRow = cs_player_session_dns($cfg);
if (!$dnsRow) {
    cs_player_write_log('web_player_dns_unavailable', ['action' => (string)($_GET['action'] ?? 'home')], 'error');
    cs_player_json(['ok'=>false,'message'=>'DNS indisponível'],503);
}
$dns = $dnsRow['url']; $u=(string)$_SESSION['cs_player_username']; $p=(string)$_SESSION['cs_player_password'];
$local = !empty($_SESSION['cs_player_local_api']);
$providerMode = (string)($_SESSION['cs_player_provider_mode'] ?? 'xtream');
$m3uCatalog = null;
if (!$local && $providerMode === 'm3u') {
    $m3uCatalog = cs_player_m3u_catalog($dnsRow, $u, $p);
    if (!is_array($m3uCatalog)) cs_player_json(['ok'=>false,'message'=>'Não foi possível carregar a lista M3U deste servidor.'],502);
}


function cs_player_cache_external_sources(array $items, string $type): void {
    if (!empty($_SESSION['cs_player_local_api'])) return;
    if (!isset($_SESSION['cs_player_external_sources']) || !is_array($_SESSION['cs_player_external_sources'])) $_SESSION['cs_player_external_sources'] = [];
    foreach ($items as $item) {
        if (!is_array($item)) continue;
        $id = (int)($item['stream_id'] ?? $item['id'] ?? 0);
        if ($id <= 0) continue;
        $direct = trim((string)($item['direct_source'] ?? $item['stream_url'] ?? ''));
        if ($direct !== '' && !preg_match('~^https?://~i', $direct)) $direct = '';
        $_SESSION['cs_player_external_sources'][$type.':'.$id] = [
            'direct_source' => $direct,
            'container_extension' => preg_replace('/[^a-zA-Z0-9]/', '', (string)($item['container_extension'] ?? $item['container'] ?? '')),
            'stream_type' => (string)($item['stream_type'] ?? ''),
            'epg_channel_id' => (string)($item['epg_channel_id'] ?? $item['epg_id'] ?? ''),
            'ts' => time(),
        ];
    }
    if (count($_SESSION['cs_player_external_sources']) > 1200) {
        $_SESSION['cs_player_external_sources'] = array_slice($_SESSION['cs_player_external_sources'], -900, null, true);
    }
}

function cs_player_is_adult_category_name(string $name): bool {
    $name = mb_strtolower(trim($name), 'UTF-8');
    if ($name === '') return false;
    $plain = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $name) ?: $name;
    return (bool)preg_match('/(^|[^a-z0-9])(adulto?s?|xxx|porno|porn|erotico?s?|erotic|sexo|sex|18\+)([^a-z0-9]|$)/i', $plain);
}

function cs_player_category_sort_key(array $category): array {
    $name = trim((string)($category['category_name'] ?? ''));
    $lower = mb_strtolower($name, 'UTF-8');
    $plain = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $lower) ?: $lower;
    $plain = preg_replace('/\s+/', ' ', $plain) ?? $plain;

    // Lançamentos sempre vêm primeiro. O ano é dinâmico e decrescente:
    // Lançamentos 2027, 2026, 2025... sem depender de alteração no banco.
    $isRelease = (bool)preg_match('/\blancamentos?\b/i', $plain);
    $year = 0;
    if (preg_match('/\b((?:19|20)\d{2})\b/', $plain, $m)) {
        $year = (int)$m[1];
    }
    if ($isRelease) {
        // Sem ano continua entre lançamentos, mas depois dos lançamentos datados.
        return [0, $year > 0 ? -$year : 0, $plain];
    }

    // Novidades/Recentes imediatamente depois dos lançamentos.
    if (preg_match('/\b(novidades?|recentes?|mais recentes|novos?)\b/i', $plain)) {
        return [1, 0, $plain];
    }

    return [2, 0, $plain];
}

function cs_player_sort_categories(array $categories): array {
    $indexed = [];
    foreach (array_values($categories) as $i => $category) {
        if (!is_array($category)) continue;
        $category['_cs_original_order'] = $i;
        $indexed[] = $category;
    }
    usort($indexed, static function(array $a, array $b): int {
        $ka = cs_player_category_sort_key($a);
        $kb = cs_player_category_sort_key($b);
        for ($i = 0; $i < 3; $i++) {
            if ($ka[$i] === $kb[$i]) continue;
            return $ka[$i] <=> $kb[$i];
        }
        return ((int)($a['_cs_original_order'] ?? 0)) <=> ((int)($b['_cs_original_order'] ?? 0));
    });
    foreach ($indexed as &$category) unset($category['_cs_original_order']);
    unset($category);
    return $indexed;
}

function cs_player_filter_adult_movies(array $categories, array $movies): array {
    $blocked = [];
    $cleanCategories = [];
    foreach ($categories as $category) {
        $id = (string)($category['category_id'] ?? '');
        $name = (string)($category['category_name'] ?? '');
        if ($id !== '' && cs_player_is_adult_category_name($name)) { $blocked[$id] = true; continue; }
        $cleanCategories[] = $category;
    }
    if (!$blocked) return [$cleanCategories, $movies, 0];
    $cleanMovies = []; $removed = 0;
    foreach ($movies as $movie) {
        $cat = (string)($movie['category_id'] ?? '');
        if ($cat !== '' && isset($blocked[$cat])) { $removed++; continue; }
        $cleanMovies[] = $movie;
    }
    return [$cleanCategories, $cleanMovies, $removed];
}

$action=(string)($_GET['action']??'home');
if ($action==='home') {
    if ($providerMode === 'm3u' && is_array($m3uCatalog)) {
        $batch = [
            'live_categories'=>$m3uCatalog['categories']['live']??[],
            'vod_categories'=>$m3uCatalog['categories']['movie']??[],
            'series_categories'=>$m3uCatalog['categories']['series']??[],
            'live_streams'=>$m3uCatalog['live']??[],
            'vod_streams'=>$m3uCatalog['movie']??[],
            'series'=>$m3uCatalog['series']??[],
        ];
    } elseif ($local) {
        $batch = [
            'live_categories' => cs_player_local_api($u,$p,'get_live_categories') ?? [],
            'vod_categories' => cs_player_local_api($u,$p,'get_vod_categories') ?? [],
            'series_categories' => cs_player_local_api($u,$p,'get_series_categories') ?? [],
            'live_streams' => cs_player_local_api($u,$p,'get_live_streams') ?? [],
            'vod_streams' => cs_player_local_api($u,$p,'get_vod_streams') ?? [],
            'series' => cs_player_local_api($u,$p,'get_series') ?? [],
        ];
    } else {
        $batch = cs_player_api_batch($dns, $u, $p, [
            'live_categories' => ['get_live_categories', []],
            'vod_categories' => ['get_vod_categories', []],
            'series_categories' => ['get_series_categories', []],
            'live_streams' => ['get_live_streams', []],
            'vod_streams' => ['get_vod_streams', []],
            'series' => ['get_series', []],
        ]);
    }
    $liveCats = $batch['live_categories'] ?? [];
    $vodCats = $batch['vod_categories'] ?? [];
    $seriesCats = $batch['series_categories'] ?? [];
    $live = $batch['live_streams'] ?? [];
    $vod = $batch['vod_streams'] ?? [];
    $series = $batch['series'] ?? [];
    if (!$local) {
        cs_player_cache_external_sources(is_array($live)?$live:[], 'live');
        cs_player_cache_external_sources(is_array($vod)?$vod:[], 'movie');
    }
    [$vodCats, $vod, $adultRemoved] = cs_player_filter_adult_movies(is_array($vodCats)?$vodCats:[], is_array($vod)?$vod:[]);
    $liveCats = cs_player_sort_categories(is_array($liveCats) ? $liveCats : []);
    $vodCats = cs_player_sort_categories(is_array($vodCats) ? $vodCats : []);
    $seriesCats = cs_player_sort_categories(is_array($seriesCats) ? $seriesCats : []);
    if ($adultRemoved > 0) cs_player_write_log('web_player_adult_movies_hidden', ['removed'=>$adultRemoved], 'info');
    $failed = [];
    foreach (['live_categories'=>$liveCats, 'vod_categories'=>$vodCats, 'series_categories'=>$seriesCats, 'live_streams'=>$live, 'vod_streams'=>$vod, 'series'=>$series] as $name => $value) {
        if ($value === []) $failed[] = $name;
    }
    if ($failed) {
        cs_player_write_log('web_player_home_partial', ['host' => (string)($dnsRow['url'] ?? ''), 'failed_actions' => $failed], 'warning');
    }
    $manualHighlights=[];
    foreach(($cfg['manual_highlights']??[]) as $h){
        if(!is_array($h)||empty($h['enabled']))continue; $type=(string)($h['type']??''); $id=(int)($h['id']??0); $pool=$type==='live'?$live:($type==='movie'?$vod:$series); $found=null;
        foreach((array)$pool as $item){$itemId=$type==='series'?(int)($item['series_id']??0):(int)($item['stream_id']??0);if($itemId===$id){$found=$item;break;}}
        if(!$found)continue; $found['_type']=$type; $found['_manual_highlight']=true; $found['_highlight_image']=(string)($h['custom_image']??''); $found['_highlight_synopsis']=(string)($h['custom_synopsis']??''); $found['_highlight_sort']=(int)($h['sort']??100); $found['_delivery_mode']=(string)($h['delivery_mode']??'inherit'); $found['_ad_mode']=(string)($h['ad_mode']??'inherit'); $found['_ad_url']=(string)($h['ad_url']??''); $manualHighlights[]=$found;
    }
    usort($manualHighlights,static fn($a,$b)=>(int)($a['_highlight_sort']??100)<=>(int)($b['_highlight_sort']??100));
    cs_player_json(['ok'=>true,'server'=>['name'=>$dnsRow['name']??'Servidor'],'user'=>$_SESSION['cs_player_user_info']??[], 'categories'=>['live'=>$liveCats,'movies'=>$vodCats,'series'=>$seriesCats], 'content'=>['live'=>array_slice($live,0,120),'movies'=>array_slice($vod,0,120),'series'=>array_slice($series,0,120)], 'manual_highlights'=>$manualHighlights, 'features'=>['pip'=>(bool)$cfg['pip_enabled'],'failover'=>(bool)$cfg['dns_failover'],'stall_timeout'=>(int)$cfg['stall_timeout'],'retries'=>(int)$cfg['hls_retries']]]);
}

if ($action==='tmdb_enrich') {
    $type=(string)($_GET['type']??'movie');
    if (!in_array($type,['movie','series'],true)) cs_player_json(['ok'=>false,'message'=>'Tipo inválido'],400);
    $title=trim((string)($_GET['title']??''));
    $year=(int)($_GET['year']??0);
    $tmdbId=(int)($_GET['tmdb_id']??0);
    $metadata=cs_player_tmdb_enrich($type,$title,$year,$tmdbId);
    if (!$metadata) {
        cs_player_write_log('tmdb_enrichment_not_found',['type'=>$type,'title_hash'=>substr(hash('sha256',$title),0,12),'year'=>$year],'info');
        cs_player_json(['ok'=>true,'data'=>null]);
    }
    cs_player_json(['ok'=>true,'data'=>$metadata]);
}


if ($action==='epg_now') {
    if (empty($cfg['live_epg_enabled'])) cs_player_json(['ok'=>true,'data'=>null]);
    $channel = trim((string)($_GET['channel'] ?? ''));
    if ($channel === '') cs_player_json(['ok'=>true,'data'=>null]);

    $template = trim((string)($cfg['live_epg_url'] ?? ''));
    if ($template === '') cs_player_json(['ok'=>true,'data'=>null]);

    $epgUrl = strtr($template, [
        '{username}' => rawurlencode($u),
        '{password}' => rawurlencode($p),
        '{dns}' => rtrim((string)$dns, '/'),
    ]);
    if (!preg_match('~^https?://~i',$epgUrl)) cs_player_json(['ok'=>true,'data'=>null]);

    $cacheDir = dirname(__DIR__).'/logs/cs-player/epg-cache';
    if (!is_dir($cacheDir)) @mkdir($cacheDir,0750,true);
    $cacheFile = $cacheDir.'/'.hash('sha256',$epgUrl).'.xml';
    $ttl = max(60,min(3600,(int)($cfg['live_epg_cache_ttl'] ?? 300)));
    if (!is_file($cacheFile) || (time()-(int)@filemtime($cacheFile))>$ttl) {
        $tmp=$cacheFile.'.tmp';
        $fp=@fopen($tmp,'wb');
        if ($fp) {
            $ch=curl_init($epgUrl);
            curl_setopt_array($ch,[
                CURLOPT_FILE=>$fp,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>4,
                CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_TIMEOUT=>30,CURLOPT_ENCODING=>'',
                CURLOPT_USERAGENT=>(string)($cfg['m3u_user_agent']??'IPTVSmartersPro'),
                CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>false
            ]);
            curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);fclose($fp);
            if ($code>=200 && $code<400 && is_file($tmp) && (int)@filesize($tmp)>100) {@rename($tmp,$cacheFile);@chmod($cacheFile,0600);} else @unlink($tmp);
        }
    }
    if (!is_file($cacheFile) || !class_exists('XMLReader')) cs_player_json(['ok'=>true,'data'=>null]);

    $now=time();$current=null;$next=null;
    $xr=new XMLReader();
    if (@$xr->open($cacheFile,null,LIBXML_NONET|LIBXML_COMPACT)) {
        while($xr->read()) {
            if ($xr->nodeType!==XMLReader::ELEMENT || $xr->name!=='programme') continue;
            if ((string)$xr->getAttribute('channel') !== $channel) continue;
            $startRaw=(string)$xr->getAttribute('start');$stopRaw=(string)$xr->getAttribute('stop');
            $parse=function($v){if(!preg_match('/^(\d{14})\s*([+-]\d{4})?/',$v,$m))return 0;$dt=DateTime::createFromFormat('YmdHis O',$m[1].' '.($m[2]??'+0000'));return $dt?$dt->getTimestamp():0;};
            $start=$parse($startRaw);$stop=$parse($stopRaw);
            if (!$start) continue;
            $node=@$xr->readOuterXML();$title='';$desc='';
            if ($node && function_exists('simplexml_load_string')) {
                $xml=@simplexml_load_string($node);
                if ($xml) {$title=trim((string)$xml->title);$desc=trim((string)$xml->desc);}
            }
            $rec=['title'=>$title,'description'=>$desc,'start'=>$start,'end'=>$stop];
            if ($start <= $now && (!$stop || $stop > $now)) {$current=$rec;}
            elseif ($start > $now && $next===null) {$next=$rec; if($current!==null) break;}
        }
        $xr->close();
    }
    cs_player_json(['ok'=>true,'data'=>['current'=>$current,'next'=>$next]]);
}

if ($action==='series_info') {
    $id=(int)($_GET['id']??0); if(!$id) cs_player_json(['ok'=>false,'message'=>'Série inválida'],400);
    $data = ($providerMode==='m3u' && is_array($m3uCatalog)) ? ['episodes'=>($m3uCatalog['episodes'][$id]??[])] : ($local ? cs_player_local_api($u,$p,'get_series_info',['series_id'=>$id]) : cs_player_api_call($dns,$u,$p,'get_series_info',['series_id'=>$id]));
    if ($providerMode==='m3u' && is_array($data['episodes'] ?? null)) {
        foreach ($data['episodes'] as $seasonEpisodes) {
            foreach ((array)$seasonEpisodes as $episode) {
                if (!is_array($episode)) continue;
                $eid=(int)($episode['id']??0); $direct=trim((string)($episode['direct_source']??''));
                if ($eid>0 && preg_match('~^https?://~i',$direct)) {
                    $_SESSION['cs_player_external_sources']['series:'.$eid]=['direct_source'=>$direct,'container_extension'=>(string)($episode['container_extension']??'mp4'),'stream_type'=>'series','ts'=>time()];
                }
            }
        }
    }
    if ($data === null) {
        cs_player_write_log('web_player_series_info_failed', ['host' => (string)($dnsRow['url'] ?? ''), 'series_id' => $id], 'error');
        cs_player_json(['ok'=>false,'message'=>'Não foi possível carregar os episódios.'],502);
    }
    cs_player_json(['ok'=>true,'data'=>$data]);
}
if ($action==='category') {
    $type=(string)($_GET['type']??'live'); $cat=(string)($_GET['category_id']??'');
    $map=['live'=>'get_live_streams','movies'=>'get_vod_streams','series'=>'get_series']; if(!isset($map[$type])) cs_player_json(['ok'=>false],400);
    if ($type === 'movies' && $cat !== '') {
        $cats = $providerMode==='m3u' && is_array($m3uCatalog) ? ($m3uCatalog['categories']['movie']??[]) : ($local ? (cs_player_local_api($u,$p,'get_vod_categories') ?? []) : (cs_player_api_call($dns,$u,$p,'get_vod_categories') ?? []));
        foreach ($cats as $category) {
            if ((string)($category['category_id'] ?? '') === $cat && cs_player_is_adult_category_name((string)($category['category_name'] ?? ''))) {
                cs_player_write_log('web_player_adult_category_blocked', ['category_id'=>$cat], 'info');
                cs_player_json(['ok'=>true,'data'=>[]]);
            }
        }
    }
    $extra=$cat!==''?['category_id'=>$cat]:[]; if($providerMode==='m3u' && is_array($m3uCatalog)){ $pool=$type==='live'?($m3uCatalog['live']??[]):($type==='movies'?($m3uCatalog['movie']??[]):($m3uCatalog['series']??[])); $data=$cat===''?$pool:array_values(array_filter($pool,static fn($x)=>(string)($x['category_id']??'')===$cat)); } else { $data=$local ? cs_player_local_api($u,$p,$map[$type],$extra) : cs_player_api_call($dns,$u,$p,$map[$type],$extra); }
    if ($data === null) {
        cs_player_write_log('web_player_category_failed', ['host' => (string)($dnsRow['url'] ?? ''), 'type' => $type, 'category_id' => $cat], 'error');
        cs_player_json(['ok'=>false,'message'=>'Não foi possível carregar esta categoria.'],502);
    }
    if (!$local && is_array($data) && in_array($type,['live','movies'],true)) {
        cs_player_cache_external_sources($data, $type==='movies'?'movie':'live');
    }
    cs_player_json(['ok'=>true,'data'=>$data]);
}
if ($action==='failover') {
    if ($local) cs_player_json(['ok'=>false,'message'=>'Servidor interno usa API local; failover de API externa não é necessário.']);
    if (empty($cfg['dns_failover'])) cs_player_json(['ok'=>false,'message'=>'Failover desativado']);
    $active=cs_player_session_dns_list($cfg); $current=(string)($_SESSION['cs_player_dns_index']??''); $start=0;
    foreach($active as $i=>$row){ if((string)$row['_index']===$current){$start=$i+1;break;} }
    for($step=0;$step<count($active);$step++){
        $row=$active[($start+$step)%count($active)]; if((string)$row['_index']===$current) continue;
        $auth=cs_player_authenticate_dns([$row],$u,$p);
        if(is_array($auth)&&isset($auth['row'],$auth['data'])){$_SESSION['cs_player_dns_index']=(string)$auth['row']['_index'];$_SESSION['cs_player_dns_name']=$auth['row']['name']??'Servidor';$_SESSION['cs_player_dns_url']=$auth['row']['url']??'';$_SESSION['cs_player_api_endpoint']=$auth['row']['api_endpoint']??'player_api.php';$_SESSION['cs_player_provider_mode']=(string)($auth['provider_mode']??$auth['row']['provider_mode_selected']??'xtream');cs_player_json(['ok'=>true,'server'=>$_SESSION['cs_player_dns_name']]);}
    }
    cs_player_write_log('web_player_failover_failed', ['current_dns' => $current, 'dns_count' => count($active)], 'error');
    cs_player_json(['ok'=>false,'message'=>'Nenhum DNS alternativo respondeu']);
}
cs_player_json(['ok'=>false,'message'=>'Ação inválida'],400);

# CS PLAYER 4.0.4 — Dual Player Live/VOD

## Player Live
- dedicado a canais;
- HTTP mantido;
- M3U8/HLS via Hls.js;
- TS/MPEG-TS via mpegts.js;
- proxy CS PLAYER / proxy HLS / direto por Settings;
- EPG XMLTV opcional configurado em Settings, com placeholders server-side;
- M3U `tvg-id` preservado para casar com XMLTV.

## Player VOD
- dedicado a filmes e séries;
- MP4 com suporte a Range;
- MKV com remux opcional para MP4 fragmentado;
- HTTP mantido;
- temporadas e episódios preservados;
- arquivo único continua compatível;
- TMDB e próximo episódio permanecem configuráveis.

Nenhuma alteração de schema de banco foi necessária.

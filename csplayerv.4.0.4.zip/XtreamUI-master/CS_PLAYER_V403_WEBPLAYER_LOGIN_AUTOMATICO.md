# CS PLAYER 4.0.3 — Web Player automático

- Remove o campo Servidor/DNS da tela de login.
- DNS/servidores passam a ser administrados somente em Settings > Web Player.
- Mantém HTTP e porta 80.
- O servidor power08121562.shop usa autenticação M3U (`get.php`) diretamente, sem depender de `player_api.php`.
- Mantém fallback inteligente para XC/JSON/M3U nos demais servidores.
- Catálogo M3U continua separando canais, filmes, séries, temporadas e episódios.
- Mantém player de destaques, HLS/M3U8, MPEG-TS/TS, MP4, MKV, proxy, PiP, Cast e anúncios.
- Nenhuma migração ou alteração de schema de banco é necessária.

<?php
/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  IDENTIDADE VISUAL ULTRA PRO – Controle Total de Assets                ║
 * ║  CS PLAYER — Compatível PHP 7.4–8.4                     ║
 * ║  Gerencia /admin/assets/ com substituição total de mídias e arquivos   ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
cs_admin_only('a identidade visual e os arquivos de assets');

if ((!hasPermissions('adv', 'settings')) && (!hasPermissions('adv', 'database'))) exit;

require_once __DIR__ . '/branding_helper.php';
require_once __DIR__ . '/cs_audit.php';

// Configurações de diretório
$baseDir = __DIR__ . '/assets/uploads/branding';
$backupDir = $baseDir . '/backups';
$projectBackupDir = $backupDir . '/project_files';
$configFile = $baseDir . '/branding.json';
$assetsRoot = __DIR__ . '/assets';
$projectRoot = realpath(__DIR__);

@mkdir($backupDir, 0755, true);
@mkdir($projectBackupDir, 0750, true);

if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

// CSRF Protection
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['cs_branding_csrf'] ?? '', (string)$_POST['csrf'])) {
        die('Erro de validação CSRF. Recarregue a página.');
    }
    $_SESSION['cs_branding_csrf'] = bin2hex(random_bytes(24));
}
if (empty($_SESSION['cs_branding_csrf'])) $_SESSION['cs_branding_csrf'] = bin2hex(random_bytes(24));
$csrf = $_SESSION['cs_branding_csrf'];

$message = ''; 
$messageType = 'success';

// Slots de Branding Essencial
$slots = [
    'logo' => [
        'logo_main'    => ['label'=>'Logo Principal', 'fallback'=>($rSettings['logo_url'] ?? 'assets/images/logo.png'), 'accept'=>'.png,.jpg,.jpeg,.webp'],
        'logo_compact' => ['label'=>'Logo Sidebar', 'fallback'=>($rSettings['logo_url_sidebar'] ?? 'assets/images/logo-back.png'), 'accept'=>'.png,.jpg,.jpeg,.webp'],
        'favicon'      => ['label'=>'Favicon', 'fallback'=>'assets/images/favicon.ico', 'accept'=>'.png,.jpg,.jpeg,.webp,.ico'],
    ],
    'login' => [
        'login_background' => ['label'=>'Fundo do Login (Imagem)', 'fallback'=>'assets/images/bg1.png', 'accept'=>'.png,.jpg,.jpeg,.webp', 'type'=>'image'],
        'login_video'      => ['label'=>'Fundo do Login (Vídeo)', 'fallback'=>'', 'accept'=>'.mp4,.webm', 'type'=>'video'],
    ],
    'dashboard' => [
        'dashboard_background' => ['label'=>'Fundo do Painel (Imagem)', 'fallback'=>'assets/images/bgpro.png', 'accept'=>'.png,.jpg,.jpeg,.webp', 'type'=>'image'],
        'dashboard_video'      => ['label'=>'Fundo do Painel (Vídeo)', 'fallback'=>'', 'accept'=>'.mp4,.webm', 'type'=>'video'],
    ],
    'banner' => [
        'banner_main' => ['label'=>'Banner Principal', 'fallback'=>'assets/images/megamenu-bg.png', 'accept'=>'.png,.jpg,.jpeg,.webp'],
    ],
    'avatar' => [
        'admin_avatar' => ['label'=>'Avatar Admin', 'fallback'=>'', 'accept'=>'.png,.jpg,.jpeg,.webp'],
    ]
];

/**
 * Funções Auxiliares
 */
function cs_branding_load_config($file) {
    if (!is_file($file)) return [];
    $data = json_decode((string)@file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function cs_branding_save_config($file, array $data) {
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) return false;
    $json = json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    if ($json === false) return false;
    $written = @file_put_contents($file, $json, LOCK_EX);
    if ($written === false) return false;
    @chmod($file, 0644);
    return true;
}

function cs_validate_file($file, $type = 'image') {
    if (!isset($file['error']) || (int)$file['error'] !== UPLOAD_ERR_OK) return [false, 'Falha no upload.'];
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return [false, 'Upload inválido ou não recebido pelo servidor.'];

    $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
    $size = (int)($file['size'] ?? 0);
    $mime = '';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) { $mime = (string)finfo_file($finfo, $file['tmp_name']); finfo_close($finfo); }
    }

    if ($type === 'video') {
        $allowed = ['mp4' => ['video/mp4', 'application/mp4'], 'webm' => ['video/webm', 'audio/webm']];
        if (!isset($allowed[$ext]) || ($mime !== '' && !in_array($mime, $allowed[$ext], true))) return [false, 'Formato de vídeo inválido ou conteúdo incompatível. Use MP4 ou WebM.'];
        if ($size <= 0 || $size > 500 * 1024 * 1024) return [false, 'Vídeo muito grande ou vazio (máx. 500MB).'];
    } elseif ($type === 'image') {
        $allowed = ['png' => ['image/png'], 'jpg' => ['image/jpeg'], 'jpeg' => ['image/jpeg'], 'webp' => ['image/webp'], 'ico' => ['image/x-icon', 'image/vnd.microsoft.icon', 'application/octet-stream']];
        if (!isset($allowed[$ext]) || ($mime !== '' && !in_array($mime, $allowed[$ext], true))) return [false, 'Formato de imagem inválido ou conteúdo incompatível.'];
        if ($size <= 0 || $size > 20 * 1024 * 1024) return [false, 'Imagem muito grande ou vazia (máx. 20MB).'];
        if ($ext !== 'ico' && function_exists('getimagesize') && @getimagesize($file['tmp_name']) === false) return [false, 'O arquivo enviado não é uma imagem válida.'];
    } elseif ($type === 'asset') {
        $allowed = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'ico', 'mp4', 'webm', 'css', 'js', 'woff', 'woff2', 'ttf', 'svg'];
        if (!in_array($ext, $allowed, true)) return [false, 'Tipo de arquivo não permitido para substituição.'];
    }

    return [$ext !== '' ? true : false, $ext !== '' ? $ext : 'Extensão ausente.'];
}

function cs_project_resolve_path($relative, $root) {
    $relative = trim(str_replace('\\\\', '/', (string)$relative));
    $relative = ltrim($relative, '/');
    if ($relative === '' || strpos($relative, "\0") !== false || strpos($relative, '../') !== false || $relative === '..' || strpos($relative, '/..') !== false) return false;
    $rootReal = realpath($root);
    if (!$rootReal) return false;
    $candidate = $rootReal . '/' . $relative;
    $parent = realpath(dirname($candidate));
    if (!$parent || strpos($parent, $rootReal) !== 0) return false;
    $full = $parent . '/' . basename($candidate);
    if (is_link($full) || !is_file($full)) return false;
    return ['relative' => str_replace('\\\\', '/', substr($full, strlen($rootReal) + 1)), 'full' => $full];
}

function cs_project_protected_path($relative) {
    $protected = [
        '.env', '.git', 'admin/config.php', 'admin/includes/config.php',
        'admin/session.php', 'admin/functions.php', 'admin/cs_admin_access.php'
    ];
    foreach ($protected as $item) {
        if ($relative === $item || strpos($relative, $item . '/') === 0) return true;
    }
    return false;
}

function cs_project_validate_upload($file, $target) {
    if (!isset($file['error']) || (int)$file['error'] !== UPLOAD_ERR_OK) return [false, 'Falha no upload do arquivo.'];
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return [false, 'Upload inválido ou não recebido pelo servidor.'];
    $size = (int)($file['size'] ?? 0);
    if ($size <= 0 || $size > 100 * 1024 * 1024) return [false, 'O arquivo deve ter entre 1 byte e 100 MB.'];
    $targetExt = strtolower(pathinfo($target, PATHINFO_EXTENSION));
    $uploadExt = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
    $allowed = ['php','phtml','inc','css','js','json','xml','html','htm','txt','md','sql','sh','conf','ini','svg','png','jpg','jpeg','webp','gif','ico','mp4','webm','woff','woff2','ttf'];
    if ($uploadExt === '' || !in_array($uploadExt, $allowed, true)) return [false, 'Extensão não permitida para substituição controlada.'];
    if ($targetExt !== '' && $uploadExt !== $targetExt) return [false, 'A extensão do arquivo enviado deve ser igual à do arquivo de destino.'];
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) { finfo_file($finfo, $file['tmp_name']); finfo_close($finfo); }
    }
    return [true, $uploadExt];
}

function cs_project_backup($target, $relative, $backupDir) {
    $id = date('Ymd_His') . '_' . bin2hex(random_bytes(5));
    $backupFile = $backupDir . '/' . $id . '.bak';
    $metaFile = $backupDir . '/' . $id . '.json';
    if (!@copy($target, $backupFile)) return false;
    @chmod($backupFile, 0600);
    $meta = ['id' => $id, 'target' => $relative, 'created_at' => date('c'), 'size' => filesize($backupFile), 'sha256' => hash_file('sha256', $backupFile)];
    if (@file_put_contents($metaFile, json_encode($meta, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX) === false) { @unlink($backupFile); return false; }
    @chmod($metaFile, 0600);
    return $meta;
}

function cs_project_load_backup($id, $backupDir) {
    $id = preg_replace('/[^A-Za-z0-9_-]/', '', (string)$id);
    if ($id === '') return false;
    $metaFile = $backupDir . '/' . $id . '.json';
    $backupFile = $backupDir . '/' . $id . '.bak';
    if (!is_file($metaFile) || !is_file($backupFile)) return false;
    $meta = json_decode((string)@file_get_contents($metaFile), true);
    if (!is_array($meta) || empty($meta['target'])) return false;
    $meta['backup_file'] = $backupFile;
    return $meta;
}

function cs_project_php_syntax_ok($file) {
    if (strtolower(pathinfo($file, PATHINFO_EXTENSION)) !== 'php') return [true, ''];
    if (!function_exists('proc_open')) return [true, ''];
    $cmd = escapeshellarg(PHP_BINARY) . ' -l ' . escapeshellarg($file);
    $pipes = [];
    $proc = @proc_open($cmd, [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    if (!is_resource($proc)) return [false, 'Não foi possível validar a sintaxe PHP do arquivo.'];
    $out = stream_get_contents($pipes[1]); $err = stream_get_contents($pipes[2]);
    foreach ($pipes as $pipe) @fclose($pipe);
    $code = proc_close($proc);
    return [$code === 0, trim($err ?: $out)];
}

function cs_resize_logo($source, $destination, $maxDim = 512) {
    if (!function_exists('imagecreatefromstring') || !function_exists('imagecreatetruecolor') || !function_exists('imagecopyresampled')) return false;
    $data = @file_get_contents($source);
    $src = @imagecreatefromstring($data);
    if (!$src) return false;

    $width = imagesx($src);
    $height = imagesy($src);
    if ($width <= $maxDim && $height <= $maxDim) {
        imagedestroy($src);
        return false;
    }

    $ratio = min($maxDim / $width, $maxDim / $height);
    $newW = (int)($width * $ratio);
    $newH = (int)($height * $ratio);

    $dst = imagecreatetruecolor($newW, $newH);
    imagealphablending($dst, false);
    imagesavealpha($dst, true);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newW, $newH, $width, $height);
    
    $ext = strtolower(pathinfo($destination, PATHINFO_EXTENSION));
    if ($ext === 'png') imagepng($dst, $destination);
    elseif (in_array($ext, ['jpg', 'jpeg'])) imagejpeg($dst, $destination, 90);
    elseif ($ext === 'webp') imagewebp($dst, $destination, 85);
    
    imagedestroy($src);
    imagedestroy($dst);
    return true;
}

// Processamento de Ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $config = cs_branding_load_config($configFile);
    $allSlotsFlat = array_merge(...array_values($slots));

    if ($action === 'upload_slot') {
        $slot = (string)($_POST['slot'] ?? '');
        if (isset($allSlotsFlat[$slot])) {
            $type = ($allSlotsFlat[$slot]['type'] ?? '') === 'video' ? 'video' : 'image';
            [$ok, $res] = cs_validate_file($_FILES['file'] ?? [], $type);
            if (!$ok) { $message = $res; $messageType = 'danger'; }
            else {
                $filename = $slot . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(5)) . '.' . $res;
                $target = $baseDir . '/' . $filename;
                if (@move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
                    @chmod($target, 0644);
                    if (in_array($slot, ['logo_main', 'logo_compact', 'favicon']) && $type === 'image') {
                        cs_resize_logo($target, $target, $slot === 'favicon' ? 128 : 512);
                    }
                    if (!empty($config[$slot]) && is_file(__DIR__ . '/' . $config[$slot])) {
                        @copy(__DIR__ . '/' . $config[$slot], $backupDir . '/old_' . basename($config[$slot]));
                    }
                    $config[$slot] = 'assets/uploads/branding/' . $filename;
                    if (!cs_branding_save_config($configFile, $config)) {
                        $message = 'Arquivo enviado, mas não foi possível salvar a configuração. Verifique permissões de escrita em admin/assets/uploads/branding.';
                        $messageType = 'danger';
                    } else {
                        $message = 'Branding atualizado com sucesso!';
                    }
                    cs_audit_log('branding.update', ['slot' => $slot]);
                } else { $message = 'Erro ao salvar arquivo. Verifique permissões.'; $messageType = 'danger'; }
            }
        }
    } elseif ($action === 'use_existing_asset') {
        $slot = (string)($_POST['slot'] ?? '');
        $asset = ltrim(str_replace(['..', '\\'], ['', '/'], (string)($_POST['existing_asset'] ?? '')), '/');
        $full = __DIR__ . '/assets/' . $asset;
        if (!isset($allSlotsFlat[$slot])) {
            $message = 'Slot de branding inválido.'; $messageType = 'danger';
        } elseif (strpos($asset, 'images/') !== 0 || !is_file($full)) {
            $message = 'Selecione um arquivo válido de /admin/assets/images/.'; $messageType = 'danger';
        } else {
            $ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
            $isVideoSlot = (($allSlotsFlat[$slot]['type'] ?? '') === 'video');
            $allowed = $isVideoSlot ? ['mp4','webm'] : ['png','jpg','jpeg','webp','gif','ico'];
            if (!in_array($ext, $allowed, true)) {
                $message = 'O tipo do arquivo não é compatível com este campo.'; $messageType = 'danger';
            } else {
                $config[$slot] = 'assets/' . $asset;
                cs_branding_save_config($configFile, $config);
                $message = 'Imagem existente aplicada ao branding com sucesso!';
                cs_audit_log('branding.existing_asset', ['slot' => $slot, 'asset' => $asset]);
            }
        }
    } elseif ($action === 'replace_asset') {
        $relPath = str_replace(['..', '\\'], ['', '/'], (string)($_POST['asset_path'] ?? ''));
        $target = realpath($assetsRoot . '/' . $relPath);
        
        if ($target && strpos($target, realpath($assetsRoot)) === 0 && is_file($target)) {
            [$ok, $result] = cs_validate_file($_FILES['file'] ?? [], 'asset');
            if (!$ok) { $message = $result; $messageType = 'danger'; }
            else {
                $ext = $result;
                $backupFile = $backupDir . '/asset_' . date('YmdHis') . '_' . basename($target);
                @copy($target, $backupFile);
                if (@move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
                    @chmod($target, 0644);
                    $message = 'Arquivo do projeto substituído! Backup criado.';
                    cs_audit_log('branding.asset_replace', ['file' => $relPath]);
                } else { $message = 'Erro na substituição.'; $messageType = 'danger'; }
            }
        } else { $message = 'Caminho de asset inválido.'; $messageType = 'danger'; }
    } elseif ($action === 'project_replace') {
        $relative = str_replace('\\\\', '/', trim((string)($_POST['project_file'] ?? '')));
        $resolved = cs_project_resolve_path($relative, $projectRoot);
        if (!$resolved) {
            $message = 'Arquivo de projeto inválido, inexistente ou fora da raiz permitida.'; $messageType = 'danger';
        } elseif (cs_project_protected_path($resolved['relative'])) {
            $message = 'Este arquivo é protegido e não pode ser substituído por este painel.'; $messageType = 'danger';
        } else {
            [$valid, $validation] = cs_project_validate_upload($_FILES['project_upload'] ?? [], $resolved['relative']);
            if (!$valid) { $message = $validation; $messageType = 'danger'; }
            else {
                [$syntaxOk, $syntaxMessage] = cs_project_php_syntax_ok($_FILES['project_upload']['tmp_name']);
                if (!$syntaxOk) { $message = 'Substituição bloqueada: sintaxe PHP inválida. ' . $syntaxMessage; $messageType = 'danger'; }
                else {
                    $backup = cs_project_backup($resolved['full'], $resolved['relative'], $projectBackupDir);
                    if (!$backup) { $message = 'Não foi possível criar o backup antes da substituição.'; $messageType = 'danger'; }
                    elseif (@move_uploaded_file($_FILES['project_upload']['tmp_name'], $resolved['full'])) {
                        @chmod($resolved['full'], fileperms($resolved['full']) & 0777);
                        $message = 'Arquivo substituído com sucesso. Backup: ' . $backup['id'];
                        cs_audit_log('project.file_replace', ['file' => $resolved['relative'], 'backup' => $backup['id']]);
                    } else { $message = 'Falha ao gravar o arquivo de destino. O backup foi preservado: ' . $backup['id']; $messageType = 'danger'; }
                }
            }
        }
    } elseif ($action === 'project_restore') {
        $backup = cs_project_load_backup((string)($_POST['backup_id'] ?? ''), $projectBackupDir);
        $resolved = $backup ? cs_project_resolve_path($backup['target'], $projectRoot) : false;
        if (!$backup || !$resolved || !hash_equals((string)$backup['sha256'], (string)hash_file('sha256', $backup['backup_file']))) {
            $message = 'Backup inválido, corrompido ou arquivo de destino indisponível.'; $messageType = 'danger';
        } elseif (cs_project_protected_path($resolved['relative'])) {
            $message = 'A restauração deste arquivo protegido deve ser feita pelo procedimento de rollback do servidor.'; $messageType = 'danger';
        } else {
            $currentBackup = cs_project_backup($resolved['full'], $resolved['relative'], $projectBackupDir);
            if (!$currentBackup || !@copy($backup['backup_file'], $resolved['full'])) {
                $message = 'Não foi possível restaurar o backup. O backup anterior foi preservado.'; $messageType = 'danger';
            } else {
                @chmod($resolved['full'], 0644);
                $message = 'Arquivo restaurado com sucesso a partir do backup ' . $backup['id'] . '.';
                cs_audit_log('project.file_restore', ['file' => $resolved['relative'], 'backup' => $backup['id'], 'safety_backup' => $currentBackup['id']]);
            }
        }
    } elseif ($action === 'restore_slot') {
        $slot = (string)($_POST['slot'] ?? '');
        if (isset($allSlotsFlat[$slot]) && isset($config[$slot])) {
            $configuredPath = ltrim((string)$config[$slot], '/');
            if (strpos($configuredPath, 'assets/uploads/branding/') === 0) {
                @unlink(__DIR__ . '/' . $configuredPath);
            }
            unset($config[$slot]);
            cs_branding_save_config($configFile, $config);
            $message = 'Restaurado para o padrão do sistema.';
            cs_audit_log('branding.restore', ['slot' => $slot]);
        }
    } elseif ($action === 'save_settings') {
        foreach (['login', 'dashboard'] as $ctx) {
            foreach (['muted', 'loop', 'autoplay'] as $f) $config[$ctx.'_'.$f] = !empty($_POST[$ctx.'_'.$f]);
            $config[$ctx.'_overlay'] = max(0, min(100, (int)($_POST[$ctx.'_overlay'] ?? 35)));
        }
        cs_branding_save_config($configFile, $config);
        $message = 'Configurações de exibição salvas.';
    } elseif ($action === 'save_theme') {
        $themeDefaults = [
            'header_start' => '#111827', 'header_end' => '#2563EB', 'sidebar_bg' => '#FFFFFF',
            'menu_surface' => '#FFFFFF', 'menu_active' => '#EFF6FF', 'menu_text' => '#475467',
            'menu_text_active' => '#2563EB', 'page_bg' => '#F4F7FB'
        ];
        foreach ($themeDefaults as $themeKey => $themeFallback) {
            $config['theme_'.$themeKey] = cs_branding_safe_color($_POST['theme_'.$themeKey] ?? $themeFallback, $themeFallback);
        }
        $iconCatalog = cs_branding_icon_catalog();
        foreach ($iconCatalog as $menuKey => $choices) {
            $candidate = (string)($_POST['menu_icon_'.$menuKey] ?? $choices[0]);
            $config['menu_icon_'.$menuKey] = in_array($candidate, $choices, true) ? $candidate : $choices[0];
        }
        cs_branding_save_config($configFile, $config);
        $message = 'Cores e ícones dos menus salvos com sucesso.';
    }
}

// Listagem de Assets para o Gerenciador
$assetFiles = [];
if (is_dir($assetsRoot)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($assetsRoot, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
        if ($file->isFile()) {
            $path = str_replace('\\', '/', substr($file->getPathname(), strlen($assetsRoot) + 1));
            $ext = strtolower($file->getExtension());
            if (in_array($ext, ['png', 'jpg', 'jpeg', 'webp', 'gif', 'ico', 'mp4', 'webm', 'css', 'js', 'svg'])) {
                $assetFiles[] = [
                    'path' => $path,
                    'size' => round($file->getSize() / 1024, 2) . ' KB',
                    'mtime' => date('d/m/Y H:i', $file->getMTime()),
                    'type' => $ext
                ];
            }
        }
    }
}
usort($assetFiles, function($a, $b) { return strcmp($a['path'], $b['path']); });
$imageLibrary = array_values(array_filter($assetFiles, function($a) {
    return strpos($a['path'], 'images/') === 0 && in_array($a['type'], ['png','jpg','jpeg','webp','gif','ico','mp4','webm'], true);
}));

$projectFiles = [];
$projectExts = ['php','phtml','inc','css','js','json','xml','html','htm','txt','md','sql','sh','conf','ini','svg','png','jpg','jpeg','webp','gif','ico','mp4','webm','woff','woff2','ttf'];
if ($projectRoot && is_dir($projectRoot)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($projectRoot, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
        if (!$file->isFile() || $file->isLink()) continue;
        $relative = str_replace('\\\\', '/', substr($file->getPathname(), strlen($projectRoot) + 1));
        if (strpos($relative, 'assets/uploads/branding/backups/') === 0 || strpos($relative, '.git/') === 0 || strpos($relative, 'vendor/') === 0) continue;
        $ext = strtolower($file->getExtension());
        if (!in_array($ext, $projectExts, true) || cs_project_protected_path($relative)) continue;
        $projectFiles[] = ['path' => $relative, 'size' => round($file->getSize() / 1024, 2) . ' KB', 'mtime' => date('d/m/Y H:i', $file->getMTime()), 'type' => $ext];
    }
}
usort($projectFiles, function($a, $b) { return strcmp($a['path'], $b['path']); });

$projectBackups = [];
foreach (glob($projectBackupDir . '/*.json') ?: [] as $metaFile) {
    $meta = json_decode((string)@file_get_contents($metaFile), true);
    if (is_array($meta) && !empty($meta['id']) && !empty($meta['target']) && is_file($projectBackupDir . '/' . $meta['id'] . '.bak')) $projectBackups[] = $meta;
}
usort($projectBackups, function($a, $b) { return strcmp((string)($b['created_at'] ?? ''), (string)($a['created_at'] ?? '')); });
$projectBackups = array_slice($projectBackups, 0, 100);

$config = cs_branding_load_config($configFile);
include $rSettings['sidebar'] ? 'header_sidebar.php' : 'header.php';
?>

<style>
    .branding-shell { max-width: 1520px; margin: 0 auto; }
    .branding-hero {
        display: flex; align-items: flex-end; justify-content: space-between; gap: 20px;
        padding: 28px 30px; margin-bottom: 22px; border-radius: 20px;
        color: #fff; background: linear-gradient(135deg, #0f172a 0%, #1e293b 58%, #2563eb 150%);
        box-shadow: 0 16px 34px rgba(15, 23, 42, .16);
    }
    .branding-eyebrow { display: block; margin-bottom: 8px; color: #7dd3fc; font-size: 11px; font-weight: 800; letter-spacing: .14em; text-transform: uppercase; }
    .branding-hero h1 { margin: 0 0 7px; color: #fff; font-size: clamp(25px, 3vw, 36px); font-weight: 800; letter-spacing: -.035em; }
    .branding-hero p { max-width: 650px; margin: 0; color: rgba(255,255,255,.72); font-size: 14px; line-height: 1.55; }
    .branding-health { display: inline-flex; align-items: center; gap: 8px; flex: 0 0 auto; padding: 10px 14px; border: 1px solid rgba(255,255,255,.16); border-radius: 999px; color: #dbeafe; background: rgba(255,255,255,.09); font-size: 12px; font-weight: 700; white-space: nowrap; }
    .branding-health-dot { width: 9px; height: 9px; border-radius: 50%; background: #34d399; box-shadow: 0 0 0 4px rgba(52,211,153,.16); }
    .branding-alert { display: flex; align-items: flex-start; gap: 10px; border: 0; border-radius: 13px; box-shadow: 0 5px 16px rgba(15,23,42,.06); }
    .branding-tabs { display: flex; gap: 7px; margin: 0 0 25px; padding: 6px; border: 1px solid var(--cs-border, #e6eaf0); border-radius: 14px; background: var(--cs-surface, #fff); box-shadow: 0 4px 14px rgba(15,23,42,.04); }
    .branding-tabs .nav-item { flex: 1 1 0; }
    .branding-tabs .nav-link { display: flex; align-items: center; justify-content: center; gap: 7px; min-height: 43px; border: 0 !important; border-radius: 10px; color: #667085; font-size: 13px; font-weight: 750; text-align: center; transition: .18s ease; }
    .branding-tabs .nav-link:hover { color: #2563eb; background: #eff6ff; }
    .branding-tabs .nav-link.active { color: #fff !important; background: linear-gradient(135deg, #2563eb, #4f46e5); box-shadow: 0 6px 14px rgba(37,99,235,.22); }
    .branding-section-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 18px; margin: 4px 0 17px; }
    .branding-section-head h2 { margin: 0 0 5px; color: var(--cs-text, #172033); font-size: 21px; font-weight: 800; letter-spacing: -.025em; }
    .branding-section-head p { margin: 0; color: var(--cs-muted, #667085); font-size: 13px; }
    .branding-section-index { display: inline-block; margin-right: 7px; color: #2563eb; font-size: 11px; font-weight: 850; letter-spacing: .12em; }
    .branding-stat-chips { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 7px; }
    .branding-stat-chip { padding: 8px 11px; border: 1px solid var(--cs-border, #e6eaf0); border-radius: 999px; color: #475467; background: #fff; font-size: 12px; font-weight: 700; white-space: nowrap; }
    .branding-slot-card { height: 100%; border: 1px solid var(--cs-border, #e6eaf0); border-radius: 16px; background: #fff; box-shadow: 0 6px 22px rgba(15,23,42,.06); overflow: hidden; transition: transform .2s ease, box-shadow .2s ease, border-color .2s ease; }
    .branding-slot-card:hover { transform: translateY(-3px); border-color: #bfd2f5; box-shadow: 0 14px 30px rgba(15,23,42,.11); }
    .branding-slot-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; padding: 18px 18px 0; }
    .branding-slot-kicker { display: block; margin-bottom: 5px; color: #98a2b3; font-size: 10px; font-weight: 800; letter-spacing: .1em; text-transform: uppercase; }
    .branding-slot-head h3 { margin: 0; color: #172033; font-size: 16px; font-weight: 800; }
    .branding-slot-type { padding: 5px 8px; border-radius: 999px; color: #2563eb; background: #eff6ff; font-size: 10px; font-weight: 800; letter-spacing: .06em; text-transform: uppercase; }
    .branding-preview { position: relative; display: flex; align-items: center; justify-content: center; height: 172px; margin: 15px 18px 14px; border: 1px solid #e7ebf1; border-radius: 12px; overflow: hidden; background: linear-gradient(135deg, #f8fafc, #eef2f7); }
    .branding-preview::after { content: ''; position: absolute; inset: 0; pointer-events: none; background: linear-gradient(135deg, rgba(255,255,255,.25), transparent 46%); }
    .branding-preview img { position: relative; z-index: 1; max-width: 88%; max-height: 82%; object-fit: contain; }
    .branding-preview video { position: relative; z-index: 1; width: 100%; height: 100%; object-fit: cover; }
    .branding-preview .no-media { color: #98a2b3; font-size: 38px; }
    .branding-preview-label { position: absolute; left: 10px; bottom: 9px; z-index: 2; padding: 4px 7px; border-radius: 6px; color: #667085; background: rgba(255,255,255,.82); font-size: 10px; font-weight: 750; }
    .branding-slot-body { padding: 0 18px 18px; }
    .branding-current { display: flex; align-items: center; gap: 7px; min-height: 25px; margin-bottom: 12px; color: #667085; font-size: 11px; }
    .branding-current-dot { width: 7px; height: 7px; border-radius: 50%; background: #34d399; }
    .branding-upload { position: relative; display: flex; align-items: center; justify-content: center; gap: 8px; min-height: 44px; margin: 0 0 9px; padding: 9px 12px; border: 1px dashed #8ab0e9; border-radius: 10px; color: #2563eb; background: #f7faff; cursor: pointer; font-size: 12px; font-weight: 750; text-align: center; transition: .18s ease; }
    .branding-upload:hover { border-color: #2563eb; background: #eff6ff; }
    .branding-upload input[type=file] { position: absolute; inset: 0; width: 100%; height: 100%; opacity: 0; cursor: pointer; }
    .branding-upload small { color: #667085; font-size: 10px; font-weight: 500; }
    .branding-existing { display: flex; gap: 7px; }
    .branding-existing select { min-width: 0; height: 40px; border-radius: 9px !important; font-size: 12px; }
    .branding-existing .btn { flex: 0 0 auto; min-height: 40px; padding: 0 13px; }
    .branding-restore { width: 100%; margin-top: 7px; padding: 5px 0; color: #d92d20; font-size: 11px; font-weight: 700; }
    .branding-restore:hover { color: #b42318; text-decoration: underline; }
    .branding-manager-card, .branding-preference-card { border: 1px solid var(--cs-border, #e6eaf0); border-radius: 16px; background: #fff; box-shadow: 0 6px 22px rgba(15,23,42,.06); overflow: hidden; }
    .branding-manager-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 18px; padding: 21px; border-bottom: 1px solid #edf0f4; }
    .branding-manager-head h2, .branding-preference-head h2 { margin: 0 0 5px; color: #172033; font-size: 19px; font-weight: 800; }
    .branding-manager-head p, .branding-preference-head p { margin: 0; color: #667085; font-size: 13px; }
    .branding-search { position: relative; min-width: min(100%, 290px); }
    .branding-search i { position: absolute; top: 50%; left: 12px; z-index: 1; color: #98a2b3; transform: translateY(-50%); }
    .branding-search input { padding-left: 35px; }
    .branding-manager-body { padding: 0 21px 21px; }
    .branding-table-wrap { margin-top: 17px; border: 1px solid #e7ebf1; border-radius: 12px; overflow: auto; }
    .branding-table { min-width: 690px; margin: 0; }
    .branding-table thead th { padding: 12px 14px; color: #667085; background: #f8fafc; font-size: 10px; letter-spacing: .07em; }
    .branding-table td { padding: 12px 14px; font-size: 12px; }
    .branding-file-name { display: flex; align-items: center; min-width: 260px; color: #344054; font-weight: 650; }
    .branding-file-thumb { width: 28px; height: 28px; margin-right: 9px; border: 1px solid #e5e7eb; border-radius: 7px; object-fit: contain; background: #f8fafc; }
    .branding-type-badge { display: inline-flex; align-items: center; justify-content: center; min-width: 42px; padding: 5px 7px; border-radius: 6px; color: #2563eb; background: #eff6ff; font-size: 10px; font-weight: 800; }
    .branding-empty { padding: 45px 20px; color: #98a2b3; text-align: center; }
    .branding-empty i { display: block; margin-bottom: 8px; font-size: 32px; }
    .branding-preference-card { height: 100%; }
    .branding-preference-head { padding: 21px 21px 0; }
    .branding-preference-body { padding: 21px; }
    .branding-preference-group { margin-bottom: 23px; padding-bottom: 19px; border-bottom: 1px solid #edf0f4; }
    .branding-preference-group:last-of-type { margin-bottom: 19px; padding-bottom: 0; border-bottom: 0; }
    .branding-preference-group h3 { margin: 0 0 12px; color: #344054; font-size: 14px; font-weight: 800; }
    .branding-preference-group p { margin: -5px 0 12px; color: #98a2b3; font-size: 12px; }
    .branding-preference-row { display: flex; align-items: center; justify-content: space-between; gap: 15px; min-height: 38px; margin-bottom: 6px; }
    .branding-preference-row label { margin: 0; color: #475467; font-size: 13px; font-weight: 600; }
    .branding-range-value { display: inline-block; min-width: 42px; margin-left: 8px; color: #2563eb; font-size: 12px; font-weight: 800; text-align: right; }
    .branding-tip-list { margin: 0; padding: 0; list-style: none; }
    .branding-tip-list li { display: flex; gap: 9px; margin: 0 0 13px; color: #667085; font-size: 12px; line-height: 1.5; }
    .branding-tip-list i { flex: 0 0 auto; color: #2563eb; }
    .branding-security-note { margin-top: 17px; padding: 12px; border: 1px solid #d1fadf; border-radius: 10px; color: #027a48; background: #ecfdf3; font-size: 11px; line-height: 1.5; }
    .branding-security-note i { margin-right: 5px; }
    .project-file-drop { display: flex; align-items: center; justify-content: center; gap: 8px; min-height: 43px; margin: 0; padding: 10px 12px; border: 1px dashed #8ab0e9; border-radius: 10px; color: #2563eb; background: #f7faff; cursor: pointer; font-size: 12px; font-weight: 750; text-align: center; }
    .project-file-drop:hover { border-color: #2563eb; background: #eff6ff; }
    .project-file-drop input[type=file] { position: absolute; width: 1px; height: 1px; opacity: 0; }
    .project-replace-form { padding: 17px; border: 1px solid #e7ebf1; border-radius: 12px; background: #f8fafc; }
    .branding-submit { min-height: 45px; border: 0; border-radius: 10px; background: linear-gradient(135deg, #2563eb, #4f46e5); box-shadow: 0 7px 15px rgba(37,99,235,.20); font-weight: 750; }
    @media (max-width: 767.98px) {
        .branding-hero { align-items: flex-start; flex-direction: column; padding: 22px 19px; border-radius: 16px; }
        .branding-health { align-self: flex-start; }
        .branding-tabs { gap: 3px; overflow-x: auto; }
        .branding-tabs .nav-item { min-width: 138px; }
        .branding-tabs .nav-link { min-height: 42px; padding: 8px 10px; font-size: 11px; white-space: nowrap; }
        .branding-section-head, .branding-manager-head { align-items: flex-start; flex-direction: column; }
        .branding-stat-chips { justify-content: flex-start; }
        .branding-manager-body { padding: 0 12px 14px; }
        .branding-manager-head { padding: 17px 14px; }
        .branding-search { width: 100%; }
        .branding-preference-head { padding: 17px 14px 0; }
        .branding-preference-body { padding: 17px 14px; }
        .branding-existing select { font-size: 16px; }
    }
    @media (max-width: 420px) {
        .branding-slot-head { padding-left: 14px; padding-right: 14px; }
        .branding-preview { height: 145px; margin-left: 14px; margin-right: 14px; }
        .branding-slot-body { padding-left: 14px; padding-right: 14px; }
        .branding-existing { flex-direction: column; }
        .branding-existing .btn { width: 100%; }
    }
    body.dark-mode .branding-hero, body[data-layout-mode="dark"] .branding-hero { background: linear-gradient(135deg, #020617, #172554); }
    body.dark-mode .branding-slot-card, body.dark-mode .branding-manager-card, body.dark-mode .branding-preference-card,
    body[data-layout-mode="dark"] .branding-slot-card, body[data-layout-mode="dark"] .branding-manager-card, body[data-layout-mode="dark"] .branding-preference-card,
    body.dark-mode .branding-tabs, body[data-layout-mode="dark"] .branding-tabs { border-color: #2b3a4e; background: #182333; }
    body.dark-mode .branding-slot-head h3, body.dark-mode .branding-section-head h2, body.dark-mode .branding-manager-head h2, body.dark-mode .branding-preference-head h2,
    body[data-layout-mode="dark"] .branding-slot-head h3, body[data-layout-mode="dark"] .branding-section-head h2, body[data-layout-mode="dark"] .branding-manager-head h2, body[data-layout-mode="dark"] .branding-preference-head h2 { color: #f3f4f6; }
    body.dark-mode .branding-preview, body[data-layout-mode="dark"] .branding-preview { border-color: #3b4d64; background: linear-gradient(135deg, #202d3f, #172033); }
    body.dark-mode .branding-manager-head, body.dark-mode .branding-preference-group, body[data-layout-mode="dark"] .branding-manager-head, body[data-layout-mode="dark"] .branding-preference-group { border-color: #2b3a4e; }
</style>

<?php
$brandingGroupMeta = [
    'logo' => ['title' => 'Logos e identificação', 'description' => 'Elementos exibidos no acesso e na navegação do painel.'],
    'login' => ['title' => 'Experiência de login', 'description' => 'Imagem e vídeo usados na tela de autenticação.'],
    'dashboard' => ['title' => 'Ambiente do painel', 'description' => 'Personalize o fundo e a atmosfera da área administrativa.'],
    'banner' => ['title' => 'Banners e destaques', 'description' => 'Imagens para áreas de destaque e comunicação visual.'],
    'avatar' => ['title' => 'Perfis e usuários', 'description' => 'Imagem padrão para administradores e perfis do sistema.'],
];
$brandingSlotCount = 0;
foreach ($slots as $slotGroup) $brandingSlotCount += count($slotGroup);
$brandingCustomCount = count($config);
$brandingBackupCount = is_dir($backupDir) ? count(glob($backupDir . '/*') ?: []) : 0;
$brandingThemeFields = [
    'header_start' => ['label' => 'Barra superior — início', 'fallback' => '#111827'],
    'header_end' => ['label' => 'Barra superior — fim', 'fallback' => '#2563EB'],
    'sidebar_bg' => ['label' => 'Fundo do menu lateral', 'fallback' => '#FFFFFF'],
    'menu_surface' => ['label' => 'Fundo do menu aberto', 'fallback' => '#FFFFFF'],
    'menu_active' => ['label' => 'Fundo do item ativo', 'fallback' => '#EFF6FF'],
    'menu_text' => ['label' => 'Texto dos menus', 'fallback' => '#475467'],
    'menu_text_active' => ['label' => 'Texto ativo', 'fallback' => '#2563EB'],
    'page_bg' => ['label' => 'Fundo da página', 'fallback' => '#F4F7FB'],
];
$brandingIconCatalog = cs_branding_icon_catalog();
$brandingIconLabels = [
    'dashboard' => 'Painel de controle', 'servers' => 'Servidores', 'management' => 'Gestão',
    'resellers' => 'Revendedores', 'users' => 'Usuários', 'content' => 'Conteúdo',
    'bouquets' => 'Buquês', 'iptv_apps' => 'Aplicações IPTV'
];
?>

<div class="<?= $rSettings['sidebar'] ? 'content-page' : 'wrapper' ?>">
    <div class="container-fluid branding-shell">
        <div class="branding-hero">
            <div>
                <span class="branding-eyebrow"><i class="mdi mdi-palette-outline"></i> CSPLAY Identity System</span>
                <h1>Branding Manager</h1>
                <p>Central profissional para controlar identidade visual, mídia, assets do painel e preferências de apresentação em um único lugar.</p>
            </div>
            <div class="branding-health"><span class="branding-health-dot"></span><?= $brandingCustomCount ?> personalizações ativas</div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?= htmlspecialchars($messageType, ENT_QUOTES, 'UTF-8') ?> branding-alert alert-dismissible fade show" role="alert">
                <i class="mdi mdi-<?= $messageType === 'success' ? 'check-circle-outline' : 'alert-circle-outline' ?> font-18"></i>
                <div><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
                <button type="button" class="close" data-dismiss="alert" aria-label="Fechar"><span aria-hidden="true">&times;</span></button>
            </div>
        <?php endif; ?>

        <ul class="nav nav-tabs branding-tabs" role="tablist" aria-label="Seções do gerenciador de identidade visual">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#essential" role="tab"><i class="mdi mdi-star-four-points-outline"></i> Essencial</a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#assets-manager" role="tab"><i class="mdi mdi-folder-multiple-image"></i> Gerenciador</a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#project-manager" role="tab"><i class="mdi mdi-shield-edit-outline"></i> Avançado</a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#settings" role="tab"><i class="mdi mdi-tune-variant"></i> Preferências</a></li>
        </ul>

        <div class="tab-content">
            <div id="essential" class="tab-pane active" role="tabpanel">
                <div class="branding-section-head">
                    <div><h2><span class="branding-section-index">01</span>Branding essencial</h2><p>Atualize cada ponto de contato sem perder a estrutura do sistema.</p></div>
                    <div class="branding-stat-chips"><span class="branding-stat-chip"><i class="mdi mdi-layers-outline"></i> <?= $brandingSlotCount ?> slots</span><span class="branding-stat-chip"><i class="mdi mdi-backup-restore"></i> <?= $brandingBackupCount ?> backups</span></div>
                </div>

                <?php foreach ($slots as $group => $groupSlots): ?>
                    <?php $groupInfo = $brandingGroupMeta[$group] ?? ['title' => ucfirst($group), 'description' => 'Assets configuráveis do painel.']; ?>
                    <div class="branding-section-head mt-4 mb-3">
                        <div><h2 class="font-17"><i class="mdi mdi-folder-outline text-primary mr-1"></i><?= htmlspecialchars($groupInfo['title'], ENT_QUOTES, 'UTF-8') ?></h2><p><?= htmlspecialchars($groupInfo['description'], ENT_QUOTES, 'UTF-8') ?></p></div>
                    </div>
                    <div class="row mb-4">
                        <?php foreach ($groupSlots as $key => $slot):
                            $current = !empty($config[$key]) ? $config[$key] : $slot['fallback'];
                            $isVid = ($slot['type'] ?? '') === 'video';
                            $safeCurrent = htmlspecialchars((string)$current, ENT_QUOTES, 'UTF-8');
                            $safeKey = htmlspecialchars((string)$key, ENT_QUOTES, 'UTF-8');
                            $safeAccept = htmlspecialchars((string)$slot['accept'], ENT_QUOTES, 'UTF-8');
                        ?>
                            <div class="col-xl-4 col-lg-6 col-12 mb-3">
                                <article class="branding-slot-card">
                                    <div class="branding-slot-head"><div><span class="branding-slot-kicker"><?= $isVid ? 'Mídia em vídeo' : 'Mídia visual' ?></span><h3><?= htmlspecialchars($slot['label'], ENT_QUOTES, 'UTF-8') ?></h3></div><span class="branding-slot-type"><?= $isVid ? 'Vídeo' : 'Imagem' ?></span></div>
                                    <div class="branding-preview">
                                        <?php if ($current): ?>
                                            <?php if ($isVid): ?><video muted loop autoplay playsinline preload="metadata"><source src="<?= $safeCurrent ?>?v=<?= time() ?>" type="video/mp4"></video>
                                            <?php else: ?><img src="<?= $safeCurrent ?>?v=<?= time() ?>" alt="Pré-visualização de <?= htmlspecialchars($slot['label'], ENT_QUOTES, 'UTF-8') ?>"><?php endif; ?>
                                            <span class="branding-preview-label"><?= !empty($config[$key]) ? 'Personalizado' : 'Padrão do sistema' ?></span>
                                        <?php else: ?><i class="mdi mdi-image-off-outline no-media" aria-hidden="true"></i><span class="branding-preview-label">Nenhum asset definido</span><?php endif; ?>
                                    </div>
                                    <div class="branding-slot-body">
                                        <div class="branding-current"><span class="branding-current-dot"></span><?= !empty($config[$key]) ? 'Asset personalizado ativo' : 'Usando o asset padrão' ?></div>
                                        <form method="post" enctype="multipart/form-data" class="branding-upload-form">
                                            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="upload_slot"><input type="hidden" name="slot" value="<?= $safeKey ?>">
                                            <label class="branding-upload"><i class="mdi mdi-cloud-upload-outline font-18"></i><span>Enviar novo arquivo<br><small><?= $safeAccept ?> · seleção automática</small></span><input type="file" name="file" accept="<?= $safeAccept ?>" aria-label="Enviar <?= htmlspecialchars($slot['label'], ENT_QUOTES, 'UTF-8') ?>" onchange="this.form.submit()"></label>
                                        </form>
                                        <form method="post" class="branding-existing">
                                            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="use_existing_asset"><input type="hidden" name="slot" value="<?= $safeKey ?>">
                                            <select name="existing_asset" class="form-control" aria-label="Usar asset existente em <?= htmlspecialchars($slot['label'], ENT_QUOTES, 'UTF-8') ?>" required><option value="">Usar asset existente...</option>
                                                <?php foreach ($imageLibrary as $lib): $libVideo = in_array($lib['type'], ['mp4','webm'], true); if ($libVideo !== $isVid) continue; ?><option value="<?= htmlspecialchars($lib['path'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars(basename($lib['path']), ENT_QUOTES, 'UTF-8') ?></option><?php endforeach; ?>
                                            </select><button class="btn btn-info" type="submit">Aplicar</button>
                                        </form>
                                        <?php if (!empty($config[$key])): ?><form method="post"><input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="restore_slot"><input type="hidden" name="slot" value="<?= $safeKey ?>"><button class="btn btn-link branding-restore" type="submit" onclick="return confirm('Restaurar para o padrão do sistema?')"><i class="mdi mdi-restore"></i> Restaurar padrão</button></form><?php endif; ?>
                                    </div>
                                </article>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div id="assets-manager" class="tab-pane" role="tabpanel">
                <div class="branding-manager-card">
                    <div class="branding-manager-head"><div><h2><span class="branding-section-index">02</span>Gerenciador de assets</h2><p>Consulte e substitua arquivos do painel mantendo backup automático.</p></div><div class="branding-search"><i class="mdi mdi-magnify"></i><input type="search" id="assetSearch" class="form-control" placeholder="Buscar arquivo..." aria-label="Buscar arquivo"></div></div>
                    <div class="branding-manager-body">
                        <div class="branding-stat-chips mt-3 justify-content-start"><span class="branding-stat-chip"><i class="mdi mdi-file-multiple-outline"></i> <?= count($assetFiles) ?> arquivos</span><span class="branding-stat-chip"><i class="mdi mdi-image-multiple-outline"></i> <?= count($imageLibrary) ?> mídias reutilizáveis</span><span class="branding-stat-chip"><i class="mdi mdi-shield-check-outline"></i> backups automáticos</span></div>
                        <div class="branding-table-wrap"><table class="table branding-table table-hover" id="assetTable"><thead><tr><th>Arquivo</th><th>Tipo</th><th>Tamanho</th><th>Atualizado</th><th class="text-right">Ação</th></tr></thead><tbody>
                            <?php if (!$assetFiles): ?><tr><td colspan="5"><div class="branding-empty"><i class="mdi mdi-folder-open-outline"></i>Nenhum asset compatível encontrado.</div></td></tr><?php endif; ?>
                            <?php foreach ($assetFiles as $asset): $assetPath = htmlspecialchars($asset['path'], ENT_QUOTES, 'UTF-8'); ?>
                                <tr class="asset-row"><td class="branding-file-name"><?php if (in_array($asset['type'], ['png','jpg','jpeg','webp','ico','svg'])): ?><img class="branding-file-thumb" src="assets/<?= $assetPath ?>?v=<?= time() ?>" alt=""><?php elseif (in_array($asset['type'], ['mp4','webm'])): ?><i class="mdi mdi-video-outline mr-2 text-primary"></i><?php else: ?><i class="mdi mdi-file-code-outline mr-2 text-muted"></i><?php endif; ?><?= $assetPath ?></td><td><span class="branding-type-badge"><?= strtoupper(htmlspecialchars($asset['type'], ENT_QUOTES, 'UTF-8')) ?></span></td><td><?= htmlspecialchars($asset['size'], ENT_QUOTES, 'UTF-8') ?></td><td><?= htmlspecialchars($asset['mtime'], ENT_QUOTES, 'UTF-8') ?></td><td class="text-right"><form method="post" enctype="multipart/form-data" class="d-inline"><input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="replace_asset"><input type="hidden" name="asset_path" value="<?= $assetPath ?>"><label class="btn btn-sm btn-outline-secondary mb-0"><i class="mdi mdi-swap-horizontal"></i> Substituir<input type="file" name="file" class="d-none" onchange="if(confirm('Deseja realmente substituir este arquivo do sistema?')) this.form.submit()"></label></form></td></tr>
                            <?php endforeach; ?>
                        </tbody></table></div>
                        <div class="branding-security-note"><i class="mdi mdi-shield-lock-outline"></i> Cada substituição cria um backup em <strong>assets/uploads/branding/backups</strong>. Use apenas arquivos confiáveis e compatíveis com o projeto.</div>
                    </div>
                </div>
            </div>

            <div id="project-manager" class="tab-pane" role="tabpanel">
                <div class="branding-manager-card">
                    <div class="branding-manager-head"><div><h2><span class="branding-section-index">03</span>Gerenciamento avançado do projeto</h2><p>Substitua arquivos permitidos dentro do projeto com backup automático, validação PHP e restauração segura.</p></div><span class="branding-theme-badge"><i class="mdi mdi-shield-check-outline"></i> Área protegida</span></div>
                    <div class="branding-manager-body">
                        <div class="branding-stat-chips mt-3 justify-content-start"><span class="branding-stat-chip"><i class="mdi mdi-file-code-outline"></i> <?= count($projectFiles) ?> arquivos editáveis</span><span class="branding-stat-chip"><i class="mdi mdi-backup-restore"></i> <?= count($projectBackups) ?> backups disponíveis</span><span class="branding-stat-chip"><i class="mdi mdi-lock-outline"></i> arquivos críticos bloqueados</span></div>
                        <div class="alert alert-warning mt-3"><i class="mdi mdi-alert-outline mr-1"></i> A substituição é limitada à raiz do projeto, mantém a extensão original, aceita até 100 MB e valida a sintaxe de arquivos PHP antes de gravar. Credenciais, sessão e funções críticas ficam protegidas.</div>
                        <form method="post" enctype="multipart/form-data" class="project-replace-form mt-3">
                            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="project_replace">
                            <div class="row align-items-end">
                                <div class="col-lg-7 mb-3"><label for="project_file"><strong>Arquivo de destino</strong></label><select id="project_file" name="project_file" class="form-control" required><option value="">Selecione um arquivo do projeto...</option><?php foreach ($projectFiles as $pf): ?><option value="<?= htmlspecialchars($pf['path'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($pf['path'], ENT_QUOTES, 'UTF-8') ?> · <?= htmlspecialchars($pf['size'], ENT_QUOTES, 'UTF-8') ?></option><?php endforeach; ?></select></div>
                                <div class="col-lg-5 mb-3"><label class="project-file-drop"><i class="mdi mdi-upload-outline mr-1"></i><span>Selecionar substituto</span><input type="file" name="project_upload" required onchange="this.parentNode.querySelector('span').textContent=this.files[0] ? this.files[0].name : 'Selecionar substituto'"></label></div>
                            </div>
                            <button type="submit" class="btn btn-primary branding-submit" onclick="return confirm('Criar backup e substituir o arquivo selecionado?')"><i class="mdi mdi-file-replace-outline mr-1"></i> Fazer backup e substituir</button>
                        </form>
                        <div class="branding-section-head mt-4 mb-2"><div><h3 class="font-17"><i class="mdi mdi-history text-primary mr-1"></i>Histórico e restauração</h3><p>Cada restauração cria um novo backup de segurança antes de alterar o destino.</p></div></div>
                        <div class="branding-table-wrap"><table class="table branding-table table-hover"><thead><tr><th>Arquivo</th><th>Backup criado</th><th>SHA-256</th><th class="text-right">Ação</th></tr></thead><tbody><?php if (!$projectBackups): ?><tr><td colspan="4"><div class="branding-empty"><i class="mdi mdi-backup-restore"></i>Nenhum backup de arquivo do projeto disponível.</div></td></tr><?php endif; ?><?php foreach ($projectBackups as $pb): ?><tr><td><?= htmlspecialchars($pb['target'], ENT_QUOTES, 'UTF-8') ?></td><td><?= htmlspecialchars(date('d/m/Y H:i:s', strtotime($pb['created_at'] ?? 'now')), ENT_QUOTES, 'UTF-8') ?></td><td><code><?= htmlspecialchars(substr($pb['sha256'], 0, 16), ENT_QUOTES, 'UTF-8') ?>…</code></td><td class="text-right"><form method="post"><input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="project_restore"><input type="hidden" name="backup_id" value="<?= htmlspecialchars($pb['id'], ENT_QUOTES, 'UTF-8') ?>"><button type="submit" class="btn btn-sm btn-outline-warning" onclick="return confirm('Restaurar este backup e criar uma cópia do estado atual?')"><i class="mdi mdi-backup-restore"></i> Restaurar</button></form></td></tr><?php endforeach; ?></tbody></table></div>
                    </div>
                </div>
            </div>

            <div id="settings" class="tab-pane" role="tabpanel">
                <div class="branding-theme-card mb-4">
                    <div class="branding-manager-head"><div><h2><span class="branding-section-index">04</span>Visual dos menus</h2><p>Escolha as cores das barras e o ícone de cada seção para personalizar o painel.</p></div><span class="branding-theme-badge"><i class="mdi mdi-brush-variant"></i> Personalização ao vivo</span></div>
                    <div class="branding-theme-body">
                        <form method="post" class="branding-theme-form">
                            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="save_theme">
                            <div class="branding-theme-subhead"><h3><i class="mdi mdi-palette-outline"></i> Paleta de cores</h3><p>Use cores em hexadecimal para manter contraste e identidade visual.</p></div>
                            <div class="row branding-color-grid">
                                <?php foreach ($brandingThemeFields as $themeKey => $themeField): $themeValue = cs_branding_safe_color($config['theme_'.$themeKey] ?? $themeField['fallback'], $themeField['fallback']); ?>
                                    <div class="col-xl-3 col-lg-4 col-6 mb-3"><label class="branding-color-field" for="theme_<?= htmlspecialchars($themeKey, ENT_QUOTES, 'UTF-8') ?>"><span><?= htmlspecialchars($themeField['label'], ENT_QUOTES, 'UTF-8') ?></span><div class="branding-color-input"><input type="color" id="theme_<?= htmlspecialchars($themeKey, ENT_QUOTES, 'UTF-8') ?>" name="theme_<?= htmlspecialchars($themeKey, ENT_QUOTES, 'UTF-8') ?>" value="<?= htmlspecialchars($themeValue, ENT_QUOTES, 'UTF-8') ?>" data-color-output="<?= htmlspecialchars($themeKey, ENT_QUOTES, 'UTF-8') ?>"><output data-color-value="<?= htmlspecialchars($themeKey, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($themeValue, ENT_QUOTES, 'UTF-8') ?></output></div></label></div>
                                <?php endforeach; ?>
                            </div>
                            <div class="branding-theme-subhead mt-3"><h3><i class="mdi mdi-shape-outline"></i> Ícones dos menus</h3><p>Selecione o estilo que será aplicado automaticamente nos menus horizontal e lateral.</p></div>
                            <div class="row branding-icon-grid">
                                <?php foreach ($brandingIconCatalog as $menuKey => $choices): $selectedIcon = (string)($config['menu_icon_'.$menuKey] ?? $choices[0]); if (!in_array($selectedIcon, $choices, true)) $selectedIcon = $choices[0]; ?>
                                    <div class="col-xl-3 col-lg-4 col-6 mb-3"><div class="branding-icon-field"><label for="menu_icon_<?= htmlspecialchars($menuKey, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($brandingIconLabels[$menuKey] ?? ucfirst($menuKey), ENT_QUOTES, 'UTF-8') ?></label><div class="branding-icon-select"><span class="branding-icon-preview"><i class="<?= htmlspecialchars($selectedIcon, ENT_QUOTES, 'UTF-8') ?>" data-icon-preview="<?= htmlspecialchars($menuKey, ENT_QUOTES, 'UTF-8') ?>"></i></span><select class="form-control branding-icon-choice" id="menu_icon_<?= htmlspecialchars($menuKey, ENT_QUOTES, 'UTF-8') ?>" name="menu_icon_<?= htmlspecialchars($menuKey, ENT_QUOTES, 'UTF-8') ?>" data-icon-target="<?= htmlspecialchars($menuKey, ENT_QUOTES, 'UTF-8') ?>"><?php foreach ($choices as $choice): ?><option value="<?= htmlspecialchars($choice, ENT_QUOTES, 'UTF-8') ?>" <?= $selectedIcon === $choice ? 'selected' : '' ?>><?= htmlspecialchars($choice, ENT_QUOTES, 'UTF-8') ?></option><?php endforeach; ?></select></div></div></div>
                                <?php endforeach; ?>
                            </div>
                            <button type="submit" class="btn btn-primary branding-submit branding-theme-submit"><i class="mdi mdi-content-save-outline mr-1"></i> Salvar visual dos menus</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-7 col-12 mb-3"><div class="branding-preference-card"><div class="branding-preference-head"><h2><span class="branding-section-index">05</span>Preferências de mídia</h2><p>Defina como vídeos e fundos se comportam em cada ambiente.</p></div><div class="branding-preference-body"><form method="post"><input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="save_settings">
                        <div class="branding-preference-group"><h3><i class="mdi mdi-login-variant text-primary mr-1"></i>Tela de login</h3><p>Equilibre impacto visual, desempenho e acessibilidade.</p><div class="branding-preference-row"><label for="l_muted">Vídeo sem som <small class="text-muted d-block">Recomendado para evitar reprodução inesperada.</small></label><div class="custom-control custom-switch"><input type="checkbox" class="custom-control-input" id="l_muted" name="login_muted" <?= !empty($config['login_muted']) ? 'checked' : '' ?>><label class="custom-control-label" for="l_muted"></label></div></div><div class="branding-preference-row"><label for="l_loop">Repetir vídeo automaticamente</label><div class="custom-control custom-switch"><input type="checkbox" class="custom-control-input" id="l_loop" name="login_loop" <?= !empty($config['login_loop']) ? 'checked' : '' ?>><label class="custom-control-label" for="l_loop"></label></div></div><div class="branding-preference-row"><label for="l_autoplay">Reprodução automática</label><div class="custom-control custom-switch"><input type="checkbox" class="custom-control-input" id="l_autoplay" name="login_autoplay" <?= !empty($config['login_autoplay']) ? 'checked' : '' ?>><label class="custom-control-label" for="l_autoplay"></label></div></div><label for="login_overlay">Escurecimento do fundo <span class="branding-range-value" data-output-for="login_overlay"><?= (int)($config['login_overlay'] ?? 35) ?>%</span></label><input type="range" class="custom-range branding-range" id="login_overlay" name="login_overlay" min="0" max="100" value="<?= (int)($config['login_overlay'] ?? 35) ?>"></div>
                        <div class="branding-preference-group"><h3><i class="mdi mdi-view-dashboard-outline text-primary mr-1"></i>Painel / dashboard</h3><p>Defina a leitura visual da área administrativa.</p><div class="branding-preference-row"><label for="d_muted">Vídeo sem som</label><div class="custom-control custom-switch"><input type="checkbox" class="custom-control-input" id="d_muted" name="dashboard_muted" <?= !empty($config['dashboard_muted']) ? 'checked' : '' ?>><label class="custom-control-label" for="d_muted"></label></div></div><div class="branding-preference-row"><label for="d_loop">Repetir vídeo automaticamente</label><div class="custom-control custom-switch"><input type="checkbox" class="custom-control-input" id="d_loop" name="dashboard_loop" <?= !empty($config['dashboard_loop']) ? 'checked' : '' ?>><label class="custom-control-label" for="d_loop"></label></div></div><div class="branding-preference-row"><label for="d_autoplay">Reprodução automática</label><div class="custom-control custom-switch"><input type="checkbox" class="custom-control-input" id="d_autoplay" name="dashboard_autoplay" <?= !empty($config['dashboard_autoplay']) ? 'checked' : '' ?>><label class="custom-control-label" for="d_autoplay"></label></div></div><label for="dashboard_overlay">Escurecimento do fundo <span class="branding-range-value" data-output-for="dashboard_overlay"><?= (int)($config['dashboard_overlay'] ?? 35) ?>%</span></label><input type="range" class="custom-range branding-range" id="dashboard_overlay" name="dashboard_overlay" min="0" max="100" value="<?= (int)($config['dashboard_overlay'] ?? 35) ?>"></div>
                        <button type="submit" class="btn btn-primary btn-block branding-submit"><i class="mdi mdi-content-save-outline mr-1"></i> Salvar preferências</button>
                    </form></div></div></div>
                    <div class="col-xl-5 col-12 mb-3"><div class="branding-preference-card"><div class="branding-preference-head"><h2><i class="mdi mdi-lightbulb-on-outline text-warning mr-1"></i>Guia inteligente</h2><p>Boas práticas para uma identidade consistente.</p></div><div class="branding-preference-body"><ul class="branding-tip-list"><li><i class="mdi mdi-check-circle-outline"></i><span><strong>Logos:</strong> prefira PNG ou WebP transparente e mantenha proporção horizontal para não cortar a marca.</span></li><li><i class="mdi mdi-check-circle-outline"></i><span><strong>Vídeos:</strong> use MP4/WebM comprimidos, com resolução adequada para reduzir o tempo de carregamento.</span></li><li><i class="mdi mdi-check-circle-outline"></i><span><strong>Contraste:</strong> ajuste o overlay quando o texto perder legibilidade sobre o fundo.</span></li><li><i class="mdi mdi-check-circle-outline"></i><span><strong>Segurança:</strong> o sistema mantém cópias de segurança ao substituir assets do projeto.</span></li></ul><div class="branding-security-note"><i class="mdi mdi-shield-check-outline"></i><strong><?= $brandingBackupCount ?></strong> backups disponíveis para recuperação.</div></div></div></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    var search = document.getElementById('assetSearch');
    if (search) {
        search.addEventListener('input', function () {
            var value = this.value.toLowerCase().trim();
            document.querySelectorAll('#assetTable tbody tr.asset-row').forEach(function (row) {
                row.style.display = row.textContent.toLowerCase().indexOf(value) !== -1 ? '' : 'none';
            });
        });
    }
    document.querySelectorAll('.branding-range').forEach(function (range) {
        var output = document.querySelector('[data-output-for="' + range.id + '"]');
        var update = function () { if (output) output.textContent = range.value + '%'; };
        range.addEventListener('input', update); update();
    });
    document.querySelectorAll('[data-color-output]').forEach(function (picker) {
        var output = document.querySelector('[data-color-value="' + picker.getAttribute('data-color-output') + '"]');
        var update = function () { if (output) output.textContent = picker.value.toUpperCase(); };
        picker.addEventListener('input', update); update();
    });
    document.querySelectorAll('.branding-icon-choice').forEach(function (select) {
        var key = select.getAttribute('data-icon-target');
        var preview = document.querySelector('[data-icon-preview="' + key + '"]');
        var update = function () { if (preview) preview.className = select.value; };
        select.addEventListener('change', update); update();
    });
}());
</script>

<?php include __DIR__ . '/footer.php'; ?>
<script src="assets/js/app.min.js"></script>
</body>
</html>

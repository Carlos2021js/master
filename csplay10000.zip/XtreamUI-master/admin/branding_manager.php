<?php
/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  IDENTIDADE VISUAL ULTRA PRO – Controle Total de Assets                ║
 * ║  CS Player / Xtream Codes — Compatível PHP 7.4–8.4                     ║
 * ║  Gerencia /admin/assets/ com substituição total de mídias e arquivos   ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
cs_admin_only('a identidade visual e os arquivos de assets');

if ((!hasPermissions('adv', 'settings')) && (!hasPermissions('adv', 'database'))) exit;

require_once __DIR__ . '/branding_helper.php';
require_once __DIR__ . '/cs_audit.php';

// Configurações de diretório
$baseDir = __DIR__ . '/assets/uploads/branding';
$backupDir = $baseDir . '/backups';
$configFile = $baseDir . '/branding.json';
$assetsRoot = __DIR__ . '/assets';

@mkdir($backupDir, 0755, true);

if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

// Detecta upload maior que post_max_size antes do CSRF (PHP esvazia POST/FILES nesse caso).
$postTooLarge = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($_POST) && empty($_FILES)) {
    $contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    $postTooLarge = $contentLength > 0;
}

// CSRF Protection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$postTooLarge) {
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['cs_branding_csrf'] ?? '', (string)$_POST['csrf'])) {
        die('Erro de validação CSRF. Recarregue a página.');
    }
    $_SESSION['cs_branding_csrf'] = bin2hex(random_bytes(24));
}
if (empty($_SESSION['cs_branding_csrf'])) $_SESSION['cs_branding_csrf'] = bin2hex(random_bytes(24));
$csrf = $_SESSION['cs_branding_csrf'];

$message = ''; 
$messageType = 'success';

// Slots de Branding Essencial
$slots = [
    'logo' => [
        'logo_main'    => ['label'=>'Logo Principal', 'fallback'=>($rSettings['logo_url'] ?? 'assets/images/logo.png'), 'accept'=>'.png,.jpg,.jpeg,.webp'],
        'logo_compact' => ['label'=>'Logo Sidebar', 'fallback'=>($rSettings['logo_url_sidebar'] ?? 'assets/images/logo-back.png'), 'accept'=>'.png,.jpg,.jpeg,.webp'],
        'favicon'      => ['label'=>'Favicon', 'fallback'=>'assets/images/favicon.ico', 'accept'=>'.png,.jpg,.jpeg,.webp,.ico'],
    ],
    'login' => [
        'login_background' => ['label'=>'Fundo do Login (Imagem)', 'fallback'=>'assets/images/bg1.png', 'accept'=>'.png,.jpg,.jpeg,.webp', 'type'=>'image'],
        'login_video'      => ['label'=>'Fundo do Login (Vídeo)', 'fallback'=>'', 'accept'=>'.mp4,.webm', 'type'=>'video'],
    ],
    'dashboard' => [
        'dashboard_background' => ['label'=>'Fundo do Painel (Imagem)', 'fallback'=>'assets/images/bgpro.png', 'accept'=>'.png,.jpg,.jpeg,.webp', 'type'=>'image'],
        'dashboard_video'      => ['label'=>'Fundo do Painel (Vídeo)', 'fallback'=>'', 'accept'=>'.mp4,.webm', 'type'=>'video'],
    ],
    'banner' => [
        'banner_main' => ['label'=>'Banner Principal', 'fallback'=>'assets/images/megamenu-bg.png', 'accept'=>'.png,.jpg,.jpeg,.webp'],
    ],
    'avatar' => [
        'admin_avatar' => ['label'=>'Avatar Admin', 'fallback'=>'', 'accept'=>'.png,.jpg,.jpeg,.webp'],
    ]
];

/**
 * Funções Auxiliares
 */
function cs_branding_load_config($file) {
    if (!is_file($file)) return [];
    $data = json_decode((string)@file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function cs_branding_save_config($file, array $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    return @file_put_contents($file, $json, LOCK_EX) !== false;
}

function cs_validate_file($file, $type = 'image') {
    if (!isset($file['error'])) return [false, 'Nenhum arquivo foi recebido pelo PHP.'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE => 'O arquivo ultrapassa upload_max_filesize do PHP.',
            UPLOAD_ERR_FORM_SIZE => 'O arquivo ultrapassa o limite permitido pelo formulário.',
            UPLOAD_ERR_PARTIAL => 'O upload foi recebido apenas parcialmente.',
            UPLOAD_ERR_NO_FILE => 'Selecione um arquivo antes de enviar.',
            UPLOAD_ERR_NO_TMP_DIR => 'A pasta temporária do PHP não está disponível.',
            UPLOAD_ERR_CANT_WRITE => 'O servidor não conseguiu gravar o arquivo no disco.',
            UPLOAD_ERR_EXTENSION => 'Uma extensão do PHP interrompeu o upload.',
        ];
        return [false, $errors[$file['error']] ?? ('Falha no upload. Código: '.(int)$file['error'])];
    }
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $size = $file['size'];

    if ($type === 'video') {
        if (!in_array($ext, ['mp4', 'webm'])) return [false, 'Formato de vídeo inválido (apenas MP4/WebM).'];
        if ($size > 500 * 1024 * 1024) return [false, 'Vídeo muito grande (máx 500MB).'];
    } elseif ($type === 'image') {
        if (!in_array($ext, ['png', 'jpg', 'jpeg', 'webp', 'ico'])) return [false, 'Formato de imagem inválido.'];
        if ($size > 20 * 1024 * 1024) return [false, 'Imagem muito grande (máx 20MB).'];
    } elseif ($type === 'asset') {
        $allowed = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'ico', 'mp4', 'webm', 'css', 'js', 'woff', 'woff2', 'ttf', 'svg'];
        if (!in_array($ext, $allowed)) return [false, 'Tipo de arquivo não permitido para substituição.'];
    }

    return [true, $ext];
}

function cs_resize_logo($source, $destination, $maxDim = 512) {
    if (!function_exists('imagecreatefromstring')) return false;
    $data = @file_get_contents($source);
    $src = @imagecreatefromstring($data);
    if (!$src) return false;

    $width = imagesx($src);
    $height = imagesy($src);
    if ($width <= $maxDim && $height <= $maxDim) {
        imagedestroy($src);
        return false;
    }

    $ratio = min($maxDim / $width, $maxDim / $height);
    $newW = (int)($width * $ratio);
    $newH = (int)($height * $ratio);

    $dst = imagecreatetruecolor($newW, $newH);
    imagealphablending($dst, false);
    imagesavealpha($dst, true);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newW, $newH, $width, $height);
    
    $ext = strtolower(pathinfo($destination, PATHINFO_EXTENSION));
    if ($ext === 'png') imagepng($dst, $destination);
    elseif (in_array($ext, ['jpg', 'jpeg'])) imagejpeg($dst, $destination, 90);
    elseif ($ext === 'webp') imagewebp($dst, $destination, 85);
    
    imagedestroy($src);
    imagedestroy($dst);
    return true;
}

// Processamento de Ações
if ($postTooLarge) {
    $message = 'O vídeo/arquivo excedeu o limite post_max_size do PHP. Aumente post_max_size e upload_max_filesize e tente novamente.';
    $messageType = 'danger';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $config = cs_branding_load_config($configFile);
    $allSlotsFlat = array_merge(...array_values($slots));

    if ($action === 'upload_slot') {
        $slot = (string)($_POST['slot'] ?? '');
        if (isset($allSlotsFlat[$slot])) {
            $type = ($allSlotsFlat[$slot]['type'] ?? '') === 'video' ? 'video' : 'image';
            [$ok, $res] = cs_validate_file($_FILES['file'] ?? [], $type);
            if (!$ok) { $message = $res; $messageType = 'danger'; }
            else {
                $filename = $slot . '_' . time() . '.' . $res;
                $target = $baseDir . '/' . $filename;
                if (@move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
                    if (in_array($slot, ['logo_main', 'logo_compact', 'favicon']) && $type === 'image') {
                        cs_resize_logo($target, $target, $slot === 'favicon' ? 128 : 512);
                    }
                    if (!empty($config[$slot]) && is_file(__DIR__ . '/' . $config[$slot])) {
                        @copy(__DIR__ . '/' . $config[$slot], $backupDir . '/old_' . basename($config[$slot]));
                    }
                    $config[$slot] = 'assets/uploads/branding/' . $filename;
                    cs_branding_save_config($configFile, $config);
                    $message = 'Branding atualizado com sucesso!';
                    cs_audit_log('branding.update', ['slot' => $slot]);
                } else { $message = 'Erro ao salvar arquivo. Verifique permissões.'; $messageType = 'danger'; }
            }
        }
    } elseif ($action === 'use_existing_asset') {
        $slot = (string)($_POST['slot'] ?? '');
        $asset = ltrim(str_replace(['..', '\\'], ['', '/'], (string)($_POST['existing_asset'] ?? '')), '/');
        $full = __DIR__ . '/assets/' . $asset;
        if (!isset($allSlotsFlat[$slot])) {
            $message = 'Slot de branding inválido.'; $messageType = 'danger';
        } elseif (!preg_match('#^(images|videos|media)/#', $asset) || !is_file($full)) {
            $message = 'Selecione uma mídia válida de /admin/assets/images, /videos ou /media.'; $messageType = 'danger';
        } else {
            $ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
            $isVideoSlot = (($allSlotsFlat[$slot]['type'] ?? '') === 'video');
            $allowed = $isVideoSlot ? ['mp4','webm'] : ['png','jpg','jpeg','webp','gif','ico'];
            if (!in_array($ext, $allowed, true)) {
                $message = 'O tipo do arquivo não é compatível com este campo.'; $messageType = 'danger';
            } else {
                $config[$slot] = 'assets/' . $asset;
                cs_branding_save_config($configFile, $config);
                $message = 'Imagem existente aplicada ao branding com sucesso!';
                cs_audit_log('branding.existing_asset', ['slot' => $slot, 'asset' => $asset]);
            }
        }
    } elseif ($action === 'replace_asset') {
        $relPath = str_replace(['..', '\\'], ['', '/'], (string)($_POST['asset_path'] ?? ''));
        $target = realpath($assetsRoot . '/' . $relPath);
        
        if ($target && strpos($target, realpath($assetsRoot)) === 0 && is_file($target)) {
            [$ok, $ext] = cs_validate_file($_FILES['file'] ?? [], 'asset');
            if (!$ok) { $message = $ext; $messageType = 'danger'; }
            else {
                $backupFile = $backupDir . '/asset_' . date('YmdHis') . '_' . basename($target);
                @copy($target, $backupFile);
                if (@move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
                    @chmod($target, 0644);
                    $message = 'Arquivo do projeto substituído! Backup criado.';
                    cs_audit_log('branding.asset_replace', ['file' => $relPath]);
                } else { $message = 'Erro na substituição.'; $messageType = 'danger'; }
            }
        } else { $message = 'Caminho de asset inválido.'; $messageType = 'danger'; }
    } elseif ($action === 'restore_slot') {
        $slot = $_POST['slot'] ?? '';
        if (isset($config[$slot])) {
            @unlink(__DIR__ . '/' . $config[$slot]);
            unset($config[$slot]);
            cs_branding_save_config($configFile, $config);
            $message = 'Restaurado para o padrão do sistema.';
        }
    } elseif ($action === 'save_settings') {
        foreach (['login', 'dashboard'] as $ctx) {
            foreach (['muted', 'loop', 'autoplay'] as $f) $config[$ctx.'_'.$f] = !empty($_POST[$ctx.'_'.$f]);
            $config[$ctx.'_overlay'] = max(0, min(100, (int)($_POST[$ctx.'_overlay'] ?? 35)));
        }
        cs_branding_save_config($configFile, $config);
        $message = 'Configurações de exibição salvas.';
    }
}

// Listagem de Assets para o Gerenciador
$assetFiles = [];
if (is_dir($assetsRoot)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($assetsRoot, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
        if ($file->isFile()) {
            $path = str_replace('\\', '/', substr($file->getPathname(), strlen($assetsRoot) + 1));
            $ext = strtolower($file->getExtension());
            if (in_array($ext, ['png', 'jpg', 'jpeg', 'webp', 'gif', 'ico', 'mp4', 'webm', 'css', 'js', 'svg'])) {
                $assetFiles[] = [
                    'path' => $path,
                    'size' => round($file->getSize() / 1024, 2) . ' KB',
                    'mtime' => date('d/m/Y H:i', $file->getMTime()),
                    'type' => $ext
                ];
            }
        }
    }
}
usort($assetFiles, function($a, $b) { return strcmp($a['path'], $b['path']); });
$imageLibrary = array_values(array_filter($assetFiles, function($a) {
    $isMediaFolder = strpos($a['path'], 'images/') === 0 || strpos($a['path'], 'videos/') === 0 || strpos($a['path'], 'media/') === 0;
    return $isMediaFolder && in_array($a['type'], ['png','jpg','jpeg','webp','gif','ico','mp4','webm'], true);
}));
$phpUploadMax = ini_get('upload_max_filesize');
$phpPostMax = ini_get('post_max_size');

$config = cs_branding_load_config($configFile);
include $rSettings['sidebar'] ? 'header_sidebar.php' : 'header.php';
?>

<style>
    .branding-card { border-radius: 12px; border: none; box-shadow: 0 4px 12px rgba(0,0,0,0.08); transition: transform 0.2s; }
    .branding-card:hover { transform: translateY(-3px); }
    .preview-area { height: 160px; background: #f8f9fa; border-radius: 8px; display: flex; align-items: center; justify-content: center; overflow: hidden; border: 1px solid #eee; margin-bottom: 15px; position: relative; }
    .preview-area img { max-width: 100%; max-height: 100%; object-fit: contain; }
    .preview-area video { width: 100%; height: 100%; object-fit: cover; }
    .preview-area .no-media { color: #ccc; font-size: 2rem; }
    .upload-btn-wrapper { position: relative; overflow: hidden; display: inline-block; width: 100%; }
    .upload-btn-wrapper input[type=file] { font-size: 100px; position: absolute; left: 0; top: 0; opacity: 0; cursor: pointer; }
    .nav-tabs-custom .nav-link.active { color: #4fc6e1; border-bottom: 3px solid #4fc6e1; font-weight: bold; }
    .asset-table-container { max-height: 600px; overflow-y: auto; }
    .badge-type { width: 45px; text-align: center; }
    .branding-hero{background:linear-gradient(135deg,rgba(79,198,225,.16),rgba(103,93,183,.10));border:1px solid rgba(79,198,225,.25);border-radius:18px;padding:20px 22px;margin-bottom:20px}
    .branding-hero h4{margin:0 0 6px;font-weight:700}.branding-hero p{margin:0}
    .branding-section-title{display:flex;align-items:center;gap:10px;margin:24px 0 12px}.branding-section-title .badge{font-size:11px}
    .branding-card{height:100%;border:1px solid rgba(0,0,0,.06)!important;border-radius:16px!important;overflow:hidden}
    .branding-card .card-body{display:flex;flex-direction:column}.branding-card .card-title{font-weight:700;min-height:38px}
    .preview-area{height:190px!important;border-radius:12px!important;background:linear-gradient(135deg,#eef2f7,#f8fafc)!important}
    .branding-card .input-group{flex-wrap:nowrap}.branding-card select.form-control{min-width:0}
    .media-kind{position:absolute;left:10px;top:10px;z-index:2;background:rgba(0,0,0,.62);color:#fff;border-radius:20px;padding:4px 9px;font-size:11px}
    .upload-hint{font-size:11px;color:#7b8794;margin-top:7px}.upload-btn-wrapper input[type=file]{width:100%;height:100%;font-size:0}
    @media(max-width:767.98px){.container-fluid{padding-left:12px;padding-right:12px}.branding-hero{padding:16px}.nav-tabs-custom{display:flex;flex-wrap:nowrap;overflow-x:auto}.nav-tabs-custom .nav-item{flex:0 0 auto}.preview-area{height:155px!important}.branding-card:hover{transform:none}.page-title-box p{font-size:13px}}
</style>

<div class="<?= $rSettings['sidebar'] ? 'content-page' : 'wrapper' ?>">
    <div class="container-fluid">
        <div class="branding-hero">
            <h4><i class="mdi mdi-palette-outline mr-1"></i> Central de Identidade Visual</h4>
            <p class="text-muted">Configure separadamente Login, Dashboard, logos, banner e avatar. Imagens e vídeos podem ser enviados ou escolhidos dos assets existentes.</p>
            <div class="mt-2"><span class="badge badge-light mr-1">upload_max_filesize: <?=htmlspecialchars((string)$phpUploadMax)?></span><span class="badge badge-light">post_max_size: <?=htmlspecialchars((string)$phpPostMax)?></span></div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="page-title"><i class="mdi mdi-palette"></i> Branding Ultra Pro</h4>
                    <p class="text-muted">Controle total sobre a identidade visual e arquivos de assets do painel.</p>
                </div>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?> alert-dismissible fade show">
                <?= $message ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>

        <ul class="nav nav-tabs nav-tabs-custom mb-4" role="tablist">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#essential">Branding Essencial</a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#assets-manager">Gerenciador de Assets</a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#settings">Preferências</a></li>
        </ul>

        <div class="tab-content">
            <!-- ABA: Branding Essencial -->
            <div id="essential" class="tab-pane active">
                <?php foreach ($slots as $group => $groupSlots): ?>
                    <?php $groupNames=['logo'=>'Logos e Favicon','login'=>'Tela de Login','dashboard'=>'Dashboard / Painel','banner'=>'Banner','avatar'=>'Administrador']; ?>
                    <div class="branding-section-title"><h5 class="mb-0 font-weight-bold"><i class="mdi mdi-folder-outline mr-1"></i> <?= $groupNames[$group] ?? ucfirst($group) ?></h5><span class="badge badge-soft-info"><?=count($groupSlots)?> opção(ões)</span></div>
                    <div class="row mb-4">
                        <?php foreach ($groupSlots as $key => $slot): 
                            $current = !empty($config[$key]) ? $config[$key] : $slot['fallback'];
                            $isVid = ($slot['type'] ?? '') === 'video';
                        ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 mb-3">
                                <div class="card branding-card">
                                    <div class="card-body">
                                        <h6 class="card-title"><?= $slot['label'] ?></h6>
                                        <div class="preview-area">
                                            <span class="media-kind"><i class="mdi <?= $isVid ? 'mdi-video' : 'mdi-image' ?>"></i> <?= $isVid ? 'VÍDEO' : 'IMAGEM' ?></span>
                                            <?php if ($current): ?>
                                                <?php if ($isVid): ?>
                                                    <video muted loop autoplay><source src="<?= $current ?>?v=<?= time() ?>" type="video/mp4"></video>
                                                <?php else: ?>
                                                    <img src="<?= $current ?>?v=<?= time() ?>" alt="Preview">
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <i class="mdi mdi-image-off-outline no-media"></i>
                                            <?php endif; ?>
                                        </div>
                                        <form method="post" enctype="multipart/form-data" class="mb-2">
                                            <input type="hidden" name="csrf" value="<?= $csrf ?>">
                                            <input type="hidden" name="action" value="upload_slot">
                                            <input type="hidden" name="slot" value="<?= $key ?>">
                                            <div class="upload-btn-wrapper">
                                                <button class="btn btn-outline-primary btn-block btn-sm"><i class="mdi mdi-upload"></i> Alterar</button>
                                                <input type="file" name="file" accept="<?= $slot['accept'] ?>" onchange="this.form.submit()">
                                            </div>
                                            <div class="upload-hint">Formatos: <?=htmlspecialchars($slot['accept'])?><?= $isVid ? ' • até 500 MB (respeitando os limites do PHP)' : '' ?></div>
                                        </form>
                                        <form method="post" class="mb-2">
                                            <input type="hidden" name="csrf" value="<?= $csrf ?>">
                                            <input type="hidden" name="action" value="use_existing_asset">
                                            <input type="hidden" name="slot" value="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>">
                                            <div class="input-group input-group-sm">
                                                <select name="existing_asset" class="form-control" required>
                                                    <option value="">Escolher mídia existente...</option>
                                                    <?php foreach ($imageLibrary as $lib):
                                                        $libVideo = in_array($lib['type'], ['mp4','webm'], true);
                                                        if ($libVideo !== $isVid) continue; ?>
                                                        <option value="<?= htmlspecialchars($lib['path'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars(basename($lib['path']), ENT_QUOTES, 'UTF-8') ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <div class="input-group-append"><button class="btn btn-info" type="submit">Aplicar</button></div>
                                            </div>
                                        </form>
                                        <?php if (!empty($config[$key])): ?>
                                            <form method="post">
                                                <input type="hidden" name="csrf" value="<?= $csrf ?>">
                                                <input type="hidden" name="action" value="restore_slot">
                                                <input type="hidden" name="slot" value="<?= $key ?>">
                                                <button class="btn btn-link btn-block btn-sm text-danger" onclick="return confirm('Restaurar para o padrão?')">Restaurar Padrão</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- ABA: Gerenciador de Assets -->
            <div id="assets-manager" class="tab-pane">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <h5 class="header-title">Arquivos do Projeto (/admin/assets/)</h5>
                                <p class="text-muted small">Substitua qualquer arquivo de sistema. O nome original será mantido.</p>
                            </div>
                            <div class="col-md-6 text-right">
                                <input type="text" id="assetSearch" class="form-control form-control-sm d-inline-block w-50" placeholder="Buscar arquivo...">
                            </div>
                        </div>
                        <div class="table-responsive asset-table-container">
                            <table class="table table-centered table-hover mb-0" id="assetTable">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Arquivo</th>
                                        <th>Tipo</th>
                                        <th>Tamanho</th>
                                        <th>Modificado</th>
                                        <th class="text-right">Ação</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($assetFiles as $asset): ?>
                                        <tr>
                                            <td class="font-weight-medium">
                                                <?php if (in_array($asset['type'], ['png', 'jpg', 'jpeg', 'webp', 'ico', 'svg'])): ?>
                                                    <img src="assets/<?= $asset['path'] ?>?v=<?= time() ?>" style="height: 24px; width: 24px; object-fit: contain; margin-right: 8px; border: 1px solid #eee;">
                                                <?php elseif (in_array($asset['type'], ['mp4', 'webm'])): ?>
                                                    <i class="mdi mdi-video-outline mr-2 text-primary"></i>
                                                <?php else: ?>
                                                    <i class="mdi mdi-file-code-outline mr-2 text-muted"></i>
                                                <?php endif; ?>
                                                <?= $asset['path'] ?>
                                            </td>
                                            <td><span class="badge badge-soft-info badge-type"><?= strtoupper($asset['type']) ?></span></td>
                                            <td><?= $asset['size'] ?></td>
                                            <td><?= $asset['mtime'] ?></td>
                                            <td class="text-right">
                                                <form method="post" enctype="multipart/form-data" class="d-inline">
                                                    <input type="hidden" name="csrf" value="<?= $csrf ?>">
                                                    <input type="hidden" name="action" value="replace_asset">
                                                    <input type="hidden" name="asset_path" value="<?= $asset['path'] ?>">
                                                    <div class="upload-btn-wrapper" style="width: auto;">
                                                        <button type="button" class="btn btn-sm btn-outline-secondary"><i class="mdi mdi-swap-horizontal"></i> Substituir</button>
                                                        <input type="file" name="file" onchange="if(confirm('Deseja realmente substituir este arquivo do sistema?')) this.form.submit()">
                                                    </div>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ABA: Configurações -->
            <div id="settings" class="tab-pane">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="header-title mb-3">Comportamento de Mídia</h5>
                                <form method="post">
                                    <input type="hidden" name="csrf" value="<?= $csrf ?>">
                                    <input type="hidden" name="action" value="save_settings">
                                    
                                    <div class="mb-4">
                                        <h6 class="font-weight-bold">Tela de Login</h6>
                                        <div class="custom-control custom-checkbox mb-1">
                                            <input type="checkbox" class="custom-control-input" id="l_muted" name="login_muted" <?= !empty($config['login_muted']) ? 'checked' : '' ?>>
                                            <label class="custom-control-label" for="l_muted">Vídeo Mudo (Recomendado)</label>
                                        </div>
                                        <div class="custom-control custom-checkbox mb-1">
                                            <input type="checkbox" class="custom-control-input" id="l_loop" name="login_loop" <?= !empty($config['login_loop']) ? 'checked' : '' ?>>
                                            <label class="custom-control-label" for="l_loop">Repetir Vídeo (Loop)</label>
                                        </div>
                                        <div class="form-group mt-2">
                                            <label>Escurecimento do Fundo (Overlay %)</label>
                                            <input type="range" class="custom-range" name="login_overlay" min="0" max="100" value="<?= $config['login_overlay'] ?? 35 ?>">
                                        </div>
                                    </div>

                                    <div class="mb-4">
                                        <h6 class="font-weight-bold">Painel / Dashboard</h6>
                                        <div class="custom-control custom-checkbox mb-1">
                                            <input type="checkbox" class="custom-control-input" id="d_muted" name="dashboard_muted" <?= !empty($config['dashboard_muted']) ? 'checked' : '' ?>>
                                            <label class="custom-control-label" for="d_muted">Vídeo Mudo</label>
                                        </div>
                                        <div class="custom-control custom-checkbox mb-1">
                                            <input type="checkbox" class="custom-control-input" id="d_loop" name="dashboard_loop" <?= !empty($config['dashboard_loop']) ? 'checked' : '' ?>>
                                            <label class="custom-control-label" for="d_loop">Repetir Vídeo</label>
                                        </div>
                                        <div class="form-group mt-2">
                                            <label>Escurecimento do Fundo (Overlay %)</label>
                                            <input type="range" class="custom-range" name="dashboard_overlay" min="0" max="100" value="<?= $config['dashboard_overlay'] ?? 35 ?>">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-primary btn-block">Salvar Preferências</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-light border-0">
                            <div class="card-body">
                                <h5 class="header-title text-info"><i class="mdi mdi-information-outline"></i> Dicas de Branding</h5>
                                <ul class="pl-3 mt-3">
                                    <li class="mb-2"><strong>Vídeos:</strong> Use formatos .mp4 otimizados para web para garantir carregamento rápido.</li>
                                    <li class="mb-2"><strong>Logos:</strong> O sistema redimensiona automaticamente para o tamanho ideal, mantendo a qualidade.</li>
                                    <li class="mb-2"><strong>Assets:</strong> Ao substituir um arquivo no Gerenciador, um backup é criado automaticamente na pasta de branding.</li>
                                    <li class="mb-2"><strong>Transparência:</strong> O painel suporta fundos semi-transparentes se configurado corretamente no CSS.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('assetSearch').addEventListener('keyup', function() {
        let val = this.value.toLowerCase();
        let rows = document.querySelectorAll('#assetTable tbody tr');
        rows.forEach(row => {
            let text = row.cells[0].textContent.toLowerCase();
            row.style.display = text.includes(val) ? '' : 'none';
        });
    });
</script>

<?php include 'footer.php'; ?>

<?php
$deliveryWasCreated = isset($_GET['created']) && (string)$_GET['created'] === '1';
$deliveryCopyRequested = isset($_GET['copy_info']);
if (empty($rUser) || empty($rUser['username']) || (!$deliveryWasCreated && !$deliveryCopyRequested)) return;

$deliveryServerId = intval($rUser['force_server_id'] ?? 0);
if ($deliveryServerId <= 0 || empty($rServers[$deliveryServerId])) $deliveryServerId = intval($_INFO['server_id'] ?? 0);
$deliveryServer = (isset($rServers[$deliveryServerId]) && is_array($rServers[$deliveryServerId])) ? $rServers[$deliveryServerId] : [];
$deliveryHttps = !empty($rAdminSettings['use_https_main']);
$deliveryScheme = $deliveryHttps ? 'https' : 'http';
$deliveryDns = '';
if (!empty($rPermissions['is_reseller']) && !empty($rUserInfo['reseller_dns'])) {
    $deliveryDns = preg_replace('#^https?://#i', '', trim((string)$rUserInfo['reseller_dns']));
    $deliveryDns = preg_replace('#/.*$#', '', $deliveryDns);
    $deliveryDns = preg_replace('#:\d+$#', '', $deliveryDns);
}
if ($deliveryDns === '') $deliveryDns = trim((string)($deliveryServer['domain_name'] ?? ''));
if ($deliveryDns === '') $deliveryDns = trim((string)($deliveryServer['server_ip'] ?? ''));
$deliveryDns = preg_replace('#^https?://#i', '', $deliveryDns);
$deliveryDns = preg_replace('#/.*$#', '', $deliveryDns);
$deliveryDns = preg_replace('#:\d+$#', '', $deliveryDns);
$deliveryPort = $deliveryHttps ? intval($deliveryServer['https_broadcast_port'] ?? 443) : intval($deliveryServer['http_broadcast_port'] ?? 80);
if ($deliveryPort <= 0) $deliveryPort = $deliveryHttps ? 443 : 80;
$deliveryBase = $deliveryDns !== '' ? $deliveryScheme . '://' . $deliveryDns . ':' . $deliveryPort : '';

// URL pública do Web Player acompanha automaticamente a forma como o painel foi publicado:
// /player/ quando admin é a raiz pública, ou /admin/player/ quando admin está em subpasta.
$deliveryRequestHttps = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') || ((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$deliveryWebScheme = $deliveryRequestHttps ? 'https' : 'http';
$deliveryWebHost = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
$deliveryScriptDir = str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/')));
if ($deliveryScriptDir === '.' || $deliveryScriptDir === '/') $deliveryScriptDir = '';
$deliveryWebPlayer = $deliveryWebHost !== '' ? $deliveryWebScheme . '://' . $deliveryWebHost . rtrim($deliveryScriptDir, '/') . '/player/' : '';
$deliveryUser = (string)$rUser['username'];
$deliveryPass = (string)$rUser['password'];
$deliveryQuery = 'username=' . rawurlencode($deliveryUser) . '&password=' . rawurlencode($deliveryPass);
$deliveryHls = $deliveryBase . '/get.php?' . $deliveryQuery . '&type=m3u_plus&output=hls';
$deliveryM3u = $deliveryBase . '/get.php?' . $deliveryQuery . '&type=m3u_plus&output=mpegts';
$deliveryApi = $deliveryBase . '/player_api.php?' . $deliveryQuery;
$deliveryBouquetNames = [];
$deliveryBouquetIds = json_decode((string)($rUser['bouquet'] ?? '[]'), true);
if (is_array($deliveryBouquetIds) && !empty($deliveryBouquetIds)) {
    $deliveryIds = array_values(array_unique(array_map('intval', $deliveryBouquetIds)));
    $deliveryIdList = implode(',', $deliveryIds);
    $deliveryResult = $db->query("SELECT `bouquet_name` FROM `bouquets` WHERE `id` IN (" . $deliveryIdList . ") ORDER BY `bouquet_order` ASC, `id` ASC;");
    if ($deliveryResult) while ($deliveryRow = $deliveryResult->fetch_assoc()) $deliveryBouquetNames[] = $deliveryRow['bouquet_name'];
}
$deliveryPlan = !empty($deliveryBouquetNames) ? implode(', ', $deliveryBouquetNames) : 'Plano configurado';
$deliveryExpires = !empty($rUser['exp_date']) ? date('d/m/Y H:i:s', (int)$rUser['exp_date']) : 'Sem expiração';
$deliveryConnections = isset($rUser['max_connections']) ? (int)$rUser['max_connections'] : 0;
$deliveryApi = $deliveryBase . '/player_api.php?' . $deliveryQuery;
$deliveryEpg = $deliveryBase . '/xmltv.php?' . $deliveryQuery;

// FORMATO PROFISSIONAL (ESTILO FOTO)
$deliveryMessage = "✅ *Usuário:* " . $deliveryUser . "\n";
$deliveryMessage .= "✅ *Senha:* " . $deliveryPass . "\n";
$deliveryMessage .= "📦 *Plano:* " . $deliveryPlan . "\n";
$deliveryMessage .= "🗓 *Vencimento:* " . $deliveryExpires . "\n";
$deliveryMessage .= "📶 *Conexões:* " . $deliveryConnections . "\n";
$deliveryMessage .= "🌐 *DNS / Servidor:* " . $deliveryBase . "\n\n";
$deliveryMessage .= "🟢 *Link HLS [MAIS RECOMENDADO] (M3U):*\n" . $deliveryHls . "\n\n";
$deliveryMessage .= "🟡 *Link (M3U):*\n" . $deliveryM3u . "\n\n";
$deliveryMessage .= "🔴 *Link (SSIPTV):*\n" . $deliveryBase . "/p/" . rawurlencode($deliveryUser) . "/" . rawurlencode($deliveryPass) . "/ssiptv\n\n";
$deliveryMessage .= "🔗 *Player API:*\n" . $deliveryApi . "\n\n";
$deliveryMessage .= "📺 *EPG / XMLTV:*\n" . $deliveryEpg . "\n\n";
$deliveryMessage .= "🟠 *XCIPTV:*\n";
$deliveryMessage .= "✅ " . $deliveryBase . "\n";
$deliveryMessage .= "✅ " . $deliveryUser . "\n";
$deliveryMessage .= "✅ " . $deliveryPass . "\n\n";
if ($deliveryWebPlayer !== '') {
    $deliveryMessage .= "🎬 *Web Player:*\n" . $deliveryWebPlayer . "\n";
    $deliveryMessage .= "👤 Usuário: " . $deliveryUser . "\n";
    $deliveryMessage .= "🔑 Senha: " . $deliveryPass . "\n\n";
}
$deliveryMessage .= "📺 *Att. Equipe CS Player*";

$deliveryJson = json_encode($deliveryMessage, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>
<div class="modal fade client-delivery-modal" id="clientDeliveryModal" tabindex="-1" role="dialog" aria-labelledby="clientDeliveryTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content text-center">
      <div class="modal-header client-delivery-header bg-primary text-white">
          <h5 class="modal-title w-100" id="clientDeliveryTitle">Detalhes do Cliente</h5>
          <button type="button" class="close text-white" data-dismiss="modal" aria-label="Fechar"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body p-4">
        <div class="alert alert-info border-info bg-transparent text-left mb-4 client-delivery-summary" style="border: 2px solid #35b8e0 !important; border-radius: 10px; color: #fff;">
            <div class="mb-1">✅ <strong>Usuário:</strong> <?=htmlspecialchars($deliveryUser)?></div>
            <div class="mb-1">✅ <strong>Senha:</strong> <?=htmlspecialchars($deliveryPass)?></div>
            <div class="mb-1">📦 <strong>Plano:</strong> <?=htmlspecialchars($deliveryPlan)?></div>
            <div class="mb-1">🗓 <strong>Vencimento:</strong> <?=htmlspecialchars($deliveryExpires)?></div>
            <div class="mb-1">📶 <strong>Conexões:</strong> <?=intval($deliveryConnections)?></div>
            <div class="mb-1">🌐 <strong>DNS:</strong> <?=htmlspecialchars($deliveryBase)?></div>
            <?php if ($deliveryWebPlayer !== '') { ?><div class="mb-1">🎬 <strong>Web Player:</strong> <?=htmlspecialchars($deliveryWebPlayer)?></div><?php } ?>
        </div>

        <div class="client-delivery-message-wrap text-left mb-4">
            <div class="client-delivery-message-label"><i class="mdi mdi-message-text-outline mr-1"></i> Mensagem completa para envio</div>
            <textarea id="clientDeliveryText" class="client-delivery-text" readonly aria-label="Mensagem completa do cliente"><?=htmlspecialchars($deliveryMessage, ENT_QUOTES, 'UTF-8')?></textarea>
        </div>
        
        <div class="row mt-3 client-delivery-actions">
            <div class="col-6">
                <button type="button" class="btn btn-success btn-whatsapp btn-block" id="clientDeliveryWhatsApp"><i class="mdi mdi-whatsapp mr-1"></i> WhatsApp</button>
            </div>
            <div class="col-6">
                <button type="button" class="btn btn-primary btn-block" id="clientDeliveryCopy"><i class="mdi mdi-content-copy mr-1"></i> Copiar</button>
            </div>
        </div>
        <div class="mt-3 client-delivery-close">
            <button type="button" class="btn btn-secondary btn-block" data-dismiss="modal">Fechar</button>
        </div>
        <div class="mt-2">
            <button type="button" class="btn btn-primary btn-block" id="clientDeliveryCopyClose"><i class="mdi mdi-content-copy mr-1"></i> Copiar e fechar</button>
        </div>
      </div>
    </div>
  </div>
</div>
<style>
.client-delivery-header{border-bottom:0}.client-delivery-summary{font-size:15px;line-height:1.7}.client-delivery-message-wrap{padding:16px;background:rgba(255,255,255,.025);border:1px dashed rgba(255,255,255,.18);border-radius:15px}.client-delivery-message-label{margin-bottom:10px;color:#aeb7c7;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.client-delivery-text{display:block;width:100%;min-height:260px;padding:15px;border:1px solid #2563eb;border-radius:10px;color:#a9d2ff;background:#12243b;resize:vertical;font-size:14px;line-height:1.6;white-space:pre-wrap}.client-delivery-actions .btn{min-height:48px}.client-delivery-close{padding-top:4px}
</style>
<script>
(function(){
  var text = <?=$deliveryJson ?: '""'?>;
  var modal = $('#clientDeliveryModal');
  function copyDelivery(closeAfter){
    var done=function(){if(window.jQuery && $.toast)$.toast({heading:'Copiado',text:'Dados do cliente copiados.',icon:'success',position:'top-right'});if(closeAfter)modal.modal('hide');};
    if(navigator.clipboard && window.isSecureContext){navigator.clipboard.writeText(text).then(done).catch(function(){
        var area = $('<textarea>').val(text).appendTo('body').select();
        document.execCommand('copy');
        area.remove();
        done();
    });}
    else{
        var area = $('<textarea>').val(text).appendTo('body').select();
        document.execCommand('copy');
        area.remove();
        done();
    }
  }
  $('#clientDeliveryCopy').on('click',function(){copyDelivery(false);});
  $('#clientDeliveryCopyClose').on('click',function(){copyDelivery(true);});
  $('#clientDeliveryWhatsApp').on('click',function(){window.open('https://wa.me/?text='+encodeURIComponent(text),'_blank','noopener');});
  $(function(){modal.modal({backdrop:'static',keyboard:false}).modal('show');});
}());
</script>

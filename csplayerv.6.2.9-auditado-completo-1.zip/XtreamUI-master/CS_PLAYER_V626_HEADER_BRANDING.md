# CS Player v6.2.6 — Header responsivo orientado pelo Branding Manager

- O `branding_manager.php`/`branding_helper.php` permanecem responsáveis por logo, avatar, banner e cores do cabeçalho.
- Removida a regra v6.2.5 que reorganizava o header como um flex genérico e podia descaracterizar o layout original.
- Smartphone/tablet: Menu + notificações à esquerda, marca centralizada e perfil à direita.
- Desktop: preserva o layout original e a identidade visual configurada pelo Branding Manager.
- Dropdowns de notificações e perfil ficam limitados à viewport no celular.
- Nenhuma alteração de banco de dados, tabelas, colunas ou IDs.

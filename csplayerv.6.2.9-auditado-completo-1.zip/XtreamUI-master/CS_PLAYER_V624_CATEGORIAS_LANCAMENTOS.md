# CS Player v6.2.4 — Organização inteligente de categorias

- Não altera banco de dados, tabelas, colunas, IDs nem `cat_order`.
- Ordena as categorias apenas na apresentação do Web Player.
- Prioridade dinâmica: Lançamentos com ano mais recente primeiro (ex.: 2027, 2026, 2025...), depois Lançamentos sem ano, Novidades/Recentes e demais categorias.
- A regra reconhece variações com ou sem acento e nomes compostos, sem renomear a categoria original.
- Nas telas Filmes e Séries, as categorias prioritárias aparecem antes da grade geral “Todos os filmes” / “Todas as séries”.
- O seletor de categorias usa exatamente a mesma ordem dos carrosséis.
- Mantém filtro adulto, destaques manuais, autenticação local, Multi-DNS, TMDB fallback e os três importadores independentes.
- Mantém a correção TMDB da v6.2.3: normalização do título apenas para busca e correspondência forte, sem criar conteúdo falso.

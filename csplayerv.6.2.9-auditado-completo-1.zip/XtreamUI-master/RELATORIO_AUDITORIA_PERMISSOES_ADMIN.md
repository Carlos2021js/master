# Relatório de auditoria — permissões do painel administrativo

**Projeto analisado:** `csplayerv.3.0.1.zip`  
**Esquema de referência:** `banco_xtream.sql`  
**Data da auditoria:** 18/08/2026  
**Escopo:** garantir que uma conta reconhecida pelo painel como administradora tenha acesso integral às funções administrativas existentes, sem alterar tabelas, colunas, registros ou o arquivo SQL.

## Conclusão

A autorização administrativa já possui um bypass centralizado: quando `is_admin` está ativo no grupo carregado para a sessão, `hasPermissions("adv", ...)` retorna `true` independentemente do conteúdo de `allowed_pages`. Isso permite que o administrador utilize configurações, servidores, segurança, grupos, pacotes, conteúdo, clientes, revendas, logs, ferramentas, importadores e APIs administrativas sem depender de uma lista incompleta de permissões do grupo.

Foram corrigidas dez rotas auxiliares que consultavam `$_SESSION` ou `$rPermissions` sem carregar primeiro `admin/session.php`. Essas rotas poderiam funcionar de forma inconsistente em requisições diretas ou AJAX, mesmo quando a página principal já estivesse autenticada. A correção foi feita somente no código, adicionando o bootstrap de sessão antes das funções centrais.

Também foi removido da Central Administrativa um link duplicado que apontava para `user_reseller.php`, página exclusiva do fluxo de revenda. A Central passa a apontar somente para o fluxo administrativo funcional `user.php`.

> **Resultado:** o banco de dados não foi importado, executado, migrado ou alterado durante esta tarefa. O arquivo SQL de referência permaneceu byte a byte idêntico ao anexo original.

## Arquivos modificados

| Arquivo | Correção aplicada | Efeito administrativo |
|---|---|---|
| `admin/api.php` | Inclusão de `session.php` antes de `functions.php` | As operações AJAX de streams, filmes, episódios, clientes, revendas, servidores, segurança, logs e ferramentas passam a receber a sessão autenticada corretamente. |
| `admin/api_renew.php` | Inclusão de `session.php` antes de `functions.php` | A renovação de clientes usa a mesma autenticação e o mesmo papel administrativo das páginas HTML. |
| `admin/database.php` | Inclusão de `session.php` antes da checagem de `is_admin` | O gerenciador de banco legado não avalia uma sessão vazia por falta de inicialização. O acesso continua exclusivo ao administrador. |
| `admin/index.php` | Inclusão de `session.php` | O redirecionamento inicial identifica corretamente administrador, revendedor e visitante. |
| `admin/table.php` | Inclusão de `session.php` | As tabelas AJAX administrativas passam a carregar permissões reais antes de aplicar seus guards. |
| `admin/table_search.php` | Inclusão de `session.php` | As listagens DataTables e ações administrativas passam a operar com a sessão correta. |
| `admin/user_activity.php` | Inclusão de `session.php` | Logs de atividade, limpeza e filtros administrativos deixam de depender de uma sessão não inicializada. |
| `admin/rtmp_ips.php` | Inclusão de `session.php` | A tela administrativa de IPs RTMP aplica o guard de administrador sobre uma sessão válida. |
| `admin/resellersmarters.php` | Inclusão de `session.php` | A tela de credenciais da API de revenda avalia corretamente a sessão antes do guard específico de revenda. |
| `admin/admin_center.php` | Remoção de link duplicado para fluxo exclusivo de revenda | A Central Administrativa não oferece ao administrador um link que seria bloqueado por `user_reseller.php`. |

## Verificações de autorização

A função `hasPermissions()` em `admin/functions.php` mantém a regra central de acesso integral ao administrador no bloco `adv`. O carregamento em `getPermissions()` normaliza flags como `is_admin`, `is_reseller` e `is_banned`, e `forceSecurity()` valida a sessão e o papel antes de disponibilizar o restante do painel. A própria sessão também transforma uma conta administrativa em não-revenda para impedir que o layout administrativo seja confundido com o layout de revenda.

As telas críticas conferidas foram `settings.php`, `groups.php`, `servers.php`, `security_center.php`, `admin_center.php`, `system_health.php`, `system_logs.php`, `database.php`, `api.php`, `api_renew.php`, `table.php` e `table_search.php`. Os guards dessas páginas continuam exigindo administrador quando a função é exclusiva e, quando usam `hasPermissions("adv", ...)`, o bypass administrativo concede acesso integral sem exigir alterações no campo `allowed_pages`.

O SQL de referência define o grupo administrativo com `group_id = 1` e `is_admin = 1`. A conta de exemplo está vinculada ao grupo 1. A implementação corrigida utiliza essa estrutura existente e não cria nenhum campo novo nem altera os registros.

## Testes realizados

| Teste | Resultado |
|---|---|
| Comparação SHA-256 de `banco_xtream.sql` original e cópia de trabalho | Aprovado. Ambos produziram `9b57e517257a73dcb459ee084efd5ffe66fa30e955db5743034aa159c854582e`. |
| Comparação byte a byte do SQL | Aprovado. `SQL_INTACTO=SIM`. |
| Busca por rotas que usam `$_SESSION` sem `session.php` | Aprovado para as rotas web corrigidas. Restaram apenas arquivos esperados: `functions.php`, `cs_audit.php`, `login.php`, `logout.php` e o próprio `session.php`. |
| Verificação do bypass de `hasPermissions("adv", ...)` | Aprovado. O administrador retorna `true` antes da avaliação de `allowed_pages`. |
| Busca por uso ativo direto de `advanced` fora do núcleo | Nenhum uso ativo encontrado fora de `functions.php` e da edição de grupos; ocorrências restantes estão em cópias de backup não carregadas. |
| Diff contra o ZIP original | Aprovado. As mudanças ficaram restritas aos dez arquivos listados acima. |
| Validação com `php -l` | Não executada neste ambiente porque o PHP CLI não está instalado. Recomenda-se rodar `php -l` no servidor ou CI com a versão PHP usada em produção antes do deploy. |

## Observações de implantação

A conta administrativa deve continuar vinculada a um grupo existente com `is_admin = 1`, estar habilitada e não pertencer ao grupo bloqueado. Não é necessário executar o `banco_xtream.sql`, aplicar `ALTER TABLE`, executar `UPDATE`, criar permissões manualmente ou importar qualquer migração para utilizar as correções.

O arquivo `admin/notification_system.php` já existente contém lógica própria de criação de uma tabela de notificações quando o recurso é utilizado. Essa lógica não foi executada nem modificada nesta auditoria. Se o requisito operacional for impedir qualquer criação automática de tabela também em produção, isso deverá ser tratado separadamente, com uma decisão explícita sobre a funcionalidade de notificações.

## Referências internas

1. [Autorização central em `admin/functions.php`](admin/functions.php#L1168-L1210)
2. [Carregamento e normalização de permissões em `admin/functions.php`](admin/functions.php#L1692-L1715)
3. [Validação global de sessão em `admin/functions.php`](admin/functions.php#L2400-L2419)
4. [Grupo administrativo no SQL de referência](../banco_xtream.sql#L974-L1023)
5. [Conta vinculada ao grupo administrativo no SQL de referência](../banco_xtream.sql#L2311-L2365)
6. [Central Administrativa](admin/admin_center.php#L1-L76)

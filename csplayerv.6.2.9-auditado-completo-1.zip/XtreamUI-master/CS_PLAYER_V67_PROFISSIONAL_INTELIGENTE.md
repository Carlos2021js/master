# CS Player v6.7 — Profissional e Inteligente

Esta versão evolui a v6.6 sem alterar o schema do banco e sem remover funcionalidades.

## Melhorias globais
- Design System global adicional (`assets/css/cs-player-v67.css`) carregado pelo header normal e sidebar.
- UX global (`assets/js/cs-player-v67.js`) com tradução visual das partes legadas do DataTables, feedback de cópia, atalho Ctrl/Cmd+K para pesquisa e barra discreta de navegação.
- Responsividade reforçada para Admin e Revenda: formulários, filtros, DataTables, cards, paginação, dropdowns e modais.
- Tabelas largas passam a ter área de rolagem controlada em smartphone em vez de quebrar o layout.
- Dark mode recebe refinamentos de contraste e componentes sem substituir os temas existentes.
- Acessibilidade: alvos de toque maiores e `prefers-reduced-motion`.

## Compatibilidade
- Nenhuma tabela criada, removida ou alterada.
- Nenhuma coluna ou índice alterado.
- Importadores existentes preservados.
- URLs/endpoints existentes preservados.

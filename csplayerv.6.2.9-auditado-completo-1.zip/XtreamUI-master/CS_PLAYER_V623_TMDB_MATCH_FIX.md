# CS Player v6.2.3 — TMDB Match Fix

- Corrige limpeza de títulos para consulta TMDB sem alterar o título exibido no catálogo.
- Extrai o ano do título, inclusive em formatos como (2026), antes da busca.
- Remove prefixos técnicos alfanuméricos de provedores, qualidade, idioma e marcadores de episódio apenas da consulta TMDB.
- Mantém correspondência forte e rejeição de conteúdo adulto; TMDB continua sendo somente fallback.
- Não altera banco de dados, tabelas, colunas ou IDs.
- Mantém autenticação local e filtro adulto já existentes.

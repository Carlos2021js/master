<?php
/** Classificação rígida/inteligente conforme estrutura do CS PLAYER. */
class CSM3U2Classifier
{
    const LIVE_EXT = array('m3u8', 'ts', 'mpegts');
    const VOD_EXT = array('mp4', 'mkv');
    const LEGACY_VOD_EXT = array('avi', 'mov', 'wmv', 'flv', 'webm', 'm4v');

    public static function classify($url, $name, $group, array $options)
    {
        $mode = isset($options['classification']) ? (string)$options['classification'] : 'auto';
        if (!in_array($mode, array('auto', 'live', 'movie', 'series'), true)) $mode = 'auto';
        $ext = self::extension($url);
        $series = self::seriesInfo($name);
        $legacyVod = !empty($options['legacy_vod']);

        $isLiveExt = in_array($ext, self::LIVE_EXT, true);
        $isVODExt = in_array($ext, self::VOD_EXT, true) || ($legacyVod && in_array($ext, self::LEGACY_VOD_EXT, true));

        if ($mode === 'live') {
            if (!$isLiveExt) return self::unknown('modo_live_incompativel', $ext);
            return array('kind' => 'live', 'type' => 1, 'ext' => $ext, 'series' => null, 'reason' => 'modo_forcado');
        }
        if ($mode === 'movie') {
            if (!$isVODExt || $series) return self::unknown($series ? 'modo_filme_com_padrao_episodio' : 'modo_filme_incompativel', $ext);
            return array('kind' => 'movie', 'type' => 2, 'ext' => $ext, 'series' => null, 'reason' => 'modo_forcado');
        }
        if ($mode === 'series') {
            if (!$isVODExt || !$series) return self::unknown(!$isVODExt ? 'modo_serie_incompativel' : 'modo_serie_sem_episodio', $ext);
            return array('kind' => 'series', 'type' => 5, 'ext' => $ext, 'series' => $series, 'reason' => 'modo_forcado');
        }

        $groupKey = CSM3U2PlaylistParser::normalize($group);
        $isSeriesGroup = (bool)preg_match('/\b(series?|seriados?|novelas?|doramas?|animes?|desenhos?|temporadas?|epis[oó]dios?)\b/iu', $groupKey);
        $isMovieGroup = (bool)preg_match('/\b(filmes?|movies?|vod|cinema)\b/iu', $groupKey);
        $isLiveGroup = (bool)preg_match('/\b(live|tv|canais?|canais? ao vivo|radio|rádio)\b/iu', $groupKey);
        // Grupos ajudam a explicar o item, mas nunca substituem a validação da extensão.
        if ($isSeriesGroup) {
            if (!$isVODExt) return self::unknown('grupo_serie_extensao_incompativel', $ext);
            $series = $series ?: array('title' => self::fallbackSeriesTitle($name), 'season' => self::seasonFallback($name), 'episode' => self::episodeNumberFallback($name));
            return array('kind' => 'series', 'type' => 5, 'ext' => $ext, 'series' => $series, 'reason' => 'grupo_series');
        }
        if ($series && $isVODExt) {
            return array('kind' => 'series', 'type' => 5, 'ext' => $ext, 'series' => $series, 'reason' => 'padrao_episodio');
        }
        if ($isMovieGroup) {
            if (!$isVODExt || $series) return self::unknown('grupo_filme_incompativel', $ext);
            return array('kind' => 'movie', 'type' => 2, 'ext' => $ext, 'series' => null, 'reason' => 'grupo_filmes');
        }
        if ($isLiveGroup) {
            if (!$isLiveExt) return self::unknown('grupo_live_extensao_incompativel', $ext);
            return array('kind' => 'live', 'type' => 1, 'ext' => $ext, 'series' => null, 'reason' => 'grupo_live');
        }
        if ($isLiveExt) {
            return array('kind' => 'live', 'type' => 1, 'ext' => $ext, 'series' => null, 'reason' => 'extensao_live');
        }
        if ($isVODExt) {
            return array('kind' => 'movie', 'type' => 2, 'ext' => $ext ?: 'mp4', 'series' => null, 'reason' => 'extensao_vod');
        }
        return array('kind' => 'unknown', 'type' => 0, 'ext' => $ext, 'series' => null, 'reason' => 'extensao_nao_suportada');
    }

    private static function unknown($reason, $ext)
    {
        return array('kind' => 'unknown', 'type' => 0, 'ext' => (string)$ext, 'series' => null, 'reason' => (string)$reason);
    }

    public static function seriesInfo($name)
    {
        $patterns = array(
            '/^(.*?)[\[\( ._\-]+S(\d{1,3})\s*E(\d{1,4})\b/i',
            '/^(.*?)[\[\( ._\-]+(\d{1,3})x(\d{1,4})\b/i',
            '/^(.*?)[._\-\s]+Season\s*(\d{1,3})[._\-\s]+Episode\s*(\d{1,4})\b/i',
            '/^(.*?)[._\-\s]+Temporada\s*(\d{1,3})[._\-\s]+(?:Epis[oó]dio|EP?)\s*(\d{1,4})\b/iu',
            '/^(.*?)[._\-\s]+T(\d{1,3})\s*(?:EP?|Epis[oó]dio)\s*(\d{1,4})\b/iu'
        );
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, (string)$name, $m)) {
                $title = CSM3U2PlaylistParser::cleanTitle($m[1]);
                if ($title === '') $title = 'Série sem nome';
                return array('title' => $title, 'season' => max(0, (int)$m[2]), 'episode' => max(1, (int)$m[3]));
            }
        }
        return null;
    }

    public static function extension($url)
    {
        $path = (string)(parse_url((string)$url, PHP_URL_PATH) ?: '');
        return strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
    }

    private static function fallbackSeriesTitle($name)
    {
        $clean = preg_replace('/\b(?:S\d{1,3}E\d{1,4}|\d{1,3}x\d{1,4}|T\d{1,3}\s*EP?\d{1,4})\b/i', '', (string)$name);
        $clean = CSM3U2PlaylistParser::cleanTitle($clean);
        return $clean !== '' ? $clean : 'Série importada';
    }

    private static function seasonFallback($name)
    {
        if (preg_match('/(?:S|T|Season|Temporada)\s*0*(\d{1,3})/iu', (string)$name, $m)) return max(1, (int)$m[1]);
        return 1;
    }

    private static function episodeNumberFallback($name)
    {
        if (preg_match('/(?:EP?|Epis[oó]dio)\s*(\d{1,4})\b/iu', (string)$name, $m)) return max(1, (int)$m[1]);
        if (preg_match('/(?:^|[._\-\s])(\d{1,4})(?:\.[a-z0-9]{2,5})?$/i', (string)$name, $m)) return max(1, (int)$m[1]);
        return 1;
    }
}

<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

include __DIR__ . '/session.php';
include __DIR__ . '/functions.php';

function json_error(string $message, int $status = 400): never {
    http_response_code($status);
    echo json_encode(['success' => false, 'message' => $message], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (empty($rPermissions['is_admin']) && empty($rPermissions['is_reseller'])) {
    json_error('Acesso negado.', 403);
}

$userId = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$userId) json_error('ID de usuário inválido.');

if (!empty($rPermissions['is_reseller']) && empty($rPermissions['is_admin'])) {
    $stmt = $db->prepare('SELECT id FROM users WHERE id = ? AND member_id IN (SELECT id FROM reg_users WHERE id = ? OR owner_id = ?) LIMIT 1');
    if (!$stmt) json_error('Erro interno de consulta.', 500);
    $ownerId = (int)$rUserInfo['id'];
    $stmt->bind_param('iii', $userId, $ownerId, $ownerId);
    $stmt->execute();
    if (!$stmt->get_result()->fetch_assoc()) json_error('Usuário não pertence a este revendedor.', 403);
    $stmt->close();
}

$stmt = $db->prepare('SELECT id, username, password, member_id, created_at, exp_date, max_connections, enabled, admin_enabled, is_trial, is_mag, is_e2, is_isplock, isp_desc, forced_country FROM users WHERE id = ? LIMIT 1');
if (!$stmt) json_error('Erro interno de consulta.', 500);
$stmt->bind_param('i', $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$user) json_error('Usuário não encontrado.', 404);

$serverId = (int)($_INFO["server_id"] ?? 0);
$server = $rServers[$serverId] ?? [];
$scheme = (!empty($rAdminSettings["use_https_main"]) || (!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off")) ? "https" : "http";
$host = trim((string)($server["domain_name"] ?? ""));
if ($host === "") $host = trim((string)($server["vpn_ip"] ?? ""));
if ($host === "") $host = trim((string)($server["server_ip"] ?? ""));
if ($host === "") $host = trim((string)($_SERVER["HTTP_HOST"] ?? ""));
$host = preg_replace("#^https?://#i", "", $host);
$host = explode("/", $host, 2)[0];
if ($host === "") json_error("Domínio público do servidor não configurado.", 500);
$port = $scheme === "https" ? (int)($server["https_broadcast_port"] ?? 0) : (int)($server["http_broadcast_port"] ?? 0);
if (strpos($host, ":") === false && $port > 0 && !(($scheme === "http" && $port === 80) || ($scheme === "https" && $port === 443))) {
    $host .= ":" . $port;
}
$base = $scheme . "://" . $host;

$u = rawurlencode((string)$user['username']);
$p = rawurlencode((string)$user['password']);
$query = '?username=' . $u . '&password=' . $p . '&type=m3u_plus';

$fmtDate = static function ($value): ?string {
    return ($value !== null && $value !== '' && (int)$value > 0) ? date('d/m/Y H:i:s', (int)$value) : null;
};

$data = [
    'id' => (int)$user['id'],
    'username' => (string)$user['username'],
    'password' => (string)$user['password'],
    'plan' => 'N/A',
    'plan_price' => 'R$ 0,00',
    'created_at' => $fmtDate($user['created_at']),
    'expiration' => $fmtDate($user['exp_date']),
    'connections' => max(1, (int)$user['max_connections']),
    'status' => (int)$user['enabled'],
    'admin_enabled' => (int)$user['admin_enabled'],
    'is_trial' => (int)$user['is_trial'],
    'is_mag' => (int)$user['is_mag'],
    'is_e2' => (int)$user['is_e2'],
    'is_isplock' => (int)$user['is_isplock'],
    'isp_desc' => (string)($user['isp_desc'] ?? ''),
    'forced_country' => (string)($user['forced_country'] ?? ''),
    'link_hls' => $base . '/get.php' . $query . '&output=hls',
    'link_mpegts' => $base . '/get.php' . $query . '&output=mpegts',
    'xciptv_url' => $base,
    'xciptv_user' => (string)$user['username'],
    'xciptv_pass' => (string)$user['password'],
];

echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

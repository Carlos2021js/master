# CS Player — pacote completo dos importadores M3U

Este pacote contém a versão corrigida do CS Player com os importadores M3U original, M3U 2 e M3U 3, além da variante compatível `m3u_update_nodup1.php`. A correção principal do M3U 3 evita manter a requisição HTTP aberta durante toda a importação: a ação `start` retorna HTTP 202 com `accepted=true` e o processamento continua pelo job acompanhado via polling.

## Conteúdo

| Arquivo ou pasta | Finalidade |
|---|---|
| `XtreamUI/` | Projeto completo corrigido. |
| `INSTALAR_PHP74.sh` | Backup, instalação, permissões, limites PHP-FPM e snippet Nginx. |
| `VALIDAR_SERVIDOR.sh` | Verificação pós-instalação. |
| `test-m3u3-fixture.m3u` | Playlist mínima com canal, filme e dois episódios. |
| `RELATORIO_TESTE_M3U3_503.md` | Resultado do teste controlado e procedimento de confirmação no VPS. |

## Instalação

Copie o ZIP para o servidor e extraia-o em uma pasta temporária. Edite `PANEL_ROOT` e `WEB_USER` caso o painel não esteja em `/home/xtreamcodes/iptv_xtream_codes` ou o PHP-FPM não use `www-data`. Em seguida, execute:

```bash
cd CS-PLAYER-PACOTE-COMPLETO
sudo PHP_VERSION=7.4 PANEL_ROOT=/home/xtreamcodes/iptv_xtream_codes WEB_USER=www-data bash INSTALAR_PHP74.sh
sudo PHP_VERSION=7.4 PANEL_ROOT=/home/xtreamcodes/iptv_xtream_codes WEB_USER=www-data bash VALIDAR_SERVIDOR.sh
```

O instalador cria um backup com data antes de copiar os arquivos e configura `upload_max_filesize = 64M`, `post_max_size = 72M`, `max_execution_time = 0`, `max_input_time = 3600` e `memory_limit = 512M`. O upload do M3U continua fragmentado, portanto o tamanho total da playlist não fica limitado a 64 MB; esse valor se aplica a cada requisição/bloco.

O snippet Nginx precisa estar incluído dentro do bloco `server` que atende o painel:

```nginx
include snippets/cs-player-importers.conf;
```

Depois valide com `nginx -t`. O instalador reinicia o PHP-FPM e recarrega o Nginx, mas não altera credenciais, banco ou configurações de autenticação.

## Teste do M3U 3

Use primeiro `test-m3u3-fixture.m3u`. A tela deve enviar, analisar e iniciar o job. A requisição de início deve receber HTTP 202 com JSON contendo `ok=true`, `accepted=true` e `job_id`. O job deve avançar para `sucesso`.

O teste deve ser feito com um servidor de streaming e um buquê selecionados. O resultado esperado é um canal em `bouquet_channels`, um filme em `bouquet_channels`, uma série em `bouquet_series` e dois episódios em `series_episodes`. Os streams também devem possuir uma linha em `streams_sys` com o `server_id` selecionado.

## Diagnóstico se ainda houver 503

Se o navegador ainda mostrar 503, colete os logs imediatamente durante o teste:

```bash
sudo tail -n 100 /var/log/nginx/error.log
sudo journalctl -u php7.4-fpm -n 100 --no-pager
sudo find /home/xtreamcodes/iptv_xtream_codes/admin/storage/m3u3 -type f -maxdepth 3 -printf '%TY-%Tm-%Td %TH:%TM:%TS %p\n' | tail -n 50
```

Verifique também se o pool PHP-FPM está reiniciando, se `pm.max_children` foi atingido, se o banco aceita a quantidade de conexões e se as pastas `admin/storage/m3u3` e `admin/storage/import_jobs` são graváveis pelo usuário do PHP-FPM.

## Rollback

O instalador informa o caminho do backup criado antes da instalação. Para restaurar, pare ou coloque o painel em manutenção, preserve eventuais arquivos novos de armazenamento e restaure a pasta do backup para o caminho original. Não restaure o armazenamento de jobs sem necessidade, pois isso pode apagar o histórico recente de importações.

## Compatibilidade

O pacote foi validado sintaticamente no ambiente local. O servidor informado usa PHP 7.4.33; essa versão está fora de suporte, portanto recomenda-se planejar atualização para PHP 8.1 ou superior após confirmar a compatibilidade do painel. A instalação deste pacote foi preparada para o pool PHP 7.4 informado.

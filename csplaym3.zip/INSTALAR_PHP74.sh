#!/usr/bin/env bash
set -Eeuo pipefail

PHP_VERSION="${PHP_VERSION:-7.4}"
PANEL_ROOT="${PANEL_ROOT:-/home/xtreamcodes/iptv_xtream_codes}"
WEB_USER="${WEB_USER:-www-data}"
NGINX_SNIPPET="/etc/nginx/snippets/cs-player-importers.conf"
PHP_INI="/etc/php/${PHP_VERSION}/fpm/conf.d/99-cs-player-importers.ini"
SOURCE_ROOT="$(cd "$(dirname "$0")" && pwd)/XtreamUI"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Execute como root: sudo bash $0"
  exit 1
fi
if [[ ! -d "$SOURCE_ROOT/admin" ]]; then
  echo "Projeto não encontrado em $SOURCE_ROOT"
  exit 1
fi
if ! command -v nginx >/dev/null 2>&1; then
  echo "Nginx não encontrado. Instale-o antes de continuar."
  exit 1
fi
if ! command -v "php-fpm${PHP_VERSION}" >/dev/null 2>&1 && ! command -v php-fpm >/dev/null 2>&1; then
  echo "PHP-FPM não encontrado para PHP ${PHP_VERSION}."
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="${PANEL_ROOT}.backup-${STAMP}"
if [[ -d "$PANEL_ROOT" ]]; then
  cp -a "$PANEL_ROOT" "$BACKUP"
  echo "Backup criado em $BACKUP"
else
  mkdir -p "$PANEL_ROOT"
fi

mkdir -p "$PANEL_ROOT/admin"
cp -a "$SOURCE_ROOT/." "$PANEL_ROOT/"

mkdir -p "$PANEL_ROOT/admin/storage/m3u2" "$PANEL_ROOT/admin/storage/m3u3" "$PANEL_ROOT/admin/storage/import_jobs"
chown -R "$WEB_USER":"$WEB_USER" "$PANEL_ROOT/admin/storage"
chmod -R u+rwX,go-rwx "$PANEL_ROOT/admin/storage"

install -d -m 0755 /etc/nginx/snippets
cat > "$NGINX_SNIPPET" <<'NGINX'
# CS Player: uploads fragmentados e importações longas em jobs.
client_max_body_size 0;
client_body_timeout 3600s;
fastcgi_read_timeout 3600s;
fastcgi_send_timeout 3600s;
NGINX

install -d -m 0755 "/etc/php/${PHP_VERSION}/fpm/conf.d"
cat > "$PHP_INI" <<'PHPINI'
; CS Player — limites por bloco do upload e jobs de importação.
upload_max_filesize = 64M
post_max_size = 72M
max_execution_time = 0
max_input_time = 3600
memory_limit = 512M
default_socket_timeout = 300
PHPINI

echo "Inclua no bloco server do Nginx: include snippets/cs-player-importers.conf;"
nginx -t
systemctl restart "php${PHP_VERSION}-fpm" 2>/dev/null || systemctl restart php-fpm
systemctl reload nginx

echo "Instalação concluída. Backup: $BACKUP"
echo "Execute agora: sudo bash VALIDAR_SERVIDOR.sh"

#!/usr/bin/env bash
set -u

PHP_VERSION="${PHP_VERSION:-7.4}"
PANEL_ROOT="${PANEL_ROOT:-/home/xtreamcodes/iptv_xtream_codes}"
WEB_USER="${WEB_USER:-www-data}"
OK=0
WARN=0

check() {
  local label="$1"; shift
  if "$@" >/dev/null 2>&1; then echo "OK    $label"; OK=$((OK+1)); else echo "ATENÇÃO $label"; WARN=$((WARN+1)); fi
}

printf '%s\n' 'CS PLAYER — validação do servidor'
command -v php >/dev/null 2>&1 && php -v | head -1 || echo 'ATENÇÃO PHP CLI não encontrado'
php -m 2>/dev/null | grep -qi '^mysqli$' && echo 'OK    mysqli' || echo 'ATENÇÃO mysqli'
php -m 2>/dev/null | grep -qi '^curl$' && echo 'OK    curl' || echo 'ATENÇÃO curl'
php -m 2>/dev/null | grep -qi '^json$' && echo 'OK    json' || echo 'ATENÇÃO json'
php -m 2>/dev/null | grep -qi '^mbstring$' && echo 'OK    mbstring' || echo 'ATENÇÃO mbstring'
php -m 2>/dev/null | grep -qi '^fileinfo$' && echo 'OK    fileinfo' || echo 'ATENÇÃO fileinfo'
php -m 2>/dev/null | grep -qi '^zip$' && echo 'OK    zip' || echo 'ATENÇÃO zip — opcional para M3U, recomendado para o painel'

php -r 'foreach (array("upload_max_filesize","post_max_size","max_execution_time","max_input_time","memory_limit") as $k) echo $k."=".ini_get($k).PHP_EOL;' 2>/dev/null || true

for f in \
  "$PANEL_ROOT/admin/m3u_update_nodup.php" \
  "$PANEL_ROOT/admin/m3u_update_nodup1.php" \
  "$PANEL_ROOT/admin/m3u_update_nodup2.php" \
  "$PANEL_ROOT/admin/m3u_update_nodup3.php" \
  "$PANEL_ROOT/admin/includes/m3u2/ImportEngine.php" \
  "$PANEL_ROOT/admin/includes/m3u3/ImportEngine.php"; do
  if [[ -f "$f" ]]; then
    php -l "$f" 2>&1 | grep -q 'No syntax errors' && echo "OK    sintaxe $(basename "$f")" || echo "FALHA sintaxe $f"
  else
    echo "FALHA ausente $f"
  fi
done

for d in "$PANEL_ROOT/admin/storage/m3u2" "$PANEL_ROOT/admin/storage/m3u3" "$PANEL_ROOT/admin/storage/import_jobs"; do
  [[ -d "$d" && -w "$d" ]] && echo "OK    gravável $d" || echo "FALHA gravável $d"
done

if command -v nginx >/dev/null 2>&1; then nginx -t 2>&1 && echo 'OK    nginx -t' || echo 'FALHA nginx -t'; fi
systemctl is-active --quiet "php${PHP_VERSION}-fpm" && echo "OK    php${PHP_VERSION}-fpm ativo" || echo "ATENÇÃO php${PHP_VERSION}-fpm — confirme o nome do serviço"

printf '\nResultado: %s verificações OK; %s pontos para revisar.\n' "$OK" "$WARN"

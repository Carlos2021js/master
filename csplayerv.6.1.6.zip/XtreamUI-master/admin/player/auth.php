<?php
require __DIR__ . '/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
$cfg = cs_player_load_config();
$username = trim((string)($_POST['username'] ?? ''));
$password = (string)($_POST['password'] ?? '');
if ($username === '' || $password === '') { $_SESSION['cs_player_error'] = 'Informe usuário e senha.'; header('Location: index.php'); exit; }
// O login prioriza a lista automática sincronizada com streaming_servers.
// DNS externos persistidos no painel são usados somente como fallback; valores manuais de sessões antigas são ignorados.
$dnsList = cs_player_session_dns_list($cfg, '', false);
$dnsDiagnostic = cs_player_internal_dns_diagnostics();
if (!$dnsList) {
    $detail = (string)($dnsDiagnostic['message'] ?? 'Nenhum servidor ativo foi sincronizado.');
    $_SESSION['cs_player_error'] = $detail . ' Configure um DNS externo no painel apenas se o serviço público estiver publicado.';
    cs_player_write_log('web_player_auth_blocked_no_dns', ['diagnostic' => $dnsDiagnostic], 'error');
    header('Location: index.php'); exit;
}
$internalDnsCount = count(array_filter($dnsList, static fn($row) => ($row['source'] ?? '') === 'streaming_servers'));
if ($internalDnsCount === 0) {
    cs_player_write_log('web_player_dns_external_fallback', ['dns_count' => count($dnsList), 'diagnostic' => $dnsDiagnostic], 'warning');
}
$authenticated = cs_player_authenticate_dns($dnsList, $username, $password);
    if (is_array($authenticated) && isset($authenticated['row'], $authenticated['data'])) {
        $row = $authenticated['row'];
        $data = $authenticated['data'];
        session_regenerate_id(true);
        $_SESSION['cs_player_auth'] = true;
        $_SESSION['cs_player_username'] = $username;
        $_SESSION['cs_player_password'] = $password;
        $_SESSION['cs_player_dns_index'] = (string)$row['_index'];
        $_SESSION['cs_player_dns_name'] = (string)($row['name'] ?? 'Servidor');
        unset($_SESSION['cs_player_manual_dns'], $_SESSION['cs_player_manual_only']);
        $_SESSION['cs_player_user_info'] = $data['user_info'] ?? [];
        header('Location: home.php'); exit;
    }

$diagnostics = is_array($authenticated['diagnostics'] ?? null) ? $authenticated['diagnostics'] : [];
cs_player_write_log('web_player_auth_failed', [
    'username_hash' => substr(hash('sha256', $username), 0, 12),
    'dns_count' => count($dnsList),
    'internal_dns_count' => $internalDnsCount,
    'dns_sync_diagnostic' => $dnsDiagnostic,
    'manual_dns' => '',
    'diagnostics' => $diagnostics,
], 'warning');
$codes = array_values(array_filter(array_map(static fn($item) => (int)($item['http_code'] ?? 0), $diagnostics)));
$connectionFailures = array_values(array_filter($diagnostics, static function ($item): bool {
    $errno = (int)($item['curl_errno'] ?? 0);
    $code = (int)($item['http_code'] ?? 0);
    return $errno === 28 || ($code === 0 && trim((string)($item['curl_error'] ?? '')) !== '');
}));
if (in_array(500, $codes, true)) {
    $_SESSION['cs_player_error'] = 'O servidor sincronizado respondeu HTTP 500 durante a autenticação. Verifique o serviço Xtream e o endpoint player_api.php no servidor.';
} elseif (in_array(404, $codes, true)) {
    $_SESSION['cs_player_error'] = 'O servidor sincronizado não encontrou o endpoint player_api.php (HTTP 404). Verifique a porta HTTP de transmissão em Servidores.';
} elseif ($connectionFailures) {
    $_SESSION['cs_player_error'] = 'Não foi possível conectar ao endpoint player_api.php nos servidores sincronizados. Verifique domínio/IP, porta HTTP de transmissão e firewall em Servidores.';
} elseif ($codes) {
    $_SESSION['cs_player_error'] = 'Os servidores sincronizados não aceitaram a requisição de autenticação. Código HTTP: ' . implode(', ', $codes) . '.';
} else {
    $_SESSION['cs_player_error'] = 'Usuário não localizado nos DNS ativos ou assinatura sem acesso.';
}
header('Location: index.php');

# CS Player v6.6 — Restauração das opções administrativas de Revendas

## Objetivo
Restaurar e preservar no painel Admin as funções clássicas existentes no antigo `admin/reg_users.php`, sem alterar o banco de dados, mantendo as correções das versões anteriores.

## Funções clássicas preservadas/restauradas
- Pesquisa de revendas.
- Filtro por proprietário/revendedor, inclusive "sem proprietário" para Admin.
- Filtro por status ativo/desativado.
- Quantidade de registros: 10, 25, 50, 250, 500 e 1000.
- Limpar filtros.
- Zoom/tamanho da tabela.
- Atualização automática/manual.
- Adicionar usuário registrado/revenda.
- Colunas: ID, usuário, proprietário, IP, tipo/grupo, status, créditos, clientes, DNS, último login e ações.
- Operações existentes: editar, resetar 2FA, ativar/desativar, banir/desbanir e excluir conforme permissão.
- Estado da DataTable e filtros preservados (`stateSave` + `formCache`).
- Processamento server-side via `table_search.php?id=reg_users`.

## Melhorias adicionadas sem remover funções
- Atalhos administrativos para páginas que já existem: adicionar revenda, grupos/permissões, créditos, logs, IPs, ISPs e User-Agents.
- Layout de filtros responsivo.
- Alternância Lista/Cards, salva em `localStorage`.
- Cards automáticos no smartphone, sem alterar os dados retornados pelo backend.
- Tabela completa preservada no desktop.
- Ações com área de toque maior no mobile.
- Compatibilidade com Dark Mode e o Design System já presente.

## Banco de dados
Nenhuma tabela, coluna, índice, ID ou registro foi alterado por esta atualização.

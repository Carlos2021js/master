# CS Player v6.4.8 — Hotfix HTTP 500 do Web Player

- Protege o carregamento de `web-player-config.php` contra arquivo inválido/corrompido.
- Protege a conexão MariaDB do módulo do Web Player contra exceções fatais.
- Protege o login persistente (cookie) contra falhas de banco/configuração.
- `player/index.php` agora registra `web_player_boot_failed` com código seguro em vez de tela branca/HTTP 500 sem diagnóstico.
- Mantém os modos Auto/XC/Smart/M3U e as melhorias da v6.4.7.
- Não altera o banco de dados.

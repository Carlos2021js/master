# Central de logs e erros do sistema

Foi adicionada a página `admin/system_logs.php` e sua entrada no menu **Ferramentas/Tools** dos layouts com e sem sidebar.

A página é restrita ao administrador principal com permissão de configurações ou banco de dados. Ela consulta somente caminhos predefinidos: logs do PHP/PHP-FPM, Nginx, sistema, SSH/autenticação, auditoria do CS Player e `admin/storage/import_jobs`, onde ficam os diagnósticos persistentes do `m3u_update_nodup.php`.

Para reduzir risco de exposição, a tela mostra somente o final dos arquivos, limitado a 256 KB e 300 linhas por arquivo, não permite informar caminhos arbitrários e mascara credenciais em URLs, incluindo parâmetros como `username`, `password`, `token` e `api_key`. A página é somente leitura e não apaga nem altera logs.

A opção não depende mais da permissão de importação M3U; ela aparece para administradores com a permissão técnica adequada. O pacote original e o arquivo de conteúdo fornecido foram mantidos intactos.

A sintaxe dos scripts Shell foi validada. A validação PHP deve ser executada no servidor, pois o ambiente de análise não possui o binário `php` instalado.

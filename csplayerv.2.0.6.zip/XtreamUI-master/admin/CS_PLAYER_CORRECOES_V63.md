# CS Player v6.3 — correções orientadas pelos logs

- Corrigido erro de sintaxe em `users.php` causado por bloco PHP incompleto.
- Corrigidos acessos inválidos a dados MAG em `user_reseller.php` quando `getMAGUser()` não retorna array.
- Corrigido `stream_categories.php` para inicializar e validar a categoria de rádio (índice 4) antes de `foreach`.
- Removida dependência de `str_starts_with()` em `resize.php`, mantendo compatibilidade com runtimes PHP antigos.
- Mantidas as correções já existentes de `group.php` e `api_renew.php`.
- Melhorado o log de autenticação para diferenciar status da conta, grupo e `is_banned`, sem liberar permissões indevidamente.
- Adicionado `.user.ini` com `max_input_vars=5000` para formulários administrativos grandes quando suportado pelo PHP-FPM.
- Nenhuma tabela, coluna, índice ou schema foi alterado.

## Observação sobre login negado com código 2
No login atual, o código interno 2 indica `member_groups.is_banned=1`. Isso é diferente de `reg_users.status`. Para preservar as regras do sistema, a versão não ignora um grupo realmente banido. O administrador pode revisar/desmarcar **Banido** em Grupos.

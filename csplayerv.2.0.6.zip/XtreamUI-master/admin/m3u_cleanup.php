<?php
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/cs_admin_access.php';

if (empty($rPermissions['is_admin']) || !hasPermissions('adv', 'mass_delete')) {
    http_response_code(403);
    exit('Acesso negado. Esta ferramenta exige permissão administrativa de exclusão em massa.');
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
if (empty($_SESSION['m3u_cleanup_token'])) {
    $_SESSION['m3u_cleanup_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['m3u_cleanup_token'];

$scopes = [
    'all'        => 'Tudo do conteúdo M3U: canais, filmes, séries, episódios e categorias vazias',
    'channels'   => 'Somente canais / Live TV',
    'movies'     => 'Somente filmes / VOD',
    'series'     => 'Séries, episódios e streams de episódios',
    'episodes'   => 'Somente episódios, mantendo as séries',
    'categories' => 'Somente categorias vazias',
];
$message = '';
$messageType = 'info';
$result = [];

function cleanupTableExists(mysqli $db, $table) {
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $check = $db->query("SHOW TABLES LIKE '" . $db->real_escape_string($safe) . "'");
    return $check && $check->num_rows > 0;
}
function cleanupDeleteIds(mysqli $db, $table, $column, array $ids) {
    if (!$ids || !cleanupTableExists($db, $table)) return 0;
    $safeTable = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $safeColumn = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    $list = implode(',', array_map('intval', $ids));
    $db->query("DELETE FROM `{$safeTable}` WHERE `{$safeColumn}` IN ({$list})");
    return $db->affected_rows;
}
function cleanupBouquets(mysqli $db, array $streamIds, array $seriesIds, $clearAll = false) {
    $changed = 0;
    if (!cleanupTableExists($db, 'bouquets')) return 0;
    $res = $db->query('SELECT id, bouquet_channels, bouquet_series FROM bouquets');
    while ($row = $res->fetch_assoc()) {
        $channels = json_decode((string)$row['bouquet_channels'], true);
        $series = json_decode((string)$row['bouquet_series'], true);
        $channels = is_array($channels) ? array_values(array_unique(array_map('intval', $channels))) : [];
        $series = is_array($series) ? array_values(array_unique(array_map('intval', $series))) : [];
        $newChannels = $clearAll ? [] : array_values(array_diff($channels, array_map('intval', $streamIds)));
        $newSeries = $clearAll ? [] : array_values(array_diff($series, array_map('intval', $seriesIds)));
        if ($newChannels !== $channels || $newSeries !== $series) {
            $stmt = $db->prepare('UPDATE bouquets SET bouquet_channels = ?, bouquet_series = ? WHERE id = ?');
            $channelsJson = json_encode($newChannels);
            $seriesJson = json_encode($newSeries);
            $id = (int)$row['id'];
            $stmt->bind_param('ssi', $channelsJson, $seriesJson, $id);
            $stmt->execute();
            $changed++;
        }
    }
    return $changed;
}
function cleanupEmptyCategories(mysqli $db) {
    $deleted = 0;
    if (!cleanupTableExists($db, 'stream_categories')) return 0;
    $res = $db->query('SELECT id, category_type FROM stream_categories');
    while ($row = $res->fetch_assoc()) {
        $id = (int)$row['id'];
        $type = strtolower((string)$row['category_type']);
        $streamCount = 0;
        $seriesCount = 0;
        if ($type === 'live') {
            $q = $db->query("SELECT COUNT(*) c FROM streams WHERE category_id = {$id}");
            $streamCount = (int)$q->fetch_assoc()['c'];
        } elseif ($type === 'movie') {
            $q = $db->query("SELECT COUNT(*) c FROM streams WHERE category_id = {$id}");
            $streamCount = (int)$q->fetch_assoc()['c'];
        } elseif ($type === 'series') {
            $q = $db->query("SELECT COUNT(*) c FROM series WHERE category_id = {$id}");
            $seriesCount = (int)$q->fetch_assoc()['c'];
            $q = $db->query("SELECT COUNT(*) c FROM streams WHERE category_id = {$id}");
            $streamCount = (int)$q->fetch_assoc()['c'];
        }
        if ($streamCount === 0 && $seriesCount === 0) {
            $db->query("DELETE FROM stream_categories WHERE id = {$id}");
            $deleted += $db->affected_rows;
        }
    }
    return $deleted;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cleanup_submit'])) {
    try {
        if (!hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
            throw new RuntimeException('Token de segurança inválido. Recarregue a página e tente novamente.');
        }
        $scope = (string)($_POST['scope'] ?? '');
        if (!isset($scopes[$scope])) throw new RuntimeException('Escopo de limpeza inválido.');
        if (($_POST['confirm_text'] ?? '') !== 'LIMPAR') {
            throw new RuntimeException('Digite LIMPAR para confirmar a operação.');
        }
        if (empty($_POST['confirm_danger'])) {
            throw new RuntimeException('Marque a confirmação de exclusão permanente.');
        }
        if (!isset($db) || !($db instanceof mysqli)) throw new RuntimeException('Conexão com o banco indisponível.');
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        set_time_limit(0);
        $streamIds = [];
        $seriesIds = [];
        $streamTypes = [];
        if ($scope === 'all' || $scope === 'channels') $streamTypes[] = 1;
        if ($scope === 'all' || $scope === 'movies') $streamTypes[] = 2;
        if ($scope === 'all' || $scope === 'series') $streamTypes[] = 5;
        if ($streamTypes) {
            $typeList = implode(',', array_map('intval', $streamTypes));
            $res = $db->query("SELECT id FROM streams WHERE type IN ({$typeList})");
            while ($row = $res->fetch_assoc()) $streamIds[] = (int)$row['id'];
        }
        if ($scope === 'all' || $scope === 'series') {
            $res = $db->query('SELECT id FROM series');
            while ($row = $res->fetch_assoc()) $seriesIds[] = (int)$row['id'];
        }
        if ($scope === 'all' || $scope === 'episodes') {
            if ($scope === 'episodes') {
                $res = $db->query('SELECT stream_id FROM series_episodes');
                while ($row = $res->fetch_assoc()) $streamIds[] = (int)$row['stream_id'];
            }
        }
        $streamIds = array_values(array_unique(array_filter($streamIds)));
        $seriesIds = array_values(array_unique(array_filter($seriesIds)));
        $db->begin_transaction();
        $deleted = ['streams_sys' => 0, 'series_episodes' => 0, 'streams' => 0, 'series' => 0, 'categories' => 0, 'bouquets' => 0];
        if ($scope === 'categories') {
            $deleted['categories'] = cleanupEmptyCategories($db);
        } else {
            $deleted['series_episodes'] = cleanupDeleteIds($db, 'series_episodes', 'stream_id', $streamIds);
            if ($scope === 'all' || $scope === 'series') {
                $deleted['series_episodes'] += cleanupDeleteIds($db, 'series_episodes', 'series_id', $seriesIds);
            }
            $deleted['streams_sys'] = cleanupDeleteIds($db, 'streams_sys', 'stream_id', $streamIds);
            $deleted['streams'] = cleanupDeleteIds($db, 'streams', 'id', $streamIds);
            if ($scope === 'all' || $scope === 'series') {
                $deleted['series'] = cleanupDeleteIds($db, 'series', 'id', $seriesIds);
            }
            $deleted['bouquets'] = cleanupBouquets($db, $streamIds, $seriesIds, $scope === 'all');
            if ($scope === 'all' || $scope === 'categories') $deleted['categories'] = cleanupEmptyCategories($db);
        }
        $db->commit();
        $result = $deleted;
        $message = 'Limpeza concluída com sucesso. Os registros excluídos não podem ser recuperados por esta tela.';
        $messageType = 'success';
    } catch (Throwable $e) {
        if (isset($db) && $db instanceof mysqli) { try { $db->rollback(); } catch (Throwable $ignored) {} }
        $message = $e->getMessage();
        $messageType = 'danger';
    }
}

$rSidebar = !empty($rSettings['sidebar']);
include ($rSidebar ? 'header_sidebar.php' : 'header.php');
?>
<div class="<?= $rSidebar ? 'content-page' : 'wrapper' ?> boxed-layout-ext">
    <div class="container-fluid">
        <div class="page-title-box"><h4 class="page-title"><i class="mdi mdi-delete-sweep text-danger"></i> Limpeza do conteúdo M3U</h4></div>
        <?php if ($message): ?><div class="alert alert-<?= htmlspecialchars($messageType) ?>"><strong><?= htmlspecialchars($message) ?></strong></div><?php endif; ?>
        <?php if ($result): ?><div class="alert alert-info"><strong>Resumo da operação:</strong> Streams: <?= (int)$result['streams'] ?>; episódios: <?= (int)$result['series_episodes'] ?>; séries: <?= (int)$result['series'] ?>; vínculos de servidor: <?= (int)$result['streams_sys'] ?>; buquês atualizados: <?= (int)$result['bouquets'] ?>; categorias vazias: <?= (int)$result['categories'] ?>.</div><?php endif; ?>
        <div class="card border-danger"><div class="card-body">
            <div class="alert alert-warning"><strong>Atenção:</strong> esta operação é permanente. O banco atual não possui um marcador que diferencie automaticamente registros importados pelo M3U de registros criados manualmente. Os escopos abaixo trabalham por tipo de conteúdo.</div>
            <form method="post" onsubmit="return confirm('Esta operação excluirá dados permanentemente. Confirma continuar?');">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                <div class="form-group"><label class="font-weight-bold">O que deseja limpar?</label><select name="scope" class="form-control" required><?php foreach ($scopes as $key => $label): ?><option value="<?= htmlspecialchars($key) ?>"><?= htmlspecialchars($label) ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Digite <strong>LIMPAR</strong> para confirmar</label><input name="confirm_text" class="form-control" autocomplete="off" required></div>
                <div class="custom-control custom-checkbox mb-3"><input type="checkbox" class="custom-control-input" id="confirm_danger" name="confirm_danger" value="1" required><label class="custom-control-label" for="confirm_danger">Confirmo que compreendo que a exclusão é permanente.</label></div>
                <button type="submit" name="cleanup_submit" class="btn btn-danger"><i class="mdi mdi-delete-sweep"></i> Executar limpeza</button>
                <a href="./m3u_update_nodup.php" class="btn btn-secondary">Voltar para importação M3U</a>
            </form>
        </div></div>
    </div>
</div>
</body></html>
<?php exit; ?>

<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CS PLAYER - Session Manager
|--------------------------------------------------------------------------
| Sessão sem timeout.
| Compatível com PHP 8.3.
| Evita múltiplos session_start().
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');

    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        ini_set('session.cookie_secure', '1');
    }

    session_start();
}

/*
|--------------------------------------------------------------------------
| Atualiza atividade
|--------------------------------------------------------------------------
*/

$_SESSION['last_activity'] = time();

/*
|--------------------------------------------------------------------------
| Verifica login
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['hash'])) {

    $referrer = urlencode($_SERVER['REQUEST_URI'] ?? '/');

    header("Location: login.php?referrer={$referrer}");
    exit;
}

/*
|--------------------------------------------------------------------------
| Regenera ID da sessão periodicamente
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['created']) ||
    (time() - $_SESSION['created']) > 1800
) {
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}
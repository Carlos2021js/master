<?php
/**
 * get_user_details.php
 * Retorna detalhes completos de um usuário para exibição no modal.
 * Compatível com smartphone e desktop.
 */
include "session.php";
include "functions.php";

// Verifica permissão (admin ou revendedor)
if (!$rPermissions["is_admin"] && !$rPermissions["is_reseller"]) {
    die(json_encode(['success' => false, 'message' => 'Acesso negado.']));
}

$user_id = intval($_GET['user_id']);
if (!$user_id) {
    die(json_encode(['success' => false, 'message' => 'ID de usuário inválido.']));
}

// Se for revendedor, verifica se o usuário pertence a ele
if ($rPermissions["is_reseller"] && !$rPermissions["is_admin"]) {
    $stmt = $db->prepare("SELECT id FROM users WHERE id = ? AND member_id = ?");
    $stmt->bind_param("ii", $user_id, $rUserInfo["id"]);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 0) {
        die(json_encode(['success' => false, 'message' => 'Usuário não pertence a este revendedor.']));
    }
}

// Busca dados do usuário (campos reais do seu sistema)
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
if (!$user) {
    die(json_encode(['success' => false, 'message' => 'Usuário não encontrado.']));
}

// Busca informações do plano
$plan_name = '';
$plan_price = 0;
if (!empty($user['plan_id'])) {
    $stmt = $db->prepare("SELECT name, price FROM plans WHERE id = ?");
    $stmt->bind_param("i", $user['plan_id']);
    $stmt->execute();
    $plan = $stmt->get_result()->fetch_assoc();
    if ($plan) {
        $plan_name = $plan['name'];
        $plan_price = $plan['price'];
    }
}

// Configurações do servidor
$base_url = $rServers[$_INFO['server_id']]['domain_name'] ?: $rServers[$_INFO['server_id']]['server_ip'];
$http_port = $rServers[$_INFO['server_id']]['http_broadcast_port'];
$https_port = $rServers[$_INFO['server_id']]['https_broadcast_port'];
$protocol = (!empty($rAdminSettings['use_https_main'])) ? 'https' : 'http';
$port = ($protocol == 'https') ? $https_port : $http_port;

// Formata datas (campos reais: created_at e expiration_date)
$created = date('d/m/Y H:i:s', $user['created_at']);
$expires = date('d/m/Y H:i:s', $user['exp_date']);

// Monta resposta com todos os campos necessários
$data = [
    'username'      => $user['username'],
    'password'      => $user['password'],
    'plan'          => $plan_name ?: 'N/A',
    'plan_price'    => 'R$ ' . number_format($plan_price, 2, ',', '.'),
    'created_at'    => $created,
    'expiration'    => $expires,
    'connections'   => intval($user['max_connections'] ?: 1),
    'status'        => intval($user['enabled']),
    'admin_enabled' => intval($user['admin_enabled']),
    // Links
    'link_hls'      => $protocol . '://' . $base_url . ':' . $port . '/get.php?username=' . $user['username'] . '&password=' . $user['password'] . '&type=m3u_plus&output=hls',
    'link_mpegts'   => $protocol . '://' . $base_url . ':' . $port . '/get.php?username=' . $user['username'] . '&password=' . $user['password'] . '&type=m3u_plus&output=mpegts',
    // SSIPTV - domínios fixos (ajuste conforme seu sistema)
    'ssiptv_link'   => 'http://e.kyup.top/p/' . $user['username'] . '/' . $user['password'] . '/ssip.tv',
    'ssiptv2_link'  => 'http://e.newbr.xyz/p/' . $user['username'] . '/' . $user['password'] . '/ssiptv',
    // XCIPTV
    'xciptv_url'    => $protocol . '://' . $base_url . ':' . $port,
    'xciptv_user'   => $user['username'],
    'xciptv_pass'   => $user['password'],
];

echo json_encode(['success' => true, 'data' => $data]);
?>
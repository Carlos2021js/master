<?php
/**
 * CS Player — Importer & Streaming Helper for Large Playlists
 * Implements memory-efficient line reading (Generator / yield) and batch processing.
 */

if (!defined('CS_IMPORTER_HELPER')) {
    define('CS_IMPORTER_HELPER', true);

    function cs_read_m3u_stream($filePath) {
        if (!file_exists($filePath)) {
            yield from [];
            return;
        }
        $handle = fopen($filePath, 'r');
        if ($handle) {
            while (($line = fgets($handle)) !== false) {
                yield trim($line);
            }
            fclose($handle);
        }
    }

    function cs_classify_media_item($url, $title, $metadata = []) {
        $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
        
        // Series / Episodes pattern detection
        $seriesPatterns = [
            '/s([0-9]+)e([0-9]+)/i',
            '/([0-9]+)x([0-9]+)/i',
            '/temporada\s*([0-9]+).*epis[oó]dio\s*([0-9]+)/i',
            '/t([0-9]+)\s*e([0-9]+)/i',
            '/season\s*([0-9]+).*episode\s*([0-9]+)/i'
        ];

        foreach ($seriesPatterns as $pattern) {
            if (preg_match($pattern, $title) || preg_match($pattern, $url)) {
                return 'SERIES_EPISODE';
            }
        }

        // Live TV detection
        if (in_array($ext, ['m3u8', 'ts', 'mpegts']) || strpos($url, 'live') !== false) {
            return 'LIVE';
        }

        // VOD Movies detection
        if (in_array($ext, ['mp4', 'mkv', 'avi', 'mov', 'wmv', 'flv'])) {
            return 'MOVIE';
        }

        return 'UNKNOWN';
    }
}

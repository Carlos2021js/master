CS PLAYER — Importador M3U 3 Ultra Pro
=====================================

Esta pasta pertence exclusivamente ao Importador Avançado 3 e não é carregada pelos importadores 1 ou 2.

Arquivos principais:
- admin/m3u_update_nodup3.php: controlador e interface responsiva.
- bootstrap.php: carregamento isolado das classes e utilitários.
- PlaylistParser.php: leitura incremental de M3U/M3U8/TXT sem carregar a playlist inteira na memória.
- Classifier.php: classificação rígida de Live, filmes e séries/episódios.
- Schema.php: validação somente leitura das tabelas e colunas existentes; não executa DDL.
- UploadManager.php: upload fragmentado, fontes remotas e armazenamento temporário por lote.
- JobStore.php: estado, progresso, cancelamento e logs em arquivos do próprio módulo.
- ImportEngine.php: análise, lotes transacionais, categorias, streams, streams_sys, séries, episódios, EPG, TMDB assíncrono, duplicidade e buquês.

Todas as ações AJAX usam o prefixo m3u3_ e o armazenamento fica em admin/storage/m3u3.
A interface permite selecionar um modo de classificação diferente para cada arquivo, além do modo global padrão.

Banco utilizado sem criar ou alterar tabelas: streams, streams_sys, stream_categories, series,
series_episodes, bouquets, streaming_servers e tmdb_async, quando disponível para fila TMDB.

Garantias:
- Não executa ALTER TABLE, CREATE TABLE, DROP TABLE, RENAME TABLE, TRUNCATE TABLE ou qualquer DDL.
- Não inclui arquivos do Importador 1 ou do Importador 2.
- Valida o schema antes da importação e interrompe apenas o módulo quando faltam estruturas essenciais.
- Processa as fontes em lotes, registra falhas individuais e mantém as demais fontes independentes.

Classificação automática:
- Live: m3u8, ts, mpegts e URLs sem extensão quando a estrutura da playlist indicar canal.
- Série/Episódio: mp4/mkv com padrão S01E01, 1x01, T01E01, Temporada/Episódio e variações comuns.
- Filme: mp4/mkv sem evidência consistente de episódio.
- VOD legado: avi, mov, wmv, flv, webm e m4v somente quando ativado.

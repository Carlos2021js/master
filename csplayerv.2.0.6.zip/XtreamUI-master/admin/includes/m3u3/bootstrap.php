<?php
/** Bootstrap do Importador M3U 3 - independente do m3u_update_nodup.php */
require_once __DIR__ . '/JobStore.php';
require_once __DIR__ . '/UploadManager.php';
require_once __DIR__ . '/PlaylistParser.php';
require_once __DIR__ . '/Classifier.php';
require_once __DIR__ . '/Schema.php';
require_once __DIR__ . '/ImportEngine.php';

if (!function_exists('cs_m3u3_owner')) {
    function cs_m3u3_owner()
    {
        $sid = session_id();
        if ($sid === '') $sid = 'sem-sessao';
        return hash('sha256', $sid);
    }
}
if (!function_exists('cs_m3u3_storage')) {
    function cs_m3u3_storage()
    {
        $dir = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'm3u3';
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new RuntimeException('Não foi possível criar admin/storage/m3u3.');
        }
        return $dir;
    }
}
if (!function_exists('cs_m3u3_json')) {
    function cs_m3u3_json(array $payload, $status = 200)
    {
        while (ob_get_level() > 0) @ob_end_clean();
        http_response_code((int)$status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('X-Content-Type-Options: nosniff');
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json === false) {
            http_response_code(500);
            $json = '{"ok":false,"error":"Falha ao serializar a resposta JSON."}';
            if (function_exists('cs_m3u3_emergency_log')) cs_m3u3_emergency_log('error', 'json', json_last_error_msg());
        }
        echo $json;
        exit;
    }
}
if (!function_exists('cs_m3u3_detach_json')) {
    function cs_m3u3_detach_json(array $payload, $status = 202)
    {
        while (ob_get_level() > 0) @ob_end_clean();
        http_response_code((int)$status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('X-Content-Type-Options: nosniff');
        header('X-Accel-Buffering: no');
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        echo $json === false ? '{"ok":false,"error":"Falha ao iniciar a importação em segundo plano."}' : $json;
        if (function_exists('fastcgi_finish_request')) {
            @fastcgi_finish_request();
        } else {
            @flush();
        }
    }
}
if (!function_exists('cs_m3u3_bool')) {
    function cs_m3u3_bool($key, $default = false)
    {
        if (!isset($_POST[$key])) return (bool)$default;
        return in_array((string)$_POST[$key], array('1','true','on','yes'), true);
    }
}

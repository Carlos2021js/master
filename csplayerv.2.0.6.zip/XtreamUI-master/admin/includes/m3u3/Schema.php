<?php
/** Valida compatibilidade com o banco existente sem executar ALTER TABLE. */
class CSM3U3Schema
{
    private $db;
    private $required = array(
        'streams' => array('id','type','category_id','stream_display_name','stream_source','stream_icon','movie_propeties','target_container','epg_id','channel_id','epg_lang','added','direct_source'),
        'streams_sys' => array('stream_id','server_id','to_analyze','stream_status'),
        'stream_categories' => array('id','category_type','category_name','parent_id','cat_order'),
        'series' => array('id','title','category_id','cover','cover_big','genre','plot','cast','rating','director','releaseDate','last_modified','tmdb_id','seasons','episode_run_time','backdrop_path','youtube_trailer'),
        'series_episodes' => array('id','season_num','series_id','stream_id','sort'),
        'bouquets' => array('id','bouquet_name','bouquet_channels','bouquet_series'),
        'streaming_servers' => array('id','server_name','server_ip'),
        'tmdb_async' => array('id','type','stream_id','status')
    );

    public function __construct(mysqli $db) { $this->db = $db; }

    public function validate()
    {
        $errors = array();
        $tables = array();
        foreach ($this->required as $table => $columns) {
            $exists = $this->tableExists($table);
            $tables[$table] = array('exists' => $exists, 'missing' => array());
            if (!$exists) {
                if ($table !== 'tmdb_async') $errors[] = 'Tabela obrigatória ausente: ' . $table;
                continue;
            }
            $actual = $this->columns($table);
            foreach ($columns as $column) {
                if (!isset($actual[$column])) {
                    $tables[$table]['missing'][] = $column;
                    if ($table !== 'tmdb_async') $errors[] = 'Coluna obrigatória ausente: ' . $table . '.' . $column;
                }
            }
        }
        return array('ok' => empty($errors), 'errors' => $errors, 'tables' => $tables);
    }

    public function tableExists($table)
    {
        $safe = $this->db->real_escape_string((string)$table);
        $res = $this->db->query("SHOW TABLES LIKE '" . $safe . "'");
        return $res && $res->num_rows > 0;
    }

    private function columns($table)
    {
        $out = array();
        $res = $this->db->query('SHOW COLUMNS FROM `' . str_replace('`', '', $table) . '`');
        if ($res) {
            while ($row = $res->fetch_assoc()) $out[$row['Field']] = true;
        }
        return $out;
    }
}

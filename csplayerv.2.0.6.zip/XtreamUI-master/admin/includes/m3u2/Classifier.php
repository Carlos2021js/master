<?php
/**
 * Detector inteligente CS Player v6.2.1.
 * Mantém a estrutura independente deste importador e apenas melhora a classificação.
 * Tipos Xtream preservados: 1=live, 2=movie, 5=series/episode.
 */
class CSM3U2Classifier
{
    const LIVE_EXT = array('m3u8', 'ts', 'mpegts');
    const VOD_EXT = array('mp4', 'mkv');
    const LEGACY_VOD_EXT = array('avi', 'mov', 'wmv', 'flv', 'webm', 'm4v');

    public static function classify($url, $name, $group, array $options)
    {
        $mode = isset($options['classification']) ? (string)$options['classification'] : 'auto';
        if (!in_array($mode, array('auto', 'live', 'movie', 'series'), true)) $mode = 'auto';

        $url = trim((string)$url);
        $name = trim((string)$name);
        $group = trim((string)$group);
        $ext = self::extension($url);
        $series = self::seriesInfo($name);
        $legacyVod = !empty($options['legacy_vod']);

        if ($mode === 'live') {
            return self::result('live', 1, in_array($ext, self::LIVE_EXT, true) ? $ext : 'ts', null, 'modo_forcado_live', 100);
        }
        if ($mode === 'movie') {
            return self::result('movie', 2, $ext ?: 'mp4', null, 'modo_forcado_movie', 100);
        }
        if ($mode === 'series') {
            $series = $series ?: self::fallbackSeriesInfo($name);
            return self::result('series', 5, $ext ?: 'mp4', $series, 'modo_forcado_series', 100);
        }

        $intent = self::groupIntent($group);
        $urlIntent = self::urlIntent($url);

        // 1) Categoria explicitamente LIVE é soberana. Ex.: "Canais | Séries 24H".
        if ($intent === 'live') {
            return self::result('live', 1, in_array($ext, self::LIVE_EXT, true) ? $ext : 'ts', null, 'categoria_live', 99);
        }

        // 2) Padrão real de episódio ganha de extensão VOD e de palavras vagas no título.
        if ($series !== null) {
            return self::result('series', 5, $ext ?: 'mp4', $series, 'padrao_episodio', 98);
        }

        // 3) Categoria explícita de série/novela/curso.
        if ($intent === 'series') {
            return self::result('series', 5, $ext ?: 'mp4', self::fallbackSeriesInfo($name), 'categoria_series', 94);
        }

        // 4) Categoria explícita de filme/coleção/VOD.
        if ($intent === 'movie') {
            return self::result('movie', 2, $ext ?: 'mp4', null, 'categoria_filme', 94);
        }

        // 5) Estrutura Xtream na URL, quando existe, é um sinal forte.
        if ($urlIntent === 'live') {
            return self::result('live', 1, in_array($ext, self::LIVE_EXT, true) ? $ext : 'ts', null, 'rota_url_live', 92);
        }
        if ($urlIntent === 'series') {
            return self::result('series', 5, $ext ?: 'mp4', self::fallbackSeriesInfo($name), 'rota_url_series', 90);
        }
        if ($urlIntent === 'movie') {
            return self::result('movie', 2, $ext ?: 'mp4', null, 'rota_url_movie', 90);
        }

        // 6) Extensões. .ts/m3u8 são live; mp4/mkv são VOD quando não há padrão de episódio.
        if (in_array($ext, self::LIVE_EXT, true)) {
            return self::result('live', 1, $ext, null, 'extensao_live', 88);
        }
        if (in_array($ext, self::VOD_EXT, true) || ($legacyVod && in_array($ext, self::LEGACY_VOD_EXT, true))) {
            return self::result('movie', 2, $ext, null, 'extensao_vod', 78);
        }

        // 7) Heurísticas fracas só entram no fim; nunca sobrepõem sinais acima.
        if (self::looksLiveTitle($name, $group)) {
            return self::result('live', 1, 'ts', null, 'heuristica_live', 62);
        }
        if (self::looksMovieTitle($name)) {
            return self::result('movie', 2, $ext ?: 'mp4', null, 'heuristica_filme', 55);
        }

        return self::result('unknown', 0, $ext, null, 'sem_sinal_confiavel', 0);
    }

    private static function result($kind, $type, $ext, $series, $reason, $confidence)
    {
        return array(
            'kind' => $kind,
            'type' => (int)$type,
            'ext' => (string)$ext,
            'series' => $series,
            'reason' => (string)$reason,
            'confidence' => (int)$confidence
        );
    }

    private static function groupIntent($group)
    {
        $g = self::normalize($group);
        if ($g === '') return '';

        // Prefixos explícitos dos dois provedores analisados.
        if (preg_match('/^(?:canais?|canal|live|tv|r[aá]dios?|radio)(?:\s*[|:\-]|\s|$)/iu', $g)) return 'live';
        if (preg_match('/^(?:s[eé]ries?|series|seriados?|novelas?|doramas?|animes?|cursos?)(?:\s*[|:\-]|\s|$)/iu', $g)) return 'series';
        if (preg_match('/^(?:filmes?|movies?|vod|cinema)(?:\s*[|:\-]|\s|$)/iu', $g)) return 'movie';
        if (preg_match('/^(?:cole[cç][aã]o|colecoes|cole[cç][oõ]es|collection|collections)(?:\s*[|:\-]|\s|$)/iu', $g)) return 'movie';
        if (preg_match('/^(?:shows?|concertos?)(?:\s*[|:\-]|\s|$)/iu', $g)) return 'movie';

        // Algumas listas não usam prefixo, mas deixam marcadores inequívocos.
        if (preg_match('/\b(?:canais?\s+ao\s+vivo|tv\s+ao\s+vivo|live\s+tv)\b/iu', $g)) return 'live';
        if (preg_match('/\b(?:temporadas?|epis[oó]dios?)\b/iu', $g) && !preg_match('/\b24\s*h\b/iu', $g)) return 'series';

        return '';
    }

    private static function urlIntent($url)
    {
        $path = strtolower((string)(parse_url((string)$url, PHP_URL_PATH) ?: ''));
        if ($path === '') return '';
        if (preg_match('~/(?:live|tv|channel|channels)/~i', $path)) return 'live';
        if (preg_match('~/(?:series|serie|episodes?|episodios?)/~i', $path)) return 'series';
        if (preg_match('~/(?:movie|movies|vod|film|filmes)/~i', $path)) return 'movie';
        return '';
    }

    public static function seriesInfo($name)
    {
        $name = trim((string)$name);
        $patterns = array(
            // Nome S01E02, Nome.S01.E02 e variações.
            '/^(.*?)(?:[._\-\s\[\(]+)S(\d{1,3})\s*[._\-\s]*E(\d{1,4})(?=\b|[._\-\s\]\)])/iu',
            '/^(.*?)(?:[._\-\s\[\(]+)(\d{1,3})x(\d{1,4})(?=\b|[._\-\s\]\)])/iu',
            '/^(.*?)(?:[._\-\s]+)Season\s*(\d{1,3})(?:[._\-\s]+)(?:Episode|Ep)\s*(\d{1,4})\b/iu',
            '/^(.*?)(?:[._\-\s]+)Temporada\s*(\d{1,3})(?:[._\-\s]+)(?:Epis[oó]dio|EP?)\s*(\d{1,4})\b/iu',
            '/^(.*?)(?:[._\-\s]+)T(?:emporada)?\s*(\d{1,3})\s*(?:EP?|Epis[oó]dio)\s*(\d{1,4})\b/iu',
            // Formatos compactos frequentes: S1 EP2, S01 - 02.
            '/^(.*?)(?:[._\-\s]+)S(\d{1,3})\s*(?:EP?|[-._ ])\s*(\d{1,4})\b/iu'
        );
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $name, $m)) {
                $title = CSM3U2PlaylistParser::cleanTitle($m[1]);
                if ($title === '') $title = 'Série sem nome';
                return array('title' => $title, 'season' => max(0, (int)$m[2]), 'episode' => max(1, (int)$m[3]));
            }
        }
        return null;
    }

    public static function extension($url)
    {
        $path = (string)(parse_url((string)$url, PHP_URL_PATH) ?: '');
        return strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
    }

    private static function fallbackSeriesInfo($name)
    {
        return array(
            'title' => self::fallbackSeriesTitle($name),
            'season' => self::seasonNumberFallback($name),
            'episode' => self::episodeNumberFallback($name)
        );
    }

    private static function fallbackSeriesTitle($name)
    {
        $clean = preg_replace('/\b(?:S\d{1,3}\s*E\d{1,4}|\d{1,3}x\d{1,4}|T(?:emporada)?\s*\d{1,3}\s*EP?\s*\d{1,4})\b/iu', '', (string)$name);
        $clean = preg_replace('/\b(?:Temporada|Season)\s*\d{1,3}\b/iu', '', (string)$clean);
        $clean = CSM3U2PlaylistParser::cleanTitle($clean);
        return $clean !== '' ? $clean : 'Série importada';
    }

    private static function seasonNumberFallback($name)
    {
        if (preg_match('/\b(?:S|T|Temporada|Season)\s*(\d{1,3})\b/iu', (string)$name, $m)) return max(0, (int)$m[1]);
        return 1;
    }

    private static function episodeNumberFallback($name)
    {
        if (preg_match('/\b(?:EP?|Epis[oó]dio|Episode)\s*(\d{1,4})\b/iu', (string)$name, $m)) return max(1, (int)$m[1]);
        if (preg_match('/(?:^|[._\-\s])(\d{1,4})(?:\.[a-z0-9]{2,5})?$/i', (string)$name, $m)) return max(1, (int)$m[1]);
        return 1;
    }

    private static function looksLiveTitle($name, $group)
    {
        $v = self::normalize($name . ' ' . $group);
        return (bool)preg_match('/\b(?:24\s*h|ao\s+vivo|live|canal|tv|radio|r[aá]dio)\b/iu', $v);
    }

    private static function looksMovieTitle($name)
    {
        $v = self::normalize($name);
        return (bool)preg_match('/(?:^|\s|\()(?:(?:19|20)\d{2})(?:\)|\s|$)/u', $v);
    }

    private static function normalize($value)
    {
        $value = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace('/\s+/u', ' ', $value);
        return trim($value);
    }
}

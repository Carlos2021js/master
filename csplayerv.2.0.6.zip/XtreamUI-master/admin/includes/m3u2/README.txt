CS PLAYER - Importador M3U 2
============================

Arquivos novos. O m3u_update_nodup.php original não é incluído nem alterado por este módulo.

Estrutura:
- admin/m3u_update_nodup2.php: controlador + interface.
- admin/includes/m3u2/UploadManager.php: upload múltiplo em chunks, idempotente e fora de ordem.
- admin/includes/m3u2/PlaylistParser.php: parser M3U em streaming.
- admin/includes/m3u2/Classifier.php: classificação Live / Filme / Série-Episódio.
- admin/includes/m3u2/Schema.php: valida banco existente sem ALTER TABLE.
- admin/includes/m3u2/ImportEngine.php: importação, categorias, EPG, TMDB, séries e buquês.
- admin/includes/m3u2/JobStore.php: progresso/cancelamento por arquivo JSON.

Banco utilizado (sem criar tabelas): streams, streams_sys, stream_categories, series,
series_episodes, bouquets, streaming_servers e tmdb_async (opcional para fila TMDB).

Classificação AUTO padrão:
- Live: m3u8, ts, mpegts.
- Série/Episódio: mp4/mkv + padrão S01E01, 1x01, Temporada/Episódio etc.
- Filme: mp4/mkv sem padrão de episódio.
- VOD legado (avi, mov, wmv, flv, webm, m4v) apenas quando ativado na tela.

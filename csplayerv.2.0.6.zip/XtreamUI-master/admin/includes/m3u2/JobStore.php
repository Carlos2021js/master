<?php
/** CS PLAYER - M3U2 job store persistente e concorrente. PHP 7.4+ */
class CSM3U2JobStore
{
    private $root;
    private $logsRoot;
    private $owner;

    public function __construct($baseDir, $owner)
    {
        $baseDir = rtrim($baseDir, DIRECTORY_SEPARATOR);
        $this->root = $baseDir . DIRECTORY_SEPARATOR . 'jobs';
        $this->logsRoot = $baseDir . DIRECTORY_SEPARATOR . 'logs';
        $this->owner = (string)$owner;
        foreach (array($this->root, $this->logsRoot) as $dir) {
            if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
                throw new RuntimeException('Não foi possível criar o diretório de persistência do Importador M3U 2.');
            }
        }
    }

    public function create(array $initial)
    {
        $id = bin2hex(random_bytes(16));
        $now = microtime(true);
        $data = array_merge(array(
            'id'=>$id,'owner'=>$this->owner,'status'=>'preparado','stage'=>'preparação','message'=>'Job preparado.',
            'created_at'=>$now,'updated_at'=>$now,'started_at'=>0,'finished_at'=>0,'cancel_requested'=>false,
            'expected'=>0,'processed'=>0,'inserted'=>0,'updated'=>0,'skipped'=>0,'errors'=>0,'warnings'=>0,
            'live'=>0,'movies'=>0,'episodes'=>0,'series_created'=>0,'categories_created'=>0,'categories_reused'=>0,
            'batches'=>0,'current_source'=>'','memory_current'=>0,'memory_peak'=>0,'logs'=>array()
        ), $initial);
        $this->writeUnlocked($id, $data);
        $this->audit('success', 'job', 'Job criado e persistido.', $id);
        return $data;
    }

    public function get($id)
    {
        $this->assertId($id);
        $lock = $this->openLock($id, LOCK_SH);
        try { return $this->readUnlocked($id, true); }
        finally { $this->closeLock($lock); }
    }

    public function update($id, array $patch)
    {
        return $this->mutate($id, function(array $data) use ($patch) {
            foreach ($patch as $k=>$v) $data[$k]=$v;
            return $data;
        });
    }

    public function increment($id, array $delta)
    {
        return $this->mutate($id, function(array $data) use ($delta) {
            foreach ($delta as $k=>$v) $data[$k]=(int)($data[$k]??0)+(int)$v;
            return $data;
        });
    }

    public function log($id, $level, $stage, $message)
    {
        $message = $this->cleanMessage($message);
        $data = $this->mutate($id, function(array $data) use ($level,$stage,$message) {
            $logs = isset($data['logs']) && is_array($data['logs']) ? $data['logs'] : array();
            $logs[] = array('time'=>date('H:i:s'),'level'=>(string)$level,'stage'=>(string)$stage,'message'=>$message);
            if (count($logs)>250) $logs=array_slice($logs,-250);
            $data['logs']=$logs;
            $data['stage']=(string)$stage;
            $data['message']=$message;
            return $data;
        });
        $this->audit($level,$stage,$message,$id);
        return $data;
    }

    public function audit($level, $stage, $message, $jobId = '')
    {
        $level = strtoupper(preg_replace('/[^A-Z]/i','',(string)$level));
        if ($level==='') $level='INFO';
        $stage = preg_replace('/[\r\n\t]+/',' ',(string)$stage);
        $message = $this->cleanMessage($message);
        $job = preg_match('/^[a-f0-9]{32}$/',(string)$jobId) ? (string)$jobId : '-';
        $line = sprintf("[%s] [%-7s] [%s] job=%s %s\n", date('Y-m-d H:i:s'), $level, $stage, $job, $message);
        $path = $this->logsRoot . DIRECTORY_SEPARATOR . 'm3u2-' . date('Y-m-d') . '.log';
        if (@file_put_contents($path, $line, FILE_APPEND | LOCK_EX) === false) {
            error_log('CS M3U2 LOG: não foi possível gravar ' . $path . ' | ' . $line);
            return false;
        }
        @chmod($path,0640);
        return true;
    }

    public function requestCancel($id)
    {
        $state=$this->update($id,array('cancel_requested'=>true,'message'=>'Cancelamento solicitado pelo administrador.'));
        $this->audit('warning','cancelamento','Cancelamento solicitado pelo administrador.',$id);
        return $state;
    }

    public function isCancelled($id) { $data=$this->get($id); return !empty($data['cancel_requested']); }

    public function cleanup($maxAge)
    {
        $cut=time()-max(3600,(int)$maxAge);
        foreach (glob($this->root.DIRECTORY_SEPARATOR.'*.json')?:array() as $path) {
            if (is_file($path) && @filemtime($path)<$cut) { @unlink($path); @unlink($path.'.lock'); }
        }
        $logCut=time()-(30*86400);
        foreach (glob($this->logsRoot.DIRECTORY_SEPARATOR.'m3u2-*.log')?:array() as $path) {
            if (is_file($path) && @filemtime($path)<$logCut) @unlink($path);
        }
    }

    private function mutate($id, callable $fn)
    {
        $this->assertId($id);
        $lock=$this->openLock($id,LOCK_EX);
        try {
            $data=$this->readUnlocked($id,true);
            $data=$fn($data);
            $data['updated_at']=microtime(true);
            $data['memory_current']=memory_get_usage(true);
            $data['memory_peak']=memory_get_peak_usage(true);
            $this->writeUnlocked($id,$data);
            return $data;
        } finally { $this->closeLock($lock); }
    }

    private function readUnlocked($id, $verifyOwner)
    {
        $path=$this->path($id);
        if (!is_file($path)) throw new RuntimeException('Job de importação não encontrado.');
        $raw=@file_get_contents($path);
        $data=json_decode((string)$raw,true);
        if (!is_array($data)) throw new RuntimeException('Estado do job está inválido ou corrompido.');
        if ($verifyOwner && (!isset($data['owner']) || !hash_equals($this->owner,(string)$data['owner']))) {
            throw new RuntimeException('Job inválido ou pertencente a outra sessão.');
        }
        return $data;
    }

    private function writeUnlocked($id, array $data)
    {
        $this->assertId($id);
        $path=$this->path($id);
        $tmp=$path.'.tmp.'.getmypid().'.'.bin2hex(random_bytes(3));
        $json=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if ($json===false || @file_put_contents($tmp,$json,LOCK_EX)===false) {
            @unlink($tmp); throw new RuntimeException('Não foi possível salvar o estado do job.');
        }
        @chmod($tmp,0640);
        if (!@rename($tmp,$path)) { @unlink($tmp); throw new RuntimeException('Não foi possível confirmar o estado do job.'); }
    }

    private function openLock($id,$mode)
    {
        $path=$this->path($id).'.lock';
        $fp=@fopen($path,'c+');
        if (!$fp || !@flock($fp,$mode)) { if (is_resource($fp)) fclose($fp); throw new RuntimeException('Não foi possível bloquear o estado do job.'); }
        return $fp;
    }
    private function closeLock($fp) { if (is_resource($fp)) { @flock($fp,LOCK_UN); fclose($fp); } }
    private function cleanMessage($message)
    {
        $m=preg_replace('/[\r\n\t]+/',' ',(string)$message);
        $m=preg_replace('~(://[^:/\s]+:)[^@/\s]+@~','$1[REDACTED]@',$m);
        $m=preg_replace('~([?&](?:username|password|user|pass|token|api_key)=)[^&\s]+~i','$1[REDACTED]',$m);
        return function_exists('mb_substr') ? mb_substr($m,0,1200,'UTF-8') : substr($m,0,1200);
    }
    private function path($id) { return $this->root.DIRECTORY_SEPARATOR.$id.'.json'; }
    private function assertId($id) { if (!preg_match('/^[a-f0-9]{32}$/',(string)$id)) throw new InvalidArgumentException('ID de job inválido.'); }
}

<?php
/** CS PLAYER - upload múltiplo/resumível M3U2. PHP 7.4+ */
class CSM3U2UploadManager
{
    private $root;
    private $maxBytes;

    public function __construct($baseDir, $owner, $maxBytes = 4294967296)
    {
        $ownerSafe = preg_replace('/[^a-f0-9]/', '', (string)$owner);
        $this->root = rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $ownerSafe;
        $this->maxBytes = (int)$maxBytes;
        if (!is_dir($this->root) && !@mkdir($this->root, 0750, true) && !is_dir($this->root)) {
            throw new RuntimeException('Não foi possível criar o armazenamento temporário do importador M3U 2.');
        }
    }

    public function receiveChunk($batchToken, $sourceId, $index, $total, $expectedSize, $fileName, array $file)
    {
        $this->assertToken($batchToken);
        $this->assertSource($sourceId);
        $index = (int)$index;
        $total = (int)$total;
        $expectedSize = (int)$expectedSize;
        if ($index < 0 || $total < 1 || $index >= $total || $total > 20000) {
            throw new InvalidArgumentException('Índice de parte inválido.');
        }
        if ($expectedSize <= 0 || $expectedSize > $this->maxBytes) {
            throw new RuntimeException('O arquivo excede o limite seguro configurado para o importador.');
        }
        if (!isset($file['tmp_name'], $file['error']) || (int)$file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
            throw new RuntimeException('Falha ao receber a parte ' . ($index + 1) . ' do arquivo.');
        }
        $dir = $this->sourceDir($batchToken, $sourceId, true);
        $part = $dir . DIRECTORY_SEPARATOR . sprintf('part_%08d.bin', $index);
        $incomingSize = (int)@filesize($file['tmp_name']);
        if ($incomingSize <= 0) {
            throw new RuntimeException('A parte recebida está vazia.');
        }
        if (is_file($part) && (int)filesize($part) === $incomingSize) {
            // Repetição idempotente: aceita sem duplicar bytes.
        } else {
            $tmp = $part . '.tmp.' . getmypid();
            if (!@move_uploaded_file($file['tmp_name'], $tmp)) {
                throw new RuntimeException('Não foi possível mover a parte enviada.');
            }
            @chmod($tmp, 0640);
            if (!@rename($tmp, $part)) {
                @unlink($tmp);
                throw new RuntimeException('Não foi possível confirmar a parte enviada.');
            }
        }
        $meta = $this->loadMeta($dir);
        $meta['kind'] = 'arquivo';
        $meta['name'] = $this->safeName($fileName);
        $meta['expected_size'] = $expectedSize;
        $meta['total_parts'] = $total;
        $meta['updated_at'] = time();
        $received = array();
        for ($i = 0; $i < $total; $i++) {
            $p = $dir . DIRECTORY_SEPARATOR . sprintf('part_%08d.bin', $i);
            if (is_file($p)) {
                $received[] = $i;
            }
        }
        $meta['received_parts'] = $received;
        $complete = count($received) === $total;
        if ($complete) {
            $this->assemble($dir, $total, $expectedSize);
            $meta['path'] = $dir . DIRECTORY_SEPARATOR . 'source.m3u';
            $meta['size'] = (int)filesize($meta['path']);
            $meta['complete'] = true;
        } else {
            $meta['complete'] = false;
        }
        $this->saveMeta($dir, $meta);
        return $meta;
    }

    public function fetchRemote($batchToken, $sourceId, $url)
    {
        $this->assertToken($batchToken);
        $this->assertSource($sourceId);
        $url = trim((string)$url);
        if (!$this->isSafeRemoteUrl($url)) {
            throw new RuntimeException('URL remota inválida ou apontando para rede local/privada.');
        }
        if (!function_exists('curl_init')) {
            throw new RuntimeException('A extensão cURL do PHP é necessária para importar URL remota.');
        }
        $dir = $this->sourceDir($batchToken, $sourceId, true);
        $path = $dir . DIRECTORY_SEPARATOR . 'source.m3u';
        $tmp = $path . '.download';
        $fp = @fopen($tmp, 'wb');
        if (!$fp) {
            throw new RuntimeException('Não foi possível criar o arquivo temporário remoto.');
        }
        $downloaded = 0;
        $maxBytes = $this->maxBytes;
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_USERAGENT => 'CS PLAYER M3U2 Importer/1.0',
            CURLOPT_FAILONERROR => true,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use ($fp, &$downloaded, $maxBytes) {
                $len = strlen($chunk);
                $downloaded += $len;
                if ($downloaded > $maxBytes) {
                    return 0;
                }
                return fwrite($fp, $chunk);
            }
        ));
        $ok = curl_exec($ch);
        $error = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);
        if (!$ok || $code >= 400 || !is_file($tmp) || (int)filesize($tmp) <= 0) {
            @unlink($tmp);
            throw new RuntimeException('Falha ao baixar playlist remota' . ($error ? ': ' . $error : '.'));
        }
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            throw new RuntimeException('Não foi possível confirmar a playlist remota.');
        }
        @chmod($path, 0640);
        $meta = array(
            'kind' => 'url',
            'name' => $this->safeName(parse_url($url, PHP_URL_PATH) ? basename(parse_url($url, PHP_URL_PATH)) : 'playlist-remota.m3u'),
            'url' => $url,
            'path' => $path,
            'size' => (int)filesize($path),
            'complete' => true,
            'updated_at' => time()
        );
        $this->saveMeta($dir, $meta);
        return $meta;
    }

    public function getSource($batchToken, $sourceId)
    {
        $this->assertToken($batchToken);
        $this->assertSource($sourceId);
        $dir = $this->sourceDir($batchToken, $sourceId, false);
        if (!is_dir($dir)) {
            throw new RuntimeException('Fonte M3U temporária não encontrada.');
        }
        $meta = $this->loadMeta($dir);
        $path = $dir . DIRECTORY_SEPARATOR . 'source.m3u';
        if (empty($meta['complete']) || !is_file($path) || !is_readable($path) || (int)filesize($path) <= 0) {
            throw new RuntimeException('Fonte M3U ainda não foi concluída.');
        }
        $meta['path'] = $path;
        $meta['size'] = (int)filesize($path);
        return $meta;
    }

    public function getSources($batchToken, array $sourceIds)
    {
        $out = array();
        foreach (array_values(array_unique($sourceIds)) as $sourceId) {
            $out[$sourceId] = $this->getSource($batchToken, $sourceId);
        }
        return $out;
    }

    public function cleanup($maxAge)
    {
        $cut = time() - max(3600, (int)$maxAge);
        foreach (glob($this->root . DIRECTORY_SEPARATOR . '*') ?: array() as $batchDir) {
            if (is_dir($batchDir) && @filemtime($batchDir) < $cut) {
                $this->removeTree($batchDir);
            }
        }
    }

    public function removeBatch($batchToken)
    {
        $this->assertToken($batchToken);
        $dir = $this->root . DIRECTORY_SEPARATOR . $batchToken;
        if (is_dir($dir)) {
            $this->removeTree($dir);
        }
    }

    private function assemble($dir, $total, $expectedSize)
    {
        $tmp = $dir . DIRECTORY_SEPARATOR . 'source.m3u.tmp';
        $out = @fopen($tmp, 'wb');
        if (!$out) {
            throw new RuntimeException('Não foi possível montar o arquivo M3U enviado.');
        }
        $written = 0;
        try {
            for ($i = 0; $i < $total; $i++) {
                $part = $dir . DIRECTORY_SEPARATOR . sprintf('part_%08d.bin', $i);
                if (!is_file($part)) {
                    throw new RuntimeException('Parte ausente durante a montagem: ' . ($i + 1) . '.');
                }
                $in = @fopen($part, 'rb');
                if (!$in) {
                    throw new RuntimeException('Não foi possível ler a parte ' . ($i + 1) . '.');
                }
                $n = stream_copy_to_stream($in, $out);
                fclose($in);
                if ($n === false) {
                    throw new RuntimeException('Falha ao juntar a parte ' . ($i + 1) . '.');
                }
                $written += $n;
            }
            fflush($out);
        } finally {
            fclose($out);
        }
        if ((int)$written !== (int)$expectedSize) {
            @unlink($tmp);
            throw new RuntimeException('Tamanho final diferente do arquivo original. Esperado ' . $expectedSize . ' bytes, recebido ' . $written . ' bytes.');
        }
        $final = $dir . DIRECTORY_SEPARATOR . 'source.m3u';
        if (!@rename($tmp, $final)) {
            @unlink($tmp);
            throw new RuntimeException('Não foi possível finalizar o arquivo M3U.');
        }
        @chmod($final, 0640);
        foreach (glob($dir . DIRECTORY_SEPARATOR . 'part_*.bin') ?: array() as $part) {
            @unlink($part);
        }
    }

    private function sourceDir($batchToken, $sourceId, $create)
    {
        $batch = $this->root . DIRECTORY_SEPARATOR . $batchToken;
        $dir = $batch . DIRECTORY_SEPARATOR . $sourceId;
        if ($create && !is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new RuntimeException('Não foi possível criar diretório da fonte M3U.');
        }
        return $dir;
    }

    private function saveMeta($dir, array $meta)
    {
        $json = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false || @file_put_contents($dir . DIRECTORY_SEPARATOR . 'meta.json', $json, LOCK_EX) === false) {
            throw new RuntimeException('Não foi possível salvar metadados do upload.');
        }
    }

    private function loadMeta($dir)
    {
        $path = $dir . DIRECTORY_SEPARATOR . 'meta.json';
        if (!is_file($path)) return array();
        $data = json_decode((string)@file_get_contents($path), true);
        return is_array($data) ? $data : array();
    }

    private function isSafeRemoteUrl($url)
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) return false;
        $parts = parse_url($url);
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower((string)($parts['host'] ?? ''));
        if (!in_array($scheme, array('http', 'https'), true) || $host === '') return false;
        if (in_array($host, array('localhost', '0.0.0.0', '::1'), true)) return false;
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return (bool)filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
        }
        return true;
    }

    private function safeName($name)
    {
        $name = trim((string)$name);
        $name = preg_replace('/[\x00-\x1F\x7F]/', '', $name);
        return mb_substr($name !== '' ? $name : 'playlist.m3u', 0, 180, 'UTF-8');
    }

    private function assertToken($token)
    {
        if (!preg_match('/^[a-f0-9]{32}$/', (string)$token)) {
            throw new InvalidArgumentException('Token de lote inválido.');
        }
    }

    private function assertSource($sourceId)
    {
        if (!preg_match('/^[a-f0-9]{16,32}$/', (string)$sourceId)) {
            throw new InvalidArgumentException('Identificador de fonte inválido.');
        }
    }

    private function removeTree($dir)
    {
        $items = @scandir($dir);
        if (!is_array($items)) return;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path)) $this->removeTree($path); else @unlink($path);
        }
        @rmdir($dir);
    }
}

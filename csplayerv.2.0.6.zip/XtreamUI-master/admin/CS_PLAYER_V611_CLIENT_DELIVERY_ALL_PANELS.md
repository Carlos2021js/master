# CS Player v6.11 — Entrega de clientes em todos os painéis

- Sem alterações no banco de dados.
- Padronizada a abertura automática dos dados após criação no Admin e Revenda/Sub-revenda.
- Corrigido `created=0` para não abrir modal de nova criação durante simples edição.
- Entrega agora inclui usuário, senha, plano/conteúdo, validade, conexões, DNS, M3U HLS/MPEGTS/M3U8, Player API, EPG/XMLTV, SSIPTV, XCIPTV e Web Player.
- Web Player é calculado a partir da URL pública real do painel (`/player/` ou `/admin/player/` conforme instalação), sem gravar campos no banco.
- DNS de entrega respeita servidor forçado do cliente quando aplicável e DNS próprio da revenda dentro das permissões existentes.
- Credenciais em links são codificadas com `rawurlencode`.

(function(){
  'use strict';
  function text(el){return (el && el.textContent || '').trim().toLowerCase();}
  function enhanceFeedback(root){
    (root||document).querySelectorAll('.alert').forEach(function(el){
      if(el.dataset.cs633==='1') return;
      el.dataset.cs633='1'; el.setAttribute('role','status'); el.classList.add('cs-feedback');
      if(el.classList.contains('alert-success')) el.classList.add('cs-feedback-success');
      else if(el.classList.contains('alert-danger')) el.classList.add('cs-feedback-danger');
      else if(el.classList.contains('alert-warning')) el.classList.add('cs-feedback-warning');
      else el.classList.add('cs-feedback-info');
    });
  }
  function enhanceCards(root){
    (root||document).querySelectorAll('.card,.card-box,.widget-rounded-circle').forEach(function(el){
      if(el.dataset.csCard==='1') return; el.dataset.csCard='1'; el.classList.add('cs-smart-card');
      var t=text(el);
      if(/erro|falha|offline|bloquead|banid/.test(t)) el.dataset.state='danger';
      else if(/aten[cç][aã]o|aviso|pendente|expir/.test(t)) el.dataset.state='warning';
      else if(/sucesso|online|ativo|conclu[ií]d/.test(t)) el.dataset.state='success';
    });
  }
  function activeDock(){
    var file=(location.pathname.split('/').pop()||'dashboard.php').toLowerCase();
    document.querySelectorAll('.cs-admin-mobile-dock a').forEach(function(a){
      var href=(a.getAttribute('href')||'').split('?')[0].toLowerCase();
      var matches=(a.getAttribute('data-match')||'').toLowerCase().split(',').map(function(x){return x.trim();}).filter(Boolean);
      var on=(href===file)||(matches.indexOf(file)!==-1);
      a.classList.toggle('active',on); if(on)a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current');
    });
  }
  function init(){enhanceFeedback(document);enhanceCards(document);activeDock();
    if(window.MutationObserver){new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(function(n){if(n.nodeType===1){enhanceFeedback(n);enhanceCards(n);}});});}).observe(document.body,{childList:true,subtree:true});}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

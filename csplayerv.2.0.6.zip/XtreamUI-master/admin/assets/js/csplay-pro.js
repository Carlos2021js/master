(function(){'use strict';
 document.documentElement.classList.add('csplay-js');
 var loader=document.createElement('div'); loader.className='csplay-page-loader'; loader.innerHTML='<div class="csplay-spinner" role="status" aria-label="Carregando"></div>'; document.body.insertBefore(loader,document.body.firstChild);
 function ready(){requestAnimationFrame(function(){loader.classList.add('hide');setTimeout(function(){if(loader.parentNode)loader.parentNode.removeChild(loader)},260)})}
 if(document.readyState==='complete')ready();else window.addEventListener('load',ready,{once:true}); setTimeout(ready,5000);
 document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href]');if(!a)return;var h=a.getAttribute('href')||'';if(h==='#'||h.indexOf('javascript:')===0||a.target==='_blank'||e.ctrlKey||e.metaKey||e.shiftKey)return;loader.classList.remove('hide');if(!loader.parentNode)document.body.insertBefore(loader,document.body.firstChild)});
 var current=(location.pathname.split('/').pop()||'dashboard.php').split('?')[0];document.querySelectorAll('#side-menu a[href]').forEach(function(a){var href=(a.getAttribute('href')||'').replace(/^\.\//,'').split('?')[0];if(href===current){a.classList.add('active');var p=a.closest('.nav-second-level');if(p){p.classList.add('in');p.setAttribute('aria-expanded','true');var li=p.closest('li');if(li){li.classList.add('active');var top=li.querySelector(':scope > a');if(top)top.classList.add('active')}}}});
 document.querySelectorAll('table').forEach(function(t){if(!t.parentElement.classList.contains('table-responsive')){var w=document.createElement('div');w.className='table-responsive';t.parentNode.insertBefore(w,t);w.appendChild(t)}});
 document.querySelectorAll('button:not([type])').forEach(function(b){b.setAttribute('type','button')});
 // Navegação exclusiva: evita que o menu principal e o menu lateral fiquem abertos ao mesmo tempo.
 function closeMainNavigation(){
   var navigation=document.getElementById('navigation');
   if(navigation){navigation.classList.remove('menu-open','show','open');navigation.setAttribute('aria-expanded','false');}
   document.querySelectorAll('#navigation .has-submenu.open, #navigation .has-submenu.show').forEach(function(li){li.classList.remove('open','show');var a=li.querySelector(':scope > a');if(a)a.setAttribute('aria-expanded','false');});
 }
 function closeSideNavigation(){
   document.body.classList.remove('sidebar-enable');
   document.querySelectorAll('.left-side-menu .has-submenu.open, .left-side-menu .has-submenu.show').forEach(function(li){li.classList.remove('open','show');var a=li.querySelector(':scope > a');if(a)a.setAttribute('aria-expanded','false');});
 }
 document.addEventListener('click',function(e){
   var sideButton=e.target.closest&&e.target.closest('.button-menu-mobile');
   if(sideButton){closeMainNavigation();return;}
   var mainButton=e.target.closest&&e.target.closest('.navbar-toggle');
   if(mainButton){closeSideNavigation();return;}
   var trigger=e.target.closest&&e.target.closest('#navigation .has-submenu > a, #side-menu .has-submenu > a');
   if(!trigger)return;
   var item=trigger.parentElement;
   var parent=item&&item.parentElement;
   if(!parent)return;
   parent.querySelectorAll(':scope > li.has-submenu').forEach(function(sibling){
     if(sibling!==item){sibling.classList.remove('open','show');var siblingLink=sibling.querySelector(':scope > a');if(siblingLink)siblingLink.setAttribute('aria-expanded','false');}
   });
 });
})();

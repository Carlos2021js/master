(function () {
  'use strict';
  var KEY = 'csplayer_theme';
  function readTheme() {
    try {
      var saved = localStorage.getItem(KEY);
      if (saved === 'light' || saved === 'dark') return saved;
    } catch (e) {}
    var body = document.body;
    if (body && (body.dataset.theme === 'dark' || body.dataset.layoutMode === 'dark' || body.classList.contains('csplay-dark'))) return 'dark';
    return 'light';
  }
  function paint(theme) {
    var body = document.body;
    if (!body) return;
    var dark = theme === 'dark';
    body.dataset.theme = dark ? 'dark' : 'light';
    body.dataset.layoutMode = dark ? 'dark' : 'light';
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    body.classList.toggle('dark-mode', dark);
    body.classList.toggle('csplay-dark', dark);
    body.classList.toggle('topbar-dark', !dark);
    body.classList.toggle('left-side-menu-light', !dark);
    try { localStorage.setItem(KEY, dark ? 'dark' : 'light'); } catch (e) {}
    var buttons = document.querySelectorAll('[data-cs-theme-toggle]');
    buttons.forEach(function (button) {
      var icon = button.querySelector('[data-cs-theme-icon]');
      var label = button.querySelector('[data-cs-theme-label]');
      if (icon) icon.className = dark ? 'mdi mdi-white-balance-sunny' : 'mdi mdi-weather-night';
      if (label) label.textContent = dark ? 'Modo dia' : 'Modo noite';
      button.title = dark ? 'Ativar modo dia' : 'Ativar modo noite';
      button.setAttribute('aria-label', button.title);
      button.setAttribute('aria-pressed', dark ? 'true' : 'false');
    });
    try { window.dispatchEvent(new CustomEvent('csplayer:themechange', {detail:{theme:dark?'dark':'light'}})); } catch(e) {}
  }
  function init() {
    paint(readTheme());
    document.addEventListener('click', function (event) {
      var button = event.target.closest && event.target.closest('[data-cs-theme-toggle]');
      if (!button) return;
      event.preventDefault();
      paint(document.body.dataset.theme === 'dark' ? 'light' : 'dark');
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true}); else init();
}());

<?php
include "session.php"; include "functions.php";
if (($rPermissions["is_reseller"]) && (!$rPermissions["create_sub_resellers"])) { exit; }
// CS Player v6.6: o administrador principal deve ter acesso integral ao gerenciador de revendas.
// As permissões granulares continuam valendo para contas de revenda/sub-revenda.
if ((!$rPermissions["is_admin"]) && (!$rPermissions["is_reseller"])) { exit; }

if ($rPermissions["is_admin"]) {
    $rRegisteredUsers = getRegisteredUsers();
} else {
    $rRegisteredUsers = getRegisteredUsers($rUserInfo["id"]);
}

if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li>
                                        <a href="#" onClick="clearFilters();">
                                            <button type="button" class="btn btn-warning waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-filter-remove"></i>
                                            </button>
                                        </a>
                                        <a href="#" onClick="changeZoom();">
                                            <button type="button" class="btn btn-info waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-magnify"></i>
                                            </button>
                                        </a>
                                        <?php if (!$detect->isMobile()) { ?>
                                        <a href="#" onClick="toggleAuto();">
                                            <button type="button" class="btn btn-dark waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-refresh"></i> <span class="auto-text"><?=$_["auto_refresh"]?></span>
                                            </button>
                                        </a>
                                        <?php } else { ?>
                                        <a href="javascript:location.reload();" onClick="toggleAuto();">
                                            <button type="button" class="btn btn-dark waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-refresh"></i> <?=$_["refresh"]?>
                                            </button>
                                        </a>
                                        <?php }
										if (($rPermissions["is_admin"]) OR (hasPermissions("adv", "add_reguser")) OR ($rPermissions["is_reseller"])) { ?>
                                        <a href="<?php if ($rPermissions["is_admin"]) { echo "reg_user"; } else { echo "subreseller"; } ?>.php">
                                            <button type="button" class="btn btn-success waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-plus"></i> <?=$_["add"]?> <?php if ($rPermissions["is_admin"]) { ?><?=$_["registered_user"]?><?php } else { ?><?=$_["subresellers"]?><?php } ?>
                                            </button>
                                        </a>
										<?php } ?>
                                    </li>
                                </ol>
                            </div>
                            <h4 class="page-title"><?php if ($rPermissions["is_admin"]) { ?><?=$_["registered_users"]?><?php } else { ?><?=$_["subresellers"]?><?php } ?></h4>
                            <?php if ($rPermissions["is_admin"]) { ?>
                            <div class="cs-admin-legacy-tools-note text-muted small mt-1">
                                <i class="mdi mdi-shield-account"></i> Gerenciamento administrativo completo: filtros, zoom, atualização automática, edição, 2FA, banir/desbanir, ativar/desativar e exclusão.
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>     
                <?php if ($rPermissions["is_admin"]) { ?>
                <div class="row cs-reg-admin-shortcuts">
                    <div class="col-12">
                        <div class="card cs-admin-shortcut-card">
                            <div class="card-body">
                                <div class="cs-admin-shortcut-head">
                                    <div>
                                        <strong>Administração de Revendas</strong>
                                        <small>Atalhos das opções administrativas existentes no painel.</small>
                                    </div>
                                </div>
                                <div class="cs-admin-shortcut-grid">
                                    <?php if (hasPermissions("adv", "add_reguser")) { ?><a class="btn btn-primary" href="reg_user.php"><i class="mdi mdi-account-plus"></i><span>Adicionar Revenda</span></a><?php } ?>
                                    <?php if (hasPermissions("adv", "mng_groups")) { ?><a class="btn btn-secondary" href="groups.php"><i class="mdi mdi-account-group"></i><span>Grupos e Permissões</span></a><?php } ?>
                                    <?php if (hasPermissions("adv", "credits_log")) { ?><a class="btn btn-secondary" href="credit_logs.php"><i class="mdi mdi-cash-multiple"></i><span>Créditos</span></a><?php } ?>
                                    <?php if (hasPermissions("adv", "reg_userlog")) { ?><a class="btn btn-secondary" href="reg_user_logs.php"><i class="mdi mdi-history"></i><span>Logs de Revendas</span></a><?php } ?>
                                    <?php if (hasPermissions("adv", "block_ips")) { ?><a class="btn btn-secondary" href="ips.php"><i class="mdi mdi-ip-network"></i><span>IPs Bloqueados</span></a><?php } ?>
                                    <?php if (hasPermissions("adv", "block_isps")) { ?><a class="btn btn-secondary" href="isps.php"><i class="mdi mdi-access-point-network"></i><span>ISPs Bloqueados</span></a><?php } ?>
                                    <?php if (hasPermissions("adv", "block_uas")) { ?><a class="btn btn-secondary" href="useragents.php"><i class="mdi mdi-web-off"></i><span>User-Agents</span></a><?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
                <!-- end page title --> 
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body cs-reg-users-body">
                                <form id="reg_users_search" class="cs-reg-filter-panel" autocomplete="off">
                                    <div class="cs-reg-filter-grid">
                                        <div class="cs-reg-field cs-reg-search">
                                            <label for="reg_search"><i class="mdi mdi-magnify"></i> <?=$_["search_resellers"]?></label>
                                            <input type="text" class="form-control" id="reg_search" value="" placeholder="<?=$_["search_resellers"]?>...">
                                        </div>
                                        <div class="cs-reg-field">
                                            <label for="reg_reseller"><?=$_["filter_results"]?> / <?=$_["owner"]?></label>
                                            <select id="reg_reseller" class="form-control" data-toggle="select2">
                                                <option value="" selected><?=$_["all_owners"]?></option>
                                                <?php if ($rPermissions["is_admin"]) { ?><option value="0"><?=$_["no_owner"]?></option><?php } ?>
                                                <?php foreach ($rRegisteredUsers as $rRegisteredUser) { ?><option value="<?=$rRegisteredUser["id"]?>"><?=htmlspecialchars($rRegisteredUser["username"], ENT_QUOTES, 'UTF-8')?></option><?php } ?>
                                            </select>
                                        </div>
                                        <div class="cs-reg-field">
                                            <label for="reg_filter"><?=$_["status"]?></label>
                                            <select id="reg_filter" class="form-control" data-toggle="select2">
                                                <option value="" selected><?=$_["no_filter"]?></option>
                                                <option value="1"><?=$_["active"]?></option>
                                                <option value="2"><?=$_["disabled"]?></option>
                                            </select>
                                        </div>
                                        <div class="cs-reg-field cs-reg-entries">
                                            <label for="reg_show_entries"><?=$_["show"]?></label>
                                            <select id="reg_show_entries" class="form-control" data-toggle="select2">
                                                <?php foreach (Array(10, 25, 50, 250, 500, 1000) as $rShow) { ?>
                                                <option<?php if ($rAdminSettings["default_entries"] == $rShow) { echo " selected"; } ?> value="<?=$rShow?>"><?=$rShow?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="cs-reg-filter-actions">
                                        <button type="button" class="btn btn-warning" onclick="clearFilters();"><i class="mdi mdi-filter-remove"></i><span>Limpar Filtro</span></button>
                                        <button type="button" class="btn btn-info" onclick="changeZoom();"><i class="mdi mdi-magnify"></i><span>Zoom</span></button>
                                        <button type="button" class="btn btn-dark" onclick="toggleAuto();"><i class="mdi mdi-refresh"></i><span class="auto-text"><?=$_["auto_refresh"]?></span></button>
                                        <?php if ((hasPermissions("adv", "add_reguser")) OR ($rPermissions["is_reseller"])) { ?>
                                        <a class="btn btn-success" href="<?php if ($rPermissions["is_admin"]) { echo "reg_user"; } else { echo "subreseller"; } ?>.php"><i class="mdi mdi-plus"></i><span><?=$_["add"]?> <?php if ($rPermissions["is_admin"]) { echo $_["registered_user"]; } else { echo $_["subresellers"]; } ?></span></a>
                                        <?php } ?>
                                        <button type="button" class="btn btn-primary cs-reg-view-toggle" id="toggle-reg-view"><i class="mdi mdi-view-grid-outline"></i><span>Cards</span></button>
                                    </div>
                                </form>
                                <div id="reg-user-cards" class="cs-reg-card-grid" style="display:none;"></div>
                                <div class="cs-reg-table-wrap"><table id="datatable-users" class="table table-hover dt-responsive nowrap font-normal">
                                    <thead>
                                        <tr>
                                            <th class="text-center"><?=$_["id"]?></th>
                                            <th><?=$_["username"]?></th>
                                            <th><?=$_["owner"]?></th>
                                            <th class="text-center"><?=$_["ip"]?></th>
                                            <th class="text-center"><?=$_["type"]?></th>
                                            <th class="text-center"><?=$_["status"]?></th>
                                            <th class="text-center"><?=$_["credits"]?></th>
                                            <th class="text-center"><?=$_["users"]?></th>
											<th class="text-center"><?=$_["dns"]?></th>
                                            <th class="text-center"><?=$_["last_login"]?></th>
                                            <th class="text-center"><?=$_["actions"]?></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table></div>

                            </div> <!-- end card body-->
                        </div> <!-- end card -->
                    </div><!-- end col-->
                </div>
                <!-- end row-->
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <style>
        /* CS Player v6.6 — preserva as ferramentas clássicas do Admin e melhora o uso responsivo. */
        #reg_users_search .form-control, #reg_users_search .select2-container { min-height: 38px; }
        .page-title-right .breadcrumb li { display:flex; flex-wrap:wrap; gap:6px; justify-content:flex-end; }
        #datatable-users_wrapper .dataTables_paginate .pagination { flex-wrap:wrap; }
        @media (max-width: 767.98px) {
            .page-title-box { padding-bottom:12px; }
            .page-title-right { float:none !important; margin-top:12px; }
            .page-title-right .breadcrumb { justify-content:flex-start; }
            .page-title-right .breadcrumb li { width:100%; justify-content:flex-start; }
            .page-title-right .btn { min-height:42px; min-width:42px; }
            #reg_users_search .form-group.row > [class*="col-"] { margin-bottom:10px; }
            #reg_users_search label { text-align:left !important; padding-top:4px; padding-bottom:4px; }
            .card-body { padding:14px; }
            #datatable-users { min-width:980px; }
            .cs-admin-legacy-tools-note { line-height:1.45; }
        }
        </style>

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>
        <script src="assets/js/pages/form-remember.js"></script>
        <script src="assets/js/app.min.js"></script>

        <script>
        var autoRefresh = true;
        var rClearing = false;
        
        function api(rID, rType) {
            if (rType == "delete") {
                if (confirm('<?=$_["are_you_sure_you_want_to_delete_this_reseller"]?>') == false) {
                    return;
                }
             } else if (rType == "enable" || rType == "unban") {
                var question = rType == "unban" ? "Desbanir esta conta e permitir novamente o acesso ao painel?" : '<?=$_["are_you_sure_you_want_to_enable"]?>';
                if (confirm(question) == false) return;
            } else if (rType == "disable" || rType == "ban") {
                var question = rType == "ban" ? "Banir esta conta do painel? O cadastro e os dados serão preservados." : '<?=$_["are_you_sure_you_want_to_disable"]?>';
                if (confirm(question) == false) return;
           }
            $.getJSON("./api.php?action=reg_user&sub=" + rType + "&user_id=" + rID, function(data) {
                if (data.result === true) {
                    if (rType == "delete") {
                        $.toast("<?=$_["user_has_been_deleted"]?>");
                    } else if (rType == "enable") {
                        $.toast("<?=$_["user_has_been_enabled"]?>");
                    } else if (rType == "disable") {
                        $.toast("<?=$_["user_has_been_disabled"]?>");
                    } else if (rType == "ban") {
                        $.toast("Conta banida do painel.");
                    } else if (rType == "unban") {
                        $.toast("Conta desbanida. O acesso ao painel foi restaurado.");
					} else if (rType == "reset") {
                        $.toast("<?=$_["two_factor_authentication_has_been_reset"]?>");
                    }
                    $('[data-toggle="tooltip"]').tooltip("hide");
                    $("#datatable-users").DataTable().ajax.reload(null, false);
                } else {
                    $.toast(data.message || "<?=$_["an_error_occured"]?>");
                }
            });
        }
        function toggleAuto() {
            if (autoRefresh == true) {
                autoRefresh = false;
                $(".auto-text").html("<?=$_["manual_mode"]?>");
            } else {
                autoRefresh = true;
                $(".auto-text").html("<?=$_["auto_refresh"]?>");
            }
        }
        function getFilter() {
            return $("#reg_filter").val();
        }
        function getReseller() {
            return $("#reg_reseller").val();
        }
        function reloadUsers() {
            if (autoRefresh == true) {
                $('[data-toggle="tooltip"]').tooltip("hide");
                $("#datatable-users").DataTable().ajax.reload(null, false);
            }
            setTimeout(reloadUsers, 5000);
        }
        function changeZoom() {
            if ($("#datatable-users").hasClass("font-large")) {
                $("#datatable-users").removeClass("font-large");
                $("#datatable-users").addClass("font-normal");
            } else if ($("#datatable-users").hasClass("font-normal")) {
                $("#datatable-users").removeClass("font-normal");
                $("#datatable-users").addClass("font-small");
            } else {
                $("#datatable-users").removeClass("font-small");
                $("#datatable-users").addClass("font-large");
            }
            $("#datatable-users").DataTable().draw();
        }
        function csStripHtml(value) {
            return $('<div>').html(value == null ? '' : String(value)).text().trim();
        }
        function csRenderRegCards() {
            var dt = $('#datatable-users').DataTable();
            var rows = dt.rows({page:'current'}).data().toArray();
            var $cards = $('#reg-user-cards');
            $cards.empty();
            if (!rows.length) {
                $cards.html('<div class="cs-reg-empty">Nenhuma revenda encontrada.</div>');
                return;
            }
            rows.forEach(function(row) {
                var username = row[1] || '';
                var owner = csStripHtml(row[2]) || '—';
                var ip = csStripHtml(row[3]) || '—';
                var type = row[4] || '';
                var status = row[5] || '';
                var credits = row[6] || '';
                var users = row[7] || '';
                var dns = csStripHtml(row[8]) || '—';
                var last = csStripHtml(row[9]) || 'NEVER';
                var actions = row[10] || '';
                $cards.append(
                    '<article class="cs-reg-card">' +
                        '<div class="cs-reg-card-head"><div><small>#'+csStripHtml(row[0])+'</small><h5>'+username+'</h5></div><div class="cs-reg-card-status">'+status+'</div></div>' +
                        '<div class="cs-reg-card-meta">' +
                            '<div><span>Proprietário</span><strong>'+owner+'</strong></div>' +
                            '<div><span>Tipo</span><strong>'+type+'</strong></div>' +
                            '<div><span>Créditos</span><strong>'+credits+'</strong></div>' +
                            '<div><span>Clientes</span><strong>'+users+'</strong></div>' +
                            '<div><span>IP</span><strong>'+ip+'</strong></div>' +
                            '<div><span>Último login</span><strong>'+last+'</strong></div>' +
                            '<div class="cs-reg-card-wide"><span>DNS</span><strong>'+dns+'</strong></div>' +
                        '</div>' +
                        '<div class="cs-reg-card-actions">'+actions+'</div>' +
                    '</article>'
                );
            });
        }
        function csApplyRegView(force) {
            var mobile = window.matchMedia('(max-width: 767.98px)').matches;
            var saved = localStorage.getItem('cs_reg_users_view');
            var cards = force || saved === 'cards' || (saved === null && mobile);
            if (cards) {
                $('.cs-reg-table-wrap').hide();
                $('#reg-user-cards').show();
                $('#toggle-reg-view').html('<i class="mdi mdi-table"></i><span>Lista</span>');
                csRenderRegCards();
            } else {
                $('#reg-user-cards').hide();
                $('.cs-reg-table-wrap').show();
                $('#toggle-reg-view').html('<i class="mdi mdi-view-grid-outline"></i><span>Cards</span>');
            }
        }

        function clearFilters() {
            window.rClearing = true;
            $("#reg_search").val("").trigger('change');
            $('#reg_filter').val("").trigger('change');
            $('#reg_reseller').val("").trigger('change');
            $('#reg_show_entries').val("<?=$rAdminSettings["default_entries"] ?: 10?>").trigger('change');
            window.rClearing = false;
            $('#datatable-users').DataTable().search($("#reg_search").val());
            $('#datatable-users').DataTable().page.len($('#reg_show_entries').val());
            $("#datatable-users").DataTable().page(0).draw('page');
            $('[data-toggle="tooltip"]').tooltip("hide");
            $("#datatable-users").DataTable().ajax.reload( null, false );
        }
        $(document).ready(function() {
			$(window).keypress(function(event){
                if(event.which == 13 && event.target.nodeName != "TEXTAREA") return false;
            });
            formCache.init();
            formCache.fetch();
            
            $.fn.dataTable.ext.errMode = 'none';
            $('select').select2({width: '100%'});
            $("#datatable-users").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination");
                    $('[data-toggle="tooltip"]').tooltip();
                    if ($('#reg-user-cards').is(':visible')) { csRenderRegCards(); }
                },
                createdRow: function(row, data, index) {
                    $(row).addClass('user-' + data[0]);
                },
				pageLength: <?=intval($rAdminSettings["default_entries"] ?: 10)?>,
                lengthMenu: [10, 25, 50, 250, 500, 1000],
				stateSave: true,
                responsive: false,
                processing: true,
                serverSide: true,
                ajax: {
                    url: "./table_search.php",
                    "data": function(d) {
                        d.id = "reg_users",
                        d.filter = getFilter(),
                        d.reseller = getReseller()
                    }
                },
                columnDefs: [
                    {"className": "dt-center", "targets": [0,1,2,3,4,5,6,7,8,9,10]},
                    <?php if ($rPermissions["is_reseller"]) { ?>
                    {"visible": false, "targets": [4]}
                    <?php } ?>
                ],
                order: [[ 0, "desc" ]],
                stateSave: true
            });
            $("#datatable-users").css("width", "100%");
            $('#toggle-reg-view').on('click', function() {
                var cardsVisible = $('#reg-user-cards').is(':visible');
                localStorage.setItem('cs_reg_users_view', cardsVisible ? 'list' : 'cards');
                csApplyRegView(!cardsVisible);
            });
            csApplyRegView(false);
            $(window).on('resize.csRegUsers', function(){
                if (localStorage.getItem('cs_reg_users_view') === null) { csApplyRegView(false); }
            });
            $('#reg_search').keyup(function(){
                if (!window.rClearing) {
                    $('#datatable-users').DataTable().search($(this).val()).draw();
                }
            });
            $('#reg_show_entries').change(function(){
                if (!window.rClearing) {
                    $('#datatable-users').DataTable().page.len($(this).val()).draw();
                }
            });
            $('#reg_filter').change(function(){
                if (!window.rClearing) {
                    $('[data-toggle="tooltip"]').tooltip("hide");
                    $("#datatable-users").DataTable().ajax.reload( null, false );
                }
            });
            $('#reg_reseller').change(function(){
                if (!window.rClearing) {
                    $('[data-toggle="tooltip"]').tooltip("hide");
                    $("#datatable-users").DataTable().ajax.reload( null, false );
                }
            });
            <?php if (!$detect->isMobile()) { ?>
            setTimeout(reloadUsers, 5000);
            <?php }
            if (!$rAdminSettings["auto_refresh"]) { ?>
            toggleAuto();
            <?php } ?>
            if ($('#reg_search').val().length > 0) {
                $('#datatable-users').DataTable().search($('#reg_search').val()).draw();
            }
        });
        
        $(window).bind('beforeunload', function() {
            formCache.save();
        });
        </script>
    </body>
</html>
<?php
/**
 * CS Player - controle centralizado das funcionalidades exclusivas do administrador.
 * Este arquivo deve ser carregado após session.php e functions.php.
 */

if (!function_exists('cs_is_primary_admin')) {
    function cs_is_primary_admin(): bool
    {
        global $rPermissions;
        return is_array($rPermissions) && !empty($rPermissions['is_admin']);
    }
}

if (!function_exists('cs_admin_only')) {
    function cs_admin_only(string $feature = 'esta funcionalidade'): void
    {
        if (cs_is_primary_admin()) {
            return;
        }

        http_response_code(403);
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Content-Type: text/html; charset=UTF-8');

        $safeFeature = htmlspecialchars($feature, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">'
            . '<meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<title>Acesso restrito — CS Player</title>'
            . '<style>body{margin:0;background:#10141b;color:#eef2f7;font-family:Arial,sans-serif;display:grid;place-items:center;min-height:100vh}'
            . '.box{width:min(92%,560px);background:#171d27;border:1px solid #2b3544;border-radius:16px;padding:30px;box-shadow:0 18px 60px rgba(0,0,0,.35)}'
            . 'h1{margin:0 0 12px;font-size:24px}p{line-height:1.55;color:#bdc7d5}.badge{display:inline-block;padding:6px 10px;border-radius:999px;background:#352329;color:#ffb4be;font-weight:bold;font-size:12px}'
            . 'a{display:inline-block;margin-top:16px;color:#fff;background:#2867d7;padding:11px 16px;border-radius:9px;text-decoration:none}</style></head><body>'
            . '<main class="box"><span class="badge">HTTP 403</span><h1>Acesso exclusivo do administrador</h1>'
            . '<p>Somente o administrador pode editar ' . $safeFeature . '. Revendedores e demais perfis visualizam apenas o resultado publicado.</p>'
            . '<a href="./index.php">Voltar ao painel</a></main></body></html>';
        exit;
    }
}

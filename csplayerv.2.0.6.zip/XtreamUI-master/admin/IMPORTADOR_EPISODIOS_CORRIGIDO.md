# Importador de episódios corrigido

## Alterações aplicadas

O processamento de `admin/episode_import.php` foi mantido no mesmo fluxo visual, mas passou a validar os campos numéricos, validar URLs HTTP/HTTPS, limitar o conteúdo M3U, ignorar itens incompletos ou inválidos, usar consultas preparadas para os três `INSERT`, usar transação com rollback em caso de erro e exibir a quantidade importada/ignorada.

Também foi acrescentado token CSRF específico para o formulário, escape do identificador usado no link de retorno e registro resumido de falhas no `error_log`, sem registrar senha ou conteúdo integral do M3U.

## Compatibilidade

O comportamento de importação continua aceitando conteúdo M3U no campo existente e mantém os campos e tabelas utilizados anteriormente. A URL M3U continua disponível quando enviada pelo formulário, mas agora é limitada a HTTP/HTTPS, com timeout de 20 segundos e sem seguir redirecionamentos automaticamente.

## Validação

Foi confirmada estaticamente a correspondência entre placeholders e parâmetros das consultas preparadas, a presença do CSRF e dos controles de transação. O `php -l` deve ser executado no servidor ou em CI compatível, pois o ambiente de geração não possui o executável PHP instalado.

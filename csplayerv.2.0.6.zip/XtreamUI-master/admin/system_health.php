<?php
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
cs_admin_only('o diagnóstico e as configurações técnicas');
if ((!hasPermissions('adv', 'settings')) && (!hasPermissions('adv', 'database'))) exit;
require_once __DIR__ . '/cs_audit.php';

function cs_ini_bytes($value) {
    $value = trim((string)$value);
    if ($value === '' || $value === '-1') return -1;
    $unit = strtolower(substr($value, -1));
    $number = (float)$value;
    if ($unit === 'g') $number *= 1024;
    if ($unit === 'm' || $unit === 'g') $number *= 1024;
    if ($unit === 'k' || $unit === 'm' || $unit === 'g') $number *= 1024;
    return (int)$number;
}
function cs_format_bytes($bytes) {
    if ($bytes < 0) return 'Ilimitado';
    $units = ['B','KB','MB','GB','TB']; $i = 0; $n = (float)$bytes;
    while ($n >= 1024 && $i < count($units)-1) { $n /= 1024; $i++; }
    return number_format($n, $i ? 1 : 0, ',', '.') . ' ' . $units[$i];
}
function cs_dir_size($dir) {
    if (!is_dir($dir)) return 0; $size = 0;
    try { $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)); foreach ($it as $f) if ($f->isFile()) $size += $f->getSize(); } catch (Throwable $e) {}
    return $size;
}
function cs_check($name, $ok, $detail, $recommendation = '') { return compact('name','ok','detail','recommendation'); }

$checks = [];
$checks[] = cs_check('Versão do PHP', version_compare(PHP_VERSION, '8.1.0', '>='), PHP_VERSION, 'Use PHP 8.1 ou superior.');
foreach (['mysqli','curl','mbstring','json','openssl','fileinfo','zip'] as $ext) $checks[] = cs_check('Extensão '.$ext, extension_loaded($ext), extension_loaded($ext) ? 'Carregada' : 'Ausente', 'Instale/ative php-'.$ext.'.');
$upload = cs_ini_bytes(ini_get('upload_max_filesize')); $post = cs_ini_bytes(ini_get('post_max_size')); $memory = cs_ini_bytes(ini_get('memory_limit'));
$checks[] = cs_check('upload_max_filesize', $upload < 0 || $upload >= 128*1024*1024, ini_get('upload_max_filesize'), 'Recomendado: 256M ou maior para vídeos e playlists grandes.');
$checks[] = cs_check('post_max_size', $post < 0 || $post >= 128*1024*1024, ini_get('post_max_size'), 'Recomendado: maior que upload_max_filesize.');
$checks[] = cs_check('memory_limit', $memory < 0 || $memory >= 256*1024*1024, ini_get('memory_limit'), 'Recomendado: 512M; o importador incremental reduz o consumo.');
$checks[] = cs_check('Tempo de execução', (int)ini_get('max_execution_time') === 0 || (int)ini_get('max_execution_time') >= 300, ini_get('max_execution_time').' s', 'Recomendado: 300 segundos ou 0 para tarefas administrativas controladas.');
$dirs = [
    'Cache CS Player' => __DIR__.'/cache/cs-player',
    'Mídias personalizadas' => __DIR__.'/assets/uploads/branding',
    'Logs de auditoria' => __DIR__.'/logs/cs-player'
];
foreach ($dirs as $label=>$dir) {
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $checks[] = cs_check($label, is_dir($dir) && is_writable($dir), is_dir($dir) ? (is_writable($dir) ? 'Gravável' : 'Sem escrita') : 'Não criado', 'Ajuste proprietário e permissões do diretório.');
}
$free = @disk_free_space(__DIR__); $total = @disk_total_space(__DIR__); $percent = ($free !== false && $total) ? ($free/$total*100) : 100;
$checks[] = cs_check('Espaço livre em disco', $percent >= 10, $free === false ? 'Não disponível' : cs_format_bytes($free).' ('.number_format($percent,1,',','.').'%)', 'Mantenha ao menos 10% do disco livre.');
$mediaSize = cs_dir_size(__DIR__.'/assets/uploads/branding');
$cacheSize = cs_dir_size(__DIR__.'/cache/cs-player');
$failed = count(array_filter($checks, function($c){ return !$c['ok']; }));
$score = max(0, 100 - $failed * 8);
cs_audit_log('system.health_view', ['score'=>$score,'failed'=>$failed]);
include $rSettings['sidebar'] ? 'header_sidebar.php' : 'header.php';
?>
<div class="wrapper"><div class="container-fluid">
<div class="row"><div class="col-12"><div class="page-title-box"><h4 class="page-title"><i class="mdi mdi-heart-pulse"></i> Saúde e diagnóstico do sistema</h4></div></div></div>
<div class="row">
<div class="col-lg-4"><div class="card"><div class="card-body text-center"><h5>Índice de saúde</h5><div style="font-size:54px;font-weight:700" class="<?=$score>=80?'text-success':($score>=60?'text-warning':'text-danger')?>"><?=$score?>%</div><p class="text-muted mb-0"><?=$failed?> ponto(s) exigem atenção</p></div></div></div>
<div class="col-lg-4"><div class="card"><div class="card-body"><h5>Armazenamento visual</h5><p class="mb-1">Mídias: <strong><?=cs_format_bytes($mediaSize)?></strong></p><p class="mb-1">Cache: <strong><?=cs_format_bytes($cacheSize)?></strong></p><p class="mb-0">Livre: <strong><?=$free===false?'N/D':cs_format_bytes($free)?></strong></p></div></div></div>
<div class="col-lg-4"><div class="card"><div class="card-body"><h5>Ambiente</h5><p class="mb-1">Servidor: <strong><?=htmlspecialchars($_SERVER['SERVER_SOFTWARE'] ?? 'N/D')?></strong></p><p class="mb-1">PHP: <strong><?=htmlspecialchars(PHP_VERSION)?></strong></p><p class="mb-0">SAPI: <strong><?=htmlspecialchars(PHP_SAPI)?></strong></p></div></div></div>
</div>
<div class="card"><div class="card-body"><h4 class="header-title mb-3">Verificações automáticas</h4><div class="table-responsive"><table class="table table-hover"><thead><tr><th>Status</th><th>Item</th><th>Resultado</th><th>Recomendação</th></tr></thead><tbody>
<?php foreach($checks as $c): ?><tr><td><span class="badge badge-<?=$c['ok']?'success':'warning'?>"><?=$c['ok']?'OK':'ATENÇÃO'?></span></td><td><?=htmlspecialchars($c['name'])?></td><td><?=htmlspecialchars($c['detail'])?></td><td><?=htmlspecialchars($c['ok']?'Funcionamento adequado.':$c['recommendation'])?></td></tr><?php endforeach; ?>
</tbody></table></div></div></div>
<div class="alert alert-info"><strong>Observação:</strong> o envio fragmentado do importador M3U continua funcionando mesmo com limites menores do Nginx. Para vídeos grandes enviados pela área visual, ajuste também <code>client_max_body_size</code> no Nginx.</div>
</div></div>
<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-md-12 copyright text-center"><?=getFooter()?></div></div></div></footer>
<script src="assets/js/vendor.min.js"></script><script src="assets/js/app.min.js"></script></body></html>

<?php
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
require_once __DIR__ . '/cs_audit.php';
cs_admin_only('o Servidor SSH');

if (empty($_SESSION['cs_vps_csrf'])) { $_SESSION['cs_vps_csrf'] = bin2hex(random_bytes(32)); }
function cs_vps_h($v){ return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function cs_vps_valid_host(string $host): bool {
    return (bool)(filter_var($host, FILTER_VALIDATE_IP) || preg_match('/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i', $host));
}
function cs_vps_read_server(int $id): ?array {
    $row = getStreamingServersByID($id);
    return is_array($row) ? $row : null;
}
function cs_vps_credentials_from_request(): array {
    $serverId = max(0, (int)($_POST['server_id'] ?? 0));
    $saved = !empty($_POST['use_saved']);
    $host = trim((string)($_POST['ssh_host'] ?? ''));
    $port = max(1, min(65535, (int)($_POST['ssh_port'] ?? 22)));
    $password = (string)($_POST['root_password'] ?? '');
    if ($saved && $serverId > 0) {
        $srv = cs_vps_read_server($serverId);
        if ($srv) {
            if ($host === '') $host = trim((string)($srv['server_ip'] ?? ''));
            $port = max(1, min(65535, (int)($srv['ssh_port'] ?? $port)));
            if ($password === '' && !empty($srv['ssh_password'])) {
                $decoded = base64_decode((string)$srv['ssh_password'], true);
                if ($decoded !== false) { $decoded2 = base64_decode($decoded, true); if ($decoded2 !== false) $password = $decoded2; }
            }
        }
    }
    return ['host'=>$host, 'port'=>$port, 'user'=>'root', 'password'=>$password, 'server_id'=>$serverId, 'use_saved'=>$saved];
}
function cs_vps_proc(array $cmd, array $env, int $timeout): array {
    $desc=[1=>['pipe','w'],2=>['pipe','w']];
    $proc=@proc_open($cmd,$desc,$pipes,null,$env,['bypass_shell'=>true]);
    if(!is_resource($proc)) return ['ok'=>false,'code'=>126,'output'=>'Não foi possível iniciar o processo SSH.'];
    stream_set_blocking($pipes[1],false); stream_set_blocking($pipes[2],false);
    $start=microtime(true); $out=''; $status=[];
    do { $out.=stream_get_contents($pipes[1]).stream_get_contents($pipes[2]); $status=proc_get_status($proc); if(!$status['running']) break; if(microtime(true)-$start>$timeout){proc_terminate($proc,15);usleep(250000);proc_terminate($proc,9);$out.="\nTempo limite excedido.";break;} usleep(100000);} while(true);
    $out.=stream_get_contents($pipes[1]).stream_get_contents($pipes[2]); fclose($pipes[1]); fclose($pipes[2]);
    $code=proc_close($proc); if($code<0 && isset($status['exitcode']) && $status['exitcode']>=0)$code=$status['exitcode'];
    return ['ok'=>$code===0,'code'=>$code,'output'=>trim($out)?:'Operação concluída.'];
}
function cs_vps_ssh_exec(array $cred, string $remoteCommand, int $timeout=60): array {
    if (!cs_vps_valid_host($cred['host'])) return ['ok'=>false,'code'=>400,'output'=>'Host/IP SSH inválido.'];
    if ($cred['password']==='') return ['ok'=>false,'code'=>401,'output'=>'Informe a senha root ou marque “Usar credenciais salvas”.'];
    $ssh='/usr/bin/ssh'; if(!is_executable($ssh)) return ['ok'=>false,'code'=>127,'output'=>'Cliente OpenSSH (/usr/bin/ssh) não encontrado.'];
    $common=['-o','ConnectTimeout=8','-o','ConnectionAttempts=1','-o','ServerAliveInterval=10','-o','ServerAliveCountMax=2','-o','StrictHostKeyChecking=accept-new','-o','PreferredAuthentications=password,keyboard-interactive','-o','PubkeyAuthentication=no','-p',(string)$cred['port'],'root@'.$cred['host'],$remoteCommand];
    if (is_executable('/usr/bin/sshpass')) {
        $env=['LANG'=>'C','LC_ALL'=>'C','SSHPASS'=>$cred['password']];
        return cs_vps_proc(array_merge(['/usr/bin/sshpass','-e',$ssh],$common),$env,$timeout);
    }
    $ask=tempnam(sys_get_temp_dir(),'csp_ask_');
    if($ask===false) return ['ok'=>false,'code'=>126,'output'=>'Não foi possível criar o autenticador SSH temporário.'];
    file_put_contents($ask,"#!/bin/sh\nprintf '%s\\n' \"\$CS_PLAYER_ROOT_PASSWORD\"\n"); @chmod($ask,0700);
    $env=['LANG'=>'C','LC_ALL'=>'C','SSH_ASKPASS'=>$ask,'SSH_ASKPASS_REQUIRE'=>'force','DISPLAY'=>'cs-player:0','CS_PLAYER_ROOT_PASSWORD'=>$cred['password']];
    $runner=is_executable('/usr/bin/setsid')?'/usr/bin/setsid':$ssh;
    $cmd=$runner===$ssh?array_merge([$ssh],$common):array_merge([$runner,'-w',$ssh],$common);
    try { return cs_vps_proc($cmd,$env,$timeout); } finally { @unlink($ask); }
}
function cs_vps_panel_cache_clear(): array {
    $targets=[__DIR__.'/cache/cs-player',__DIR__.'/storage/m3u_uploads'];$removed=0;$failed=0;$now=time();
    foreach($targets as $dir){if(!is_dir($dir))continue;try{$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $file){if(!$file->isFile())continue;if(strpos($dir,'m3u_uploads')!==false&&$file->getMTime()>$now-86400)continue;if(@unlink($file->getPathname()))$removed++;else$failed++;}}catch(Throwable $e){$failed++;}}
    if(function_exists('opcache_reset'))@opcache_reset(); clearstatcache(true);
    return ['ok'=>$failed===0,'code'=>$failed?1:0,'output'=>"Cache do painel limpo. Arquivos removidos: {$removed}. Falhas: {$failed}. OPcache solicitado."];
}

$commands=[
 'status'=>"printf 'CS PLAYER - STATUS DO SERVIDOR\\n'; date; uptime; printf '\\nMemória:\\n'; free -h; printf '\\nDisco:\\n'; df -h /; printf '\\nServiços:\\n'; systemctl is-active php8.3-fpm 2>/dev/null || true; systemctl is-active nginx 2>/dev/null || true; systemctl is-active mariadb 2>/dev/null || true; systemctl is-active ssh 2>/dev/null || true",
 'restart_php'=>"systemctl restart php8.3-fpm || systemctl restart php8.4-fpm || systemctl restart php8.2-fpm",
 'reload_nginx'=>"nginx -t && systemctl reload nginx",
 'restart_nginx'=>"nginx -t && systemctl restart nginx",
 'clear_system_cache'=>"sync; (command -v sysctl >/dev/null && sysctl -w vm.drop_caches=1 >/dev/null 2>&1 || true); find /tmp -xdev -type f -mtime +3 -delete 2>/dev/null || true; echo 'Caches seguros processados.'",
 'rotate_logs'=>"logrotate -f /etc/logrotate.conf 2>&1 || true; journalctl --vacuum-time=14d 2>&1 || true",
 'disk_cleanup'=>"apt-get clean; journalctl --vacuum-time=7d 2>&1 || true; find /tmp /var/tmp -xdev -type f -mtime +3 -delete 2>/dev/null || true; echo 'Limpeza concluída.'",
 'test_config'=>"php -v | head -2; printf '\\nNginx:\\n'; (nginx -t 2>&1 || true); printf '\\nPHP-FPM:\\n'; (php-fpm8.3 -t 2>&1 || php-fpm8.4 -t 2>&1 || true)",
 'php_profile_safe'=>"printf 'memory_limit=512M\\nupload_max_filesize=2G\\npost_max_size=2G\\nmax_execution_time=3600\\nmax_input_time=3600\\n' > /etc/php/8.3/fpm/conf.d/99-cs-player.ini && php-fpm8.3 -t && systemctl restart php8.3-fpm",
 'php_profile_large'=>"printf 'memory_limit=1G\\nupload_max_filesize=10G\\npost_max_size=10G\\nmax_execution_time=0\\nmax_input_time=-1\\n' > /etc/php/8.3/fpm/conf.d/99-cs-player.ini && php-fpm8.3 -t && systemctl restart php8.3-fpm",
 'php_profile_unlimited_time'=>"printf 'memory_limit=1G\\nupload_max_filesize=10G\\npost_max_size=10G\\nmax_execution_time=0\\nmax_input_time=-1\\n' > /etc/php/8.3/fpm/conf.d/99-cs-player.ini && php-fpm8.3 -t && systemctl restart php8.3-fpm",
 'restart_vps'=>"nohup sh -c 'sleep 2; systemctl reboot' >/dev/null 2>&1 & echo 'Reinicialização agendada.'"
];
$result=null; $cred=['host'=>'','port'=>22,'server_id'=>0,'use_saved'=>true];
if($_SERVER['REQUEST_METHOD']==='POST'){
    $now=microtime(true);$last=(float)($_SESSION['cs_vps_last_action']??0);
    if($now-$last<1.5){$result=['ok'=>false,'code'=>429,'output'=>'Aguarde um instante antes de executar outra ação.'];}
    elseif(!hash_equals($_SESSION['cs_vps_csrf'],(string)($_POST['csrf']??''))){$result=['ok'=>false,'code'=>419,'output'=>'Token de segurança inválido. Atualize a página.'];}
    else{
        $action=(string)($_POST['action']??'');$cred=cs_vps_credentials_from_request();
        if($action==='clear_panel_cache'){$result=cs_vps_panel_cache_clear();}
        elseif(isset($commands[$action])){
            $critical=in_array($action,['restart_vps','restart_nginx','php_profile_safe','php_profile_large','php_profile_unlimited_time','disk_cleanup'],true);
            if($critical && (string)($_POST['confirm']??'')!=='CONFIRMAR')$result=['ok'=>false,'code'=>400,'output'=>'Digite CONFIRMAR para executar esta ação crítica.'];
            else $result=cs_vps_ssh_exec($cred,$commands[$action],$action==='restart_vps'?12:90);
        } else $result=['ok'=>false,'code'=>400,'output'=>'Ação não permitida.'];
        $_SESSION['cs_vps_last_action']=$now; cs_audit_log('vps_manager.ssh_action',['action'=>$action,'host'=>$cred['host'],'port'=>$cred['port'],'server_id'=>$cred['server_id'],'ok'=>(bool)$result['ok'],'code'=>(int)$result['code']]);
    }
}
$rServersLocal=getStreamingServers(); $firstServer=$rServersLocal?reset($rServersLocal):null;
$defaultHost=$cred['host']?:($firstServer['server_ip']??'127.0.0.1'); $defaultPort=$cred['port']?:((int)($firstServer['ssh_port']??22));
include $rSettings['sidebar']?'header_sidebar.php':'header.php';
?>
<style>
.cs-ssh-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:18px}.cs-span-4{grid-column:span 4}.cs-span-8{grid-column:span 8}.cs-span-12{grid-column:span 12}.cs-server-card{height:100%;border:1px solid rgba(100,116,139,.16);border-radius:18px;box-shadow:0 10px 28px rgba(15,23,42,.07)}.cs-server-card .card-body{padding:22px}.cs-credential-card{background:linear-gradient(135deg,rgba(37,99,235,.08),rgba(14,165,233,.04))}.cs-status-pre{white-space:pre-wrap;max-height:350px;overflow:auto;background:#0f172a;color:#dbeafe;padding:16px;border-radius:12px;font-size:12px}.cs-ssh-btn{min-height:44px;border-radius:10px;font-weight:600}.cs-badge-live{display:inline-flex;align-items:center;gap:7px;padding:6px 10px;border-radius:999px;background:rgba(16,185,129,.1);color:#047857;font-weight:700}.cs-dot{width:8px;height:8px;border-radius:50%;background:#10b981}.cs-password-wrap{position:relative}.cs-password-wrap .form-control{padding-right:48px}.cs-pass-toggle{position:absolute;right:7px;top:7px;border:0;background:transparent;height:34px;width:36px;border-radius:8px}.cs-help{font-size:12px;color:#64748b}.cs-action-stack form{margin-bottom:10px}@media(max-width:991.98px){.cs-span-4,.cs-span-8{grid-column:span 12}}@media(max-width:575.98px){.cs-ssh-grid{gap:12px}.cs-server-card .card-body{padding:16px}.page-title-box{padding-top:6px}.cs-ssh-btn{font-size:14px}}
</style>
<div class="wrapper"><div class="container-fluid">
<div class="row"><div class="col-12"><div class="page-title-box"><h4 class="page-title"><i class="mdi mdi-server-security"></i> Servidor SSH</h4></div></div></div>
<?php if($result):?><div class="alert alert-<?=$result['ok']?'success':'danger'?>"><strong><?=$result['ok']?'Concluído':'Falha'?> (código <?=intval($result['code'])?>)</strong><pre class="mt-2 mb-0" style="white-space:pre-wrap"><?=cs_vps_h($result['output'])?></pre></div><?php endif;?>
<div class="cs-ssh-grid">
<div class="cs-span-12"><div class="card cs-server-card cs-credential-card"><div class="card-body"><div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div><h4 class="header-title mb-1">Acesso root direto por SSH</h4><div class="cs-help">Funciona sem sudo NOPASSWD e sem o helper. Pode usar a mesma senha SSH cadastrada em Servidores.</div></div><span class="cs-badge-live"><span class="cs-dot"></span> Gerenciamento direto</span></div>
<form id="sshCredentials" onsubmit="return false"><div class="row"><div class="col-md-4 mb-2"><label>Servidor cadastrado</label><select class="form-control" id="server_id"><?php foreach($rServersLocal as $sid=>$srv):?><option value="<?=intval($sid)?>" data-host="<?=cs_vps_h($srv['server_ip']??'')?>" data-port="<?=intval($srv['ssh_port']??22)?>"><?=cs_vps_h($srv['server_name']??('Servidor #'.$sid))?> — <?=cs_vps_h($srv['server_ip']??'')?></option><?php endforeach;?></select></div><div class="col-md-3 mb-2"><label>Host / IP</label><input class="form-control" id="ssh_host" value="<?=cs_vps_h($defaultHost)?>" autocomplete="off"></div><div class="col-md-2 mb-2"><label>Porta SSH</label><input class="form-control" id="ssh_port" type="number" min="1" max="65535" value="<?=intval($defaultPort)?>"></div><div class="col-md-3 mb-2"><label>Senha root</label><div class="cs-password-wrap"><input class="form-control" id="root_password" type="password" autocomplete="current-password" placeholder="Senha root"><button type="button" class="cs-pass-toggle" id="toggleRootPass" title="Mostrar/ocultar senha"><i class="mdi mdi-eye-outline"></i></button></div></div></div><label class="mb-0"><input type="checkbox" id="use_saved" checked> Usar credenciais salvas do servidor quando a senha acima estiver vazia</label></form>
</div></div></div>
<div class="cs-span-4"><div class="card cs-server-card"><div class="card-body"><h4 class="header-title">Estado do servidor</h4><p class="text-muted">Consulta CPU, memória, disco e serviços usando SSH root.</p><div id="statusHint" class="cs-status-pre">Clique em “Atualizar estado” para consultar o servidor.</div><button class="btn btn-info btn-block cs-ssh-btn mt-3" data-action="status"><i class="mdi mdi-refresh"></i> Atualizar estado</button></div></div></div>
<div class="cs-span-4"><div class="card cs-server-card"><div class="card-body cs-action-stack"><h4 class="header-title">Serviços e desempenho</h4><button class="btn btn-warning btn-block cs-ssh-btn" data-action="restart_php">Reiniciar PHP-FPM</button><button class="btn btn-secondary btn-block cs-ssh-btn" data-action="reload_nginx">Validar e recarregar Nginx</button><button class="btn btn-light btn-block cs-ssh-btn" data-action="test_config">Diagnóstico PHP/Nginx</button><button class="btn btn-primary btn-block cs-ssh-btn" data-action="clear_panel_cache">Limpar cache do painel/OPcache</button></div></div></div>
<div class="cs-span-4"><div class="card cs-server-card"><div class="card-body cs-action-stack"><h4 class="header-title">Manutenção</h4><button class="btn btn-light btn-block cs-ssh-btn" data-action="clear_system_cache">Limpar caches seguros</button><button class="btn btn-light btn-block cs-ssh-btn" data-action="rotate_logs">Rotacionar logs</button><button class="btn btn-warning btn-block cs-ssh-btn" data-action="disk_cleanup" data-critical="1">Limpeza avançada de disco</button><button class="btn btn-danger btn-block cs-ssh-btn" data-action="restart_vps" data-critical="1">Reiniciar VPS</button></div></div></div>
<div class="cs-span-8"><div class="card cs-server-card"><div class="card-body"><h4 class="header-title">Perfis PHP 8.3</h4><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Perfil</th><th>Configuração</th><th></th></tr></thead><tbody><tr><td>Seguro</td><td>512M / upload 2G / 3600s</td><td><button class="btn btn-sm btn-success" data-action="php_profile_safe" data-critical="1">Aplicar</button></td></tr><tr><td>Arquivos grandes</td><td>1G / upload 10G / tempo ilimitado</td><td><button class="btn btn-sm btn-warning" data-action="php_profile_large" data-critical="1">Aplicar</button></td></tr><tr><td>Tempo ilimitado</td><td>1G / 10G / max_execution_time=0</td><td><button class="btn btn-sm btn-danger" data-action="php_profile_unlimited_time" data-critical="1">Aplicar</button></td></tr></tbody></table></div></div></div></div>
<div class="cs-span-4"><div class="card cs-server-card"><div class="card-body"><h4 class="header-title">Segurança operacional</h4><p class="text-muted mb-2">A senha digitada não é gravada pelo CS PLAYER. Se “credenciais salvas” estiver ativo, o painel reutiliza o campo <code>ssh_password</code> já existente em <code>streaming_servers</code>.</p><p class="text-muted mb-0">Comandos são pré-definidos e ações críticas exigem confirmação.</p></div></div></div>
</div></div></div>
<form method="post" id="actionForm" style="display:none"><input type="hidden" name="csrf" value="<?=cs_vps_h($_SESSION['cs_vps_csrf'])?>"><input type="hidden" name="action" id="f_action"><input type="hidden" name="confirm" id="f_confirm"><input type="hidden" name="server_id" id="f_server_id"><input type="hidden" name="ssh_host" id="f_host"><input type="hidden" name="ssh_port" id="f_port"><input type="hidden" name="root_password" id="f_password"><input type="hidden" name="use_saved" id="f_saved"></form>
<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-md-12 copyright text-center"><?=getFooter()?></div></div></div></footer>
<script src="assets/js/vendor.min.js"></script><script src="assets/js/app.min.js"></script><script>
(function(){var sel=document.getElementById('server_id'),host=document.getElementById('ssh_host'),port=document.getElementById('ssh_port'),pass=document.getElementById('root_password'),saved=document.getElementById('use_saved');
function syncServer(){if(!sel||!sel.options.length)return;var o=sel.options[sel.selectedIndex];if(o.dataset.host)host.value=o.dataset.host;if(o.dataset.port)port.value=o.dataset.port;} if(sel)sel.addEventListener('change',syncServer);
var t=document.getElementById('toggleRootPass');if(t)t.addEventListener('click',function(){pass.type=pass.type==='password'?'text':'password';this.querySelector('i').className=pass.type==='password'?'mdi mdi-eye-outline':'mdi mdi-eye-off-outline';});
function submitAction(btn){var critical=btn.dataset.critical==='1',confirm='';if(critical){confirm=window.prompt('Ação crítica. Digite CONFIRMAR para continuar:','')||'';if(confirm!=='CONFIRMAR')return;}document.getElementById('f_action').value=btn.dataset.action;document.getElementById('f_confirm').value=confirm;document.getElementById('f_server_id').value=sel?sel.value:'';document.getElementById('f_host').value=host.value;document.getElementById('f_port').value=port.value;document.getElementById('f_password').value=pass.value;document.getElementById('f_saved').value=saved&&saved.checked?'1':'';btn.disabled=true;document.getElementById('actionForm').submit();}
document.querySelectorAll('[data-action]').forEach(function(b){b.addEventListener('click',function(){submitAction(this);});});})();
</script></body></html>

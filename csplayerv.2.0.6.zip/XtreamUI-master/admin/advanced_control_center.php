<?php
include "session.php"; include "functions.php";
if ((!$rPermissions["is_admin"]) && (!$rPermissions["is_reseller"])) { http_response_code(403); exit; }

function csAdvancedCount($rSql) {
    global $db;
    $rResult = $db->query($rSql);
    if (($rResult) && ($rRow = $rResult->fetch_assoc())) { return intval(array_values($rRow)[0]); }
    return 0;
}

$rUsersTotal = csAdvancedCount("SELECT COUNT(*) AS total FROM `users`");
$rUsersActive = csAdvancedCount("SELECT COUNT(*) AS total FROM `users` WHERE `enabled` = 1 AND (`exp_date` IS NULL OR `exp_date` = 0 OR `exp_date` > ".intval(time()).")");
$rResellersTotal = $rPermissions["is_admin"] ? csAdvancedCount("SELECT COUNT(*) AS total FROM `reg_users`") : 0;
$rStreamsTotal = $rPermissions["is_admin"] ? csAdvancedCount("SELECT COUNT(*) AS total FROM `streams`") : 0;
$rOnlineTotal = csAdvancedCount("SELECT COUNT(*) AS total FROM `user_activity_now`");

if ($rSettings["sidebar"]) { include "header_sidebar.php"; } else { include "header.php"; }
if ($rSettings["sidebar"]) { ?>
<div class="content-page"><div class="content boxed-layout-ext"><div class="container-fluid">
<?php } else { ?>
<div class="wrapper boxed-layout-ext"><div class="container-fluid">
<?php } ?>
    <div class="row"><div class="col-12"><div class="page-title-box"><h4 class="page-title">Centro de Controle Avançado</h4><p class="text-muted mb-0">Visão operacional do painel sem substituir os módulos existentes.</p></div></div></div>
    <div class="row">
        <div class="col-xl-3 col-md-6"><div class="card cs-advanced-stat"><div class="card-body"><span class="text-muted">Clientes cadastrados</span><h2><?=number_format($rUsersTotal, 0, ',', '.')?></h2><a href="users.php">Abrir clientes <i class="mdi mdi-arrow-right"></i></a></div></div></div>
        <div class="col-xl-3 col-md-6"><div class="card cs-advanced-stat"><div class="card-body"><span class="text-muted">Clientes ativos</span><h2><?=number_format($rUsersActive, 0, ',', '.')?></h2><a href="users.php?filter=1">Ver ativos <i class="mdi mdi-arrow-right"></i></a></div></div></div>
        <?php if ($rPermissions["is_admin"]) { ?><div class="col-xl-3 col-md-6"><div class="card cs-advanced-stat"><div class="card-body"><span class="text-muted">Revendedores</span><h2><?=number_format($rResellersTotal, 0, ',', '.')?></h2><a href="reg_users.php">Gerenciar revendas <i class="mdi mdi-arrow-right"></i></a></div></div></div><div class="col-xl-3 col-md-6"><div class="card cs-advanced-stat"><div class="card-body"><span class="text-muted">Streams cadastrados</span><h2><?=number_format($rStreamsTotal, 0, ',', '.')?></h2><a href="streams.php">Gerenciar streams <i class="mdi mdi-arrow-right"></i></a></div></div></div><?php } ?>
    </div>
    <div class="row">
        <div class="col-xl-8"><div class="card"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-3"><div><h4 class="header-title mb-1">Ações rápidas</h4><p class="text-muted mb-0">Acesse tarefas frequentes sem alterar os fluxos tradicionais.</p></div><span class="badge badge-soft-primary"><i class="mdi mdi-flash"></i> Operação rápida</span></div><div class="row cs-advanced-actions">
            <div class="col-md-4"><a href="<?= $rPermissions["is_reseller"] ? "user_reseller.php" : "user.php" ?>" class="cs-advanced-action"><i class="mdi mdi-account-plus"></i><strong>Adicionar cliente</strong><span>Gerar credenciais e copiar acesso.</span></a></div>
            <div class="col-md-4"><a href="cs_m3u_diagnostics.php" class="cs-advanced-action"><i class="mdi mdi-play-network"></i><strong>Diagnóstico M3U</strong><span>Validar formatos e fontes autorizadas.</span></a></div>
            <div class="col-md-4"><a href="system_health.php" class="cs-advanced-action"><i class="mdi mdi-heart-pulse"></i><strong>Saúde do sistema</strong><span>Verificar ambiente e armazenamento.</span></a></div>
            <div class="col-md-4"><a href="live_connections.php" class="cs-advanced-action"><i class="mdi mdi-access-point"></i><strong>Conexões ao vivo</strong><span>Observar clientes conectados agora.</span></a></div>
            <div class="col-md-4"><a href="backups.php" class="cs-advanced-action"><i class="mdi mdi-backup-restore"></i><strong>Backups</strong><span>Revisar cópias e restauração.</span></a></div>
            <div class="col-md-4"><a href="security_center.php" class="cs-advanced-action"><i class="mdi mdi-shield-check"></i><strong>Segurança</strong><span>Auditoria, login e proteção.</span></a></div>
        </div></div></div></div>
        <div class="col-xl-4"><div class="card"><div class="card-body"><h4 class="header-title mb-3">Status operacional</h4><div class="cs-advanced-status"><span class="status-dot bg-success"></span><div><strong>Painel administrativo</strong><small>Funcionando nesta sessão</small></div></div><div class="cs-advanced-status"><span class="status-dot bg-info"></span><div><strong>Conexões monitoradas</strong><small><?=number_format($rOnlineTotal, 0, ',', '.')?> atividade(s) registrada(s)</small></div></div><div class="cs-advanced-status"><span class="status-dot bg-warning"></span><div><strong>Transmissão</strong><small>Use o diagnóstico para validar DNS, portas e origem.</small></div></div></div></div></div>
    </div>
</div></div>
<?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-md-12 copyright text-center"><?=getFooter()?></div></div></div></footer>
<script src="assets/js/vendor.min.js"></script><script src="assets/js/app.min.js"></script>
</body></html>

<?php
include 'session.php';
include 'functions.php';
require_once __DIR__ . '/cs_admin_access.php';
cs_admin_only('o Servidor SSH');
header('Location: servidor_ssh.php', true, 302);
exit;

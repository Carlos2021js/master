<?php
/**
 * CS PLAYER shared compatibility footer.
 * Preserves the legacy vendor bundle and supplies the visual footer only on
 * pages that do not already render their own <footer class="footer">.
 */
if (count(get_included_files()) === 1) { exit; }
$csPlayerFooterHtml = function_exists('getFooter') ? (string)getFooter() : 'CS PLAYER';
?>
<?php if (empty($GLOBALS['cs_player_vendor_loaded'])): ?>
<script src="assets/js/vendor.min.js"></script>
<?php endif; ?>
<script>
(function () {
    function ensureCsPlayerFooter() {
        if (document.querySelector('footer.footer')) return;
        var footer = document.createElement('footer');
        footer.className = 'footer csplayer-shared-footer';
        var container = document.createElement('div');
        container.className = 'container-fluid';
        var row = document.createElement('div');
        row.className = 'row';
        var copyright = document.createElement('div');
        copyright.className = 'col-md-12 copyright text-center';
        copyright.innerHTML = <?=json_encode($csPlayerFooterHtml, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)?>;
        row.appendChild(copyright);
        container.appendChild(row);
        footer.appendChild(container);
        document.body.appendChild(footer);
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', ensureCsPlayerFooter, {once:true});
    } else {
        ensureCsPlayerFooter();
    }
}());
</script>

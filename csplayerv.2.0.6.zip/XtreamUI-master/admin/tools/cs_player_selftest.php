<?php
require_once dirname(__DIR__) . '/cs_player.php';
$checks = array();
foreach (array(
    'ambas vazias' => array('recaptcha_v3_enable'=>1,'recaptcha_v3_site_key'=>'','recaptcha_v3_secret_key'=>''),
    'site vazia' => array('recaptcha_v3_enable'=>1,'recaptcha_v3_site_key'=>'','recaptcha_v3_secret_key'=>'secret'),
    'secret vazia' => array('recaptcha_v3_enable'=>1,'recaptcha_v3_site_key'=>'site','recaptcha_v3_secret_key'=>''),
    'completa' => array('recaptcha_v3_enable'=>1,'recaptcha_v3_site_key'=>'site','recaptcha_v3_secret_key'=>'secret')
) as $name => $settings) {
    $checks['recaptcha'][$name] = cs_recaptcha_v3_config($settings)['enabled'];
}
$checks['provider'] = array(
    'hls' => cs_detect_provider_type('https://example.com/live/test.m3u8'),
    'm3u' => cs_detect_provider_type('https://example.com/list.m3u'),
    'xtream-api' => cs_detect_provider_type('https://example.com/player_api.php?username=x'),
    'stalker' => cs_detect_provider_type('https://example.com/stalker_portal/server/load.php')
);
$key = 'selftest-' . bin2hex(random_bytes(4));
$checks['cache_write'] = cs_cache_set('selftest', $key, array('ok'=>true), 30);
$checks['cache_read'] = cs_cache_get('selftest', $key, array());
$checks['php'] = PHP_VERSION;
$checks['memory_limit'] = ini_get('memory_limit');
echo json_encode($checks, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), PHP_EOL;

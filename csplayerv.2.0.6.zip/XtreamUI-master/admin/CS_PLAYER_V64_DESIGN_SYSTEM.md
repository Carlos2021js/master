# CS Player v6.4 — Padronização Admin / Revenda / Clientes

## Escopo aplicado

Esta atualização trabalha somente no código do projeto. Nenhuma tabela, coluna, índice, ID ou estrutura SQL foi criada, removida ou alterada.

### Clientes (`users.php`)
- Mesmo `users.php` utilizado por Admin e Revenda, preservando permissões distintas.
- Filtros reorganizados em design responsivo: pesquisa, revenda, vencimento, criação, situação, teste/oficial, servidor e conexões.
- Ações principais padronizadas: Limpar Filtro, Adicionar e Lista/Cards.
- Cards como visualização adequada para smartphone e tabela preservada para desktop.
- Ações existentes continuam disponíveis dentro dos cards.
- Preferência Lista/Cards continua salva em `localStorage`, sem banco.

### Copiar informações do cliente
- Modal de detalhes disponível para Admin e Revenda com validação de propriedade para Revenda.
- Copiar Tudo / WhatsApp com dados reais disponíveis: usuário, senha, revenda, bouquets/conteúdo, datas, conexões, servidor, DNS, M3U HLS, MPEG-TS, M3U8, Player API, EPG/XMLTV, SSIPTV e XCIPTV quando disponíveis.
- `get_user_details.php` deixou de depender de `users.plan_id` e tabela `plans`, que não existem no schema fornecido.
- O conteúdo/plano exibido é derivado dos bouquets reais do cliente, sem inventar relacionamento no banco.
- `user.php` e `user_reseller.php` ganharam acesso a “Copiar informações” para clientes já existentes.
- O modal pós-criação (`client_delivery.php`) foi ampliado e continua sem persistência adicional.

### Admin + Revenda
- Design System compartilhado por CSS, sem unificar regras de negócio.
- Mesmas animações leves, cards, controles, modais, espaçamento e comportamento responsivo.
- Bottom navigation existente preservada.
- Dark Mode recebe contraste e componentes consistentes.
- `prefers-reduced-motion` respeitado.

### Compatibilidade mobile
- Filtros empilhados em telas pequenas.
- Cards de clientes em uma coluna.
- Ações com áreas de toque maiores.
- Modais com altura máxima e rolagem interna.
- Conteúdo recebe espaço para a barra inferior e safe-area.
- Tabelas desktop continuam disponíveis sem serem removidas.

## Banco de dados

**ALTERAÇÕES ESTRUTURAIS: ZERO.**

A implementação utiliza somente tabelas/campos já existentes, incluindo `users`, `reg_users`, `bouquets`, `servers` e configurações já carregadas pelo painel.

## Validação

- Lint executado em 254 arquivos PHP.
- Resultado: nenhum erro de sintaxe PHP.

## Arquivos principais alterados

- `admin/users.php`
- `admin/table_search.php`
- `admin/get_user_details.php`
- `admin/client_delivery.php`
- `admin/user.php`
- `admin/user_reseller.php`
- `admin/header.php`
- `admin/header_sidebar.php`
- `admin/assets/css/csplay-sigma.css`

Backups da versão anterior estão em `admin/backups/2026-08-17_03-00-00-v64-design/`.

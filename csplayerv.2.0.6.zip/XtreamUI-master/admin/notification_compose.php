<?php
include 'session.php'; include 'functions.php'; include 'notification_system.php';
if (!$rPermissions['is_admin']) { header('Location: notifications.php'); exit; }
cs_notify_install(); $success=''; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $target=$_POST['target'] ?? 'all_resellers'; $title=trim($_POST['title'] ?? ''); $message=trim($_POST['message'] ?? ''); $category=$_POST['category'] ?? 'info'; $url=trim($_POST['action_url'] ?? '');
    if ($title==='' || $message==='') $error='Informe o título e a mensagem.';
    else {
        $sent=0;
        if ($target==='all_resellers') {
            $q=$db->query("SELECT `id` FROM `reg_users` WHERE `status`=1 AND `id`<>".intval($rUserInfo['id']));
            if($q) while($u=$q->fetch_assoc()){ cs_notify_send($u['id'],$title,$message,$category,$url,'reseller',$rUserInfo['id'],null,1); $sent++; }
        } elseif ($target==='all') {
            cs_notify_send(0,$title,$message,$category,$url,'all',$rUserInfo['id'],null,0); $sent=1;
        } else {
            $rid=intval($target); if($rid>0){ cs_notify_send($rid,$title,$message,$category,$url,'reseller',$rUserInfo['id'],null,1); $sent=1; }
        }
        $success='Mensagem enviada para '.$sent.' destinatário(s).';
    }
}
$resellers=[]; $q=$db->query("SELECT `id`,`username`,`email`,`status` FROM `reg_users` WHERE `id`<>".intval($rUserInfo['id'])." ORDER BY `username`"); if($q)while($u=$q->fetch_assoc())$resellers[]=$u;
if ($rSettings['sidebar']) include 'header_sidebar.php'; else include 'header.php';
?>
<?php if ($rSettings['sidebar']) { ?><div class="content-page"><div class="content"><div class="container-fluid"><?php } else { ?><div class="wrapper"><div class="container-fluid"><?php } ?>
<div class="row"><div class="col-xl-8 mx-auto"><div class="page-title-box"><h4 class="page-title"><i class="mdi mdi-send-circle-outline"></i> Enviar mensagem push</h4></div>
<?php if($success){ ?><div class="alert alert-success"><i class="mdi mdi-check-circle"></i> <?=htmlspecialchars($success)?></div><?php } if($error){ ?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php } ?>
<div class="card-box"><form method="post" autocomplete="off">
<div class="form-group"><label>Destinatário</label><select name="target" class="form-control" required><option value="all_resellers">Todas as revendas (privada individual)</option><option value="all">Todos os usuários do painel (comunicado)</option><?php foreach($resellers as $u){ ?><option value="<?=intval($u['id'])?>"><?=htmlspecialchars($u['username'])?><?=(!$u['status']?' — desativado':'')?></option><?php } ?></select></div>
<div class="form-row"><div class="form-group col-md-8"><label>Título</label><input name="title" maxlength="180" class="form-control" required placeholder="Ex.: Atenção à renovação dos clientes"></div><div class="form-group col-md-4"><label>Prioridade</label><select name="category" class="form-control"><option value="info">Informativa</option><option value="success">Sucesso</option><option value="warning">Aviso</option><option value="danger">Urgente / erro</option><option value="system">Sistema</option></select></div></div>
<div class="form-group"><label>Mensagem</label><textarea name="message" rows="7" class="form-control" required placeholder="Digite uma orientação clara e profissional para a revenda."></textarea></div>
<div class="form-group"><label>Link de ação (opcional)</label><input name="action_url" class="form-control" placeholder="users.php, tickets.php ou URL interna"></div>
<div class="alert alert-info"><i class="mdi mdi-shield-lock-outline"></i> Mensagens de erros internos do sistema permanecem privadas e são encaminhadas somente ao administrador.</div>
<div class="text-right"><a href="notifications.php" class="btn btn-light">Cancelar</a> <button class="btn btn-primary" type="submit"><i class="mdi mdi-send"></i> Enviar agora</button></div>
</form></div></div></div>
</div></div><?php if ($rSettings['sidebar']) echo '</div>'; ?>
<?php include __DIR__ . '/footer.php'; ?>
<script src="assets/js/app.min.js"></script>
</body>
</html>

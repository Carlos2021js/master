<?php
include 'session.php';
include 'functions.php';
if (empty($rPermissions['is_admin'])) { http_response_code(403); exit('Acesso restrito ao administrador.'); }

$groups = [
    'Principal' => [
        ['dashboard.php','Painel / Dashboard','mdi-view-dashboard'],
        ['settings.php','Configurações gerais','mdi-cog'],
        ['edit_profile.php','Perfil do administrador','mdi-account-circle'],
        ['branding_manager.php','Identidade visual','mdi-image-multiple'],
    ],
    'Clientes e Revendas' => [
        ['users.php','Gerenciar clientes','mdi-account-group'],
        ['user.php','Adicionar cliente','mdi-account-plus'],
        ['reg_users.php','Gerenciar revendas','mdi-account-multiple'],
        ['reg_user.php','Adicionar revenda','mdi-account-multiple-plus'],
        ['groups.php','Grupos e permissões','mdi-account-key'],
        ['packages.php','Pacotes','mdi-package-variant'],
        ['credits_log.php','Histórico de créditos','mdi-cash-multiple'],
        ['login_logs.php','Logs de login','mdi-login-variant'],
    ],
    'Conteúdo IPTV' => [
        ['streams.php','Canais / Streams','mdi-play-network'],
        ['stream.php','Adicionar stream','mdi-plus-network'],
        ['movies.php','Filmes','mdi-movie'],
        ['movie.php','Adicionar filme','mdi-movie-open-plus'],
        ['series.php','Séries','mdi-television-classic'],
        ['serie.php','Adicionar série','mdi-television-guide'],
        ['episodes.php','Episódios','mdi-playlist-play'],
        ['radios.php','Rádios','mdi-radio'],
        ['categories.php','Categorias','mdi-folder-multiple'],
        ['bouquets.php','Bouquets','mdi-flower-tulip'],
        ['epgs.php','EPG','mdi-calendar-clock'],
        ['channel_order.php','Ordenação de canais','mdi-sort'],
    ],
    'Importação' => [
        ['m3u_update_nodup.php','Importador M3U','mdi-file-import'],
        ['m3u_update_nodup1.php','Importador M3U 1','mdi-file-import-outline'],
        ['m3u_update_nodup2.php','Importador M3U 2','mdi-file-sync'],
        ['m3u_update_nodup3.php','Importador M3U 3','mdi-file-cog'],
        ['vod_import.php','Importar VOD','mdi-movie-open'],
        ['episode_import.php','Importar episódios','mdi-playlist-plus'],
        ['watch.php','Watch Folder','mdi-folder-eye'],
    ],
    'Servidores e Sistema' => [
        ['servers.php','Servidores','mdi-server'],
        ['server.php','Adicionar / editar servidor','mdi-server-plus'],
        ['servidor_ssh.php','Servidor SSH','mdi-server-security'],
        ['process_monitor.php','Monitor de processos','mdi-monitor-dashboard'],
        ['system_health.php','Saúde do sistema','mdi-heart-pulse'],
        ['system_logs.php','Logs do sistema','mdi-text-box-search'],
        ['advanced_control_center.php','Central avançada','mdi-tune-vertical'],
        ['database.php','Banco de dados','mdi-database'],
        ['backups.php','Backups','mdi-backup-restore'],
    ],
    'Ferramentas e Segurança' => [
        ['stream_tools.php','Ferramentas de streams','mdi-tools'],
        ['mass_delete.php','Exclusão em massa','mdi-delete-sweep'],
        ['fingerprint.php','Fingerprint','mdi-fingerprint'],
        ['blocked_ips.php','IPs bloqueados','mdi-ip-network'],
        ['isps.php','ISPs','mdi-access-point-network'],
        ['useragents.php','User Agents','mdi-web'],
        ['login_flood.php','Proteção de login','mdi-shield-lock'],
        ['tickets.php','Tickets','mdi-email'],
        ['notifications.php','Notificações','mdi-bell'],
    ],
];

// Só exibe links para arquivos realmente presentes nesta versão.
foreach ($groups as $section => $items) {
    $groups[$section] = array_values(array_filter($items, function($item){ return is_file(__DIR__ . '/' . $item[0]); }));
    if (!$groups[$section]) unset($groups[$section]);
}
include $rSettings['sidebar'] ? 'header_sidebar.php' : 'header.php';
?>
<div class="wrapper cs-admin-center"><div class="container-fluid">
<div class="row"><div class="col-12"><div class="page-title-box d-flex align-items-center justify-content-between flex-wrap">
<h4 class="page-title mb-2"><i class="mdi mdi-shield-crown-outline"></i> Central Administrativa</h4>
<div class="cs-admin-center-search-wrap"><input id="csAdminSearch" class="form-control" type="search" placeholder="Pesquisar opção administrativa..." autocomplete="off"></div>
</div></div></div>
<div class="alert alert-info cs-admin-note"><i class="mdi mdi-information-outline"></i> Esta central reúne somente páginas que já existem no projeto. Nenhuma alteração no banco de dados é necessária.</div>
<?php foreach ($groups as $section => $items): ?>
<section class="cs-admin-section" data-section="<?=htmlspecialchars($section,ENT_QUOTES,'UTF-8')?>">
<h5 class="cs-admin-section-title"><?=htmlspecialchars($section,ENT_QUOTES,'UTF-8')?></h5>
<div class="row cs-admin-grid">
<?php foreach ($items as $item): ?>
<div class="col-12 col-sm-6 col-lg-4 col-xl-3 cs-admin-option" data-search="<?=htmlspecialchars(mb_strtolower($item[1].' '.$section),ENT_QUOTES,'UTF-8')?>">
<a class="card cs-admin-option-card" href="<?=htmlspecialchars($item[0],ENT_QUOTES,'UTF-8')?>"><div class="card-body">
<span class="cs-admin-option-icon"><i class="mdi <?=htmlspecialchars($item[2],ENT_QUOTES,'UTF-8')?>"></i></span>
<span class="cs-admin-option-text"><strong><?=htmlspecialchars($item[1],ENT_QUOTES,'UTF-8')?></strong><small><?=htmlspecialchars($section,ENT_QUOTES,'UTF-8')?></small></span>
<i class="mdi mdi-chevron-right cs-admin-option-arrow"></i>
</div></a></div>
<?php endforeach; ?>
</div></section>
<?php endforeach; ?>
<div id="csAdminEmpty" class="alert alert-secondary d-none">Nenhuma opção encontrada.</div>
</div></div>
<footer class="footer"><div class="container-fluid"><div class="row"><div class="col-md-12 copyright text-center"><?=getFooter()?></div></div></div></footer>
<script src="assets/js/vendor.min.js"></script><script src="assets/js/app.min.js"></script>
<script>
(function(){
 var input=document.getElementById('csAdminSearch'), empty=document.getElementById('csAdminEmpty');
 if(!input)return;
 input.addEventListener('input',function(){
   var q=(this.value||'').toLowerCase().trim(), visible=0;
   document.querySelectorAll('.cs-admin-section').forEach(function(sec){
     var sectionVisible=0;
     sec.querySelectorAll('.cs-admin-option').forEach(function(el){
       var ok=!q || (el.getAttribute('data-search')||'').indexOf(q)!==-1;
       el.style.display=ok?'':'none'; if(ok){visible++;sectionVisible++;}
     });
     sec.style.display=sectionVisible?'':'none';
   });
   if(empty) empty.classList.toggle('d-none', visible!==0);
 });
})();
</script></body></html>

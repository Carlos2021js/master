# CS Player — restauração do painel Admin

- Banco de dados: **não alterado**.
- `hasPermissions("adv", ...)`: contas marcadas como administrador passam a ter acesso completo às funções administrativas já existentes no código, evitando opções ocultas por `allowed_pages` incompleto.
- Criada `admin_center.php`: central responsiva que lista somente páginas administrativas realmente existentes nesta versão.
- Adicionado atalho **Central Admin — Todas as opções** no menu do administrador.
- Melhorias mobile para central administrativa, tabelas e modais.
- Backups dos arquivos alterados em `admin/backups/2026-08-16_admin_restore/`.

Nenhuma tabela, coluna, índice ou ID foi criado, removido ou modificado.

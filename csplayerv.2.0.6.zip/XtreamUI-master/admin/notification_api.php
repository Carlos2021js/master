<?php
include 'session.php'; include 'functions.php'; include 'notification_system.php';
header('Content-Type: application/json; charset=utf-8');
cs_notify_generate_smart_alerts();
$action=$_GET['action'] ?? 'poll';
if ($action==='read') { cs_notify_mark_read(intval($_POST['id'] ?? $_GET['id'] ?? 0)); echo json_encode(['ok'=>true,'count'=>cs_notify_unread_count()]); exit; }
$items=cs_notify_list(8,true);
$out=[]; foreach($items as $n) $out[]=['id'=>(int)$n['id'],'title'=>$n['title'],'message'=>mb_strimwidth(strip_tags($n['message']),0,180,'…'),'category'=>$n['category'],'url'=>$n['action_url'] ?: 'notifications.php','created_at'=>(int)$n['created_at']];
echo json_encode(['ok'=>true,'count'=>cs_notify_unread_count(),'items'=>$out], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

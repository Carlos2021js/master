# CS Player — Correções v6

Data: 2026-08-16

## Regras preservadas
- Nenhuma alteração estrutural no banco de dados.
- Nenhuma tabela/coluna/ID foi criado, removido ou renomeado.
- Importadores existentes foram preservados.

## Correções aplicadas
- Login do painel: validação de permissões mais robusta para Admin e Revenda.
- Compatibilidade de senha: mantém hash histórico Xtream e aceita hashes `password_hash()` já existentes.
- Sessão: validação null-safe, status da conta e grupo banido antes de carregar preferências.
- Contas do painel: Admin agora possui ações explícitas **Banir** e **Desbanir** usando o campo `reg_users.status` já existente.
- Proteção contra auto-banimento da conta administrativa em uso.
- Clientes: modal de detalhes e **Copiar Tudo** agora incluem usuário, senha, plano, preço, conexões, status, criação, vencimento, M3U HLS, M3U MPEG-TS, SSIPTV e XCIPTV.
- Clientes mobile: preferência Lista/Cards persistida no navegador; primeira visita mobile prioriza Cards.
- Responsividade: melhorias para tabelas, grupos de ações, modais, Select2, paginação, safe-area e smartphones.
- Login: identificação visual atualizada para Admin & Revendas.

## Arquivos alterados
- `admin/functions.php`
- `admin/login.php`
- `admin/api.php`
- `admin/table_search.php`
- `admin/reg_users.php`
- `admin/users.php`
- `admin/assets/css/csplay-sigma.css`

## Banco
ALTERAÇÕES ESTRUTURAIS NO BANCO: **ZERO**

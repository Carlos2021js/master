<?php
/**
 * CS PLAYER - redimensionador de ícones compatível com PHP 8.x.
 * Mantém o endpoint legado e evita HTTP 500 quando GD ou a imagem remota
 * não estão disponíveis.
 */
ini_set('display_errors', '0');
error_reporting(E_ALL);

$rPath = __DIR__ . '/icons/';
if (!is_dir($rPath)) { @mkdir($rPath, 0755, true); }

function csTransparentPixel(): void {
    header('Content-Type: image/png');
    header('Cache-Control: public, max-age=300');
    // PNG transparente 1x1. Funciona mesmo sem extensão GD.
    echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=');
    exit;
}

function csFetchImage(string $url): ?string {
    if (!preg_match('~^https?://~i', $url)) return null;
    $parts = @parse_url($url);
    if (!$parts || empty($parts['host'])) return null;
    $host = strtolower((string)$parts['host']);
    if ($host === 'localhost') return null;
    $ip = @gethostbyname($host);
    if ($ip && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) return null;

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_USERAGENT => 'CS PLAYER/1.0 Image Proxy',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
        ]);
        $data = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $type = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);
        if ($data !== false && $code >= 200 && $code < 300 && strpos(strtolower((string)$type), 'image/') === 0 && strlen($data) <= 8 * 1024 * 1024) {
            return $data;
        }
        return null;
    }

    $ctx = stream_context_create(['http' => ['timeout' => 8, 'user_agent' => 'CS PLAYER/1.0 Image Proxy', 'follow_location' => 1, 'max_redirects' => 3]]);
    $data = @file_get_contents($url, false, $ctx, 0, 8 * 1024 * 1024 + 1);
    return ($data !== false && strlen($data) <= 8 * 1024 * 1024) ? $data : null;
}

$url = trim((string)($_GET['url'] ?? ''));
$max = max(16, min(1024, (int)($_GET['max'] ?? 0)));
if ($url === '' || $max <= 0) csTransparentPixel();

$cache = $rPath . hash('sha256', $url) . '_' . $max . '.png';
if (is_file($cache) && filesize($cache) > 0) {
    header('Content-Type: image/png');
    header('Cache-Control: public, max-age=86400');
    readfile($cache);
    exit;
}

// Sem GD: não derruba o painel; retorna placeholder transparente.
$gdRequired = ['imagecreatetruecolor','imagecreatefromstring','imagecopyresampled','imagepng'];
foreach ($gdRequired as $fn) if (!function_exists($fn)) csTransparentPixel();

$data = csFetchImage($url);
if ($data === null) csTransparentPixel();
$src = @imagecreatefromstring($data);
if (!$src) csTransparentPixel();
$width = imagesx($src); $height = imagesy($src);
if ($width < 1 || $height < 1) { imagedestroy($src); csTransparentPixel(); }
$scale = min(1, $max / $width, $max / $height);
$newW = max(1, (int)floor($width * $scale));
$newH = max(1, (int)floor($height * $scale));
$dst = imagecreatetruecolor($newW, $newH);
imagealphablending($dst, false); imagesavealpha($dst, true);
$transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127); imagefill($dst, 0, 0, $transparent);
imagecopyresampled($dst, $src, 0, 0, 0, 0, $newW, $newH, $width, $height);
@imagepng($dst, $cache, 6);
header('Content-Type: image/png');
header('Cache-Control: public, max-age=86400');
imagepng($dst, null, 6);
imagedestroy($src); imagedestroy($dst);

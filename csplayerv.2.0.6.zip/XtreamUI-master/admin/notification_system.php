<?php
if (count(get_included_files()) === 1) { exit; }

function cs_notify_install() {
    global $db;
    static $done = false;
    if ($done) return;
    $done = true;
    $db->query("CREATE TABLE IF NOT EXISTS `cs_notifications` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `recipient_id` INT NOT NULL DEFAULT 0,
        `sender_id` INT NOT NULL DEFAULT 0,
        `audience` ENUM('admin','reseller','all') NOT NULL DEFAULT 'reseller',
        `category` VARCHAR(32) NOT NULL DEFAULT 'info',
        `title` VARCHAR(180) NOT NULL,
        `message` TEXT NOT NULL,
        `action_url` VARCHAR(500) DEFAULT NULL,
        `is_private` TINYINT(1) NOT NULL DEFAULT 1,
        `is_read` TINYINT(1) NOT NULL DEFAULT 0,
        `dedupe_key` VARCHAR(191) DEFAULT NULL,
        `created_at` INT NOT NULL,
        `read_at` INT DEFAULT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_dedupe_recipient` (`recipient_id`,`dedupe_key`),
        KEY `idx_recipient_unread` (`recipient_id`,`is_read`,`created_at`),
        KEY `idx_audience` (`audience`,`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function cs_notify_send($recipientId, $title, $message, $category='info', $actionUrl='', $audience='reseller', $senderId=0, $dedupeKey=null, $private=1) {
    global $db;
    cs_notify_install();
    $recipientId = intval($recipientId); $senderId = intval($senderId);
    $title = mb_substr(trim((string)$title), 0, 180);
    $message = trim((string)$message);
    $category = preg_replace('/[^a-z_]/', '', strtolower((string)$category));
    if (!in_array($category, ['info','success','warning','danger','expiry','system'], true)) $category='info';
    if (!in_array($audience, ['admin','reseller','all'], true)) $audience='reseller';
    $urlSql = strlen($actionUrl) ? "'".ESC($actionUrl)."'" : "NULL";
    $dedupeSql = ($dedupeKey !== null && $dedupeKey !== '') ? "'".ESC(mb_substr($dedupeKey,0,191))."'" : "NULL";
    return $db->query("INSERT IGNORE INTO `cs_notifications` (`recipient_id`,`sender_id`,`audience`,`category`,`title`,`message`,`action_url`,`is_private`,`is_read`,`dedupe_key`,`created_at`) VALUES (".$recipientId.",".$senderId.",'".ESC($audience)."','".ESC($category)."','".ESC($title)."','".ESC($message)."',".$urlSql.",".intval($private).",0,".$dedupeSql.",".time().")");
}

function cs_notify_current_user_filter() {
    global $rPermissions, $rUserInfo;
    $uid = intval($rUserInfo['id']);
    if (!empty($rPermissions['is_admin'])) {
        return "((`recipient_id`={$uid}) OR (`recipient_id`=0 AND `audience` IN ('admin','all')))";
    }
    return "((`recipient_id`={$uid}) OR (`recipient_id`=0 AND `audience` IN ('reseller','all') AND `is_private`=0))";
}

function cs_notify_list($limit=12, $unreadOnly=false) {
    global $db;
    cs_notify_install();
    $where = cs_notify_current_user_filter();
    if ($unreadOnly) $where .= " AND `is_read`=0";
    $limit = max(1, min(100, intval($limit)));
    $result = $db->query("SELECT * FROM `cs_notifications` WHERE {$where} ORDER BY `created_at` DESC LIMIT {$limit}");
    $rows=[]; if ($result) while ($row=$result->fetch_assoc()) $rows[]=$row;
    return $rows;
}

function cs_notify_unread_count() {
    global $db;
    cs_notify_install();
    $result=$db->query("SELECT COUNT(*) AS c FROM `cs_notifications` WHERE ".cs_notify_current_user_filter()." AND `is_read`=0");
    $row=$result ? $result->fetch_assoc() : ['c'=>0];
    return intval($row['c'] ?? 0);
}

function cs_notify_mark_read($id=0) {
    global $db;
    cs_notify_install();
    $where=cs_notify_current_user_filter();
    if (intval($id)>0) $where .= " AND `id`=".intval($id);
    return $db->query("UPDATE `cs_notifications` SET `is_read`=1, `read_at`=".time()." WHERE {$where}");
}


function cs_notify_safe_system_message($row) {
    $id = intval(isset($row['id']) ? $row['id'] : 0);
    $dedupe = isset($row['dedupe_key']) ? (string)$row['dedupe_key'] : '';
    $title = isset($row['title']) ? (string)$row['title'] : '';
    $message = isset($row['message']) ? (string)$row['message'] : '';
    $isPanelError = (strpos($dedupe, 'panel_error:') === 0) || stripos($title, 'Erro privado do sistema') !== false || stripos($title, 'Erro interno do sistema') !== false;
    if (!$isPanelError) return $message;
    $errorId = $id;
    if (preg_match('/panel_error:(\d+)/', $dedupe, $m)) $errorId = intval($m[1]);
    $code = 'ERR-' . str_pad((string)$errorId, 6, '0', STR_PAD_LEFT);
    return 'Foi detectado um erro interno no sistema. Consulte Logs e erros do sistema para os detalhes técnicos. Código: ' . $code;
}

function cs_notify_generate_smart_alerts() {
    global $db, $rPermissions, $rUserInfo;
    cs_notify_install();
    $uid=intval($rUserInfo['id']); $now=time(); $until=$now+(7*86400);
    if (!empty($rPermissions['is_reseller'])) {
        $q=$db->query("SELECT `id`,`username`,`exp_date` FROM `users` WHERE `member_id`={$uid} AND `enabled`=1 AND `admin_enabled`=1 AND `exp_date` IS NOT NULL AND `exp_date` BETWEEN {$now} AND {$until} ORDER BY `exp_date` ASC LIMIT 100");
        if ($q) while ($u=$q->fetch_assoc()) {
            $days=max(0,(int)ceil((intval($u['exp_date'])-$now)/86400));
            cs_notify_send($uid,'Usuário próximo do vencimento','O usuário '.$u['username'].' vence em '.$days.' dia(s), em '.date('d/m/Y H:i',intval($u['exp_date'])).'.','expiry','users.php','reseller',0,'expiry:'.intval($u['id']).':'.date('Ymd',intval($u['exp_date'])),1);
        }
    }
    if (!empty($rPermissions['is_admin'])) {
        $since=$now-900;
        $q=$db->query("SELECT `id`,`log_message`,`date` FROM `panel_logs` WHERE `date` >= {$since} ORDER BY `id` DESC LIMIT 20");
        if ($q) while ($e=$q->fetch_assoc()) {
            $errorId = intval($e['id']);
            $safeMessage = 'Foi detectado um erro interno no sistema. Consulte Logs e erros do sistema para os detalhes técnicos. Código: ERR-' . str_pad((string)$errorId, 6, '0', STR_PAD_LEFT);
            cs_notify_send($uid,'Erro interno do sistema',$safeMessage,'danger','system_logs.php?source=panel&period=24h&severity=error','admin',0,'panel_error:'.$errorId,1);
        }
    }
}

function cs_notify_bootstrap_ui() {
    global $rPermissions;
    cs_notify_generate_smart_alerts();
    $count=cs_notify_unread_count();
    $items=cs_notify_list(6);
    ?>
    <link href="assets/css/cs-notifications.css" rel="stylesheet" type="text/css">
    <li class="dropdown notification-list cs-notification-bell">
      <a class="nav-link dropdown-toggle waves-effect text-white" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false" title="Central de mensagens">
        <i class="mdi mdi-bell-outline noti-icon"></i><span id="csNotifyBadge" class="badge badge-danger rounded-circle noti-icon-badge" style="<?=($count?'':'display:none')?>"><?=$count?></span>
      </a>
      <div class="dropdown-menu dropdown-menu-right dropdown-lg cs-notification-menu">
        <div class="dropdown-item noti-title"><h5 class="m-0">Mensagens <span class="float-right badge badge-primary" id="csNotifyCount"><?=$count?></span></h5></div>
        <div id="csNotifyItems" class="slimscroll noti-scroll">
          <?php foreach($items as $n): ?>
          <a href="<?=htmlspecialchars($n['action_url'] ?: 'notifications.php')?>" class="dropdown-item notify-item <?=(!$n['is_read']?'cs-unread':'')?>" data-notification-id="<?=intval($n['id'])?>">
            <div class="notify-icon cs-notify-<?=htmlspecialchars($n['category'])?>"><i class="mdi mdi-message-text-outline"></i></div>
            <p class="notify-details"><?=htmlspecialchars($n['title'])?><small class="text-muted"><?=htmlspecialchars(mb_strimwidth(strip_tags(cs_notify_safe_system_message($n)),0,85,'…'))?></small></p>
          </a><?php endforeach; ?>
        </div>
        <a href="notifications.php" class="dropdown-item text-center text-primary notify-item notify-all">Abrir central de mensagens <i class="fi-arrow-right"></i></a>
        <?php if (!empty($rPermissions['is_admin'])): ?><a href="notification_compose.php" class="dropdown-item text-center text-success">Enviar mensagem push</a><?php endif; ?>
      </div>
    </li>
    <script>window.CS_NOTIFY_ENDPOINT='notification_api.php';</script>
    <script src="assets/js/cs-notifications.js"></script>
    <?php
}

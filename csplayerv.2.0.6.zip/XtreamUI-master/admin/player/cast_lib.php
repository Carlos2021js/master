<?php
require_once __DIR__ . '/proxy_lib.php';
function cs_cast_cors(): void {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, HEAD, OPTIONS');
    header('Access-Control-Allow-Headers: Range, Content-Type');
    header('Access-Control-Expose-Headers: Content-Length, Content-Range, Accept-Ranges, Content-Type');
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }
}
function cs_cast_entry(string $token): ?array {
    if (!preg_match('/^[a-f0-9]{48}$/', $token)) return null;
    $file = __DIR__ . '/storage/cast/' . $token . '.json';
    if (!is_file($file)) return null;
    $data = json_decode((string)@file_get_contents($file), true);
    if (!is_array($data) || (int)($data['expires_at'] ?? 0) < time() || !hash_equals((string)($data['token'] ?? ''), $token)) {
        @unlink($file); return null;
    }
    return $data;
}
function cs_cast_b64e(string $value): string { return rtrim(strtr(base64_encode($value), '+/', '-_'), '='); }
function cs_cast_b64d(string $value) { $pad = strlen($value) % 4; if ($pad) $value .= str_repeat('=', 4-$pad); return base64_decode(strtr($value, '-_', '+/'), true); }
function cs_cast_segment_url(string $token, string $secret, string $url): string {
    $u = cs_cast_b64e($url); $sig = hash_hmac('sha256', $u, $secret);
    return 'cast_segment.php?token=' . rawurlencode($token) . '&u=' . rawurlencode($u) . '&sig=' . rawurlencode($sig);
}
function cs_cast_rewrite_manifest(string $body, string $base, string $token, string $secret): string {
    $lines = preg_split('/\r\n|\r|\n/', $body);
    foreach ($lines as &$line) {
        if ($line !== '' && $line[0] !== '#') {
            $line = cs_cast_segment_url($token, $secret, cs_abs_url($base, trim($line)));
        } elseif (strpos($line, 'URI="') !== false) {
            $line = preg_replace_callback('/URI="([^"]+)"/', function ($m) use ($base, $token, $secret) {
                return 'URI="' . cs_cast_segment_url($token, $secret, cs_abs_url($base, $m[1])) . '"';
            }, $line);
        }
    }
    return implode("\n", $lines);
}

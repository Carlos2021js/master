# CS Player Web Player

Web Player multi-DNS integrado ao CS Player sem alteração estrutural do banco.

- Configure os DNS em **Admin > Settings > Web Player Multi-DNS**.
- Login inteligente testa os DNS ativos pela prioridade e seleciona o primeiro que autenticar o usuário.
- Failover pode trocar para outro DNS quando a reprodução falhar, preservando o mesmo usuário/senha e stream ID.
- HLS usa proxy de manifesto/segmentos do próprio player para reduzir problemas de CORS.
- Filmes/episódios suportam proxy com Range.
- Preferências de favoritos/posição ficam no navegador do usuário.

<?php
require __DIR__ . '/bootstrap.php';
$_SESSION = [];
setcookie('cs_player_remember','',['expires'=>time()-3600,'path'=>dirname($_SERVER['SCRIPT_NAME'] ?? '/admin/player/') . '/','httponly'=>true,'samesite'=>'Lax']);
if (ini_get('session.use_cookies')) { $p=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']); }
session_destroy(); header('Location: index.php');

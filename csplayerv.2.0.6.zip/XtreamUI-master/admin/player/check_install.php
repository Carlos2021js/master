<?php
// CS Player - verificador de instalação compatível com PHP 7.4 a 8.4.
// Quando existir o PHP interno legado do servidor, ele é usado como referência de lint,
// mesmo que este script tenha sido iniciado pelo PHP do Ubuntu.

if (version_compare(PHP_VERSION, '7.4.0', '<')) {
    fwrite(STDERR, "PHP 7.4 ou superior e necessario para o Web Player.\n");
    exit(2);
}
if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Execute somente via CLI.\n");
    exit(2);
}

$root = dirname(__DIR__, 2);
$internalPhp = $root . '/php/bin/php';
$lintPhp = (is_file($internalPhp) && is_executable($internalPhp)) ? $internalPhp : PHP_BINARY;
$lintVersion = '';
$versionOut = [];
$versionCode = 0;
@exec(escapeshellarg($lintPhp) . ' -r ' . escapeshellarg('echo PHP_VERSION;') . ' 2>&1', $versionOut, $versionCode);
if ($versionCode === 0 && !empty($versionOut)) {
    $lintVersion = trim(implode('', $versionOut));
}
if ($lintVersion === '') {
    $lintVersion = PHP_VERSION;
}

$files = [];
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($it as $f) {
    if ($f->isFile() && strtolower($f->getExtension()) === 'php') {
        $files[] = $f->getPathname();
    }
}
sort($files);

$failed = 0;
$compatWarnings = 0;
echo "CS PLAYER - verificacao de instalacao\n";
echo "PHP do comando: " . PHP_VERSION . "\n";
echo "PHP usado no lint: " . $lintVersion . " (" . $lintPhp . ")\n";

foreach ($files as $f) {
    $out = [];
    $code = 0;
    $cmd = escapeshellarg($lintPhp) . ' -l ' . escapeshellarg($f) . ' 2>&1';
    @exec($cmd, $out, $code);
    if ($code !== 0) {
        $failed++;
        echo "FALHA: $f\n" . implode("\n", $out) . "\n";
    }
}

// Remove strings, comentarios e HTML antes da analise de compatibilidade para evitar falsos positivos.
function cs_player_php_code_only($src)
{
    if (!is_string($src)) return '';
    $tokens = token_get_all($src);
    $out = '';
    foreach ($tokens as $token) {
        if (!is_array($token)) { $out .= $token; continue; }
        $id = $token[0];
        if (in_array($id, [T_CONSTANT_ENCAPSED_STRING, T_ENCAPSED_AND_WHITESPACE, T_INLINE_HTML, T_COMMENT, T_DOC_COMMENT], true)) {
            $out .= ' ';
            continue;
        }
        $out .= $token[1];
    }
    return $out;
}

// Varredura adicional: construções que quebram no PHP 7.4 mesmo quando o lint
// foi executado acidentalmente por um PHP mais novo.
$playerDir = $root . '/admin/player';
$compatPatterns = [
    '/\\bmatch\\s*\\(/' => 'match() exige PHP 8+',
    '/\\?->/' => 'operador nullsafe exige PHP 8+',
    '/\\bstr_(?:contains|starts_with|ends_with)\\s*\\(/' => 'função nativa exige PHP 8+',
    '/^\\s*#\\[/' => 'atributos exigem PHP 8+',
    '/\\benum\\s+[A-Za-z_]/' => 'enum exige PHP 8.1+',
    '/\\breadonly\\s+(?:class|[A-Za-z_$])/' => 'readonly exige PHP 8.1+',
];
if (is_dir($playerDir)) {
    $pit = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($playerDir, FilesystemIterator::SKIP_DOTS));
    foreach ($pit as $f) {
        if (!$f->isFile() || strtolower($f->getExtension()) !== 'php') continue;
        if ($f->getFilename() === 'check_install.php') continue; // contém os próprios padrões como texto
        $src = @file_get_contents($f->getPathname());
        if (!is_string($src)) continue;
        $codeOnly = cs_player_php_code_only($src);
        foreach ($compatPatterns as $rx => $label) {
            if (preg_match($rx, $codeOnly)) {
                $compatWarnings++;
                echo "COMPAT PHP 7.4: " . $f->getPathname() . " - " . $label . "\n";
            }
        }
    }
}


// Arquivos de integração do Web Player fora de admin/player também precisam respeitar PHP 7.4.
$extraCompatFiles = [
    $root . '/admin/player_admin_api.php',
    $root . '/admin/settings.php',
];
foreach ($extraCompatFiles as $extraFile) {
    if (!is_file($extraFile)) continue;
    $src = @file_get_contents($extraFile);
    if (!is_string($src)) continue;
    $codeOnly = cs_player_php_code_only($src);
    foreach ($compatPatterns as $rx => $label) {
        if (preg_match($rx, $codeOnly)) {
            $compatWarnings++;
            echo "COMPAT PHP 7.4: " . $extraFile . " - " . $label . "\n";
        }
    }
}

$bootstrap = $root . '/admin/player/bootstrap.php';
$marker = 'CS_PLAYER_WEBPLAYER_BOOTSTRAP_VERSION: 6.7.0-logs-notifications-safe';
$bootstrapOk = false;
if (is_file($bootstrap)) {
    $head = @file_get_contents($bootstrap, false, null, 0, 512);
    $bootstrapOk = is_string($head) && strpos($head, $marker) !== false;
}
echo "Bootstrap esperado: 6.7.0-logs-notifications-safe\n";
echo "Bootstrap instalado: " . ($bootstrapOk ? 'OK' : 'DIFERENTE/ANTIGO') . "\n";
// Verifica a estrutura técnica usada pelo atualizador por comando.
$installerWarnings = 0;
$fsremake = $root . '/pytools/fsremake.py';
$installerNeedle = '/tmp/update/XtreamUI-master/*';
$installerOk = false;
if (is_file($fsremake)) {
    $fsSrc = @file_get_contents($fsremake);
    $installerOk = is_string($fsSrc) && strpos($fsSrc, $installerNeedle) !== false;
}
if (!$installerOk) {
    $installerWarnings++;
    echo "ESTRUTURA INSTALADOR: ALERTA - referência XtreamUI-master não encontrada em pytools/fsremake.py\n";
} else {
    echo "Estrutura instalador: XtreamUI-master preservada\n";
}

$criticalFiles = [
    $root . '/permissions.sh',
    $root . '/pytools/fsremake.py',
    $root . '/admin/player/bootstrap.php',
    $root . '/admin/player/api.php',
    $root . '/admin/settings.php',
];
foreach ($criticalFiles as $criticalFile) {
    if (!is_file($criticalFile)) {
        $installerWarnings++;
        echo "ARQUIVO CRITICO AUSENTE: $criticalFile\n";
    }
}

echo "Arquivos PHP: " . count($files) . " | Falhas: $failed | Alertas compat PHP 7.4: $compatWarnings | Alertas instalador: $installerWarnings\n";
exit(($failed || $compatWarnings || !$bootstrapOk || $installerWarnings) ? 1 : 0);

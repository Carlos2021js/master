<?php
require __DIR__ . '/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if (empty($_SESSION['cs_player_auth'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Sessão expirada.'], JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Método não permitido.'], JSON_UNESCAPED_UNICODE);
    exit;
}
$payload = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($payload)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'JSON inválido.'], JSON_UNESCAPED_UNICODE);
    exit;
}
$message = trim((string)($payload['message'] ?? 'Erro não especificado'));
$stack = trim((string)($payload['stack'] ?? ''));
$context = trim((string)($payload['context'] ?? ''));
cs_player_write_log('web_player_client_error', [
    'message' => substr($message, 0, 500),
    'stack' => substr($stack, 0, 2000),
    'context' => substr($context, 0, 160),
], 'error');
echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);

<?php
require __DIR__ . '/proxy_lib.php';
cs_player_require_login();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function cs_cast_json(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function cs_cast_storage_dir(): string {
    $dir = __DIR__ . '/storage/cast';
    if (!is_dir($dir)) { @mkdir($dir, 0750, true); }
    return $dir;
}
function cs_cast_gc(string $dir): void {
    foreach (glob($dir . '/*.json') ?: [] as $file) {
        if (@filemtime($file) < time() - 10800) { @unlink($file); }
    }
}

$type = strtolower((string)($_POST['type'] ?? ''));
$id = (int)($_POST['id'] ?? 0);
$ext = preg_replace('/[^a-zA-Z0-9]/', '', (string)($_POST['ext'] ?? ''));
$title = trim((string)($_POST['title'] ?? 'CS Player'));
$image = trim((string)($_POST['image'] ?? ''));
if (!in_array($type, ['live', 'movie', 'series'], true) || $id <= 0) {
    cs_cast_json(['ok' => false, 'message' => 'Mídia inválida para transmissão.'], 400);
}

$cfg = cs_player_load_config();
if (empty($cfg['proxy_enabled']) || empty($cfg['proxy_cast'])) {
    cs_cast_json(['ok' => false, 'message' => 'Transmissão para TV pelo proxy está desativada em Settings → Web Player.'], 409);
}
$row = cs_player_session_dns($cfg, null);
if (!$row) { cs_cast_json(['ok' => false, 'message' => 'Servidor indisponível.'], 503); }
$username = (string)($_SESSION['cs_player_username'] ?? '');
$password = (string)($_SESSION['cs_player_password'] ?? '');
$origin = '';
if (!empty($_SESSION['cs_player_local_api'])) {
    $origin = (string)(cs_player_local_stream_source($id, $username, $password) ?: '');
} else {
    $base = rtrim((string)$row['url'], '/');
    $u = rawurlencode($username); $p = rawurlencode($password);
    if ($type === 'live') $origin = "$base/live/$u/$p/$id.m3u8";
    elseif ($type === 'movie') $origin = "$base/movie/$u/$p/$id." . ($ext ?: 'mp4');
    else $origin = "$base/series/$u/$p/$id." . ($ext ?: 'mp4');
}
if ($origin === '') {
    cs_player_write_log('cast_origin_unavailable', ['stream_type' => $type, 'stream_id' => $id], 'error');
    cs_cast_json(['ok' => false, 'message' => 'Origem indisponível para transmissão.'], 404);
}

$dir = cs_cast_storage_dir(); cs_cast_gc($dir);
try { $token = bin2hex(random_bytes(24)); $secret = bin2hex(random_bytes(32)); }
catch (Throwable $e) { cs_cast_json(['ok' => false, 'message' => 'Não foi possível preparar a transmissão.'], 500); }
$payload = [
    'token' => $token, 'secret' => $secret, 'origin' => $origin, 'type' => $type,
    'id' => $id, 'ext' => $ext, 'title' => mb_substr($title ?: 'CS Player', 0, 180),
    'image' => filter_var($image, FILTER_VALIDATE_URL) ? $image : '',
    'created_at' => time(), 'expires_at' => time() + 7200,
    'user_id' => (int)($_SESSION['cs_player_user_id'] ?? 0),
];
$file = $dir . '/' . $token . '.json';
if (@file_put_contents($file, json_encode($payload, JSON_UNESCAPED_SLASHES), LOCK_EX) === false) {
    cs_cast_json(['ok' => false, 'message' => 'Armazenamento temporário indisponível.'], 500);
}
@chmod($file, 0640);
$url = 'cast_stream.php?token=' . rawurlencode($token);
cs_player_write_log('cast_token_created', ['stream_type' => $type, 'stream_id' => $id, 'expires_in' => 7200], 'info');
cs_cast_json(['ok' => true, 'url' => $url, 'expires_in' => 7200]);

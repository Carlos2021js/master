<?php
/**
 * CS PLAYER 2.0.5 - Motor Legacy Compat
 * Adaptador compatível com o fluxo simples do Web Player de referência.
 * Mantém o layout do CS PLAYER; reutiliza apenas a estratégia de comunicação.
 */

function cs_player_legacy_status_code(array $headers): int {
    foreach ($headers as $line) {
        if (preg_match('#^HTTP/\\S+\\s+(\\d{3})#i', (string)$line, $m)) return (int)$m[1];
    }
    return 0;
}

function cs_player_legacy_get(string $url, int $timeout = 10): array {
    $headers = "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36\\r\\n" .
               "Accept: application/json, text/plain, */*\\r\\n" .
               "Connection: close\\r\\n";
    $opts = array(
        'http'=>array('method'=>'GET','header'=>$headers,'timeout'=>$timeout,'ignore_errors'=>true,'follow_location'=>1,'max_redirects'=>5,'protocol_version'=>1.1),
        'ssl'=>array('verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true)
    );
    $ctx = stream_context_create($opts);
    $started = microtime(true);
    $body = @file_get_contents($url, false, $ctx);
    $respHeaders = isset($http_response_header) && is_array($http_response_header) ? $http_response_header : array();
    $code = cs_player_legacy_status_code($respHeaders);
    $decoded = is_string($body) ? json_decode($body, true) : null;
    return array(
        'ok'=>($code >= 200 && $code < 400 && is_array($decoded)),
        'http_code'=>$code,
        'data'=>is_array($decoded) ? $decoded : null,
        'bytes'=>is_string($body) ? strlen($body) : 0,
        'time_ms'=>(int)round((microtime(true)-$started)*1000),
        'headers'=>$respHeaders
    );
}

function cs_player_legacy_authenticate(array $dnsList, string $username, string $password): ?array {
    foreach ($dnsList as $row) {
        $base = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($base === '') continue;
        $target = rtrim($base, '/') . '/player_api.php?' . http_build_query(array('username'=>$username,'password'=>$password));
        $res = cs_player_legacy_get($target, 10);
        $payload = is_array($res['data'] ?? null) ? cs_player_normalize_auth_payload($res['data'], $username) : null;
        if (!empty($res['ok']) && cs_player_is_authenticated_response($payload)) {
            $row['url'] = $base;
            $row['api_endpoint'] = 'player_api.php';
            $row['provider_mode_selected'] = 'legacy_ref';
            $row['http_profile_selected'] = 'legacy_reference';
            cs_player_write_log('web_player_reference_engine_selected', array(
                'host'=>(string)(parse_url($base, PHP_URL_HOST) ?: ''),
                'port'=>(int)(parse_url($base, PHP_URL_PORT) ?: (stripos($base,'https://')===0?443:80)),
                'http_code'=>(int)$res['http_code'],
                'time_ms'=>(int)$res['time_ms'],
                'engine'=>'reference_file_get_contents'
            ), 'info');
            return array('row'=>$row,'data'=>$payload,'provider_mode'=>'legacy_ref','diagnostics'=>array());
        }
        cs_player_write_log('web_player_reference_engine_failed', array(
            'host'=>(string)(parse_url($base, PHP_URL_HOST) ?: ''),
            'port'=>(int)(parse_url($base, PHP_URL_PORT) ?: (stripos($base,'https://')===0?443:80)),
            'http_code'=>(int)($res['http_code'] ?? 0),
            'response_bytes'=>(int)($res['bytes'] ?? 0),
            'time_ms'=>(int)($res['time_ms'] ?? 0),
            'engine'=>'reference_file_get_contents'
        ), 'warning');
    }
    return null;
}

function cs_player_legacy_api_call(string $dns, string $username, string $password, string $action = '', array $extra = []): ?array {
    $params = array_merge(array('username'=>$username,'password'=>$password), $extra);
    if ($action !== '') $params['action'] = $action;
    $url = rtrim(cs_player_normalize_dns($dns), '/') . '/player_api.php?' . http_build_query($params);
    $res = cs_player_legacy_get($url, 20);
    return (!empty($res['ok']) && is_array($res['data'] ?? null)) ? $res['data'] : null;
}

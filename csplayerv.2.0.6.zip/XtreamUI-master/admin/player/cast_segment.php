<?php
require __DIR__ . '/cast_lib.php';
cs_cast_cors();
$token = (string)($_GET['token'] ?? ''); $entry = cs_cast_entry($token);
$u = (string)($_GET['u'] ?? ''); $sig = (string)($_GET['sig'] ?? '');
if (!$entry || $u === '' || !hash_equals(hash_hmac('sha256', $u, (string)$entry['secret']), $sig)) { http_response_code(403); exit; }
$url = cs_cast_b64d($u); if (!is_string($url) || !preg_match('~^https?://~i', $url)) { http_response_code(400); exit; }
if (preg_match('~\.m3u8(?:\?|$)~i', $url)) {
    [$code,$body,$ct,$effective] = cs_fetch_small($url); if ($code < 200 || $code >= 400) { http_response_code($code ?: 502); exit; }
    header('Content-Type: application/vnd.apple.mpegurl'); header('Cache-Control: no-store');
    echo cs_cast_rewrite_manifest($body, $effective ?: $url, $token, (string)$entry['secret']); exit;
}
header('Cache-Control: no-store'); cs_stream_binary($url);

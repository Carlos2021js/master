CS PLAYER - CONFIGURACAO PERSISTENTE DO WEB PLAYER

A configuracao editavel em admin/settings.php NAO deve ser distribuida neste diretorio.
Desde a v6.4.2 ela e salva em:
  admin/logs/cs-player/web-player-config.php

Na primeira execucao, configuracoes antigas de admin/player/storage/config.php ou config.json
sao migradas automaticamente. Isso evita perder DNS externos, destaques e proxy ao atualizar o projeto.

CS PLAYER 2.0.5 - Integração do Web Player funcional

- Layout/design do CS PLAYER preservado.
- Motor de autenticação do webplayer.zip funcional incorporado como legacy_ref.
- Ordem: reference engine -> JSON compat -> XC/API avançada -> M3U -> fallback banco local.
- Em sucesso, catálogo usa o mesmo engine e o mesmo DNS da autenticação.
- Nenhuma alteração de schema do banco.
- Logs: web_player_reference_engine_selected / web_player_reference_engine_failed.

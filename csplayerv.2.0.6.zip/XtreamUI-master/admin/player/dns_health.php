<?php
declare(strict_types=1);

if (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }

/** Estado de saúde dos DNS fora do banco. */
function cs_player_dns_health_key(array $row): string {
    $url = strtolower(rtrim(cs_player_normalize_dns((string)($row['url'] ?? '')), '/'));
    return substr(hash('sha256', $url), 0, 24);
}
function cs_player_load_dns_health(): array {
    if (!is_file(CS_PLAYER_DNS_HEALTH_FILE)) return [];
    try { $d = include CS_PLAYER_DNS_HEALTH_FILE; return is_array($d) ? $d : []; } catch (\Throwable $e) { return []; }
}
function cs_player_save_dns_health(array $data): bool {
    $dir=dirname(CS_PLAYER_DNS_HEALTH_FILE); if(!is_dir($dir) && !@mkdir($dir,0750,true) && !is_dir($dir)) return false;
    $tmp=CS_PLAYER_DNS_HEALTH_FILE.'.tmp';
    $php="<?php\nif (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }\nreturn ".var_export($data,true).";\n";
    if(@file_put_contents($tmp,$php,LOCK_EX)===false)return false; @chmod($tmp,0640); if(!@rename($tmp,CS_PLAYER_DNS_HEALTH_FILE)){@unlink($tmp);return false;} @chmod(CS_PLAYER_DNS_HEALTH_FILE,0640); return true;
}
function cs_player_record_dns_health(array $row, bool $ok, int $latencyMs = 0, string $kind = ''): void {
    $cfg=cs_player_load_config(); $all=cs_player_load_dns_health(); $key=cs_player_dns_health_key($row); $e=is_array($all[$key]??null)?$all[$key]:[]; $now=time();
    $e['host']=(string)(parse_url((string)($row['url']??''),PHP_URL_HOST)??''); $e['updated_at']=$now;
    if($latencyMs>0){$old=(int)($e['latency_ms']??0);$e['latency_ms']=$old>0?(int)round($old*0.7+$latencyMs*0.3):$latencyMs;}
    if($ok){$e['success_at']=$now;$e['consecutive_failures']=0;$e['cooldown_until']=0;$e['last_status']='ok';}
    elseif($kind==='auth_rejected'){$e['last_status']='auth_rejected';}
    else{$f=(int)($e['consecutive_failures']??0)+1;$e['consecutive_failures']=$f;$e['failure_at']=$now;$e['last_status']=$kind?:'failed';$threshold=max(1,min(5,(int)($cfg['dns_fail_threshold']??2)));if($f>=$threshold)$e['cooldown_until']=$now+max(15,min(600,(int)($cfg['dns_cooldown']??90)));}
    $all[$key]=$e; foreach($all as $k=>$v){if((int)($v['updated_at']??0)<$now-604800)unset($all[$k]);} cs_player_save_dns_health($all);
}
function cs_player_dns_health_score(array $row, array $cfg, array $health): int {
    $priority=max(1,(int)($row['priority']??100)); $key=cs_player_dns_health_key($row); $e=is_array($health[$key]??null)?$health[$key]:[];
    $score=$priority*100; if((int)($e['cooldown_until']??0)>time())$score+=100000; $score+=min(5000,(int)($e['consecutive_failures']??0)*900); $score+=min(2000,(int)($e['latency_ms']??0)/5);
    if(!empty($cfg['dns_prefer_last']) && (string)($_SESSION['cs_player_last_good_dns']??'')===(string)($row['id']??''))$score-=250; return (int)$score;
}
function cs_player_dns_health_public(array $row): array {
    $all=cs_player_load_dns_health(); $e=$all[cs_player_dns_health_key($row)]??[]; if(!is_array($e))$e=[]; return ['latency_ms'=>(int)($e['latency_ms']??0),'consecutive_failures'=>(int)($e['consecutive_failures']??0),'cooldown_until'=>(int)($e['cooldown_until']??0),'last_status'=>(string)($e['last_status']??'unknown'),'success_at'=>(int)($e['success_at']??0),'failure_at'=>(int)($e['failure_at']??0)];
}
function cs_player_curl_ipresolve(array $row): int {
    $m=strtolower(trim((string)($row['ip_mode']??'auto'))); if($m==='ipv4' && defined('CURL_IPRESOLVE_V4')) return CURL_IPRESOLVE_V4; if($m==='ipv6' && defined('CURL_IPRESOLVE_V6')) return CURL_IPRESOLVE_V6; return defined('CURL_IPRESOLVE_WHATEVER')?CURL_IPRESOLVE_WHATEVER:0;
}

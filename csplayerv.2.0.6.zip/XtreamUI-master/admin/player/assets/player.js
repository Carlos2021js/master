const PlayerUI = (() => {
  const themeKey = 'csplayer_theme';
  let data = { content: { live: [], movies: [], series: [] }, categories: {}, server: { name: 'DNS' } };
  let currentType = 'home';
  let currentItem = null;
  let hls = null;
  let stallTimer = null;
  let lastProgress = 0;
  let retries = 0;
  let recovering = false;
  let liveTsFallback = false;
  let recoverTimer = null;
  let heroItems = [];
  let heroIndex = 0;
  let heroTimer = null;
  let heroPausedUntil = 0;
  const tmdbCache = new Map();

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (match) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[match]));
  const imageOf = (item) => item?._highlight_image || item?.stream_icon || item?.cover || item?.cover_big || item?.movie_image || item?.backdrop_path?.[0] || '';
  const titleOf = (item) => item?.name || item?.title || item?.stream_display_name || 'Sem título';
  const typeOf = (item, type) => (type === 'mixed' || type === 'continue') ? (item?._type || 'movie') : type;
  const categoryIdOf = (item) => String(item?.category_id ?? item?.categoryId ?? '');
  const yearOf = (item) => {
    const value = String(item?.releaseDate || item?.release_date || item?.year || item?.added || '');
    const match = value.match(/(19|20)\d{2}/);
    return match ? Number(match[0]) : 0;
  };
  const dateScoreOf = (item) => {
    const value = item?.added || item?.last_modified || item?.releaseDate || item?.release_date || item?.year || 0;
    const numeric = Number(value);
    if (Number.isFinite(numeric) && numeric > 0) return numeric;
    const parsed = Date.parse(String(value));
    return Number.isFinite(parsed) ? parsed / 1000 : 0;
  };
  const newest = (items) => [...(Array.isArray(items) ? items : [])].sort((a, b) => (yearOf(b) - yearOf(a)) || (dateScoreOf(b) - dateScoreOf(a)) || titleOf(a).localeCompare(titleOf(b), 'pt-BR'));
  const currentYear = () => new Date().getFullYear();
  const normalizeCategoryName = (value) => String(value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  const categorySortKey = (category) => {
    const name = normalizeCategoryName(category?.category_name);
    const release = /\blancamentos?\b/.test(name);
    const yearMatch = name.match(/\b(19|20)\d{2}\b/);
    const year = yearMatch ? Number(yearMatch[0]) : 0;
    if (release) return [0, year ? -year : 0, name];
    if (/\b(novidades?|recentes?|mais recentes|novos?)\b/.test(name)) return [1, 0, name];
    return [2, 0, name];
  };
  const sortedCategories = (categories) => [...(Array.isArray(categories) ? categories : [])]
    .map((category, index) => ({ category, index, key: categorySortKey(category) }))
    .sort((a, b) => {
      for (let i = 0; i < 3; i += 1) {
        if (a.key[i] === b.key[i]) continue;
        if (typeof a.key[i] === 'string') return a.key[i].localeCompare(b.key[i], 'pt-BR');
        return a.key[i] - b.key[i];
      }
      return a.index - b.index;
    }).map((row) => row.category);
  const tmdbIdOf = (item) => Number(item?.tmdb_id || item?.info?.tmdb_id || 0) || 0;
  const hasText = (value) => typeof value === 'string' && value.trim().length > 0;
  const localOverviewOf = (item) => [item?._highlight_synopsis, item?.plot, item?.description, item?.overview].find(hasText) || '';
  const localBackdropOf = (item) => {
    const backdrop = Array.isArray(item?.backdrop_path) ? item.backdrop_path.find(hasText) : item?.backdrop_path;
    return hasText(backdrop) ? backdrop : '';
  };
  const localRatingOf = (item) => Number(item?.rating || item?.rating_5based || 0) || 0;

  const runtimeLabel = (minutes) => {
    const n = Number(minutes || 0); if (!n) return '';
    const h = Math.floor(n / 60), m = n % 60;
    return h ? `${h}h ${m ? `${m}min` : ''}`.trim() : `${m}min`;
  };
  async function tmdbMetadata(item, type) {
    if (!item || !['movie','series'].includes(type)) return null;
    const cacheKey = `${type}:${tmdbIdOf(item)}:${titleOf(item)}:${yearOf(item)}`;
    if (tmdbCache.has(cacheKey)) return tmdbCache.get(cacheKey);
    try {
      const qs = new URLSearchParams({ action:'tmdb_enrich', type, title:titleOf(item), year:String(yearOf(item)||0), tmdb_id:String(tmdbIdOf(item)||0) });
      const payload = await fetchJSON(`api.php?${qs.toString()}`);
      const meta = payload?.data || null;
      tmdbCache.set(cacheKey, meta);
      return meta;
    } catch (error) {
      tmdbCache.set(cacheKey, null);
      reportClientError(error, 'tmdb.enrich');
      return null;
    }
  }

  function safeRead(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch (error) { return fallback; }
  }


  function toast(message, tone = 'info', timeout = 2600) {
    const region = document.getElementById('toastRegion');
    if (!region || !message) return;
    const node = document.createElement('div');
    node.className = `player-toast ${tone}`;
    node.innerHTML = `<span>${tone === 'success' ? '✓' : tone === 'warning' ? '!' : tone === 'error' ? '×' : 'i'}</span><strong>${esc(message)}</strong>`;
    region.appendChild(node);
    requestAnimationFrame(() => node.classList.add('show'));
    setTimeout(() => { node.classList.remove('show'); setTimeout(() => node.remove(), 240); }, Math.max(1200, timeout));
  }

  function updateNetworkStatus() {
    const online = navigator.onLine !== false;
    const badge = document.getElementById('networkBadge');
    if (badge) {
      badge.textContent = online ? '● Online' : '● Offline';
      badge.classList.toggle('offline', !online);
    }
    document.body.classList.toggle('is-offline', !online);
    if (!online) toast('Sem conexão. O player tentará reconectar automaticamente.', 'warning', 4200);
  }

  function uniqueMixed(items) {
    const seen = new Set();
    return (Array.isArray(items) ? items : []).filter((entry) => {
      const item = entry?.item || entry;
      const type = entry?.type || item?._type || 'movie';
      const key = `${type}:${item?.stream_id || item?.series_id || item?.id || titleOf(item)}`;
      if (seen.has(key)) return false;
      seen.add(key); return true;
    });
  }

  function scoreOf(item) {
    const rating = Number(item?.rating || item?.rating_5based || 0) || 0;
    const year = yearOf(item) || 0;
    const freshness = Math.max(0, year - (currentYear() - 5));
    return rating * 100 + freshness * 8 + Math.min(20, dateScoreOf(item) / 1e9);
  }

  function topTenItems() {
    const mixed = [
      ...(data.content?.movies || []).map((item) => ({ ...item, _type: 'movie' })),
      ...(data.content?.series || []).map((item) => ({ ...item, _type: 'series' }))
    ];
    return uniqueMixed(mixed).sort((a, b) => scoreOf(b) - scoreOf(a)).slice(0, 10);
  }

  function allSearchItems() {
    return [
      ...(data.content?.live || []).map((item) => ({ ...item, _type: 'live' })),
      ...(data.content?.movies || []).map((item) => ({ ...item, _type: 'movie' })),
      ...(data.content?.series || []).map((item) => ({ ...item, _type: 'series' }))
    ];
  }

  function normalizeSearch(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  }

  function bindRailControls() {
    document.querySelectorAll('.rail').forEach((railNode) => {
      const track = railNode.querySelector('.rail-track');
      if (!track) return;
      railNode.querySelector('[data-rail-prev]')?.addEventListener('click', () => track.scrollBy({ left: -Math.max(280, track.clientWidth * .82), behavior: 'smooth' }));
      railNode.querySelector('[data-rail-next]')?.addEventListener('click', () => track.scrollBy({ left: Math.max(280, track.clientWidth * .82), behavior: 'smooth' }));
    });
  }

  function reportClientError(error, context = '') {
    try {
      const payload = JSON.stringify({
        message: String(error?.message || error || 'Erro não especificado'),
        stack: String(error?.stack || ''),
        context: String(context || '').slice(0, 160),
      });
      const blob = new Blob([payload], { type: 'application/json' });
      if (navigator.sendBeacon) {
        navigator.sendBeacon('client_error.php', blob);
      } else {
        fetch('client_error.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: payload, keepalive: true }).catch(() => {});
      }
    } catch (ignored) {}
  }

  window.addEventListener('error', (event) => reportClientError(event.error || event.message, 'window.error'));
  window.addEventListener('unhandledrejection', (event) => reportClientError(event.reason, 'unhandledrejection'));

  function themeFromStorage() {
    try {
      const stored = localStorage.getItem(themeKey);
      if (stored === 'light' || stored === 'dark') return stored;
    } catch (error) {}
    return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }

  function setTheme(theme) {
    const next = theme === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem(themeKey, next); } catch (error) {}
    const button = document.getElementById('themeToggle');
    if (button) {
      button.textContent = next === 'dark' ? '☀' : '☾';
      button.title = next === 'dark' ? 'Ativar modo claro' : 'Ativar modo escuro';
      button.setAttribute('aria-label', button.title);
      button.setAttribute('aria-pressed', String(next === 'dark'));
    }
  }

  function toggleTheme() {
    setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  }

  async function fetchJSON(url) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 35000);
    let response;
    try {
      response = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' }, signal: controller.signal });
    } catch (error) {
      reportClientError(error, `fetch:${url}`);
      if (error?.name === 'AbortError') throw new Error('O servidor demorou demais para responder. Tente novamente.');
      throw error;
    } finally {
      window.clearTimeout(timer);
    }
    let payload = {};
    try { payload = await response.json(); } catch (error) {}
    if (response.status === 401) {
      location.href = 'index.php';
      throw new Error('Sessão expirada.');
    }
    if (!response.ok || payload.ok === false) {
      throw new Error(payload.error || payload.message || `Falha na comunicação (${response.status}).`);
    }
    return payload;
  }

  function card(item, type, poster = false) {
    const cardType = typeOf(item, type);
    const id = item?.stream_id || item?.series_id || item?.id || 0;
    const image = imageOf(item);
    const progress = type === 'continue' && Number.isFinite(Number(item?._progress)) ? Math.max(0, Math.min(100, Number(item._progress))) : 0;
    const progressBar = progress > 0 ? `<span class="card-progress" aria-label="${Math.round(progress)}% assistido"><i style="width:${progress}%"></i></span>` : '';
    const badge = cardType === 'live' ? '<span class="card-badge live-badge">AO VIVO</span>' : (item?.rating ? `<span class="card-badge">★ ${esc(item.rating)}</span>` : '');
    const typeLabel = cardType === 'live' ? 'Canal' : cardType === 'series' ? 'Série' : 'Filme';
    return `<article class="media-card ${poster ? 'poster' : ''}" data-type="${esc(cardType)}" data-source="${type === 'mixed' ? (currentType === 'favorites' ? 'favorites' : 'mixed') : type === 'continue' ? 'continue' : esc(cardType)}" data-id="${esc(id)}" tabindex="0" role="button" aria-label="Abrir ${esc(titleOf(item))}">${image ? `<img loading="lazy" decoding="async" src="${esc(image)}" alt="" onerror="this.remove()">` : `<div class="fallback">${esc(titleOf(item))}</div>`}${badge}<div class="card-hover"><span class="card-play">▶</span><span class="card-title">${esc(titleOf(item))}</span><small>${[typeLabel, yearOf(item)||'', categoryNameOf(item,cardType)].filter(Boolean).map(esc).join(' · ')}</small></div><div class="caption">${esc(titleOf(item))}</div>${progressBar}</article>`;
  }

  function rail(title, items, type, poster = false) {
    if (!Array.isArray(items) || !items.length) return '';
    return `<section class="rail" data-type="${esc(type)}"><div class="rail-heading"><h2>${esc(title)}</h2><div class="rail-controls"><button type="button" data-rail-prev aria-label="Voltar">‹</button><button type="button" data-rail-next aria-label="Avançar">›</button></div></div><div class="rail-track ${poster ? 'poster-track' : ''}">${items.slice(0, 80).map((item) => card(item, type, poster)).join('')}</div></section>`;
  }

  function currentList(type) {
    if (type === 'live') return data.content.live || [];
    if (type === 'movie') return data.content.movies || [];
    if (type === 'series') return data.content.series || [];
    if (type === 'continue') return safeRead('csplayer_continue', []);
    return safeRead('csplayer_favorites', []);
  }

  function categoryRails(items, type, categories, poster) {
    if (!Array.isArray(categories)) return '';
    return sortedCategories(categories).slice(0, 16).map((category) => {
      const id = String(category?.category_id ?? '');
      const filtered = (Array.isArray(items) ? items : []).filter((item) => categoryIdOf(item) === id);
      return rail(category?.category_name || 'Categoria', newest(filtered), type, poster);
    }).join('');
  }

  function render() {
    const rails = document.getElementById('rails');
    if (!rails) return;
    let html = '';
    const live = newest(data.content.live);
    const movies = newest(data.content.movies);
    const series = newest(data.content.series);
    const year = currentYear();
    if (currentType === 'home') {
      const continueItems = safeRead('csplayer_continue', []).sort((a, b) => Number(b?._updatedAt || 0) - Number(a?._updatedAt || 0));
      const releases = movies.filter((item) => yearOf(item) === year);
      html += rail('Continue assistindo', continueItems, 'continue', true);
      html += rail(`Lançamentos ${year}`, releases.length ? releases : movies, 'movie', true);
      const top10 = topTenItems();
      if (top10.length) html += rail('Top 10 para você', top10, 'mixed', true).replace('class="rail-track poster-track"', 'class="rail-track poster-track top10-track"');
      html += rail('Canais ao vivo', live, 'live');
      html += categoryRails(live, 'live', data.categories?.live, false);
      html += categoryRails(movies, 'movie', data.categories?.movies, true);
      html += categoryRails(series, 'series', data.categories?.series, true);
    } else if (currentType === 'favorites') {
      const favorites = safeRead('csplayer_favorites', []);
      html = rail('Minha Lista', favorites, 'mixed', true) || '<div class="empty-state">Sua lista ainda está vazia.</div>';
    } else {
      const map = {
        live: ['Canais', live, 'live', false, data.categories?.live],
        movies: ['Filmes', movies, 'movie', true, data.categories?.movies],
        series: ['Séries', series, 'series', true, data.categories?.series]
      };
      const selected = map[currentType];
      if (selected) {
        if (currentType === 'movies' || currentType === 'series') {
          // Nas bibliotecas VOD, as categorias prioritárias aparecem antes da grade geral.
          // Ex.: Lançamentos 2026, Lançamentos 2025, Novidades, Ação...
          html += categoryRails(selected[1], selected[2], selected[4], selected[3]);
          html += rail(currentType === 'movies' ? 'Todos os filmes' : 'Todas as séries', selected[1], selected[2], selected[3]);
        } else {
          html += rail(selected[0], selected[1], selected[2], selected[3]);
          html += categoryRails(selected[1], selected[2], selected[4], selected[3]);
        }
      }
    }
    rails.innerHTML = html || '<div class="empty-state">Nenhum conteúdo disponível no momento.</div>';
    bindCards();
    bindRailControls();
    fillCategories();
  }

  function bindCards() {
    document.querySelectorAll('.media-card').forEach((element) => {
      const open = () => {
        const type = element.dataset.type;
        const source = element.dataset.source;
        const id = String(element.dataset.id);
        const list = source === 'favorites' ? safeRead('csplayer_favorites', []) : source === 'continue' ? safeRead('csplayer_continue', []) : source === 'mixed' ? allSearchItems() : currentList(type);
        const item = list.find((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === id);
        if (item) showInfo(item, typeOf(item, type));
      };
      element.addEventListener('click', open);
      element.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(); }
      });
    });
  }

  function fillCategories() {
    const select = document.getElementById('categoryFilter');
    if (!select) return;
    const key = currentType === 'movies' ? 'movies' : currentType === 'series' ? 'series' : 'live';
    const categories = currentType === 'favorites' ? [] : sortedCategories(data.categories?.[key] || []);
    select.disabled = !categories.length;
    select.innerHTML = '<option value="">Todas as categorias</option>' + categories.map((category) => `<option value="${esc(category.category_id)}">${esc(category.category_name)}</option>`).join('');
  }

  function categoryNameOf(item, type) {
    const key = type === 'movie' ? 'movies' : type === 'series' ? 'series' : 'live';
    const category = (data.categories?.[key] || []).find((entry) => String(entry?.category_id ?? '') === categoryIdOf(item));
    return category?.category_name || '';
  }

  function setHero(item, type) {
    if (!item) return;
    currentItem = { item, type: typeOf(item, type) };
    const normalizedType = currentItem.type;
    const title = document.getElementById('heroTitle');
    const meta = document.getElementById('heroMeta');
    const description = document.getElementById('heroDesc');
    const hero = document.getElementById('hero');
    if (title) title.textContent = titleOf(item);
    if (meta) meta.textContent = [normalizedType === 'live' ? 'Ao vivo' : normalizedType === 'movie' ? 'Filme' : 'Série', categoryNameOf(item, normalizedType), yearOf(item) || '', item.rating ? `★ ${item.rating}` : ''].filter(Boolean).join(' · ');
    if (description) description.textContent = localOverviewOf(item) || 'Sinopse não disponível.';
    const image = Array.isArray(item.backdrop_path) ? item.backdrop_path[0] : (item.backdrop_path || imageOf(item));
    if (hero && image) hero.style.backgroundImage = `url("${String(image).replace(/["\\]/g, '')}")`;
  }

  async function enrichHero(item, type) {
    const normalizedType = typeOf(item, type);
    if (!['movie','series'].includes(normalizedType)) return;
    const meta = await tmdbMetadata(item, normalizedType);
    if (!meta || !currentItem || String(currentItem.item?.stream_id || currentItem.item?.series_id || '') !== String(item?.stream_id || item?.series_id || '')) return;
    const hero = document.getElementById('hero');
    if (hero && !localBackdropOf(item) && !imageOf(item) && meta.backdrop) hero.style.backgroundImage = `url("${String(meta.backdrop).replace(/["\\]/g, '')}")`;
    const desc = document.getElementById('heroDesc'); if (desc && !localOverviewOf(item) && meta.overview) desc.textContent = meta.overview;
    const pieces = [normalizedType === 'movie' ? 'Filme' : 'Série', yearOf(item) || meta.year || '', categoryNameOf(item, normalizedType) || (meta.genres || []).slice(0,3).join(' · '), runtimeLabel(meta.runtime)].filter(Boolean);
    const metaEl = document.getElementById('heroMeta'); if (metaEl) metaEl.textContent = pieces.join(' · ');
    const score = document.getElementById('heroMatch'); if (score && !localRatingOf(item)) score.textContent = meta.rating ? `★ ${meta.rating}` : '';
    const eye = document.getElementById('heroEyebrow'); if (eye) eye.textContent = normalizedType === 'movie' ? 'FILME EM DESTAQUE' : 'SÉRIE EM DESTAQUE';
  }

  function stopHeroTimer() {
    if (heroTimer) { clearTimeout(heroTimer); heroTimer = null; }
    document.getElementById('heroProgress')?.classList.remove('running');
  }

  function heroIntervalMs() {
    return Math.max(4, Number(window.CS_PLAYER_CONFIG?.heroInterval || 8)) * 1000;
  }

  function restartHeroProgress() {
    const progress = document.getElementById('heroProgress');
    if (!progress) return;
    progress.classList.remove('running');
    void progress.offsetWidth;
    progress.style.setProperty('--hero-duration', `${heroIntervalMs() / 1000}s`);
    if (window.CS_PLAYER_CONFIG?.heroAutoplay !== false && heroItems.length > 1 && !document.hidden) progress.classList.add('running');
  }

  function scheduleHeroRotation(delayOverride = 0) {
    stopHeroTimer();
    if (window.CS_PLAYER_CONFIG?.heroAutoplay === false || heroItems.length < 2 || document.hidden) return;
    const now = Date.now();
    const pauseRemaining = Math.max(0, heroPausedUntil - now);
    const delay = Math.max(250, Number(delayOverride) || pauseRemaining || heroIntervalMs());
    if (!pauseRemaining) restartHeroProgress();
    heroTimer = setTimeout(() => {
      if (document.hidden) return;
      const remaining = Math.max(0, heroPausedUntil - Date.now());
      if (remaining > 0) { scheduleHeroRotation(remaining); return; }
      showHeroAt(heroIndex + 1, true);
    }, delay);
  }

  function renderHeroDots() {
    const dots = document.getElementById('heroDots');
    if (!dots) return;
    if (heroItems.length <= 1) { dots.innerHTML = ''; return; }
    const visible = Math.min(heroItems.length, 12);
    const start = Math.max(0, Math.min(heroIndex - Math.floor(visible / 2), heroItems.length - visible));
    dots.innerHTML = heroItems.slice(start, start + visible).map((_, localIndex) => {
      const index = start + localIndex;
      return `<button type="button" class="hero-dot ${index === heroIndex ? 'active' : ''}" data-hero-index="${index}" aria-label="Ir ao destaque ${index + 1}" title="${esc(titleOf(heroItems[index].item))}"></button>`;
    }).join('');
    dots.querySelectorAll('[data-hero-index]').forEach((button) => button.addEventListener('click', () => selectHeroManually(Number(button.dataset.heroIndex))));
  }

  function renderHeroSelector() {
    const list = document.getElementById('heroSelectorList');
    if (!list) return;
    list.innerHTML = heroItems.map((entry, index) => {
      const item = entry.item || {};
      const type = typeOf(item, entry.type);
      const label = type === 'live' ? 'Canal' : type === 'series' ? 'Série' : 'Filme';
      const image = imageOf(item);
      return `<button type="button" class="hero-selector-item ${index === heroIndex ? 'active' : ''}" data-hero-pick="${index}">${image ? `<img src="${esc(image)}" alt="" loading="lazy" onerror="this.remove()">` : '<span class="hero-selector-fallback">▶</span>'}<span><strong>${esc(titleOf(item))}</strong><small>${esc(label)} · Destaque ${index + 1}</small></span></button>`;
    }).join('') || '<div class="hero-selector-empty">Nenhum destaque disponível.</div>';
    list.querySelectorAll('[data-hero-pick]').forEach((button) => button.addEventListener('click', () => {
      selectHeroManually(Number(button.dataset.heroPick));
      closeHeroSelector();
    }));
  }

  function openHeroSelector() {
    const panel = document.getElementById('heroSelector');
    const button = document.getElementById('heroSelectorButton');
    renderHeroSelector();
    panel?.classList.remove('hidden');
    button?.setAttribute('aria-expanded', 'true');
  }

  function closeHeroSelector() {
    document.getElementById('heroSelector')?.classList.add('hidden');
    document.getElementById('heroSelectorButton')?.setAttribute('aria-expanded', 'false');
  }

  function selectHeroManually(index) {
    heroPausedUntil = Date.now() + 8000;
    showHeroAt(index, false);
    scheduleHeroRotation(Math.max(250, heroPausedUntil - Date.now()));
  }

  function showHeroAt(index, automatic = false) {
    if (!heroItems.length) return;
    heroIndex = (Number(index) + heroItems.length) % heroItems.length;
    const pick = heroItems[heroIndex];
    const hero = document.getElementById('hero');
    if (hero) hero.classList.add('hero-switching');
    window.setTimeout(() => {
      setHero(pick.item, pick.type);
      enrichHero(pick.item, pick.type);
      renderHeroDots();
      renderHeroSelector();
      if (hero) hero.classList.remove('hero-switching');
    }, automatic ? 140 : 60);
    if (automatic) scheduleHeroRotation();
  }

  function setupHeroCarousel(items) {
    stopHeroTimer();
    heroItems = Array.isArray(items) ? items.filter((entry) => entry?.item) : [];
    if (window.CS_PLAYER_CONFIG?.heroOrder === 'random' && heroItems.length > 1) {
      heroItems = [...heroItems].sort(() => Math.random() - 0.5);
    }
    heroIndex = 0;
    heroPausedUntil = 0;
    renderHeroDots();
    renderHeroSelector();
    if (heroItems.length) showHeroAt(0, false);
    document.getElementById('heroPrev')?.addEventListener('click', () => selectHeroManually(heroIndex - 1));
    document.getElementById('heroNext')?.addEventListener('click', () => selectHeroManually(heroIndex + 1));
    document.getElementById('heroSelectorButton')?.addEventListener('click', (event) => {
      event.preventDefault();
      const panel = document.getElementById('heroSelector');
      if (panel?.classList.contains('hidden')) openHeroSelector(); else closeHeroSelector();
    });
    document.getElementById('heroSelectorClose')?.addEventListener('click', closeHeroSelector);

    const hero = document.getElementById('hero');
    if (hero) {
      let touchX = null;
      hero.addEventListener('touchstart', (event) => { touchX = event.touches?.[0]?.clientX ?? null; }, { passive: true });
      hero.addEventListener('touchend', (event) => {
        if (touchX === null) return;
        const endX = event.changedTouches?.[0]?.clientX ?? touchX;
        const delta = endX - touchX;
        touchX = null;
        if (Math.abs(delta) >= 45) selectHeroManually(heroIndex + (delta < 0 ? 1 : -1));
      }, { passive: true });
    }
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) stopHeroTimer(); else scheduleHeroRotation();
    });
    document.addEventListener('click', (event) => {
      const panel = document.getElementById('heroSelector');
      const button = document.getElementById('heroSelectorButton');
      if (panel && button && !panel.classList.contains('hidden') && !panel.contains(event.target) && !button.contains(event.target)) closeHeroSelector();
    });
    scheduleHeroRotation();
  }

  async function showInfo(item, type) {
    const normalizedType = typeOf(item, type);
    setHero(item, normalizedType);
    enrichHero(item, normalizedType);
    const body = document.getElementById('infoBody');
    if (!body) return;
    const isFavorite = safeRead('csplayer_favorites', []).some((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === String(item?.stream_id || item?.series_id || item?.id));
    const initialImage = imageOf(item);
    body.innerHTML = `<div class="detail-hero" ${initialImage ? `style="background-image:url('${esc(initialImage)}')"` : ''}><div class="detail-gradient"></div><div class="detail-copy"><span class="eyebrow">${normalizedType === 'live' ? 'TV AO VIVO' : normalizedType === 'movie' ? 'FILME' : 'SÉRIE'}</span><h2>${esc(titleOf(item))}</h2><div class="detail-meta" id="detailMeta">${[yearOf(item)||'', item.rating ? `★ ${item.rating}` : '', categoryNameOf(item, normalizedType)].filter(Boolean).map(esc).join(' · ')}</div><p id="detailOverview">${esc(localOverviewOf(item) || 'Sinopse não disponível.')}</p><div class="hero-buttons"><button class="light-btn" id="infoPlay" type="button">▶ Assistir</button><button class="round-action" id="favoriteBtn" type="button" title="Minha Lista">${isFavorite ? '✓' : '＋'}</button><a class="round-action hidden" id="trailerBtn" target="_blank" rel="noopener" title="Trailer">▶</a></div><div class="detail-extra" id="detailExtra"></div></div></div>`;
    document.getElementById('infoModal')?.classList.remove('hidden');
    document.getElementById('infoPlay')?.addEventListener('click', () => play(item, normalizedType));
    document.getElementById('favoriteBtn')?.addEventListener('click', () => {
      const added = favorite(item, normalizedType);
      const button = document.getElementById('favoriteBtn'); if (button) button.textContent = added ? '✓' : '＋';
    });
    if (['movie','series'].includes(normalizedType)) {
      const meta = await tmdbMetadata(item, normalizedType);
      if (meta) {
        const heroNode = body.querySelector('.detail-hero'); if (heroNode && !initialImage && meta.backdrop) heroNode.style.backgroundImage = `url("${String(meta.backdrop).replace(/["\\]/g,'')}")`;
        const overview = document.getElementById('detailOverview'); if (overview && !localOverviewOf(item) && meta.overview) overview.textContent = meta.overview;
        const metaLine = document.getElementById('detailMeta'); if (metaLine) metaLine.textContent = [localRatingOf(item) ? `★ ${localRatingOf(item)}` : (meta.rating ? `★ ${meta.rating}` : ''), yearOf(item) || meta.year || '', runtimeLabel(meta.runtime), categoryNameOf(item, normalizedType) || (meta.genres || []).slice(0,3).join(' · ')].filter(Boolean).join(' · ');
        const extra = document.getElementById('detailExtra'); if (extra) extra.innerHTML = `${meta.cast?.length ? `<p><b>Elenco:</b> ${esc(meta.cast.join(', '))}</p>` : ''}${meta.tagline ? `<p class="tagline">${esc(meta.tagline)}</p>` : ''}`;
        const trailer = document.getElementById('trailerBtn'); if (trailer && meta.trailer) { trailer.href = meta.trailer; trailer.classList.remove('hidden'); }
      }
    }
  }

  function favorite(item, type) {
    const favorites = safeRead('csplayer_favorites', []);
    const id = String(item?.stream_id || item?.series_id || item?.id);
    const index = favorites.findIndex((entry) => String(entry?.stream_id || entry?.series_id || entry?.id) === id);
    if (index >= 0) { favorites.splice(index, 1); localStorage.setItem('csplayer_favorites', JSON.stringify(favorites)); toast('Removido da Minha Lista.', 'info'); return false; }
    favorites.push({ ...item, _type: type });
    localStorage.setItem('csplayer_favorites', JSON.stringify(favorites.slice(-100)));
    toast('Adicionado à Minha Lista.', 'success');
    return true;
  }

  async function play(item, type) {
    let normalizedType = typeOf(item, type);
    if (normalizedType === 'series') {
      const seriesInfo = await fetchJSON(`api.php?action=series_info&id=${encodeURIComponent(item.series_id)}`);
      const episodes = seriesInfo.data?.episodes || {};
      const seasons = Object.keys(episodes).sort((a, b) => Number(a) - Number(b));
      const first = seasons.length ? episodes[seasons[0]]?.[0] : null;
      if (!first) { setHealth('Nenhum episódio disponível.', false); return; }
      item = { ...first, stream_id: first.id || first.stream_id };
    }
    currentItem = { item, type: normalizedType };
    closeInfo();
    document.getElementById('playerModal')?.classList.remove('hidden');
    document.getElementById('playerTitle').textContent = titleOf(item);
    document.getElementById('playerStatus').textContent = data.server?.name || 'DNS';
    retries = 0;
    liveTsFallback = false;
    startStream();
  }

  function streamUrl() {
    const item = currentItem.item;
    const id = item.stream_id || item.id;
    const ext = item.container_extension || item.container || '';
    const format = currentItem.type === 'live' && liveTsFallback ? '&format=ts' : '';
    return `stream.php?type=${encodeURIComponent(currentItem.type)}&id=${encodeURIComponent(id)}&ext=${encodeURIComponent(ext)}${format}&v=${Date.now()}`;
  }

  function startStream() {
    const video = document.getElementById('video');
    if (!video || !currentItem) return;
    const url = streamUrl();
    destroyHls();
    setHealth('Conectando...', false);
    if (currentItem.type === 'live' && window.Hls && Hls.isSupported()) {
      hls = new Hls({ enableWorker: true, lowLatencyMode: true, backBufferLength: 30, maxBufferLength: 25, maxBufferHole: .6 });
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => { video.play().catch(() => {}); setHealth('Online', true); });
      hls.on(Hls.Events.ERROR, (_, error) => {
        if (!error.fatal) return;
        const code = Number(error?.response?.code || error?.networkDetails?.status || 0);
        if (currentItem?.type === 'live' && !liveTsFallback && (code === 404 || String(error?.details || '').includes('manifest'))) {
          liveTsFallback = true;
          recovering = false;
          setHealth('Tentando formato alternativo automaticamente…', false);
          setTimeout(startStream, 250);
          return;
        }
        recover();
      });
    } else {
      video.src = url;
      video.play().catch(() => {});
    }
    attachHealth();
    restorePosition();
  }

  function attachHealth() {
    const video = document.getElementById('video');
    if (!video) return;
    video.onplaying = () => { recovering = false; retries = 0; setHealth('Reproduzindo', true); updatePlayerControls(); };
    video.onwaiting = () => { setHealth('Bufferizando...', false); updatePlayerControls(); };
    video.onerror = () => recover();
    video.ontimeupdate = () => { lastProgress = Date.now(); savePosition(); updatePlayerControls(); };
    clearInterval(stallTimer);
    lastProgress = Date.now();
    stallTimer = setInterval(() => {
      const timeout = Number(window.CS_PLAYER_CONFIG?.stall || 12) * 1000;
      if (!video.paused && Date.now() - lastProgress > timeout) recover();
    }, 3000);
  }

  async function recover() {
    if (!currentItem || recovering) return;
    recovering = true;
    const limit = Math.max(1, Number(window.CS_PLAYER_CONFIG?.retries || 4));
    const video = document.getElementById('video');
    const position = Number(video?.currentTime || 0);
    if (retries < limit) {
      retries += 1;
      const delay = Math.min(8000, 650 * Math.pow(1.65, retries - 1));
      setHealth('Recuperando conexão automaticamente…', false);
      clearTimeout(recoverTimer);
      recoverTimer = setTimeout(() => {
        recovering = false;
        startStream();
        const target = document.getElementById('video');
        if (target && currentItem?.type !== 'live' && position > 1) {
          target.addEventListener('loadedmetadata', () => { try { target.currentTime = Math.min(position, Number.isFinite(target.duration) ? target.duration : position); } catch (error) {} }, { once: true });
        }
      }, delay);
      return;
    }
    if (window.CS_PLAYER_CONFIG?.failover) {
      setHealth('Alternando servidor automaticamente…', false);
      try {
        const response = await fetchJSON('api.php?action=failover');
        if (response.ok) {
          data.server.name = response.server;
          const badge = document.getElementById('serverBadge'); if (badge) badge.textContent = response.server;
          const status = document.getElementById('playerStatus'); if (status) status.textContent = response.server;
          retries = 0;
          recovering = false;
          startStream();
          return;
        }
      } catch (error) {}
    }
    recovering = false;
    retries = 0;
    reportClientError(new Error('Não foi possível recuperar o stream automaticamente.'), 'stream.recover');
    setHealth('Conexão interrompida. Tentando novamente em instantes…', false);
    clearTimeout(recoverTimer);
    recoverTimer = setTimeout(() => { if (currentItem) recover(); }, 10000);
  }

  function destroyHls() {
    if (hls) { hls.destroy(); hls = null; }
    const video = document.getElementById('video');
    if (video) { video.pause(); video.removeAttribute('src'); video.load(); }
  }

  function setHealth(text, online) {
    const label = document.getElementById('healthText');
    const dot = document.getElementById('healthDot');
    if (label) label.textContent = text;
    if (dot) { dot.style.background = online ? 'var(--success)' : 'var(--warning)'; dot.style.boxShadow = online ? '0 0 0 4px color-mix(in srgb, var(--success) 18%, transparent)' : '0 0 0 4px color-mix(in srgb, var(--warning) 18%, transparent)'; }
  }

  function formatMediaTime(value) {
    const seconds = Math.max(0, Math.floor(Number(value) || 0));
    const h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), s = seconds % 60;
    return h > 0 ? `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}` : `${m}:${String(s).padStart(2,'0')}`;
  }

  function updatePlayerControls() {
    const video = document.getElementById('video'); if (!video) return;
    const play = document.getElementById('playPauseBtn');
    const center = document.getElementById('centerPlayBtn');
    const mute = document.getElementById('muteBtn');
    const volume = document.getElementById('volumeBar');
    const seek = document.getElementById('seekBar');
    const time = document.getElementById('timeDisplay');
    const isPlaying = !video.paused && !video.ended;
    if (play) play.textContent = isPlaying ? '❚❚' : '▶';
    if (center) { center.classList.toggle('is-playing', isPlaying); center.querySelector('span').textContent = isPlaying ? '❚❚' : '▶'; }
    if (mute) mute.textContent = video.muted || video.volume === 0 ? '🔇' : (video.volume < .5 ? '🔉' : '🔊');
    if (volume) volume.value = video.muted ? 0 : video.volume;
    const duration = Number.isFinite(video.duration) ? video.duration : 0;
    if (seek) { seek.disabled = !duration || currentItem?.type === 'live'; seek.value = duration ? Math.round((video.currentTime / duration) * 1000) : 0; }
    if (time) time.textContent = currentItem?.type === 'live' ? 'AO VIVO' : `${formatMediaTime(video.currentTime)} / ${formatMediaTime(duration)}`;
  }

  function initYouTubePlayerControls() {
    const video = document.getElementById('video'); if (!video || video.dataset.ytReady === '1') return;
    video.dataset.ytReady = '1';
    const stage = document.getElementById('videoStage');
    const controls = document.getElementById('ytControls');
    const toggle = () => video.paused ? video.play().catch(()=>{}) : video.pause();
    document.getElementById('playPauseBtn')?.addEventListener('click', toggle);
    document.getElementById('centerPlayBtn')?.addEventListener('click', toggle);
    video.addEventListener('click', toggle);
    video.addEventListener('play', updatePlayerControls); video.addEventListener('pause', updatePlayerControls);
    video.addEventListener('loadedmetadata', updatePlayerControls); video.addEventListener('durationchange', updatePlayerControls);
    document.getElementById('seekBar')?.addEventListener('input', (event) => {
      if (currentItem?.type === 'live' || !Number.isFinite(video.duration) || video.duration <= 0) return;
      video.currentTime = (Number(event.target.value) / 1000) * video.duration; updatePlayerControls();
    });
    document.getElementById('volumeBar')?.addEventListener('input', (event) => { video.muted = false; video.volume = Math.max(0, Math.min(1, Number(event.target.value))); updatePlayerControls(); });
    document.getElementById('muteBtn')?.addEventListener('click', () => { video.muted = !video.muted; updatePlayerControls(); });
    document.getElementById('playerCloseBtn')?.addEventListener('click', closePlayer);
    document.getElementById('pipBtn')?.addEventListener('click', async () => { try { if (document.pictureInPictureElement) await document.exitPictureInPicture(); else if (document.pictureInPictureEnabled) await video.requestPictureInPicture(); } catch (error) {} });
    document.getElementById('fullscreenBtn')?.addEventListener('click', async () => { try { if (document.fullscreenElement) await document.exitFullscreen(); else if (stage?.requestFullscreen) await stage.requestFullscreen(); } catch (error) {} });
    const settings = document.getElementById('playerSettings');
    document.getElementById('settingsBtn')?.addEventListener('click', (event) => { event.stopPropagation(); settings?.classList.toggle('hidden'); });
    settings?.querySelectorAll('[data-speed]').forEach((button) => button.addEventListener('click', () => { video.playbackRate = Number(button.dataset.speed || 1); settings.classList.add('hidden'); toast(`Velocidade ${video.playbackRate}x`, 'success'); }));
    let hideTimer = null;
    const showControls = () => { stage?.classList.add('controls-visible'); clearTimeout(hideTimer); if (!video.paused) hideTimer = setTimeout(() => stage?.classList.remove('controls-visible'), 2800); };
    ['mousemove','touchstart','pointerdown'].forEach((name) => stage?.addEventListener(name, showControls, {passive:true}));
    controls?.addEventListener('pointerdown', (event) => event.stopPropagation());
    video.addEventListener('pause', () => stage?.classList.add('controls-visible'));
    video.addEventListener('play', showControls);
    stage?.classList.add('controls-visible');
    document.addEventListener('keydown', (event) => {
      if (document.getElementById('playerModal')?.classList.contains('hidden')) return;
      if (['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) return;
      if (event.code === 'Space') { event.preventDefault(); toggle(); }
      if (event.key === 'ArrowRight' && currentItem?.type !== 'live') video.currentTime = Math.min(video.duration || Infinity, video.currentTime + 10);
      if (event.key === 'ArrowLeft' && currentItem?.type !== 'live') video.currentTime = Math.max(0, video.currentTime - 10);
      if (event.key.toLowerCase() === 'm') { video.muted = !video.muted; updatePlayerControls(); }
      if (event.key.toLowerCase() === 'f') document.getElementById('fullscreenBtn')?.click();
    });
    updatePlayerControls();
  }

  function setAppLoading(active, title = 'Carregando seu conteúdo...', text = 'Conectando ao servidor e organizando canais, filmes e séries.') {
    const overlay = document.getElementById('appLoading');
    if (!overlay) return;
    overlay.classList.toggle('hidden', !active);
    overlay.setAttribute('aria-hidden', active ? 'false' : 'true');
    const titleNode = document.getElementById('appLoadingTitle');
    const textNode = document.getElementById('appLoadingText');
    if (titleNode) titleNode.textContent = title;
    if (textNode) textNode.textContent = text;
    document.body.classList.toggle('is-loading', active);
  }

  function closePlayer() { savePosition(); destroyHls(); clearInterval(stallTimer); clearTimeout(recoverTimer); recovering = false; document.getElementById('playerModal')?.classList.add('hidden'); }
  function closeInfo() { document.getElementById('infoModal')?.classList.add('hidden'); }
  function retry() { retries = 0; startStream(); }
  function keyForPos() { if (!currentItem) return ''; const item = currentItem.item; return `cspos:${currentItem.type}:${item.stream_id || item.id || item.series_id}`; }
  function rememberContinue(position = 0, duration = 0) {
    if (!window.CS_PLAYER_CONFIG?.remember || !currentItem || currentItem.type === 'live') return;
    const safeDuration = Number(duration || 0);
    const item = { ...currentItem.item, _type: currentItem.type, _position: Number(position || 0), _progress: safeDuration > 0 ? Math.max(0, Math.min(100, Number(position || 0) / safeDuration * 100)) : Number(currentItem.item?._progress || 0), _updatedAt: Date.now() };
    const key = String(item.stream_id || item.id || item.series_id || '');
    if (!key) return;
    const items = safeRead('csplayer_continue', []).filter((entry) => String(entry?.stream_id || entry?.id || entry?.series_id || '') !== key);
    items.unshift(item);
    try { localStorage.setItem('csplayer_continue', JSON.stringify(items.slice(0, 30))); } catch (error) {}
  }
  function savePosition() {
    if (!window.CS_PLAYER_CONFIG?.remember || !currentItem || currentItem.type === 'live') return;
    const video = document.getElementById('video');
    if (video?.currentTime > 10) {
      try { localStorage.setItem(keyForPos(), String(video.currentTime)); } catch (error) {}
      rememberContinue(video.currentTime, video.duration);
    }
  }
  function restorePosition() {
    if (!window.CS_PLAYER_CONFIG?.remember || currentItem?.type === 'live') return;
    const savedItem = safeRead('csplayer_continue', []).find((entry) => String(entry?.stream_id || entry?.id || entry?.series_id || '') === String(currentItem.item?.stream_id || currentItem.item?.id || currentItem.item?.series_id || ''));
    const position = Number(localStorage.getItem(keyForPos()) || savedItem?._position || 0);
    if (position > 10) document.getElementById('video')?.addEventListener('loadedmetadata', () => { try { document.getElementById('video').currentTime = position; } catch (error) {} }, { once: true });
  }

  function search(query) {
    const normalized = normalizeSearch(query);
    const clear = document.getElementById('clearSearch');
    clear?.classList.toggle('hidden', !normalized);
    if (!normalized) { render(); return; }
    const tokens = normalized.split(' ').filter(Boolean);
    const results = allSearchItems().map((item) => {
      const type = item._type || 'movie';
      const haystack = normalizeSearch([titleOf(item), categoryNameOf(item, type), item?.genre, item?.plot, item?.description].filter(Boolean).join(' '));
      const exact = haystack.includes(normalized) ? 100 : 0;
      const matched = tokens.reduce((sum, token) => sum + (haystack.includes(token) ? 15 : 0), 0);
      return { item, score: exact + matched + scoreOf(item) / 200 };
    }).filter((entry) => entry.score > 0).sort((a, b) => b.score - a.score).slice(0, 120).map((entry) => entry.item);
    const rails = document.getElementById('rails');
    if (!rails) return;
    rails.innerHTML = results.length ? rail(`Resultados para “${query.trim()}”`, results, 'mixed', true) : `<div class="empty-state search-empty"><strong>Nenhum resultado encontrado</strong><span>Tente outro título, categoria ou gênero.</span></div>`;
    bindCards(); bindRailControls();
  }

  function surpriseMe() {
    const pool = uniqueMixed([
      ...(data.content?.movies || []).map((item) => ({ ...item, _type: 'movie' })),
      ...(data.content?.series || []).map((item) => ({ ...item, _type: 'series' }))
    ]);
    if (!pool.length) { toast('Nenhum filme ou série disponível.', 'warning'); return; }
    const pick = pool[Math.floor(Math.random() * pool.length)];
    showInfo(pick, pick._type || 'movie');
    toast(`Sugestão: ${titleOf(pick)}`, 'success');
  }

  function quickFilter(key) {
    if (key === 'releases') {
      currentType = 'movies';
      document.querySelectorAll('[data-view]').forEach((el) => el.classList.toggle('active', el.dataset.view === 'movies'));
      render();
      const category = sortedCategories(data.categories?.movies || []).find((cat) => /lancamentos?/i.test(normalizeCategoryName(cat?.category_name)));
      if (category) { const select = document.getElementById('categoryFilter'); if (select) { select.value = String(category.category_id); select.dispatchEvent(new Event('change')); } }
      return;
    }
    const map = { live: 'live', movies: 'movies', series: 'series', favorites: 'favorites' };
    if (map[key]) {
      currentType = map[key];
      document.querySelectorAll('[data-view]').forEach((el) => el.classList.toggle('active', el.dataset.view === currentType));
      render(); window.scrollTo({ top: Math.max(0, document.getElementById('rails')?.offsetTop - 90 || 0), behavior: 'smooth' });
    }
  }

  async function filterCategory(event) {
    const id = event.target.value;
    if (!id) { render(); return; }
    const type = currentType === 'movies' ? 'movies' : currentType === 'series' ? 'series' : 'live';
    setAppLoading(true, 'Atualizando conteúdo...', 'Buscando os itens desta categoria.');
    try {
      const response = await fetchJSON(`api.php?action=category&type=${type}&category_id=${encodeURIComponent(id)}`);
      data.content[type] = response.data || [];
      render();
    } catch (error) { setHealth(error.message, false); }
    finally { setAppLoading(false); }
  }

  function focusSearch() { document.getElementById('globalSearch')?.focus(); }



  // Google Cast / Remote Playback — CS Player v6.3.5
  let castReady = false;
  let castContext = null;
  let castSession = null;
  let castRemotePlayer = null;
  let castRemoteController = null;

  function castButtonState(state, text = '') {
    const button = document.getElementById('castBtn');
    const status = document.getElementById('castStatus');
    if (!button) return;
    button.classList.toggle('cast-connected', state === 'connected');
    button.classList.toggle('cast-unavailable', state === 'unavailable');
    button.setAttribute('aria-pressed', state === 'connected' ? 'true' : 'false');
    button.title = state === 'connected' ? 'Transmitindo para TV' : 'Transmitir para TV';
    if (status) {
      status.textContent = text || (state === 'connected' ? 'Transmitindo para TV' : '');
      status.classList.toggle('hidden', !(text || state === 'connected'));
    }
  }

  function initCastFramework() {
    if (!window.cast?.framework || !window.chrome?.cast) return false;
    try {
      castContext = cast.framework.CastContext.getInstance();
      castContext.setOptions({
        receiverApplicationId: chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID,
        autoJoinPolicy: chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED
      });
      castRemotePlayer = new cast.framework.RemotePlayer();
      castRemoteController = new cast.framework.RemotePlayerController(castRemotePlayer);
      castContext.addEventListener(cast.framework.CastContextEventType.SESSION_STATE_CHANGED, (event) => {
        const connected = [cast.framework.SessionState.SESSION_STARTED, cast.framework.SessionState.SESSION_RESUMED].includes(event.sessionState);
        castSession = connected ? castContext.getCurrentSession() : null;
        castButtonState(connected ? 'connected' : 'ready', connected ? `Transmitindo para ${castSession?.getCastDevice?.().friendlyName || 'TV'}` : '');
        if (!connected && document.getElementById('video')) {
          const saved = castRemotePlayer?.savedPlayerState;
          if (saved && Number(saved.currentTime) > 0 && !currentItem?.type?.includes('live')) {
            try { document.getElementById('video').currentTime = Number(saved.currentTime); } catch (error) {}
          }
        }
      });
      castReady = true;
      castButtonState('ready');
      return true;
    } catch (error) {
      reportClientError(error, 'cast.init');
      castButtonState('unavailable');
      return false;
    }
  }

  function castContentType(item, type) {
    const ext = String(item?.container_extension || item?.container || '').toLowerCase();
    if (type === 'live' || ext === 'm3u8') return 'application/x-mpegURL';
    if (ext === 'webm') return 'video/webm';
    if (ext === 'mkv') return 'video/x-matroska';
    if (ext === 'ts') return 'video/mp2t';
    return 'video/mp4';
  }

  async function createCastMediaUrl() {
    if (!currentItem) throw new Error('Abra um canal, filme ou episódio antes de transmitir.');
    const item = currentItem.item || {};
    const body = new URLSearchParams({
      type: currentItem.type,
      id: String(item.stream_id || item.id || ''),
      ext: String(item.container_extension || item.container || ''),
      title: titleOf(item),
      image: imageOf(item) || ''
    });
    const response = await fetch('cast_token.php', { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body: body.toString(), credentials: 'same-origin' });
    const json = await response.json().catch(() => ({}));
    if (!response.ok || !json.ok || !json.url) throw new Error(json.message || 'Não foi possível preparar a transmissão.');
    return new URL(json.url, window.location.href).href;
  }

  async function loadCurrentOnCast() {
    castSession = castContext?.getCurrentSession?.();
    if (!castSession) throw new Error('Nenhuma TV conectada.');
    const url = await createCastMediaUrl();
    const item = currentItem.item || {};
    const mediaInfo = new chrome.cast.media.MediaInfo(url, castContentType(item, currentItem.type));
    const metadata = new chrome.cast.media.GenericMediaMetadata();
    metadata.title = titleOf(item);
    metadata.subtitle = currentItem.type === 'live' ? 'Ao vivo · CS Player' : 'CS Player';
    const image = imageOf(item);
    if (image) metadata.images = [new chrome.cast.Image(image)];
    mediaInfo.metadata = metadata;
    mediaInfo.streamType = currentItem.type === 'live' ? chrome.cast.media.StreamType.LIVE : chrome.cast.media.StreamType.BUFFERED;
    const request = new chrome.cast.media.LoadRequest(mediaInfo);
    const video = document.getElementById('video');
    if (currentItem.type !== 'live' && video && Number(video.currentTime) > 0) request.currentTime = Number(video.currentTime);
    request.autoplay = true;
    await castSession.loadMedia(request);
    if (video) video.pause();
    castButtonState('connected', `Transmitindo para ${castSession.getCastDevice?.().friendlyName || 'TV'}`);
    toast('Transmissão iniciada na TV.', 'success');
  }

  async function castToTV() {
    if (!currentItem) { toast('Abra um canal, filme ou episódio primeiro.', 'warning'); return; }
    if (!window.isSecureContext && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
      // O Web Sender do Google Cast é projetado para páginas HTTPS. O fallback Remote Playback ainda pode existir em alguns navegadores.
      const video = document.getElementById('video');
      if (video?.remote?.prompt) {
        try { await video.remote.prompt(); return; } catch (error) {}
      }
      toast('Para transmitir como no YouTube, abra o Web Player por HTTPS.', 'warning');
      return;
    }
    if (!castReady && !initCastFramework()) {
      const video = document.getElementById('video');
      if (video?.remote?.prompt) {
        try { await video.remote.prompt(); return; } catch (error) {}
      }
      toast('Google Cast não está disponível neste navegador.', 'warning');
      return;
    }
    try {
      if (!castContext.getCurrentSession()) await castContext.requestSession();
      await loadCurrentOnCast();
    } catch (error) {
      if (String(error).includes('cancel')) return;
      reportClientError(error, 'cast.start');
      toast(error?.message || 'Não foi possível transmitir para a TV.', 'warning');
    }
  }

  async function init() {
    setTheme(document.documentElement.dataset.theme || themeFromStorage());
    document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
    const rails = document.getElementById('rails');
    if (rails) rails.innerHTML = '<div class="skeleton"></div><div class="skeleton"></div>';
    setAppLoading(true);
    try {
      const requestStarted = (window.performance && performance.now) ? performance.now() : Date.now();
      data = await fetchJSON('api.php?action=home');
      data.content = data.content || { live: [], movies: [], series: [] };
      data.content.live = newest(data.content.live);
      data.content.movies = newest(data.content.movies);
      data.content.series = newest(data.content.series);
      const requestLatency = Math.max(0, Math.round(((window.performance && performance.now) ? performance.now() : Date.now()) - requestStarted));
      const server = data.server?.name || 'DNS';
      const dnsSource = data.server?.dns_source || 'automático';
      const totalContent = ['live', 'movies', 'series'].reduce((total, key) => total + (Array.isArray(data.content?.[key]) ? data.content[key].length : 0), 0);
      const serverBadge = document.getElementById('serverBadge');
      if (serverBadge) {
        serverBadge.textContent = `${server} · ${totalContent} itens · ${requestLatency}ms`;
        serverBadge.title = `Servidor: ${server}. Origem DNS: ${dnsSource}. Conteúdo recebido: ${totalContent}. Latência: ${requestLatency} ms.`;
      }
      const manual = (Array.isArray(data.manual_highlights) ? data.manual_highlights : []).filter((item) => item && item._manual_highlight !== false);
      const manualHeroItems = manual.map((item) => ({ item, type: item._type || 'movie' }));
      const automaticHeroItems = [...(data.content?.movies || []).slice(0,12).map(item=>({item,type:'movie'})), ...(data.content?.series || []).slice(0,12).map(item=>({item,type:'series'})), ...(data.content?.live || []).slice(0,4).map(item=>({item,type:'live'}))];
      setupHeroCarousel(manualHeroItems.length ? manualHeroItems : automaticHeroItems);
      document.getElementById('heroPlay')?.addEventListener('click', () => currentItem && play(currentItem.item, currentItem.type));
      document.getElementById('heroInfo')?.addEventListener('click', () => currentItem && showInfo(currentItem.item, currentItem.type));
      render();
      setAppLoading(false);
      document.querySelectorAll('[data-view]').forEach((button) => button.addEventListener('click', () => {
        currentType = button.dataset.view;
        document.querySelectorAll('[data-view]').forEach((element) => element.classList.toggle('active', element.dataset.view === currentType));
        render();
      }));
      document.getElementById('globalSearch')?.addEventListener('input', (event) => search(event.target.value));
      document.getElementById('clearSearch')?.addEventListener('click', () => { const input = document.getElementById('globalSearch'); if (input) { input.value = ''; input.focus(); search(''); } });
      document.getElementById('categoryFilter')?.addEventListener('change', filterCategory);
      document.getElementById('surpriseBtn')?.addEventListener('click', surpriseMe);
      document.querySelectorAll('[data-quick]').forEach((button) => button.addEventListener('click', () => quickFilter(button.dataset.quick)));
      document.getElementById('castBtn')?.addEventListener('click', castToTV);
      window.addEventListener('csplayer:cast-api', (event) => { if (event.detail?.available) initCastFramework(); else castButtonState('unavailable'); });
      if (window.cast?.framework && window.chrome?.cast) initCastFramework();
      initYouTubePlayerControls();
      updateNetworkStatus();
      window.addEventListener('online', () => { updateNetworkStatus(); toast('Conexão restabelecida.', 'success'); });
      window.addEventListener('offline', updateNetworkStatus);
      document.addEventListener('keydown', (event) => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); focusSearch(); } if (event.key === 'Escape') { closeHeroSelector(); closeInfo(); } });
      window.addEventListener('beforeunload', savePosition);
    } catch (error) {
      reportClientError(error, 'home.init');
      setAppLoading(false, 'Não foi possível carregar', error.message || 'Verifique a conexão e tente novamente.');
      if (rails) rails.innerHTML = `<div class="empty-state">${esc(error.message || 'Não foi possível carregar o conteúdo.')}</div>`;
    }
  }

  function showFavorites(){ currentType='favorites'; document.querySelectorAll('[data-view]').forEach((element)=>element.classList.toggle('active',element.dataset.view==='favorites')); render(); document.getElementById('profileMenu')?.classList.add('hidden'); }
  function toggleThemeFromMenu(){ toggleTheme(); document.getElementById('profileMenu')?.classList.add('hidden'); }
  document.addEventListener('click',(event)=>{const btn=document.getElementById('profileMenuButton'),menu=document.getElementById('profileMenu');if(!btn||!menu)return;if(btn.contains(event.target)){event.preventDefault();menu.classList.toggle('hidden');btn.setAttribute('aria-expanded',String(!menu.classList.contains('hidden')));return;}if(!menu.contains(event.target)){menu.classList.add('hidden');btn.setAttribute('aria-expanded','false');}});
  return { init, showInfo, play, closePlayer, closeInfo, retry, focusSearch, toggleTheme, showFavorites, toggleThemeFromMenu };
})();
document.addEventListener('DOMContentLoaded', PlayerUI.init);

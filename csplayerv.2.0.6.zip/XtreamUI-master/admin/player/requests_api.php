<?php
require __DIR__ . '/bootstrap.php';
cs_player_require_login();
header('Content-Type: application/json; charset=utf-8');

function cs_wp_request_json(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function cs_wp_request_user(): ?array {
    return cs_player_local_user((string)($_SESSION['cs_player_username'] ?? ''), (string)($_SESSION['cs_player_password'] ?? ''));
}
function cs_wp_request_map_file(): string { return __DIR__ . '/storage/webplayer_ticket_links.php'; }
function cs_wp_request_load_map(): array {
    $file = cs_wp_request_map_file();
    if (!is_file($file)) return [];
    $data = @include $file;
    return is_array($data) ? $data : [];
}
function cs_wp_request_save_map(array $map): bool {
    $file = cs_wp_request_map_file(); $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    $payload = "<?php\n// CS Player: vínculo interno entre clientes do Web Player e tickets existentes.\nreturn " . var_export($map, true) . ";\n";
    return @file_put_contents($file, $payload, LOCK_EX) !== false;
}
function cs_wp_request_owner_id(mysqli $db, array $user): int {
    $owner = (int)($user['member_id'] ?? 0);
    if ($owner > 0) {
        $stmt = $db->prepare('SELECT `id` FROM `reg_users` WHERE `id`=? LIMIT 1');
        if ($stmt) { $stmt->bind_param('i', $owner); $stmt->execute(); $r=$stmt->get_result(); $ok=$r&&$r->num_rows>0; $stmt->close(); if ($ok) return $owner; }
    }
    $r = @$db->query('SELECT `id` FROM `reg_users` ORDER BY `owner_id` ASC, `id` ASC LIMIT 1');
    if ($r && ($row=$r->fetch_assoc())) return (int)$row['id'];
    return 0;
}
function cs_wp_request_allowed_ids(int $uid): array {
    $map = cs_wp_request_load_map(); $ids=[];
    foreach ($map as $ticketId=>$row) {
        if (is_array($row) && (int)($row['client_id'] ?? 0) === $uid) $ids[(int)$ticketId]=true;
    }
    return $ids;
}
function cs_wp_request_status(array $ticket): array {
    $status=(int)($ticket['status']??0); $adminRead=(int)($ticket['admin_read']??0); $userRead=(int)($ticket['user_read']??1);
    if ($status===0) return ['key'=>'closed','label'=>'Fechado'];
    if ($userRead===0) return ['key'=>'answered','label'=>'Respondido'];
    if ($adminRead===1) return ['key'=>'read','label'=>'Em análise'];
    return ['key'=>'open','label'=>'Aberto'];
}
function cs_wp_request_ticket(mysqli $db, int $ticketId, int $uid): ?array {
    $allowed=cs_wp_request_allowed_ids($uid); if (empty($allowed[$ticketId])) return null;
    $stmt=$db->prepare('SELECT `id`,`member_id`,`title`,`status`,`admin_read`,`user_read` FROM `tickets` WHERE `id`=? LIMIT 1');
    if(!$stmt)return null; $stmt->bind_param('i',$ticketId); $stmt->execute(); $res=$stmt->get_result(); $ticket=$res?$res->fetch_assoc():null; $stmt->close();
    return is_array($ticket)?$ticket:null;
}

$user = cs_wp_request_user();
if (!$user) cs_wp_request_json(['ok'=>false,'message'=>'Pedidos estão disponíveis para clientes do servidor principal.'],403);
$db = cs_player_db(); if (!$db) cs_wp_request_json(['ok'=>false,'message'=>'Serviço de pedidos temporariamente indisponível.'],503);
$uid=(int)($user['id']??0); if($uid<=0) cs_wp_request_json(['ok'=>false,'message'=>'Cliente inválido.'],403);
$action=(string)($_GET['action']??$_POST['action']??'list');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $token=(string)($_POST['csrf']??'');
    if (empty($_SESSION['cs_player_request_csrf']) || !hash_equals((string)$_SESSION['cs_player_request_csrf'],$token)) {
        cs_player_write_log('web_player_request_csrf_failed',['user_id'=>$uid],'warning');
        cs_wp_request_json(['ok'=>false,'message'=>'Sua sessão expirou. Atualize a página e tente novamente.'],403);
    }
}

if ($action==='list') {
    $ids=array_keys(cs_wp_request_allowed_ids($uid)); rsort($ids); $out=[];
    foreach(array_slice($ids,0,80) as $ticketId){
        $ticket=cs_wp_request_ticket($db,(int)$ticketId,$uid); if(!$ticket)continue;
        $replies=[]; $stmt=$db->prepare('SELECT `admin_reply`,`message`,`date` FROM `tickets_replies` WHERE `ticket_id`=? ORDER BY `date` ASC');
        if($stmt){$tid=(int)$ticketId;$stmt->bind_param('i',$tid);$stmt->execute();$res=$stmt->get_result();while($row=$res->fetch_assoc()){$replies[]=['from'=>(int)$row['admin_reply']===1?'Atendimento':'Você','message'=>(string)$row['message'],'date'=>date('d/m/Y H:i',(int)$row['date'])];}$stmt->close();}
        $status=cs_wp_request_status($ticket);
        $out[]=['id'=>(int)$ticket['id'],'title'=>(string)$ticket['title'],'status'=>$status['key'],'status_label'=>$status['label'],'replies'=>$replies];
    }
    cs_wp_request_json(['ok'=>true,'tickets'=>$out]);
}

if ($action==='create' && $_SERVER['REQUEST_METHOD']==='POST') {
    $type=(string)($_POST['type']??'filme'); $allowedTypes=['filme'=>'Filme','serie'=>'Série','canal'=>'Canal','outro'=>'Outro']; if(!isset($allowedTypes[$type]))$type='outro';
    $title=trim((string)($_POST['title']??'')); $message=trim((string)($_POST['message']??''));
    if($title===''||mb_strlen($title)>160)cs_wp_request_json(['ok'=>false,'message'=>'Informe o título do pedido.'],422);
    if(mb_strlen($message)>1500)cs_wp_request_json(['ok'=>false,'message'=>'A observação deve ter no máximo 1500 caracteres.'],422);
    $owner=cs_wp_request_owner_id($db,$user); if($owner<=0)cs_wp_request_json(['ok'=>false,'message'=>'Não foi possível localizar o atendimento responsável pela sua conta.'],503);
    $subject='[PEDIDO WEB PLAYER] '.$allowedTypes[$type].': '.$title;
    $body="Pedido de {$allowedTypes[$type]} pelo Web Player\nCliente: ".(string)($user['username']??'')."\nTítulo: {$title}".($message!==''?"\nObservação: {$message}":'');
    $db->begin_transaction();
    try{
        $stmt=$db->prepare('INSERT INTO `tickets` (`member_id`,`title`,`status`,`admin_read`,`user_read`) VALUES (?, ?, 1, 0, 1)'); if(!$stmt)throw new RuntimeException('prepare ticket');
        $stmt->bind_param('is',$owner,$subject); if(!$stmt->execute())throw new RuntimeException('insert ticket'); $ticketId=(int)$stmt->insert_id; $stmt->close();
        $now=time(); $stmt=$db->prepare('INSERT INTO `tickets_replies` (`ticket_id`,`admin_reply`,`message`,`date`) VALUES (?,0,?,?)'); if(!$stmt)throw new RuntimeException('prepare reply');
        $stmt->bind_param('isi',$ticketId,$body,$now); if(!$stmt->execute())throw new RuntimeException('insert reply'); $stmt->close();
        $map=cs_wp_request_load_map(); $map[(string)$ticketId]=['client_id'=>$uid,'client_username'=>(string)($user['username']??''),'type'=>$type,'created_at'=>date('c')]; if(!cs_wp_request_save_map($map))throw new RuntimeException('save map');
        $db->commit(); cs_player_write_log('web_player_request_created',['ticket_id'=>$ticketId,'user_id'=>$uid,'type'=>$type],'info');
        cs_wp_request_json(['ok'=>true,'ticket_id'=>$ticketId,'message'=>'Pedido enviado para o atendimento.']);
    }catch(Throwable $e){$db->rollback();cs_player_write_log('web_player_request_create_failed',['user_id'=>$uid,'error'=>$e->getMessage()],'error');cs_wp_request_json(['ok'=>false,'message'=>'Não foi possível enviar o pedido agora.'],500);}
}

if ($action==='reply' && $_SERVER['REQUEST_METHOD']==='POST') {
    $ticketId=(int)($_POST['ticket_id']??0); $message=trim((string)($_POST['message']??'')); if($ticketId<=0||$message===''||mb_strlen($message)>1500)cs_wp_request_json(['ok'=>false,'message'=>'Resposta inválida.'],422);
    $ticket=cs_wp_request_ticket($db,$ticketId,$uid); if(!$ticket)cs_wp_request_json(['ok'=>false,'message'=>'Pedido não encontrado.'],404); if((int)$ticket['status']===0)cs_wp_request_json(['ok'=>false,'message'=>'Este pedido está fechado.'],409);
    $db->begin_transaction(); try{$stmt=$db->prepare('UPDATE `tickets` SET `admin_read`=0,`user_read`=1 WHERE `id`=?');$stmt->bind_param('i',$ticketId);$stmt->execute();$stmt->close();$now=time();$stmt=$db->prepare('INSERT INTO `tickets_replies` (`ticket_id`,`admin_reply`,`message`,`date`) VALUES (?,0,?,?)');$stmt->bind_param('isi',$ticketId,$message,$now);$stmt->execute();$stmt->close();$db->commit();cs_player_write_log('web_player_request_reply',['ticket_id'=>$ticketId,'user_id'=>$uid],'info');cs_wp_request_json(['ok'=>true,'message'=>'Resposta enviada.']);}catch(Throwable $e){$db->rollback();cs_player_write_log('web_player_request_reply_failed',['ticket_id'=>$ticketId,'user_id'=>$uid],'error');cs_wp_request_json(['ok'=>false,'message'=>'Não foi possível responder agora.'],500);}
}
cs_wp_request_json(['ok'=>false,'message'=>'Ação inválida.'],400);

# Melhorias e correções aplicadas

Esta versão foi preparada em uma cópia de trabalho. Os arquivos originais enviados permanecem intactos.

## Correção do erro de senha sudo

`admin/servidor_ssh.php` agora detecta quando o PHP já está executando como root e chama o helper diretamente, evitando uma chamada desnecessária ao `sudo`. Quando o PHP não é root, continua usando `/usr/bin/sudo -n`, sem permitir prompt interativo. Se a regra `NOPASSWD` estiver ausente, a interface apresenta uma orientação específica em vez de apenas mostrar `sudo: a password is required`.

## Instalação segura

O instalador `admin/server-config/install_vps_manager.sh` passou a aceitar o usuário real do PHP-FPM como argumento, validar o nome do usuário, instalar a regra sudoers em arquivo temporário validado por `visudo` e somente depois ativá-la. O helper existente, que já restringe as ações permitidas e usa lock de manutenção, foi preservado.

Também foi adicionado `admin/server-config/README.md` com instruções de instalação, diagnóstico e verificação, sem uso de senha root no painel.

## Validação

A sintaxe dos dois scripts Shell foi validada com `bash -n`. Os hashes da cópia de preservação coincidem com os hashes dos anexos originais. A validação automática de PHP não pôde ser executada neste ambiente porque não há um executável `php` instalado; recomenda-se executar `php -l` em cada arquivo PHP no servidor ou em um ambiente CI com PHP compatível antes da publicação.

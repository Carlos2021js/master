<?php
/**
 * CS Player - detalhes/copiar cliente.
 * Somente leitura. Usa exclusivamente campos/tabelas já existentes no schema Xtream.
 */
include "session.php";
include "functions.php";
header('Content-Type: application/json; charset=utf-8');

function cs_details_reply($success, $message = '', $data = []) {
    echo json_encode(['success' => (bool)$success, 'message' => (string)$message, 'data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (empty($rPermissions["is_admin"]) && empty($rPermissions["is_reseller"])) {
    cs_details_reply(false, 'Acesso negado.');
}

$userId = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
if ($userId <= 0) {
    cs_details_reply(false, 'ID de cliente inválido.');
}

$stmt = $db->prepare("SELECT u.*, ru.username AS owner_name FROM users u LEFT JOIN reg_users ru ON ru.id = u.member_id WHERE u.id = ? LIMIT 1");
if (!$stmt) cs_details_reply(false, 'Não foi possível consultar o cliente.');
$stmt->bind_param('i', $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$user) cs_details_reply(false, 'Cliente não encontrado.');

// Revendas só podem consultar clientes pertencentes à sua árvore já autorizada pelo painel.
if (!empty($rPermissions['is_reseller']) && empty($rPermissions['is_admin'])) {
    $allowedMembers = array_keys((array)getRegisteredUsers($rUserInfo['id']));
    $allowedMembers[] = intval($rUserInfo['id']);
    $allowedMembers = array_map('intval', array_unique($allowedMembers));
    if (!in_array(intval($user['member_id']), $allowedMembers, true)) {
        cs_details_reply(false, 'Cliente não pertence a esta revenda.');
    }
}

$serverId = intval($user['force_server_id'] ?? 0);
if ($serverId <= 0 || empty($rServers[$serverId])) $serverId = intval($_INFO['server_id'] ?? 0);
$server = (isset($rServers[$serverId]) && is_array($rServers[$serverId])) ? $rServers[$serverId] : [];
$useHttps = !empty($rAdminSettings['use_https_main']);
$scheme = $useHttps ? 'https' : 'http';
$host = '';
if (!empty($rUserInfo['reseller_dns']) && !empty($rPermissions['is_reseller'])) {
    $host = preg_replace('#^https?://#i', '', trim((string)$rUserInfo['reseller_dns']));
    $host = preg_replace('#/.*$#', '', $host);
    $host = preg_replace('#:\d+$#', '', $host);
}
if ($host === '') $host = trim((string)($server['domain_name'] ?? ''));
if ($host === '') $host = trim((string)($server['server_ip'] ?? ''));
$port = $useHttps ? intval($server['https_broadcast_port'] ?? 443) : intval($server['http_broadcast_port'] ?? 80);
if ($port <= 0) $port = $useHttps ? 443 : 80;
$baseUrl = $host !== '' ? $scheme . '://' . $host . ':' . $port : '';

$username = (string)$user['username'];
$password = (string)$user['password'];
$query = 'username=' . rawurlencode($username) . '&password=' . rawurlencode($password);

$requestHttps = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') || ((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$webScheme = $requestHttps ? 'https' : 'http';
$webHost = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
$scriptDir = str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/')));
if ($scriptDir === '.' || $scriptDir === '/') $scriptDir = '';
$webPlayerUrl = $webHost !== '' ? $webScheme . '://' . $webHost . rtrim($scriptDir, '/') . '/player/' : '';

// O banco não possui plan_id em users. Exibe os bouquets reais como conteúdo/plano em vez de inventar vínculo.
$bouquetNames = [];
$bouquetIds = json_decode((string)($user['bouquet'] ?? '[]'), true);
if (is_array($bouquetIds)) {
    $bouquetIds = array_values(array_filter(array_unique(array_map('intval', $bouquetIds)), function($id){ return $id > 0; }));
    if ($bouquetIds) {
        $ids = implode(',', $bouquetIds);
        $result = $db->query("SELECT bouquet_name FROM bouquets WHERE id IN (" . $ids . ") ORDER BY bouquet_order ASC, id ASC");
        if ($result) while ($row = $result->fetch_assoc()) $bouquetNames[] = (string)$row['bouquet_name'];
    }
}

if (empty($user['admin_enabled'])) {
    $status = 'Banido';
} elseif (empty($user['enabled'])) {
    $status = 'Inativo';
} elseif (!empty($user['exp_date']) && intval($user['exp_date']) <= time()) {
    $status = 'Vencido';
} else {
    $status = 'Ativo';
}

$created = !empty($user['created_at']) ? date('d/m/Y H:i:s', intval($user['created_at'])) : '';
$expiration = !empty($user['exp_date']) ? date('d/m/Y H:i:s', intval($user['exp_date'])) : 'Sem expiração';
$planLabel = $bouquetNames ? implode(', ', $bouquetNames) : '';

$data = [
    'id' => intval($user['id']),
    'username' => $username,
    'password' => $password,
    'owner' => (string)($user['owner_name'] ?? ''),
    'plan' => $planLabel,
    'plan_price' => '',
    'bouquets' => $bouquetNames,
    'created_at' => $created,
    'expiration' => $expiration,
    'expiration_ts' => !empty($user['exp_date']) ? intval($user['exp_date']) : null,
    'connections' => intval($user['max_connections'] ?? 0),
    'status' => $status,
    'enabled' => intval($user['enabled'] ?? 0),
    'admin_enabled' => intval($user['admin_enabled'] ?? 0),
    'is_trial' => intval($user['is_trial'] ?? 0),
    'server_name' => (string)($server['server_name'] ?? ''),
    'dns' => $baseUrl,
    'link_hls' => $baseUrl !== '' ? $baseUrl . '/get.php?' . $query . '&type=m3u_plus&output=hls' : '',
    'link_mpegts' => $baseUrl !== '' ? $baseUrl . '/get.php?' . $query . '&type=m3u_plus&output=mpegts' : '',
    'link_m3u8' => $baseUrl !== '' ? $baseUrl . '/get.php?' . $query . '&type=m3u_plus&output=m3u8' : '',
    'player_api' => $baseUrl !== '' ? $baseUrl . '/player_api.php?' . $query : '',
    'epg_link' => $baseUrl !== '' ? $baseUrl . '/xmltv.php?' . $query : '',
    'xciptv_url' => $baseUrl,
    'xciptv_user' => $username,
    'xciptv_pass' => $password,
    // Mantém o endpoint SSIPTV já usado pela própria versão do projeto, derivado do DNS selecionado.
    'ssiptv_link' => $baseUrl !== '' ? $baseUrl . '/p/' . rawurlencode($username) . '/' . rawurlencode($password) . '/ssiptv' : '',
    'web_player_url' => $webPlayerUrl,
    'web_player_user' => $username,
    'web_player_pass' => $password
];

cs_details_reply(true, '', $data);

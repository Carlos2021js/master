-- CSPlay Premium/Turbo UI - migration additive and reversible
-- Execute once on the same database used by the panel.
-- This only adds one nullable column; it does not remove or rewrite existing data.

SET @csplay_ui_version_exists := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'reg_users'
    AND COLUMN_NAME = 'ui_version'
);

SET @csplay_ui_version_sql := IF(
  @csplay_ui_version_exists = 0,
  'ALTER TABLE `reg_users` ADD COLUMN `ui_version` VARCHAR(20) NOT NULL DEFAULT ''legacy'' AFTER `expanded_sidebar`',
  'SELECT 1'
);

PREPARE csplay_ui_stmt FROM @csplay_ui_version_sql;
EXECUTE csplay_ui_stmt;
DEALLOCATE PREPARE csplay_ui_stmt;

-- Rollback, only if you explicitly need to revert this feature:
-- ALTER TABLE `reg_users` DROP COLUMN `ui_version`;

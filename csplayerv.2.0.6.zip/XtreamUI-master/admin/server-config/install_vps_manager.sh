#!/usr/bin/env bash
set -Eeuo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo 'Execute como root: sudo bash admin/server-config/install_vps_manager.sh [usuario-web]' >&2
  exit 1
fi

BASE="$(cd "$(dirname "$0")" && pwd)"
WEB_USER="${1:-www-data}"
if [[ ! "${WEB_USER}" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]; then
  echo 'Usuário web inválido.' >&2
  exit 2
fi

install -o root -g root -m 0755 "$BASE/cs-player-adminctl" /usr/local/sbin/cs-player-adminctl
install -d -m 0750 /var/log/cs-player
chown www-data:www-data /var/log/cs-player 2>/dev/null || true

SUDOERS_TMP="$(mktemp /etc/sudoers.d/cs-player-adminctl.XXXXXX)"
trap 'rm -f "$SUDOERS_TMP"' EXIT
cat >"$SUDOERS_TMP" <<EOF
# CS Player: somente o helper auditado pode ser executado pelo usuário web.
${WEB_USER} ALL=(root) NOPASSWD: /usr/local/sbin/cs-player-adminctl
EOF
chmod 0440 "$SUDOERS_TMP"
visudo -cf "$SUDOERS_TMP"
mv -f "$SUDOERS_TMP" /etc/sudoers.d/cs-player-adminctl
trap - EXIT

printf '\nInstalação concluída.\n- Helper: /usr/local/sbin/cs-player-adminctl\n- Sudoers: /etc/sudoers.d/cs-player-adminctl\n- Usuário autorizado: %s\n- Nenhuma senha root foi armazenada.\n\n' "$WEB_USER"
if command -v sudo >/dev/null 2>&1; then
  sudo -u "$WEB_USER" -n /usr/local/sbin/cs-player-adminctl status >/dev/null && echo 'Teste sudo: OK.' || echo 'Aviso: o teste como usuário web falhou; confira o usuário do PHP-FPM.'
fi

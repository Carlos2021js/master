# Gerenciador seguro do servidor

A página `admin/servidor_ssh.php` não deve receber nem armazenar senha root. Ela executa somente o helper `/usr/local/sbin/cs-player-adminctl`, que possui uma lista fechada de ações e validações próprias.

## Instalação

Execute, como `root`, a partir da raiz do projeto:

```bash
bash admin/server-config/install_vps_manager.sh www-data
```

Substitua `www-data` pelo usuário real que executa o PHP-FPM. Para descobrir o usuário, consulte o pool do PHP-FPM ou execute `ps -eo user,comm | grep php-fpm`.

O instalador copia o helper com proprietário `root:root`, permissões `0755`, cria uma regra sudoers temporária, valida-a com `visudo` e somente então a ativa. A regra permite apenas o helper auditado e não permite comandos arbitrários.

## Diagnóstico do erro de senha

A mensagem `sudo: a password is required` significa que o usuário do PHP-FPM não tem uma regra `NOPASSWD` aplicável. Verifique:

```bash
sudo -l -U www-data
sudo -u www-data -n /usr/local/sbin/cs-player-adminctl status
```

Se o PHP-FPM rodar com outro usuário, reinstale passando esse usuário ao instalador. A página também evita chamar `sudo` quando o próprio PHP já estiver executando como root.

Não configure senha root no painel e não substitua `sudo -n` por `sudo` interativo: processos web não devem aguardar entrada de senha.

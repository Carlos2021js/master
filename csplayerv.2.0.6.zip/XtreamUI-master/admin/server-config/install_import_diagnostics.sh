#!/usr/bin/env bash
set -euo pipefail
ADMIN_DIR="${1:-/var/www/html/admin}"
PHP_USER="${PHP_USER:-www-data}"
PHP_GROUP="${PHP_GROUP:-www-data}"

for dir in \
  "$ADMIN_DIR/storage" \
  "$ADMIN_DIR/storage/m3u_uploads" \
  "$ADMIN_DIR/storage/import_jobs"; do
  install -d -o "$PHP_USER" -g "$PHP_GROUP" -m 0750 "$dir"
done

find "$ADMIN_DIR/storage/m3u_uploads" -type f -exec chmod 0640 {} + 2>/dev/null || true
find "$ADMIN_DIR/storage/import_jobs" -type f -exec chmod 0640 {} + 2>/dev/null || true

echo "Diretórios do importador preparados em: $ADMIN_DIR/storage"
echo "Usuário PHP-FPM: $PHP_USER:$PHP_GROUP"

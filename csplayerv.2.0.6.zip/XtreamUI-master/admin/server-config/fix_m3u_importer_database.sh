#!/usr/bin/env bash
set -euo pipefail

# Uso:
#   sudo bash fix_m3u_importer_database.sh NOME_DO_BANCO [USUARIO_MYSQL]
DB_NAME="${1:-}"
DB_USER="${2:-root}"

if [[ -z "$DB_NAME" ]]; then
  echo "Uso: sudo bash $0 NOME_DO_BANCO [USUARIO_MYSQL]" >&2
  exit 1
fi

read -rsp "Senha MySQL de ${DB_USER}: " DB_PASS
echo
MYSQL=(mysql --default-character-set=utf8mb4 -u"$DB_USER" -p"$DB_PASS" "$DB_NAME")

"${MYSQL[@]}" <<'SQL'
SET SESSION sql_safe_updates = 0;

-- Corrige categorias criadas por versões antigas que gravavam 1/2/5 em vez de live/movie/series.
UPDATE stream_categories SET category_type = 'live'   WHERE category_type = '1';
UPDATE stream_categories SET category_type = 'movie'  WHERE category_type = '2';
UPDATE stream_categories SET category_type = 'series' WHERE category_type = '5';

-- Remove vínculos de episódios órfãos sem apagar streams válidos.
DELETE se
FROM series_episodes se
LEFT JOIN series s ON s.id = se.series_id
LEFT JOIN streams st ON st.id = se.stream_id
WHERE s.id IS NULL OR st.id IS NULL;
SQL

# Índice para localizar temporada/episódio rapidamente. Só cria se ainda não existir.
HAS_EP_INDEX=$("${MYSQL[@]}" -Nse "SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='series_episodes' AND index_name='idx_series_season_sort'")
if [[ "$HAS_EP_INDEX" == "0" ]]; then
  "${MYSQL[@]}" -e "ALTER TABLE series_episodes ADD INDEX idx_series_season_sort (series_id, season_num, sort);"
fi

HAS_CAT_INDEX=$("${MYSQL[@]}" -Nse "SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='stream_categories' AND index_name='idx_category_type_name'")
if [[ "$HAS_CAT_INDEX" == "0" ]]; then
  "${MYSQL[@]}" -e "ALTER TABLE stream_categories ADD INDEX idx_category_type_name (category_type, category_name);"
fi

echo "Correção do banco concluída. Reinicie apenas PHP-FPM e tente uma nova importação."

#!/usr/bin/env bash
set -euo pipefail
PHP_VERSION="${1:-8.3}"
NGINX_SNIPPET="/etc/nginx/snippets/cs-player-upload.conf"
PHP_INI="/etc/php/${PHP_VERSION}/fpm/conf.d/99-cs-player-upload.ini"

sudo install -d -m 0755 /etc/nginx/snippets
sudo tee "$NGINX_SNIPPET" >/dev/null <<'NGINX'
# Sem limite total no Nginx. O CS Player envia arquivos em blocos adaptativos.
client_max_body_size 0;
client_body_timeout 3600s;
fastcgi_read_timeout 3600s;
fastcgi_send_timeout 3600s;
NGINX

sudo tee "$PHP_INI" >/dev/null <<'PHPINI'
# Cada requisição contém apenas um bloco; o tamanho total pode superar 1 TB,
# condicionado ao espaço em disco e aos limites do sistema de arquivos.
upload_max_filesize = 64M
post_max_size = 72M
max_execution_time = 0
max_input_time = 3600
memory_limit = 512M
default_socket_timeout = 300
PHPINI

echo "Inclua no server {} do painel: include snippets/cs-player-upload.conf;"
sudo nginx -t
sudo systemctl restart "php${PHP_VERSION}-fpm"
sudo systemctl reload nginx

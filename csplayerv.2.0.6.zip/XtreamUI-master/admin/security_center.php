<?php
include "session.php"; include "functions.php";
if ((!$rPermissions["is_admin"]) OR (!hasPermissions("adv", "security_center"))) { exit; }

if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li>
                                        <?php if ($rPermissions["is_admin"]) { ?>
                                        <?php }
                                        if (!$detect->isMobile()) { ?>
                                        <a href="javascript:location.reload();">
                                            <button type="button" class="btn btn-dark waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-refresh"></i>  <?=$_["refresh"]?>
                                            </button>
                                        </a>
                                        <?php } else { ?>
                                        <a href="javascript:location.reload();" onClick="toggleAuto();" style="margin-right:10px;">
                                            <button type="button" class="btn btn-dark waves-effect waves-light btn-sm">
                                                <i class="mdi mdi-refresh"></i>  <?=$_["refresh"]?>
                                            </button>
                                        </a>
                                        <?php } ?>
                                    </li>
                                </ol>
                            </div>
                            <h4 class="page-title"> <?=$_["security_center"]?></h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title -->
            <h5 class="page-title"> <?=$_["restream_finder"]?></p></h5> 
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body" style="overflow-x:auto;">
                                <table id="datatable" class="table table-bordered table-hover table-sm table-striped font-normal">
                                    <thead>
                                        <tr>
                                            <th class="text-center"> <?=$_["user_id"]?></th>
                                            <!--<th class="text-center">MAG Adress</th>-->
                                            <th class="text-center"> <?=$_["username"]?></th>
                                            <!--<th class="text-center">Username</th>-->
                                            <!--<th class="text-center">Password</th>-->
                                            <th class="text-center"> <?=$_["channel"]?></th>
                                            <th class="text-center"> <?=$_["max_connections"]?></th>                                            
                                            <th class="text-center"> <?=$_["active Connections"]?></th>
                                            <th class="text-center"> <?=$_["total_active_connections"]?></th>
                                            <th class="text-center"> <?=$_["action"]?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach (getSecurityCenter() as $rIP) {
                                        ?>
                                        <tr id="ip-<?=$rIP["id"]?>">
                                            <td class="text-center"><a href="./user.php?id=<?=$rIP["id"]?>"><?=$rIP["id"]?></td>
                                            <!--<td class="text-center"><?=$rIP["FROM_BASE64(mac)"]?></td>-->
                                            <td class="text-center"><?php
											$MAG_or_M3U = $rIP["FROM_BASE64(mac)"];

												// True because $MAG_or_M3U is empty
											if (empty($MAG_or_M3U)) {
											  echo $rIP["username"];
											}

												// True because $MAG_or_M3U is set
											if (isset($MAG_or_M3U)) {
											  echo $rIP["FROM_BASE64(mac)"];
											}
											?></td>
                                            <!--<td class="text-center"><?=$rIP["username"]?></td>-->
                                            <!--<td class="text-center"><?=$rIP["password"]?></td>-->
                                            <td class="text-center"><?=$rIP["stream_display_name"]?></td>
                                            <td class="text-center"><?=$rIP["max_connections"]?></td>
                                            <td class="text-center"><?=$rIP["active_connections"]?></td>
                                            <td class="text-center"><?=$rIP["total_active_connections"]?></td>
                                            <td class="text-center"><a href="./user.php?id=<?=$rIP["id"]?>"><button type="button" class="btn btn-dark waves-effect waves-light btn-xs"><i class="far fa-eye"></i></button></a></td>
                                            <!--<td class="text-center"><?php
                                            if ($rIP["is_restreamer"] > 0) {
                    						echo '<i class="text-success fas fa-check fa-lg"></i>';
                							} else {
                    						echo '<i class="text-danger fas fa-times fa-lg"></i>';
                							}
                							rIP["is_restreamer"]?></td>-->
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div> <!-- end card body-->
                        </div> <!-- end card -->
                    </div><!-- end col-->
                </div>
                <!-- end row-->
                
            </br><h5 class="page-title"> <?=$_["check_leaked"]?></p></h5>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body" style="overflow-x:auto;">
                                <table id="datatable2" class="table table-bordered table-hover table-sm table-striped font-normal">
                                    <thead>
                                        <tr>
                                            <th class="text-center"> <?=$_["user_id"]?></th>
                                            <!--<th class="text-center">MAG Adress</th>-->
                                            <th class="text-center"> <?=$_["username_device"]?></th>
                                            <!--<th class="text-center">Username</th>-->
                                            <!--<th class="text-center">Password</th>-->
                                            <th class="text-center"> <?=$_["containers"]?></th>
                                            <th class="text-center"> <?=$_["flags"]?></th>                                            
                                            <th class="text-center"> <?=$_["user_ips"]?></th>
                                            <th class="text-center"> <?=$_["actions"]?></th>
                                            <!--<th class="text-center"> <?=$_["is_restreamer"]?></th>-->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach (getLeakedLines() as $rIP) {
                                        ?>
                                        <tr id="ip-<?=$rIP["id"]?>">
                                            <td class="text-center"><a href="./user.php?id=<?=$rIP["user_id"]?>"><?=$rIP["user_id"]?></td>
                                            <!--<td class="text-center"><?=$rIP["FROM_BASE64(mac)"]?></td>-->
                                            <td class="text-center"><?php
											$MAG_or_M3U = $rIP["FROM_BASE64(mac)"];

												// True because $MAG_or_M3U is empty
											if (empty($MAG_or_M3U)) {
											  echo $rIP["username"];
											}

												// True because $MAG_or_M3U is set
											if (isset($MAG_or_M3U)) {
											  echo $rIP["FROM_BASE64(mac)"];
											}
											?></td>
                                            <!--<td class="text-center"><?=$rIP["username"]?></td>-->
                                            <!--<td class="text-center"><?=$rIP["password"]?></td>-->
                                            <td class="text-center"><?=$rIP["GROUP_CONCAT(DISTINCT container)"]?></td>
                                            <td class="text-center"><?=$rIP["GROUP_CONCAT(DISTINCT geoip_country_code)"]?></td>
                                            <td class="text-center"><?=$rIP["GROUP_CONCAT(DISTINCT user_ip)"]?></td>
                                            <td class="text-center"><a href="./user.php?id=<?=$rIP["user_id"]?>"><button type="button" class="btn btn-dark waves-effect waves-light btn-xs"><i class="far fa-eye"></i></button></a></td>
                                            <!--<td class="text-center"><?php
                                            if ($rIP["is_restreamer"] > 0) {
                    						echo '<i class="text-success fas fa-check fa-lg"></i>';
                							} else {
                    						echo '<i class="text-danger fas fa-times fa-lg"></i>';
                							}
                							rIP["is_restreamer"]?></td>-->
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div> <!-- end card body-->
                        </div> <!-- end card -->
                    </div><!-- end col-->
                </div>
                <!-- end row-->
            </div> <!-- end container -->
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>
        <script src="assets/libs/pdfmake/pdfmake.min.js"></script>
        <script src="assets/libs/pdfmake/vfs_fonts.js"></script>

        <script>
        function api(rID, rType) {
            if (rType == "delete") {
                if (confirm(' <?=$_["block_ip_delete_confirm"]?>') == false) {
                    return;
                } else {
					$.toast(" <?=$_["blocked_ip_unblocked"]?>");
					if (rType == "delete") {
                        $("#ip-" + rID).remove();
                    }
                    $.each($('.tooltip'), function (index, element) {
                        $(this).remove();
                    });
					$('[data-toggle="tooltip"]').tooltip();
				}
            }
            $.getJSON("./api.php?action=ip&sub=" + rType + "&ip=" + rID, function(data) {
                if (data.result === true) {
                    if (rType == "delete") {
                        $.toast(" <?=$_["blocked_ip_deleted"]?>");
                    }
                } else {
                    $.toast(" <?=$_["an_error_occured"]?>");
                }
            });
        }
        
        $(document).ready(function() {
            $("#datatable").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination");
                },
                responsive: false
            });
            $("#datatable").css("width", "100%");
        });
        
        $(document).ready(function() {
            $("#datatable2").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination");
                },
                responsive: false
            });
            $("#datatable2").css("width", "100%");
        });
        </script>

        <!-- App js-->
        <script src="assets/js/app.min.js"></script>
    </body>
</html>
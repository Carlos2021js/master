# CS PLAYER v6.3.7 — Barra superior completa restaurada

- Restaura a barra superior completa no Admin, Revenda e demais painéis.
- Mantém menu principal, notificações, perfil, tickets/atalhos, tema e identidade do Branding Manager.
- Mantém o dock inferior mobile como atalho complementar; ele não substitui mais o cabeçalho.
- Web Player não foi alterado.
- No smartphone, a barra é compactada de forma responsiva: marca central, ações à esquerda e conta à direita.
- Dropdowns permanecem dentro da viewport.
- Nenhuma alteração de banco de dados.

# CS Player v6.4.3 — DNS Manual Only

- Web Player usa somente DNS cadastrados manualmente em `admin/settings.php`.
- Removida a inclusão automática de `streaming_servers` no login/failover do Web Player.
- Removida a área de DNS fixos/sincronização do Settings do Web Player.
- DNS manual possui ativar/desativar, nome, URL, prioridade, teste e remoção.
- Menor prioridade é tentada primeiro; falha aciona automaticamente o próximo DNS ativo.
- Configuração continua persistente em `admin/logs/cs-player/web-player-config.php` no servidor e não exige alteração do banco.
- Admin, Revenda, 3 importadores, TMDB, destaques, proxy, Cast e player estilo YouTube permanecem preservados.

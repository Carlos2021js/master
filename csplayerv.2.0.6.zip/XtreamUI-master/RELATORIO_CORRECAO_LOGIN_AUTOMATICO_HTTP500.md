# Correção do login automático — CS Player

## Escopo

Esta versão remove o campo de DNS manual da tela de login do Web Player, restaura a seleção automática dos servidores ativos e melhora o diagnóstico de falhas de autenticação. O arquivo SQL foi utilizado somente para consulta e comparação; nenhuma operação de banco foi executada.

## Causa observada

Os logs recebidos registravam `auth_request_failed` e `web_player_auth_failed`. Havia respostas HTTP 500 no fluxo de autenticação e o histórico anterior também registrava HTTP 404. A reprodução sem credenciais reais confirmou que `http://169.58.140.143:80/player_api.php` respondeu HTTP 404 e que o endpoint não está disponível nessa origem/porta. Portanto, a porta HTTP configurada precisa publicar `player_api.php`; o navegador não consegue corrigir uma rota que o servidor externo não possui.

## Correções aplicadas

O formulário de `admin/player/index.php` voltou a conter somente usuário e senha. O texto do botão informa que a validação usa a sincronização automática de servidores. O CSS foi versionado para impedir que o navegador reutilize a tela antiga com o campo DNS manual.

O `admin/player/auth.php` agora chama a lista automática sincronizada com `streaming_servers`, passando uma string vazia para ignorar valores manuais persistidos em sessões antigas. Ao autenticar, os campos de DNS manual antigos são removidos da sessão. O login não grava nem lê mais DNS manual da interface.

O `admin/player/bootstrap.php` passou a devolver diagnósticos por servidor quando a autenticação falha. O log inclui somente host, código HTTP e indicação se a resposta era JSON; não inclui senha, token ou corpo potencialmente sensível.

A mensagem exibida ao usuário diferencia as situações. HTTP 500 informa que o serviço Xtream respondeu com erro interno. HTTP 404 informa que `player_api.php` não foi encontrado e orienta revisar a porta HTTP de transmissão no menu **Servidores**. Outros códigos são exibidos como falha de autenticação dos servidores sincronizados.

## Sincronização e banco

A sincronização automática permanece baseada nos servidores ativos de `streaming_servers`, respeitando domínio/IP e portas já cadastrados. Não foi alterada nenhuma tabela, coluna, registro, senha, usuário, grupo, porta ou configuração no banco.

A comparação byte a byte do SQL original produziu o mesmo SHA-256 nos dois arquivos:

```text
9b57e517257a73dcb459ee084efd5ffe66fa30e955db5743034aa159c854582e
```

## Validações

Os arquivos `bootstrap.php`, `auth.php`, `api.php` e `index.php` passaram no lint PHP. O JavaScript do Web Player passou no `node --check`. A tela não contém mais `DNS manual`, `manualDns`, `manualOnly`, `manual_dns` ou `manual_only`, e o auth chama explicitamente a lista automática. O SQL original e a cópia de trabalho permanecem idênticos.

## Ação necessária no servidor

Se o login continuar falhando depois de publicar o pacote, abra **Servidores** e confirme que o domínio/IP aponta para o servidor que realmente fornece o serviço Xtream e que `http_broadcast_port` é a porta pública do broadcast/API. O teste correto é que a URL base configurada responda a `/player_api.php?username=...&password=...` com JSON; uma página Nginx HTTP 404 ou uma resposta HTTP 500 significa que o serviço de origem ainda precisa ser corrigido ou que a porta cadastrada não corresponde ao serviço Xtream.

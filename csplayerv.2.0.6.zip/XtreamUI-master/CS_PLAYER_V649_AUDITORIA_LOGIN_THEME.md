# CS PLAYER v6.4.9 — Auditoria completa + Login dia/noite

## Escopo
- Base: v6.4.8 HTTP500 boot fix.
- Banco de dados: nenhuma tabela, coluna, índice ou ID alterado.
- Admin, Revenda, Web Player, importadores e rotas preservados.

## Correção principal do login.php
O botão dia/noite existia visualmente, porém o próprio `login.php` enviava uma Content-Security-Policy que não permitia JavaScript inline. O código que alternava o tema era inline e podia ser bloqueado pelo navegador.

### Correção
- nonce CSP aleatório por requisição;
- scripts inline legítimos do login recebem o mesmo nonce;
- não foi habilitado `unsafe-inline` para scripts;
- tema continua salvo em `localStorage` usando `csplayer_theme`;
- sincronização de `data-theme`, `data-layout-mode`, `dark-mode` e `csplay-dark`;
- botão atualiza ícone, rótulo, `title`, `aria-label` e `aria-pressed`;
- escolha de tema permanece ao entrar no Admin/Revenda.

## Validação
- 285 arquivos PHP verificados com `php -l`;
- 0 erros de sintaxe PHP;
- JavaScripts próprios principais verificados com `node --check`;
- 0 erros de sintaxe JavaScript;
- ZIP final testado.

## Compatibilidade
- PHP 8.3 / Ubuntu 24.04;
- smartphone, tablet e desktop;
- fluxo de login, 2FA, reCAPTCHA e permissões preservados.

# CS PLAYER v6.1.8 — Auditoria completa e responsividade

## Regras preservadas
- Nenhuma tabela, coluna ou ID do banco foi alterado.
- Nenhum importador existente foi removido.
- Rotas e páginas legadas foram preservadas.
- O Web Player, Multi-DNS, TMDB, login por usuário/e-mail e login automático foram mantidos.

## Correções aplicadas
- Proteção contra `in_array()` com valor nulo/JSON inválido em páginas legadas de usuário/servidor.
- Normalização de países GeoIP antes da comparação estrita.
- Nova camada CSS global carregada por último para smartphone, tablet e desktop.
- Cabeçalho administrativo estabilizado, menu móvel com área rolável e conteúdo sem overflow horizontal.
- Formulários, Select2, Bootstrap Select, DataTables, modais, tabs e wizards adaptados para toque.
- Botões com alvos maiores no celular e suporte a safe-area.
- Web Player refinado para celular: login, hero, carrosséis, cards, detalhes e controles.
- Preferência `prefers-reduced-motion` e foco visível melhorados.

## Validação
O pacote deve ser validado com `php -l` em todos os arquivos PHP e `node --check` nos JavaScripts próprios antes da implantação.

# CS Player v6.1.6 — Cinema UI + TMDB

- Web Player redesenhado em estilo de plataforma premium de streaming.
- Hero dinâmico com backdrop TMDB e seleção rotativa de filmes/séries.
- Carrosséis horizontais, hover, badges, detalhes avançados e responsividade.
- TMDB integrado no backend com cache de 7 dias.
- Chave TMDB fixa no runtime do projeto via getSettings(), sem alteração de SQL.
- A chave não é enviada ao JavaScript do Web Player.
- Detalhes: sinopse, pôster/backdrop, ano, nota, gêneros, duração, elenco e trailer.
- Admin TMDB existente continua compatível e passa a usar a chave fixa do projeto.

# CS PLAYER v6.5.6 — Identidade técnica

Esta revisão consolida a identidade pública do projeto como **CS PLAYER**.

## Regras aplicadas
- Interface, mensagens e diagnósticos novos usam CS PLAYER.
- Referências legadas em caminhos absolutos, banco, serviços e valores de protocolo são preservadas quando necessárias à compatibilidade.
- O modo XC continua disponível apenas como protocolo de conexão, não como identidade do produto.
- Não altera tabelas, colunas, IDs ou schema do banco.
- Não renomeia `/home/xtreamcodes/iptv_xtream_codes/`, pois esse caminho faz parte da instalação existente e renomeá-lo quebraria serviços.
- O Web Player continua compatível com PHP interno 7.4.33 e PHP 8.x.

## Identidade
Nome oficial: CS PLAYER
Versão: 6.5.6

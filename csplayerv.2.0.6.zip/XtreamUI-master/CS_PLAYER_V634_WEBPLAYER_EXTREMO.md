# CS PLAYER v6.3.4 — Web Player Premium

Versão baseada na v6.3.3, com foco exclusivo na evolução do Web Player.

## Melhorias

- Home cinematográfica refinada sem alterar o catálogo real.
- Busca global real em canais, filmes e séries carregados.
- Atalhos rápidos para Lançamentos, Ao vivo, Filmes, Séries e Minha Lista.
- Botão Surpreenda-me usando somente itens existentes no catálogo.
- Seção Top 10 calculada a partir dos itens reais disponíveis.
- Trilhos com navegação anterior/próximo no desktop.
- Cards com hierarquia visual, metadados e progresso de Continue assistindo.
- Destaques automáticos/manuais preservados, até 100 itens via Settings.
- Menu de conta, Pedidos, Perfil, Minha Lista e tema preservados.
- Indicador online/offline e feedback visual por toasts.
- Player com PiP, tela cheia, mute, reconexão e failover existentes.
- Melhorias mobile para hero, player, cards, modais e controles de toque.
- TMDB continua somente como fallback para metadados ausentes.
- Nenhuma tabela, coluna, índice ou ID do banco foi alterado.

## Compatibilidade

Admin e Revenda da v6.3.3 foram preservados. Esta revisão concentra alterações em `admin/player/`.

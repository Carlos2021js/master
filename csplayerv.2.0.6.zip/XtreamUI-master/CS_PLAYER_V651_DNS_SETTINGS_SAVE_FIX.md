# CS Player v6.5.1 — DNS Settings e Salvamento

- Corrige falha genérica ao salvar configurações do Web Player.
- Backend passa a devolver JSON seguro também em exceções.
- Configuração tenta o caminho runtime principal e fallbacks sem alterar o banco.
- Falhas de escrita são registradas em `web-player.log` como `runtime_config_save_failed`.
- DNS manuais redesenhados em cards compactos.
- Campos principais: Ativo, Nome, DNS/URL, Modo e Prioridade.
- Perfil HTTP, IP, Saída e Caminho M3U ficam em “Opções avançadas”.
- Diagnóstico mostra estado no próprio card.
- Barra de salvar permanece acessível no smartphone.
- Nenhuma tabela, coluna ou ID do banco foi alterado.

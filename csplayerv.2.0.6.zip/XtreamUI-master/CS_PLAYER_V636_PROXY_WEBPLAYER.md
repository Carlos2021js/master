# CS PLAYER v6.3.6 — Proxy inteligente dentro do Web Player

## Escopo
- Proxy exclusivo em `admin/player/`.
- Configuração no `admin/settings.php` principal do CS PLAYER.
- Sem tabelas/colunas/IDs novos.
- Admin, Revenda, importadores e Web Player existentes preservados.

## Configurações novas em Settings → Web Player
- Ativar/desativar proxy do Web Player.
- Proxy HLS/canais.
- Proxy VOD/filmes/séries.
- Proxy/CORS para TV Cast.
- Logs próprios do proxy.
- Retries da origem (0–5).
- Timeout de conexão (2–20s).
- Detecção de origem lenta (10–120s).
- Cache curto de manifesto HLS por sessão (0–15s).

## Funcionamento
- `player/stream.php` é a porta de entrada de mídia do navegador.
- HLS: playlist M3U8 e URIs internas são reescritas para `player/segment.php`.
- Segmentos e subplaylists continuam passando pelo módulo do Web Player.
- VOD: MP4/MKV e outros binários preservam `Range`, `Content-Range` e `Accept-Ranges`.
- Retry binário só ocorre antes de qualquer byte ser entregue, evitando duplicar/corromper mídia.
- CORS de mídia pode ser habilitado para Cast/reprodução remota.
- URLs completas/credenciais de origem não são gravadas no log do proxy.

## Logs
`admin/logs/cs-player/web-player-proxy.log`

O arquivo foi adicionado à fonte "Web Player / testes de servidor" em `system_logs.php`.

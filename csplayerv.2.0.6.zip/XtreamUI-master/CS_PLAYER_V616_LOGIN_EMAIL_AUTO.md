# CS Player v6.1.6 — Login por usuário/e-mail e acesso automático

- Admin e Revenda: login aceita `reg_users.username` ou `reg_users.email`.
- Clientes: campo opcional **E-mail do cliente** em `admin/user.php` e `admin/user_reseller.php`.
- O e-mail de login do cliente é salvo fora do banco em `admin/player/data/client_email_aliases.json`, vinculado ao ID do usuário. Nenhuma tabela/coluna foi criada ou alterada.
- Web Player: login aceita usuário ou e-mail.
- Web Player local: após o primeiro login válido, cria cookie HTTP-only assinado por 30 dias; não grava a senha em localStorage.
- Ao clicar em Sair, o cookie de acesso automático é removido. Alterar a senha do cliente invalida o token anterior.

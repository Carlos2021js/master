# CS Player v6.5.3 — Compatibilidade PHP do Web Player

- Remove sintaxe exclusiva do PHP 8 no módulo `admin/player/`.
- `match` substituído por `switch`.
- Tipo de retorno union `string|false` removido em `cast_lib.php`.
- `str_starts_with()`/`str_contains()` substituídos por equivalentes compatíveis com PHP 7.4.
- Preserva DNS manual, Auto/XC/Smart/M3U Plus, proxy, Cast, PiP, reconexão automática, TMDB, destaques e pedidos.
- Nenhuma alteração no banco de dados.

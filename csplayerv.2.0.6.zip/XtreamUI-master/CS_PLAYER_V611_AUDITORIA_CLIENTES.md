# CS Player v6.11 — Auditoria de clientes e Web Player

Data: 18/08/2026

## Escopo validado

- Painel Administrador: criação/edição de clientes em `admin/user.php`.
- Painel Revenda e Sub-revenda: criação/edição de clientes em `admin/user_reseller.php`.
- Gestão/listagem de clientes em `admin/users.php`.
- Endpoint de detalhes/cópia em `admin/get_user_details.php`.
- Entrega automática pós-criação em `admin/client_delivery.php`.
- Web Player em `admin/player/` e sincronização Multi-DNS existente.

## Correções aplicadas

1. Revenda/Sub-revenda agora redireciona com `created=1` somente quando um cliente é realmente criado, igualando o comportamento do Admin.
2. `created=0` não abre mais a entrega automática ao apenas editar um cliente.
3. A entrega usa o servidor forçado do cliente (`force_server_id`) quando configurado, ou o servidor principal como fallback.
4. DNS de revenda continua respeitado para revendedores, sem liberar configurações administrativas do Web Player.
5. Dados completos entregues/copiedos:
   - usuário;
   - senha;
   - conteúdo/plano (bouquets existentes);
   - revenda/proprietário;
   - servidor;
   - criação;
   - vencimento;
   - conexões;
   - status;
   - DNS/URL do servidor;
   - M3U HLS;
   - M3U MPEG-TS;
   - M3U8;
   - Player API;
   - EPG/XMLTV;
   - SSIPTV;
   - XCIPTV/Xtream Codes;
   - Web Player;
   - usuário e senha do Web Player.
6. O endereço do Web Player é detectado pela URL pública real do painel, suportando `/player/` e `/admin/player/` conforme a instalação.
7. Credenciais embutidas em links usam codificação de URL.
8. Nenhuma tabela, coluna ou ID de banco de dados foi criado, removido ou alterado.

## Validação

- 277 arquivos PHP verificados com `php -l`.
- Resultado: 277/277 sem erros de sintaxe.
- Arquivos centrais modificados também validados individualmente.

## Arquivos modificados

- `admin/client_delivery.php`
- `admin/get_user_details.php`
- `admin/user_reseller.php`
- `admin/users.php`
- `admin/CS_PLAYER_V611_CLIENT_DELIVERY_ALL_PANELS.md`
- `CS_PLAYER_V611_AUDITORIA_CLIENTES.md`

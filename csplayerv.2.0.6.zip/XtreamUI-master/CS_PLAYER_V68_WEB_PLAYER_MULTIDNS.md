# CS Player v6.8 — Web Player Multi-DNS

## Adicionado sem remover funcionalidades existentes
- Web Player centralizado exclusivamente em `admin/player/`.
- Web Player responsivo com estética premium de streaming inspirada na referência visual.
- Login inteligente que testa os DNS ativos em ordem de prioridade e seleciona automaticamente o DNS em que o usuário autentica.
- Catálogo: TV ao vivo, Filmes, Séries e Minha Lista.
- Player HLS com proxy local de manifestos/segmentos para reduzir problemas de CORS.
- Proxy com suporte a Range para VOD/episódios.
- Reconexão automática e failover para DNS alternativo.
- PiP quando suportado pelo navegador.
- Continuar assistindo e favoritos armazenados localmente no navegador.
- Busca e filtro por categoria.
- Administração do Web Player integrada em `admin/settings.php`.
- Cadastro de múltiplos DNS com nome, URL, prioridade, ativo/inativo e teste de latência.
- Configuração salva em `admin/player/storage/config.php`, sem criar tabela ou coluna.

## Banco
Nenhuma alteração estrutural no banco de dados.

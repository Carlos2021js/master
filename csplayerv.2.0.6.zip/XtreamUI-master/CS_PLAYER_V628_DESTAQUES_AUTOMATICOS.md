# CS PLAYER v6.2.8 — Destaques automáticos

- Mantido o `admin/settings.php` existente.
- Até 100 destaques manuais, sem alteração do banco de dados.
- Rotação automática configurável (5, 8, 10, 15, 20 ou 30 segundos).
- Ordem manual ou aleatória.
- Controles anterior/próximo no desktop e indicadores responsivos.
- Pausa temporária quando o cliente interage com o destaque.
- Se não houver destaques manuais, o Web Player monta uma seleção automática do catálogo real.
- TMDB continua somente como fallback de metadados ausentes; não cria conteúdo.
- Canais, filmes e séries usados nos destaques precisam existir no sistema.

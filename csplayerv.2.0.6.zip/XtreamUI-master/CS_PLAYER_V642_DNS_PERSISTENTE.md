# CS PLAYER v6.4.2 — DNS externo persistente

## Correção principal
O pacote anterior distribuía `admin/player/storage/config.php` com `dns: []`. Ao atualizar os arquivos, isso podia substituir a configuração dinâmica salva no `settings.php`, fazendo o Web Player enxergar apenas o DNS interno.

## Nova persistência
A configuração dinâmica do Web Player passa a ser salva em:

`admin/logs/cs-player/web-player-config.php`

Esse arquivo não é incluído no pacote de atualização. Assim DNS externos, destaques, opções de proxy e demais configurações do Web Player sobrevivem às próximas atualizações.

Na primeira execução, configurações antigas em `admin/player/storage/config.php` ou `config.json` são migradas automaticamente.

## Diagnóstico
O log de falha de autenticação agora informa `internal_dns_count` e `external_dns_count`. Ao salvar Settings, o evento `web_player_config_saved` registra a quantidade de DNS externos habilitados, sem gravar credenciais.

## Banco
Nenhuma tabela, coluna, índice ou ID foi alterado.

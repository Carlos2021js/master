# CS Player v6.2.1 — Detector inteligente nos 3 importadores

## Escopo
- Banco de dados preservado integralmente.
- Tipos existentes preservados: `1=live`, `2=movie`, `5=series/episode`.
- Cada importador mantém sua própria arquitetura e seus próprios arquivos.
- O detector foi calibrado com duas playlists reais, sem copiar as playlists nem credenciais para o projeto.

## Ordem de decisão
1. Modo manual (quando escolhido pelo administrador).
2. Categoria explicitamente de canais/live.
3. Padrão inequívoco de episódio (`SxxEyy`, `1x01`, `Season/Episode`, `Temporada/Episódio`, `Txx EPxx`).
4. Categoria de séries/novelas/doramas/animes/cursos.
5. Categoria de filmes/VOD/coleções/shows.
6. Estrutura da URL (`/live/`, `/series/`, `/movie/`).
7. Extensão (`.ts/.m3u8/.mpegts` para live; `.mp4/.mkv` para VOD).
8. Heurísticas fracas de título apenas como último recurso.

## Casos críticos corrigidos
- `Canais | Séries 24H` é LIVE, mesmo contendo a palavra Séries.
- `24H FILMES` com URL `.ts` é LIVE, e não VOD.
- `Filmes | Drama` é MOVIE.
- `Coleção: ...` é MOVIE.
- `Series | Netflix` + `S01E01` é episódio.
- `Novelas` + `S01E01` é episódio.
- URLs sem extensão continuam classificáveis quando a categoria é explícita.

## Compatibilidade
Os detectores foram aplicados separadamente em:
- `admin/m3u_update_nodup.php`
- `admin/m3u_update_nodup1.php` (compatibilidade legada)
- `admin/includes/m3u2/Classifier.php`
- `admin/includes/m3u3/Classifier.php`

Nenhuma migração SQL é necessária.

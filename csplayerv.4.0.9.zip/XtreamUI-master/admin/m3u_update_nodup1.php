<?php
/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  IMPORTAÇÃO INTELIGENTEDE M3U — ULTRA PRO v5.0 (PHP 7.4–8.4)         ║
 * ║  CS PLAYER — Compatível com PHP 7.4+                    ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */

// ═══════════════════════════════════════════════════════════════════════════
// PREVENÇÃO DE ERRO 500 – LOGS, VERIFICAÇÕES E CAPTURA DE ERROS
// ═══════════════════════════════════════════════════════════════════════════

register_shutdown_function(function () {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
        echo "ERRO FATAL DO PHP: " . $error['message'] . " em " . $error['file'] . ":" . $error['line'];
        exit;
    }
});

// Warnings permanecem no log do PHP-FPM, mas nunca contaminam a resposta do endpoint.
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);

try {
    $requiredFiles = [
        'session.php',
        'functions.php',
        'cs_admin_access.php',
        'cs_m3u_diagnostics.php'
    ];

    foreach ($requiredFiles as $file) {
        $path = __DIR__ . DIRECTORY_SEPARATOR . $file;
        if (!file_exists($path)) {
            throw new RuntimeException("Arquivo obrigatório não encontrado: {$file}. Verifique a instalação.");
        }
        require_once $path;
    }

    if (!class_exists('CSM3UImportDiagnostics')) {
        class CSM3UImportDiagnostics
        {
            private $id;
            private $data;
            private static $instances = [];

            public function __construct($sourceType, $sourceName)
            {
                $this->id = bin2hex(random_bytes(8));
                $this->data = [
                    'status'               => 'iniciado',
                    'stage'                => '',
                    'channels_expected'    => 0,
                    'channels_found'       => 0,
                    'channels_imported'    => 0,
                    'channels_updated'     => 0,
                    'channels_skipped'     => 0,
                    'errors'               => 0,
                    'warnings'             => 0,
                    'categories_created'   => 0,
                    'categories_reused'    => 0,
                    'sql_queries'          => 0,
                    'memory_current'       => 0,
                    'memory_peak'          => 0,
                    'elapsed_seconds'      => 0,
                    'average_batch_seconds'=> 0,
                    'logs'                 => [],
                    'batches'              => 0
                ];
                self::$instances[$this->id] = $this;
            }

            public static function create($sourceType, $sourceName)
            {
                return new self($sourceType, $sourceName);
            }

            public static function open($id)
            {
                if (!isset(self::$instances[$id])) {
                    throw new RuntimeException("Diagnóstico não encontrado: {$id}");
                }
                return self::$instances[$id];
            }

            public function id()
            {
                return $this->id;
            }

            public function snapshot()
            {
                $this->data['memory_current'] = memory_get_usage();
                $this->data['memory_peak'] = memory_get_peak_usage();
                $this->data['elapsed_seconds'] = microtime(true) - ($_SERVER['REQUEST_TIME_FLOAT'] ?? microtime(true));
                return $this->data;
            }

            public function update(array $data)
            {
                $this->data = array_merge($this->data, $data);
            }

            public function increment($key)
            {
                if (isset($this->data[$key])) {
                    $this->data[$key]++;
                }
            }

            public function log($level, $stage, $message, $e = null)
            {
                $this->data['logs'][] = [
                    'time'    => date('H:i:s'),
                    'level'   => $level,
                    'stage'   => $stage,
                    'message' => $message,
                    'file'    => $e ? $e->getFile() : null,
                    'line'    => $e ? $e->getLine() : null
                ];
            }

            public function setStage($stage, $message)
            {
                $this->data['stage'] = $stage;
                $this->log('info', $stage, $message);
            }

            public function finish($status, $message)
            {
                $this->data['status'] = $status;
                $this->log('info', 'finalizado', $message);
            }

            public function fail($e, $stage)
            {
                $this->data['status'] = 'falha';
                $this->log('error', $stage, $e ? $e->getMessage() : 'Erro desconhecido', $e);
            }
        }
    }

    if (!isset($db) || !($db instanceof mysqli)) {
        throw new RuntimeException("Conexão com o banco de dados (\$db) não está disponível.");
    }

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    // ═══════════════════════════════════════════════════════════════════════
    // CLASSE DE IMPORTAÇÃO (PHP 7.4+)
    // ═══════════════════════════════════════════════════════════════════════
    class M3UImporter
    {
        private $db;
        private $stats;
        private $bouquetData;
        private $categoryCache;
        private $seriesCache;
        private $existingStreamsCache;
        private $seriesSeasons;
        private $touchedSeries;
        private $diagnostics;
        private $batchStartedAt = 0.0;
        private $batchSecondsTotal = 0.0;
        const LOCK_RETRIES = 4;

        const EXT_LIVE = ['m3u8', 'ts', 'mpegts'];
        const EXT_VOD  = ['mp4', 'mkv', 'avi', 'mov', 'wmv', 'flv', 'webm', 'm4v'];
        const SERIES_PATTERNS = [
            '/^(.*?)[._\-\s]+S(\d{1,3})\s*E(\d{1,4})\b/i',
            '/^(.*?)[._\-\s]+(\d{1,3})x(\d{1,4})\b/i',
            '/^(.*?)[._\-\s]+Season\s*(\d{1,3})[._\-\s]+Episode\s*(\d{1,4})\b/i',
            '/^(.*?)[._\-\s]+Temporada\s*(\d{1,3})[._\-\s]+(?:Epis[oó]dio|EP?)\s*(\d{1,4})\b/iu',
            '/^(.*?)[._\-\s]+T(\d{1,3})\s*(?:EP?|Epis[oó]dio)\s*(\d{1,4})\b/iu',
        ];

        private static function categoryTypeForStream($type)
        {
            switch ($type) {
                case 1:  return 'live';
                case 2:  return 'movie';
                case 5:  return 'series';
                default: return 'live';
            }
        }

        public function __construct(mysqli $db, $diagnostics = null)
        {
            $this->db = $db;
            $this->diagnostics = $diagnostics;
            $this->stats = [
                'total'              => 0,
                'inserted'           => 0,
                'updated'            => 0,
                'skipped'            => 0,
                'errors'             => 0,
                'live'               => 0,
                'movies'             => 0,
                'series'             => 0,
                'radio'              => 0,
                'categories_created' => 0,
                'categories_reused'  => 0,
                'sql_queries'        => 0,
                'warnings'           => 0,
            ];
            $this->bouquetData           = [];
            $this->categoryCache         = [];
            $this->seriesCache           = [];
            $this->existingStreamsCache  = [];
            $this->seriesSeasons         = [];
            $this->touchedSeries         = [];
        }

        private function sql($stage, callable $operation)
        {
            $this->stats['sql_queries']++;
            if ($this->diagnostics) {
                $this->diagnostics->increment('sql_queries');
            }
            try {
                return $operation();
            } catch (Throwable $e) {
                if ($this->diagnostics) {
                    $this->diagnostics->log('error', $stage, 'Falha SQL: ' . $e->getMessage(), $e);
                }
                throw $e;
            }
        }

        private function log($level, $stage, $message, $e = null)
        {
            if ($this->diagnostics) {
                $this->diagnostics->log($level, $stage, $message, $e);
            }
        }

        public static function isValidUrl($url)
        {
            if (!filter_var($url, FILTER_VALIDATE_URL)) return false;
            $parts = parse_url($url);
            $host  = isset($parts['host']) ? $parts['host'] : '';
            if (empty($host)) return false;
            if (in_array(strtolower($host), ['127.0.0.1', 'localhost', '::1', '0.0.0.0'])) return false;
            $ip = @inet_pton($host);
            if ($ip !== false && strlen($ip) === 4) {
                $ip4 = ip2long($host);
                if ($ip4 !== false) {
                    $privateRanges = [
                        [ip2long('10.0.0.0'),    ip2long('10.255.255.255')],
                        [ip2long('172.16.0.0'),  ip2long('172.31.255.255')],
                        [ip2long('192.168.0.0'), ip2long('192.168.255.255')],
                        [ip2long('169.254.0.0'), ip2long('169.254.255.255')],
                        [ip2long('127.0.0.0'),   ip2long('127.255.255.255')],
                    ];
                    foreach ($privateRanges as $range) {
                        if ($ip4 >= $range[0] && $ip4 <= $range[1]) return false;
                    }
                }
            }
            return true;
        }

        public static function parseSeriesInfo($name)
        {
            foreach (self::SERIES_PATTERNS as $pattern) {
                if (preg_match($pattern, $name, $m)) {
                    $title = self::cleanTitle(trim($m[1]));
                    if ($title === '') $title = 'Série sem nome';
                    return [
                        'title'   => $title,
                        'season'  => max(0, (int)$m[2]),
                        'episode' => max(1, (int)$m[3]),
                    ];
                }
            }
            return null;
        }

        public static function cleanTitle($title)
        {
            $title = preg_replace('/[._\-\s]?(?:1080p|720p|480p|2160p|4k|uhd|hevc|x264|x265|h264|h265|avc|hevc|aac|dts|bluray|bdrip|dvdrip|webrip|hdtv|sd|hd|fhd|uhd)[._\-\s]?$/i', '', $title);
            $title = preg_replace('/[._\-\s]?(?:the\.complete\.series|complete\.series|complete\.season)[._\-\s]?$/i', '', $title);
            return trim($title, ' ._-');
        }

        /**
         * Detector inteligente CS Player v6.2.1.
         * Mantém banco/IDs/tipos intactos e combina categoria, episódio, URL e extensão.
         */
        public static function classifyType($url, $name, $group = '', $mode = 'auto')
        {
            $mode = in_array($mode, ['auto', 'live', 'movie', 'series'], true) ? $mode : 'auto';
            $url = trim((string)$url);
            $name = trim((string)$name);
            $group = trim((string)$group);
            $path = parse_url($url, PHP_URL_PATH) ?: '';
            $ext = strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
            $info = self::parseSeriesInfo($name);

            if ($mode === 'live') return ['type'=>1,'ext'=>in_array($ext,self::EXT_LIVE,true)?$ext:'ts','series'=>null,'reason'=>'modo_forcado_live','confidence'=>100];
            if ($mode === 'movie') return ['type'=>2,'ext'=>$ext ?: 'mp4','series'=>null,'reason'=>'modo_forcado_movie','confidence'=>100];
            if ($mode === 'series') return ['type'=>5,'ext'=>$ext ?: 'mp4','series'=>$info ?: self::fallbackSeriesInfo($name),'reason'=>'modo_forcado_series','confidence'=>100];

            $intent = self::groupIntent($group);
            $urlIntent = self::urlIntent($url);

            if ($intent === 'live') return ['type'=>1,'ext'=>in_array($ext,self::EXT_LIVE,true)?$ext:'ts','series'=>null,'reason'=>'categoria_live','confidence'=>99];
            if ($info) return ['type'=>5,'ext'=>$ext ?: 'mp4','series'=>$info,'reason'=>'padrao_episodio','confidence'=>98];
            if ($intent === 'series') return ['type'=>5,'ext'=>$ext ?: 'mp4','series'=>self::fallbackSeriesInfo($name),'reason'=>'categoria_series','confidence'=>94];
            if ($intent === 'movie') return ['type'=>2,'ext'=>$ext ?: 'mp4','series'=>null,'reason'=>'categoria_filme','confidence'=>94];

            if ($urlIntent === 'live') return ['type'=>1,'ext'=>in_array($ext,self::EXT_LIVE,true)?$ext:'ts','series'=>null,'reason'=>'rota_url_live','confidence'=>92];
            if ($urlIntent === 'series') return ['type'=>5,'ext'=>$ext ?: 'mp4','series'=>self::fallbackSeriesInfo($name),'reason'=>'rota_url_series','confidence'=>90];
            if ($urlIntent === 'movie') return ['type'=>2,'ext'=>$ext ?: 'mp4','series'=>null,'reason'=>'rota_url_movie','confidence'=>90];

            if (in_array($ext, self::EXT_LIVE, true)) return ['type'=>1,'ext'=>$ext,'series'=>null,'reason'=>'extensao_live','confidence'=>88];
            if (in_array($ext, self::EXT_VOD, true)) return ['type'=>2,'ext'=>$ext,'series'=>null,'reason'=>'extensao_vod','confidence'=>78];

            if (self::looksLiveTitle($name, $group)) return ['type'=>1,'ext'=>'ts','series'=>null,'reason'=>'heuristica_live','confidence'=>62];
            if (preg_match('/(?:^|\s|\()(?:(?:19|20)\d{2})(?:\)|\s|$)/u', $name)) return ['type'=>2,'ext'=>$ext ?: 'mp4','series'=>null,'reason'=>'heuristica_filme','confidence'=>55];

            return ['type'=>0,'ext'=>$ext,'series'=>null,'reason'=>'sem_sinal_confiavel','confidence'=>0];
        }

        private static function groupIntent($group)
        {
            $group = html_entity_decode((string)$group, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $group = trim(preg_replace('/\s+/u', ' ', $group));
            if ($group === '') return '';
            if (preg_match('/^(?:canais?|canal|live|tv|r[aá]dios?|radio)(?:\s*[|:\-]|\s|$)/iu', $group)) return 'live';
            if (preg_match('/^(?:s[eé]ries?|series|seriados?|novelas?|doramas?|animes?|cursos?)(?:\s*[|:\-]|\s|$)/iu', $group)) return 'series';
            if (preg_match('/^(?:filmes?|movies?|vod|cinema)(?:\s*[|:\-]|\s|$)/iu', $group)) return 'movie';
            if (preg_match('/^(?:cole[cç][aã]o|colecoes|cole[cç][oõ]es|collection|collections)(?:\s*[|:\-]|\s|$)/iu', $group)) return 'movie';
            if (preg_match('/^(?:shows?|concertos?)(?:\s*[|:\-]|\s|$)/iu', $group)) return 'movie';
            if (preg_match('/\b(?:canais?\s+ao\s+vivo|tv\s+ao\s+vivo|live\s+tv)\b/iu', $group)) return 'live';
            if (preg_match('/\b(?:temporadas?|epis[oó]dios?)\b/iu', $group) && !preg_match('/\b24\s*h\b/iu', $group)) return 'series';
            return '';
        }

        private static function urlIntent($url)
        {
            $path = strtolower((string)(parse_url((string)$url, PHP_URL_PATH) ?: ''));
            if ($path === '') return '';
            if (preg_match('~/(?:live|tv|channel|channels)/~i', $path)) return 'live';
            if (preg_match('~/(?:series|serie|episodes?|episodios?)/~i', $path)) return 'series';
            if (preg_match('~/(?:movie|movies|vod|film|filmes)/~i', $path)) return 'movie';
            return '';
        }

        private static function looksLiveTitle($name, $group)
        {
            $v = trim(preg_replace('/\s+/u', ' ', (string)$name . ' ' . (string)$group));
            return (bool)preg_match('/\b(?:24\s*h|ao\s+vivo|live|canal|tv|radio|r[aá]dio)\b/iu', $v);
        }

        private static function fallbackSeriesInfo($name)
        {
            $title = preg_replace('/\b(?:S\d{1,3}\s*E\d{1,4}|\d{1,3}x\d{1,4}|T(?:emporada)?\s*\d{1,3}\s*EP?\s*\d{1,4})\b/iu', '', (string)$name);
            $title = preg_replace('/\b(?:Temporada|Season)\s*\d{1,3}\b/iu', '', (string)$title);
            $title = self::cleanTitle($title);
            if ($title === '') $title = 'Série importada';

            $season = 1;
            if (preg_match('/\b(?:S|T|Temporada|Season)\s*(\d{1,3})\b/iu', (string)$name, $m)) $season = max(0, (int)$m[1]);
            $episode = 1;
            if (preg_match('/\b(?:EP?|Epis[oó]dio|Episode)\s*(\d{1,4})\b/iu', (string)$name, $m)) $episode = max(1, (int)$m[1]);
            return ['title'=>$title,'season'=>$season,'episode'=>$episode];
        }

        public static function normalizeText($value)
        {
            $value = trim(preg_replace('/\s+/u', ' ', $value));
            return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
        }

        public static function parseM3U($content)
        {
            $results = [];
            $index   = -1;
            preg_match_all(
                '/(?P<tag>#EXTINF:[-1,0])|(?:(?P<prop_key>[-a-z0-9]+)=\"(?P<prop_val>[^\"]+)\")|(?<name>,[^\r\n]+)|(?<url>http[^\s]+)/i',
                $content,
                $matches
            );
            for ($i = 0; $i < count($matches[0]); $i++) {
                if (!empty($matches['tag'][$i])) {
                    $index++;
                } elseif ($index >= 0) {
                    if (!empty($matches['prop_key'][$i])) {
                        $results[$index][strtolower($matches['prop_key'][$i])] = trim($matches['prop_val'][$i]);
                    } elseif (!empty($matches['name'][$i])) {
                        $results[$index]['name'] = trim(substr($matches[0][$i], 1));
                    } elseif (!empty($matches['url'][$i])) {
                        $results[$index]['url'] = str_replace(' ', '%20', trim($matches[0][$i]));
                    }
                }
            }
            return array_filter($results, function ($item) {
                return !empty($item['name']) && !empty($item['url']);
            });
        }

        public static function iterateFile($filePath)
        {
            $handle = @fopen($filePath, 'rb');
            if (!$handle) {
                throw new RuntimeException('Não foi possível abrir a playlist para leitura.');
            }
            $pending = null;
            try {
                while (($line = fgets($handle)) !== false) {
                    $line = trim($line);
                    if ($line === '' || $line === '#EXTM3U') continue;
                    if (strpos($line, '#EXTINF:') === 0) {
                        preg_match_all('/([a-zA-Z0-9_-]+)="([^"]*)"/', $line, $m, PREG_SET_ORDER);
                        $pending = [];
                        foreach ($m as $attr) {
                            $pending[strtolower($attr[1])] = trim($attr[2]);
                        }
                        $comma = strpos($line, ',');
                        $pending['name'] = $comma !== false ? trim(substr($line, $comma + 1)) : '';
                        continue;
                    }
                    if ($pending !== null && preg_match('#^https?://#i', $line)) {
                        $pending['url'] = str_replace(' ', '%20', $line);
                        if ($pending['name'] !== '') yield $pending;
                        $pending = null;
                    }
                }
            } finally {
                fclose($handle);
            }
        }

        public static function analyzeFile($filePath, $mode = 'auto')
        {
            $summary = [
                'file_size'          => @filesize($filePath) ?: 0,
                'total'              => 0,
                'live'               => 0,
                'movies'             => 0,
                'series'             => 0,
                'unknown'            => 0,
                'categories'         => [],
                'series_titles'      => [],
                'seasons'            => [],
                'duplicates_in_file' => 0,
                'warnings'           => []
            ];
            $seen = [];
            foreach (self::iterateFile($filePath) as $item) {
                $summary['total']++;
                $name  = trim(isset($item['name']) ? $item['name'] : '');
                $url   = trim(isset($item['url']) ? $item['url'] : '');
                $group = trim(isset($item['group-title']) ? $item['group-title'] : 'Sem categoria');
                $classification = self::classifyType($url, $name, $group, $mode);
                $type = (int)$classification['type'];
                switch ($type) {
                    case 1:  $summary['live']++;   break;
                    case 2:  $summary['movies']++; break;
                    case 5:
                        $summary['series']++;
                        $info = $classification['series'];
                        if ($info) {
                            $titleKey = self::normalizeText($info['title']);
                            $summary['series_titles'][$titleKey] = $info['title'];
                            $summary['seasons'][$titleKey][(int)$info['season']] = true;
                        }
                        break;
                    default: $summary['unknown']++; break;
                }
                $catKey = self::normalizeText($group);
                if (!isset($summary['categories'][$catKey])) {
                    $summary['categories'][$catKey] = [
                        'name'    => $group,
                        'total'   => 0,
                        'live'    => 0,
                        'movies'  => 0,
                        'series'  => 0,
                        'unknown' => 0
                    ];
                }
                $summary['categories'][$catKey]['total']++;
                $bucket = '';
                switch ($type) {
                    case 1: $bucket = 'live'; break;
                    case 2: $bucket = 'movies'; break;
                    case 5: $bucket = 'series'; break;
                    default: $bucket = 'unknown'; break;
                }
                $summary['categories'][$catKey][$bucket]++;
                $dupKey = hash('sha256', self::normalizeText($url));
                if (isset($seen[$dupKey])) {
                    $summary['duplicates_in_file']++;
                } else {
                    $seen[$dupKey] = true;
                }
            }
            $summary['series_titles_count'] = count($summary['series_titles']);
            $summary['seasons_count'] = array_sum(array_map('count', $summary['seasons']));
            unset($summary['series_titles'], $summary['seasons']);
            uasort($summary['categories'], function ($a, $b) {
                return $b['total'] - $a['total'];
            });
            $summary['categories'] = array_values($summary['categories']);
            if ($summary['unknown'] > 0) {
                $summary['warnings'][] = $summary['unknown'] . ' itens não puderam ser classificados automaticamente.';
            }
            return $summary;
        }

        private function loadCaches()
        {
            $res = $this->db->query("SELECT id, category_name, category_type FROM stream_categories");
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $categoryType = strtolower(trim((string)$row['category_type']));
                    $this->categoryCache[$categoryType][self::normalizeText((string)$row['category_name'])] = (int)$row['id'];
                }
            }

            $res = $this->db->query("SELECT id, title, category_id, seasons FROM series");
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $this->seriesCache[self::normalizeText((string)$row['title'])][(int)$row['category_id']] = (int)$row['id'];
                    $decodedSeasons = json_decode($row['seasons'] ? $row['seasons'] : '[]', true);
                    $this->seriesSeasons[(int)$row['id']] = array_fill_keys(array_map('intval', is_array($decodedSeasons) ? $decodedSeasons : []), true);
                }
            }

            $res = $this->db->query("SELECT id, stream_display_name, stream_source, type FROM streams");
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $type = (int)$row['type'];
                    $this->existingStreamsCache['name'][$type][strtolower($row['stream_display_name'])] = $row['id'];
                    $srcs = json_decode($row['stream_source'], true);
                    if (is_array($srcs)) {
                        foreach ($srcs as $s) {
                            $this->existingStreamsCache['url'][$type][strtolower(trim(str_replace(' ', '%20', $s)))] = $row['id'];
                        }
                    }
                }
            }
        }

        private function loadBouquets(array $bouquetIds)
        {
            foreach ($bouquetIds as $bId) {
                $bId  = (int)$bId;
                $bRow = getBouquet($bId);
                if ($bRow) {
                    $this->bouquetData[$bId] = [
                        'streams' => array_map('intval', json_decode($bRow['bouquet_channels'] ? $bRow['bouquet_channels'] : '[]', true) ?: []),
                        'series'  => array_map('intval', json_decode($bRow['bouquet_series'] ? $bRow['bouquet_series'] : '[]', true) ?: []),
                    ];
                }
            }
        }

        private function resolveCategory($catName, $type)
        {
            $catName = trim($catName) !== '' ? trim($catName) : 'Importação Automática';
            $categoryType = self::categoryTypeForStream($type);
            $key = self::normalizeText($catName);
            if (isset($this->categoryCache[$categoryType][$key])) {
                $this->stats['categories_reused']++;
                if ($this->diagnostics) $this->diagnostics->increment('categories_reused');
                return $this->categoryCache[$categoryType][$key];
            }
            $stmt = $this->sql('criação de categoria', function () {
                return $this->db->prepare("INSERT INTO stream_categories (category_name, category_type, parent_id, cat_order) VALUES (?, ?, 0, 0)");
            });
            $stmt->bind_param("ss", $catName, $categoryType);
            $this->sql('criação de categoria', function () use ($stmt) { $stmt->execute(); });
            $catId = $this->db->insert_id;
            if ($catId <= 0) throw new RuntimeException('A categoria foi executada, mas o banco não retornou um ID válido.');
            $this->categoryCache[$categoryType][$key] = $catId;
            $this->stats['categories_created']++;
            if ($this->diagnostics) {
                $this->diagnostics->increment('categories_created');
                $this->diagnostics->log('success', 'categorias', 'Categoria criada: ' . $catName);
            }
            return $catId;
        }

        private function findExisting($type, $url, $name)
        {
            $urlKey  = strtolower(str_replace(' ', '%20', $url));
            $nameKey = strtolower($name);
            if (isset($this->existingStreamsCache['url'][$type][$urlKey])) {
                return $this->existingStreamsCache['url'][$type][$urlKey];
            }
            if (isset($this->existingStreamsCache['name'][$type][$nameKey])) {
                return $this->existingStreamsCache['name'][$type][$nameKey];
            }
            return null;
        }

        private function processStream(array $item, $serverId, array $options = [])
        {
            $name    = trim(isset($item['name']) ? $item['name'] : '');
            $url     = trim(isset($item['url']) ? $item['url'] : '');
            $catName = trim(isset($item['group-title']) ? $item['group-title'] : 'Importação Automática');
            $icon    = isset($item['tvg-logo']) ? $item['tvg-logo'] : '';

            $classification = self::classifyType($url, $name, $catName, $options['classification'] ?? 'auto');
            $type = $classification['type'];
            $ext  = $classification['ext'];
            $info = $classification['series'];

            if ($type === 0) {
                $this->stats['skipped']++;
                return null;
            }

            $catId = $this->resolveCategory($catName, $type);
            $existingId = $this->findExisting($type, $url, $name);

            $source    = json_encode([$url]);
            $props     = json_encode([
                "movie_image" => $icon,
                "genre"       => $catName,
                "plot"        => "",
                "cast"        => "",
                "rating"      => "",
                "director"    => "",
                "releasedate" => "",
                "tmdb_id"     => "",
            ]);
            $container = json_encode([$ext ? $ext : ($type === 1 ? "ts" : "mp4")]);

            global $rAdminSettings;
            if (!empty($icon) && isset($rAdminSettings['download_images']) && $rAdminSettings['download_images']) {
                if (function_exists('downloadImage')) {
                    $icon = downloadImage($icon);
                }
            }

            if ($existingId) {
                $stmt = $this->db->prepare(
                    "UPDATE streams SET
                        stream_display_name = ?,
                        stream_source = ?,
                        stream_icon = ?,
                        movie_propeties = ?,
                        category_id = ?
                    WHERE id = ?"
                );
                $stmt->bind_param("ssssii", $name, $source, $icon, $props, $catId, $existingId);
                $this->sql('atualização de stream', function () use ($stmt) { $stmt->execute(); });
                if ($stmt->affected_rows < 0) throw new RuntimeException('Falha ao confirmar atualização do stream.');
                $this->stats['updated']++;
                if ($this->diagnostics) $this->diagnostics->increment('channels_updated');
                $streamId = $existingId;
                $this->ensureServerLink($streamId, $serverId);
            } else {
                $now = time();
                $stmt = $this->db->prepare(
                    "INSERT INTO streams
                        (type, category_id, stream_display_name, stream_source, stream_icon,
                         added, movie_propeties, target_container,
                         gen_timestamps, direct_source, movie_symlink,
                         redirect_stream, allow_record, probesize_ondemand)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 1, 1, 1, 128000)"
                );
                $stmt->bind_param("iisssiss", $type, $catId, $name, $source, $icon, $now, $props, $container);
                $this->sql('inserção de stream', function () use ($stmt) { $stmt->execute(); });
                $streamId = $this->db->insert_id;
                if ($streamId <= 0) throw new RuntimeException('O banco não retornou ID após inserir o stream.');

                $stmtSys = $this->db->prepare(
                    "INSERT INTO streams_sys (stream_id, server_id, to_analyze, stream_status) VALUES (?, ?, 0, 0)"
                );
                $stmtSys->bind_param("ii", $streamId, $serverId);
                $this->sql('vínculo do stream ao servidor', function () use ($stmtSys) { $stmtSys->execute(); });

                $this->existingStreamsCache['name'][$type][strtolower($name)] = $streamId;
                $this->existingStreamsCache['url'][$type][strtolower(str_replace(' ', '%20', $url))] = $streamId;

                $this->stats['inserted']++;
                if ($this->diagnostics) $this->diagnostics->increment('channels_imported');
            }

            switch ($type) {
                case 1: $this->stats['live']++; break;
                case 2: $this->stats['movies']++; break;
                case 5: $this->stats['series']++; break;
            }

            if ($type === 5 && $info) {
                $this->processSeries($info, $catId, $catName, $streamId, $icon);
            }

            $this->addToBouquets($type, $streamId);

            return $streamId;
        }

        private function processSeries(array $info, $catId, $catName, $streamId, $icon)
        {
            $title  = $info['title'];
            $season = $info['season'];
            $epNum  = $info['episode'];

            $seriesKey = self::normalizeText($title);
            if (!isset($this->seriesCache[$seriesKey][$catId])) {
                $stmt = $this->db->prepare(
                    "INSERT INTO series
                        (title, category_id, cover, cover_big, genre, plot, cast, rating,
                         director, releaseDate, last_modified, tmdb_id, seasons,
                         episode_run_time, backdrop_path, youtube_trailer)
                    VALUES (?, ?, ?, ?, ?, '', '', 0, '', '', ?, 0, '[]', 0, '', '')"
                );
                $now = time();
                $stmt->bind_param("sisssi", $title, $catId, $icon, $icon, $catName, $now);
                $stmt->execute();

                $seriesId = $this->db->insert_id;
                $this->seriesCache[$seriesKey][$catId] = $seriesId;
            } else {
                $seriesId = $this->seriesCache[$seriesKey][$catId];
                $this->db->query("UPDATE series SET last_modified = " . time() . " WHERE id = " . (int)$seriesId);
            }

            $stmtFind = $this->db->prepare(
                "SELECT id FROM series_episodes WHERE series_id = ? AND season_num = ? AND sort = ? LIMIT 1"
            );
            $stmtFind->bind_param("iii", $seriesId, $season, $epNum);
            $stmtFind->execute();
            $episodeRow = $stmtFind->get_result()->fetch_assoc();
            if ($episodeRow) {
                $episodeId = (int)$episodeRow['id'];
                $stmtEpisode = $this->db->prepare("UPDATE series_episodes SET stream_id = ? WHERE id = ?");
                $stmtEpisode->bind_param("ii", $streamId, $episodeId);
            } else {
                $stmtEpisode = $this->db->prepare(
                    "INSERT INTO series_episodes (season_num, series_id, stream_id, sort) VALUES (?, ?, ?, ?)"
                );
                $stmtEpisode->bind_param("iiii", $season, $seriesId, $streamId, $epNum);
            }
            $stmtEpisode->execute();

            $this->seriesSeasons[$seriesId][(int)$season] = true;
            $this->touchedSeries[$seriesId] = true;

            foreach ($this->bouquetData as $bId => &$data) {
                if (!in_array($seriesId, $data['series'], true)) {
                    $data['series'][] = $seriesId;
                }
            }
        }

        private function flushSeriesSeasons()
        {
            foreach (array_keys($this->touchedSeries) as $seriesId) {
                $seasons = array_map('intval', array_keys($this->seriesSeasons[$seriesId] ?: []));
                sort($seasons, SORT_NUMERIC);
                $json = json_encode($seasons);
                $stmt = $this->db->prepare('UPDATE series SET seasons = ?, last_modified = ? WHERE id = ?');
                $now = time();
                $stmt->bind_param('sii', $json, $now, $seriesId);
                $stmt->execute();
            }
        }

        private function ensureServerLink($streamId, $serverId)
        {
            $stmt = $this->db->prepare("INSERT IGNORE INTO streams_sys (stream_id, server_id, to_analyze, stream_status) VALUES (?, ?, 0, 0)");
            if (!$stmt) throw new RuntimeException('Não foi possível preparar o vínculo do stream ao servidor.');
            $stmt->bind_param('ii', $streamId, $serverId);
            $this->sql('vínculo do stream existente ao servidor', function () use ($stmt) { $stmt->execute(); });
        }

        private function addToBouquets($type, $streamId)
        {
            foreach ($this->bouquetData as $bId => &$data) {
                if ($type === 5) continue;
                if (!in_array($streamId, $data['streams'], true)) {
                    $data['streams'][] = $streamId;
                }
            }
        }

        private function saveBouquets()
        {
            foreach ($this->bouquetData as $bId => $data) {
                $streamsJson = json_encode(array_values(array_map('intval', $data['streams'])));
                $seriesJson  = json_encode(array_values(array_map('intval', $data['series'])));
                $stmt = $this->db->prepare(
                    "UPDATE bouquets SET bouquet_channels = ?, bouquet_series = ? WHERE id = ?"
                );
                $stmt->bind_param("ssi", $streamsJson, $seriesJson, $bId);
                $stmt->execute();
            }
        }

        public function executeFile($filePath, $serverId, array $bouquetIds, $batchSize = 750, array $options = [])
        {
            if (!is_readable($filePath)) throw new RuntimeException('A playlist não pode ser lida: ' . basename($filePath));
            $batchSize = max(100, min(1500, (int)$batchSize));
            if ($this->diagnostics) $this->diagnostics->setStage('carregamento de cache', 'Carregando categorias, séries e streams existentes.');
            $this->loadCaches();
            $this->loadBouquets($bouquetIds);
            $processedInBatch = 0;
            $batchCount = 0;
            $this->db->query("SET SESSION innodb_lock_wait_timeout = 8");
            $this->db->query("SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED");
            $this->batchStartedAt = microtime(true);
            $this->db->begin_transaction();
            if ($this->diagnostics) $this->diagnostics->setStage('importação', 'Processando itens reais da playlist em lotes.');
            try {
                foreach (self::iterateFile($filePath) as $item) {
                    $this->stats['total']++;
                    if ($this->diagnostics) $this->diagnostics->increment('channels_found');
                    $streamId = null;
                    $itemCompleted = false;
                    for ($attempt = 1; $attempt <= self::LOCK_RETRIES && !$itemCompleted; $attempt++) {
                        $savepoint = 'm3u_item_' . $attempt;
                        $this->db->query("SAVEPOINT " . $savepoint);
                        try {
                            $streamId = $this->processStream($item, $serverId, $options);
                            $this->db->query("RELEASE SAVEPOINT " . $savepoint);
                            $itemCompleted = true;
                        } catch (Throwable $itemError) {
                            try { $this->db->query("ROLLBACK TO SAVEPOINT " . $savepoint); } catch (Throwable $ignored) {}
                            $isLockError = in_array((int)$itemError->getCode(), [1205, 1213], true)
                                || stripos($itemError->getMessage(), 'lock wait timeout') !== false
                                || stripos($itemError->getMessage(), 'deadlock') !== false;
                            if ($isLockError && $attempt < self::LOCK_RETRIES) {
                                $this->stats['warnings']++;
                                usleep(150000 * $attempt);
                                continue;
                            }
                            $this->stats['errors']++;
                            $name = trim(isset($item['name']) ? $item['name'] : 'item sem nome');
                            $this->log('error', 'processamento do item', $name . ': ' . $itemError->getMessage(), $itemError);
                            break;
                        }
                    }
                    if ($streamId === null && $this->diagnostics) $this->diagnostics->increment('channels_skipped');
                    $processedInBatch++;
                    if ($processedInBatch >= $batchSize) {
                        $this->db->commit();
                        $batchSeconds = microtime(true) - $this->batchStartedAt;
                        $this->batchSecondsTotal += $batchSeconds;
                        $batchCount++;
                        if ($this->diagnostics) {
                            $this->diagnostics->increment('batches');
                            $this->diagnostics->update([
                                'status' => 'executando',
                                'average_batch_seconds' => $this->batchSecondsTotal / $batchCount,
                                'message' => 'Lote ' . $batchCount . ' confirmado no banco. ' . $this->stats['total'] . ' itens processados.'
                            ]);
                            $this->diagnostics->log('success', 'confirmação de lote', 'Lote ' . $batchCount . ' gravado no banco com sucesso.');
                        }
                        $this->db->begin_transaction();
                        $processedInBatch = 0;
                        $this->batchStartedAt = microtime(true);
                    }
                }
                if ($this->diagnostics) $this->diagnostics->setStage('finalização', 'Salvando temporadas e buquês.');
                $this->flushSeriesSeasons();
                $this->saveBouquets();
                $this->db->commit();
                foreach ($bouquetIds as $bId) {
                    try { if (function_exists('scanBouquet')) scanBouquet((int)$bId); }
                    catch (Throwable $scanError) {
                        $this->stats['warnings']++;
                        $this->log('warning', 'atualização de buquê', 'Importação salva, mas o scan do buquê ' . (int)$bId . ' falhou: ' . $scanError->getMessage(), $scanError);
                    }
                }
                return $this->stats;
            } catch (Throwable $e) {
                try { $this->db->rollback(); } catch (Throwable $ignored) {}
                $this->log('error', 'falha da importação', $e->getMessage(), $e);
                return ['error' => 'Erro durante a importação após ' . $this->stats['total'] . ' itens: ' . $e->getMessage()] + $this->stats;
            }
        }

        public function execute($m3uContent, $serverId, array $bouquetIds)
        {
            $items = self::parseM3U($m3uContent);
            $this->stats['total'] = count($items);
            if ($this->stats['total'] === 0) {
                return ['error' => 'Playlist vazia ou sem itens válidos.'];
            }
            $this->loadCaches();
            $this->loadBouquets($bouquetIds);
            $this->db->begin_transaction();
            try {
                foreach ($items as $item) {
                    $this->processStream($item, $serverId);
                }
                $this->flushSeriesSeasons();
                $this->saveBouquets();
                $this->db->commit();
                foreach ($bouquetIds as $bId) {
                    if (function_exists('scanBouquet')) scanBouquet((int)$bId);
                }
                return $this->stats;
            } catch (Exception $e) {
                $this->db->rollback();
                return ['error' => 'Erro crítico durante a importação: ' . $e->getMessage()];
            }
        }

        public function getStats()
        {
            return $this->stats;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // FUNÇÕES AUXILIARES DE UPLOAD E TOKEN
    // ═══════════════════════════════════════════════════════════════════════
    if (!function_exists('csM3UTempDir')) {
    function csM3UTempDir()
    {
        $sessionKey = preg_replace('/[^a-zA-Z0-9_-]/', '', session_id());
        $base = __DIR__ . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'm3u_uploads' . DIRECTORY_SEPARATOR . $sessionKey;
        if (!is_dir($base) && !@mkdir($base, 0750, true) && !is_dir($base)) {
            throw new RuntimeException('Não foi possível criar o diretório temporário de upload.');
        }
        return $base;
    }
    }


    if (!function_exists('csM3UTokenPath')) {
    function csM3UTokenPath($token, $suffix = '.m3u')
    {
        if (!preg_match('/^[a-f0-9]{32}$/', $token)) {
            throw new RuntimeException('Token de upload inválido.');
        }
        return csM3UTempDir() . DIRECTORY_SEPARATOR . $token . $suffix;
    }
    }


    if (!function_exists('csM3UJson')) {
    function csM3UJson(array $payload, $status = 200)
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
    }


    if (!function_exists('csM3UCleanup')) {
    function csM3UCleanup($maxAge = 86400)
    {
        $dir = csM3UTempDir();
        foreach (glob($dir . DIRECTORY_SEPARATOR . '*') ?: [] as $file) {
            if (is_file($file) && filemtime($file) < time() - $maxAge) {
                @unlink($file);
            }
        }
    }
    }


    csM3UCleanup();

    // ═══════════════════════════════════════════════════════════════════════
    // API AJAX
    // ═══════════════════════════════════════════════════════════════════════
    if (isset($_GET['import_status'])) {
        try {
            $diag = CSM3UImportDiagnostics::open((string)$_GET['import_status']);
            csM3UJson(['ok' => true, 'diagnostic' => $diag->snapshot()]);
        } catch (Throwable $e) {
            csM3UJson(['ok' => false, 'error' => $e->getMessage()], 404);
        }
    }

    if (isset($_POST['ajax_action'])) {
        try {
            $action = (string)$_POST['ajax_action'];
            if ($action === 'upload_chunk') {
                $token = (string)($_POST['upload_token'] ?? '');
                $index = max(0, (int)($_POST['chunk_index'] ?? 0));
                $total = max(1, (int)($_POST['chunk_total'] ?? 1));
                $expectedSize = max(0, (int)($_POST['file_size'] ?? 0));
                $fileName = basename((string)($_POST['file_name'] ?? 'playlist.m3u'));
                if (!isset($_FILES['chunk']) || $_FILES['chunk']['error'] !== UPLOAD_ERR_OK) {
                    throw new RuntimeException('Falha ao receber a parte ' . ($index + 1) . ' do arquivo.');
                }
                $path = csM3UTokenPath($token);
                $metaPath = csM3UTokenPath($token, '.json');
                $previous = is_file($metaPath) ? json_decode(file_get_contents($metaPath), true) : [];
                $receivedParts = (int)($previous['received'] ?? 0);
                if ($index !== $receivedParts) {
                    throw new RuntimeException('Parte fora de ordem. Esperada: ' . ($receivedParts + 1) . '. Recebida: ' . ($index + 1) . '.');
                }
                if ($index === 0 && $expectedSize > 0) {
                    $free = @disk_free_space(dirname($path));
                    $reserve = max(268435456, (int)ceil($expectedSize * 0.05));
                    if ($free !== false && $free < ($expectedSize + $reserve)) {
                        throw new RuntimeException('Espaço em disco insuficiente para receber a playlist. Necessário: ' . round(($expectedSize + $reserve) / 1073741824, 2) . ' GB.');
                    }
                }
                $mode = $index === 0 ? 'wb' : 'ab';
                $out = fopen($path, $mode);
                $in = fopen($_FILES['chunk']['tmp_name'], 'rb');
                if (!$out || !$in) throw new RuntimeException('Não foi possível gravar o arquivo temporário.');
                if (!flock($out, LOCK_EX)) throw new RuntimeException('Não foi possível bloquear o arquivo temporário para escrita.');
                $written = stream_copy_to_stream($in, $out);
                fflush($out); flock($out, LOCK_UN);
                fclose($in); fclose($out);
                if ($written === false || $written <= 0) throw new RuntimeException('A parte recebida não pôde ser gravada.');
                clearstatcache(true, $path);
                $meta = ['token' => $token, 'name' => $fileName, 'expected_size' => $expectedSize, 'parts' => $total, 'received' => $index + 1, 'size' => filesize($path), 'updated_at' => time()];
                file_put_contents($metaPath, json_encode($meta, JSON_UNESCAPED_UNICODE), LOCK_EX);
                csM3UJson(['ok' => true, 'received' => $index + 1, 'total' => $total, 'size' => $meta['size']]);
            } elseif ($action === 'fetch_remote') {
                $token = (string)($_POST['upload_token'] ?? '');
                $url = trim((string)($_POST['m3u_url'] ?? ''));
                if (!M3UImporter::isValidUrl($url)) throw new RuntimeException('URL remota inválida ou não permitida.');
                $path = csM3UTokenPath($token);
                $out = fopen($path, 'wb');
                if (!$out) throw new RuntimeException('Não foi possível criar o arquivo temporário.');
                $ch = curl_init($url);
                curl_setopt_array($ch, [CURLOPT_FILE => $out, CURLOPT_FOLLOWLOCATION => true, CURLOPT_CONNECTTIMEOUT => 20, CURLOPT_TIMEOUT => 0, CURLOPT_USERAGENT => 'CS Player M3U Importer/6.0', CURLOPT_FAILONERROR => true]);
                $ok = curl_exec($ch);
                $error = curl_error($ch);
                curl_close($ch); fclose($out);
                if (!$ok || !is_file($path) || filesize($path) === 0) { @unlink($path); throw new RuntimeException('Falha ao baixar a playlist: ' . $error); }
                csM3UJson(['ok' => true, 'size' => filesize($path)]);
            } elseif ($action === 'analyze') {
                $token = (string)($_POST['upload_token'] ?? '');
                $path = csM3UTokenPath($token);
                if (!is_file($path) || filesize($path) === 0) throw new RuntimeException('Arquivo temporário não encontrado ou vazio.');
                $metaPath = csM3UTokenPath($token, '.json');
                $meta = is_file($metaPath) ? json_decode(file_get_contents($metaPath), true) : [];
                if (!empty($meta['parts']) && (int)($meta['received'] ?? 0) !== (int)$meta['parts']) {
                    throw new RuntimeException('O upload ainda não foi concluído.');
                }
                if (!empty($meta['expected_size']) && (int)filesize($path) !== (int)$meta['expected_size']) {
                    throw new RuntimeException('O tamanho recebido não corresponde ao arquivo original. Reenvie a playlist.');
                }
                $mode = (string)($_POST['classification_mode'] ?? 'auto');
                $analysis = M3UImporter::analyzeFile($path, $mode);
                file_put_contents(csM3UTokenPath($token, '.analysis.json'), json_encode($analysis, JSON_UNESCAPED_UNICODE), LOCK_EX);
                csM3UJson(['ok' => true, 'analysis' => $analysis]);
            } elseif ($action === 'prepare_import') {
                $token = (string)($_POST['upload_token'] ?? '');
                $path = csM3UTokenPath($token);
                $analysisPath = csM3UTokenPath($token, '.analysis.json');
                if (!is_file($path) || !is_readable($path) || filesize($path) === 0) throw new RuntimeException('Playlist temporária ausente, vazia ou sem permissão de leitura.');
                if (!is_file($analysisPath)) throw new RuntimeException('A análise prévia não foi encontrada.');
                $metaPath = csM3UTokenPath($token, '.json');
                $meta = is_file($metaPath) ? json_decode(file_get_contents($metaPath), true) : [];
                $analysis = json_decode(file_get_contents($analysisPath), true) ?: [];
                $diag = CSM3UImportDiagnostics::create(!empty($meta['name']) ? 'arquivo' : 'URL', (string)($meta['name'] ?? basename($path)));
                $diag->update(['status' => 'preparado', 'categories_found' => count($analysis['categories'] ?? []), 'channels_expected' => (int)($analysis['total'] ?? 0)]);
                csM3UJson(['ok' => true, 'job_id' => $diag->id()]);
            } elseif ($action === 'start_import') {
                $token = (string)($_POST['upload_token'] ?? '');
                $path = csM3UTokenPath($token);
                $analysisPath = csM3UTokenPath($token, '.analysis.json');
                if (!is_file($path) || !is_readable($path) || filesize($path) === 0) throw new RuntimeException('Playlist temporária ausente, vazia ou sem permissão de leitura.');
                if (!is_file($analysisPath)) throw new RuntimeException('A análise prévia não foi encontrada.');
                $serverId = (int)($_POST['servers'] ?? 0);
                if ($serverId <= 0) throw new RuntimeException('Selecione um servidor de streaming válido.');
                $bouquetIds = array_values(array_filter(array_map('intval', $_POST['bouquets'] ?? [])));
                $options = [
                    'classification' => (string)($_POST['classification_mode'] ?? 'auto'),
                ];
                $metaPath = csM3UTokenPath($token, '.json');
                $jobId = (string)($_POST['job_id'] ?? '');
                $diag = CSM3UImportDiagnostics::open($jobId);
                if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
                register_shutdown_function(function () use ($diag) {
                    $last = error_get_last();
                    if ($last && in_array($last['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
                        $diag->fail(new ErrorException($last['message'], 0, $last['type'], $last['file'], $last['line']), 'erro fatal do PHP');
                    }
                });
                $analysis = json_decode(file_get_contents($analysisPath), true) ?: [];
                $diag->update(['status' => 'executando', 'categories_found' => count($analysis['categories'] ?? []), 'channels_found' => 0, 'channels_expected' => (int)($analysis['total'] ?? 0)]);
                $importer = new M3UImporter($db, $diag);
                $result = $importer->executeFile($path, $serverId, $bouquetIds, 50, $options);
                if (isset($result['error'])) {
                    $diag->finish('falha', $result['error']);
                } else {
                    $diag->update([
                        'channels_found' => (int)($result['total'] ?? 0),
                        'channels_imported' => (int)($result['inserted'] ?? 0),
                        'channels_updated' => (int)($result['updated'] ?? 0),
                        'channels_skipped' => (int)($result['skipped'] ?? 0),
                        'categories_created' => (int)($result['categories_created'] ?? 0),
                        'categories_reused' => (int)($result['categories_reused'] ?? 0),
                        'sql_queries' => (int)($result['sql_queries'] ?? 0),
                    ]);
                    $finalStatus = ((int)($result['errors'] ?? 0) > 0 || (int)($result['warnings'] ?? 0) > 0) ? 'concluído_com_avisos' : 'sucesso';
                    $diag->finish($finalStatus, 'Importação concluída e confirmada no banco de dados.');
                    @unlink($path); @unlink($analysisPath); @unlink($metaPath);
                }
                csM3UJson(['ok' => !isset($result['error']), 'job_id' => $jobId, 'result' => $result], isset($result['error']) ? 500 : 200);
            } else {
                throw new RuntimeException('Ação de importação desconhecida.');
            }
        } catch (Throwable $e) {
            csM3UJson(['ok' => false, 'error' => $e->getMessage()], 400);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DO FORMULÁRIO CLÁSSICO (POST)
    // ═══════════════════════════════════════════════════════════════════════
    if (isset($_POST["submit_update"])) {
        set_time_limit(0);
        ignore_user_abort(true);
        ini_set('mysql.connect_timeout', '0');
        ini_set('max_execution_time', '0');
        ini_set('default_socket_timeout', '300');

        try {
            $token = (string)($_POST['upload_token'] ?? '');
            $filePath = csM3UTokenPath($token);
            if (!is_file($filePath) || filesize($filePath) === 0) {
                throw new RuntimeException('Faça o upload e conclua a análise antes de importar.');
            }
            $analysisPath = csM3UTokenPath($token, '.analysis.json');
            if (!is_file($analysisPath)) {
                throw new RuntimeException('A análise prévia é obrigatória antes da importação.');
            }
            $serverId = (int)($_POST['servers'] ?? 0);
            if ($serverId <= 0) throw new RuntimeException('Selecione um servidor de streaming válido.');
            $bouquetIds = array_values(array_filter(array_map('intval', $_POST['bouquets'] ?? [])));
            $options = ['classification' => (string)($_POST['classification_mode'] ?? 'auto')];
            $importer = new M3UImporter($db);
            $_RESULT = $importer->executeFile($filePath, $serverId, $bouquetIds, 50, $options);
            if (!isset($_RESULT['error'])) {
                @unlink($filePath); @unlink($analysisPath); @unlink(csM3UTokenPath($token, '.json'));
            }
        } catch (Throwable $e) {
            $_RESULT = ['error' => $e->getMessage()];
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // CARREGAMENTO DE DADOS PARA O FORMULÁRIO
    // ═══════════════════════════════════════════════════════════════════════
    $rServers = function_exists('getStreamingServers') ? getStreamingServers(true) : [];

    $rBouquets = [];
    $res = $db->query("SELECT id, bouquet_name FROM bouquets ORDER BY bouquet_order ASC");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $rBouquets[] = $row;
        }
    }

    $rCounts = ['live' => 0, 'movies' => 0, 'series' => 0];
    $res = $db->query("SELECT type, COUNT(*) as cnt FROM streams GROUP BY type");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $t = (int)$row['type'];
            switch ($t) {
                case 1:  $rCounts['live']   = (int)$row['cnt']; break;
                case 2:  $rCounts['movies'] = (int)$row['cnt']; break;
                case 5:  $rCounts['series'] = (int)$row['cnt']; break;
            }
        }
    }

    $rSidebar = isset($rSettings["sidebar"]) ? (bool)$rSettings["sidebar"] : false;
    include ($rSidebar ? "header_sidebar.php" : "header.php");

} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo "<h1>Erro interno no servidor</h1>";
    echo "<p>Ocorreu uma falha ao carregar o módulo de importação.</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<p>Verifique os logs do PHP para mais detalhes.</p>";
    exit;
}

// ═══════════════════════════════════════════════════════════════════════════
// INÍCIO DO HTML E INTERFACE
// ═══════════════════════════════════════════════════════════════════════════
?>
<style>
.boxed-layout-ext { padding: 10px; }
.card-stats { border-left: 4px solid; transition: transform 0.2s; }
.card-stats:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
.card-stats.live { border-left-color: #4fc6e1; }
.card-stats.movies { border-left-color: #81c868; }
.card-stats.series { border-left-color: #03a9f4; }
.card-stats.radio { border-left-color: #ab8ce4; }
.stat-number { font-size: 2rem; font-weight: 700; line-height: 1; }
.stat-label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; color: #868e96; }
.upload-zone {
    border: 2px dashed #dee2e6;
    border-radius: 8px;
    padding: 30px 20px;
    text-align: center;
    transition: all 0.3s;
    cursor: pointer;
    background: #f8f9fa;
}
.upload-zone:hover, .upload-zone.dragover {
    border-color: #4fc6e1;
    background: #e8f4f8;
}
.upload-zone i { font-size: 2.5rem; color: #adb5bd; margin-bottom: 10px; }
.upload-zone:hover i { color: #4fc6e1; }
.btn-import {
    background: linear-gradient(135deg, #4fc6e1 0%, #03a9f4 100%);
    border: none;
    color: #fff;
    font-weight: 600;
    padding: 12px 40px;
    font-size: 1rem;
    border-radius: 6px;
    letter-spacing: 0.5px;
    transition: all 0.3s;
}
.btn-import:hover {
    background: linear-gradient(135deg, #03a9f4 0%, #4fc6e1 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 15px rgba(79,198,225,0.4);
    color: #fff;
}
.badge-count {
    font-size: 0.7rem;
    padding: 3px 8px;
    border-radius: 10px;
    font-weight: 600;
}
.section-title {
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #868e96;
    margin-bottom: 15px;
    padding-bottom: 8px;
    border-bottom: 1px solid #eee;
}
</style>

<div class="<?= $rSidebar ? 'content-page' : 'wrapper' ?> boxed-layout-ext">
    <div class="container-fluid">
        <!-- HEADER -->
        <div class="row">
            <div class="col-xl-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li>
                                <a href="./dashboard.php">
                                    <button type="button" class="btn btn-primary waves-effect waves-light btn-sm">
                                        <i class="mdi mdi-keyboard-backspace"></i> Voltar
                                    </button>
                                </a>
                            </li>
                        </ol>
                    </div>
                    <h4 class="page-title">
                        <i class="mdi mdi-cloud-upload" style="color:#4fc6e1;"></i>
                        Importação M3U Ultra Pro v5.0
                        <span class="badge badge-info ml-2" style="font-size:0.7rem;">PHP 7.4-8.4</span>
                    </h4>
                </div>
            </div>
        </div>

        <!-- MENSAGENS DE RESULTADO -->
        <?php if (isset($_RESULT) && !isset($_RESULT["error"])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <strong><i class="mdi mdi-check-circle"></i> Importação Concluída com Sucesso!</strong>
                <div class="mt-2" style="font-size:0.9rem;">
                    <span class="badge badge-primary badge-count">Total: <?= intval($_RESULT["total"]) ?></span>
                    <span class="badge badge-success badge-count">Inseridos: <?= intval($_RESULT["inserted"]) ?></span>
                    <span class="badge badge-warning badge-count">Atualizados: <?= intval($_RESULT["updated"]) ?></span>
                    <span class="badge badge-secondary badge-count">Ignorados: <?= intval($_RESULT["skipped"]) ?></span>
                    <br>
                    <span class="badge badge-info badge-count">Live: <?= intval($_RESULT["live"] ?? 0) ?></span>
                    <span class="badge badge-success badge-count">Filmes: <?= intval($_RESULT["movies"] ?? 0) ?></span>
                    <span class="badge badge-primary badge-count">Séries: <?= intval($_RESULT["series"] ?? 0) ?></span>
                </div>
            </div>
        <?php elseif (isset($_RESULT["error"])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <strong><i class="mdi mdi-alert-circle"></i> Erro na Importação</strong>
                <div class="mt-1"><?= htmlspecialchars($_RESULT["error"]) ?></div>
            </div>
        <?php endif; ?>

        <!-- FORMULÁRIO PRINCIPAL -->
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <form action="./m3u_update_nodup.php" method="POST" id="importForm">
                            <input type="hidden" name="upload_token" id="upload_token" value="">
                            <div class="row">
                                <!-- SELEÇÃO DE SERVIDOR E BUQUÊS -->
                                <div class="col-lg-6">
                                    <div class="section-title"><i class="mdi mdi-server"></i> Destino</div>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label class="font-weight-bold">Servidor de Streaming</label>
                                                <select name="servers" class="form-control" data-toggle="select2">
                                                    <?php if (empty($rServers)): ?>
                                                        <option value="">Nenhum servidor ativo</option>
                                                    <?php else: ?>
                                                        <?php foreach ($rServers as $srv): ?>
                                                            <option value="<?= intval($srv["id"]) ?>"><?= htmlspecialchars($srv["server_name"]) ?> (<?= htmlspecialchars($srv["server_ip"]) ?>)</option>
                                                        <?php endforeach; ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label class="font-weight-bold">Buquês de Destino</label>
                                                <select name="bouquets[]" class="form-control select2-multiple" multiple data-toggle="select2" data-placeholder="Selecione os buquês...">
                                                    <?php if (empty($rBouquets)): ?>
                                                        <option value="">Nenhum buquê disponível</option>
                                                    <?php else: ?>
                                                        <?php foreach ($rBouquets as $b): ?>
                                                            <option value="<?= intval($b['id']) ?>"><?= htmlspecialchars($b['bouquet_name']) ?></option>
                                                        <?php endforeach; ?>
                                                    <?php endif; ?>
                                                </select>
                                                <small class="text-muted">Selecione um ou mais buquês para adicionar o conteúdo importado.</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- UPLOAD M3U -->
                                <div class="col-lg-6">
                                    <div class="section-title"><i class="mdi mdi-file-upload"></i> Fonte M3U</div>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label class="font-weight-bold">Arquivo M3U Local</label>
                                                <div class="upload-zone" id="uploadZone">
                                                    <i class="mdi mdi-cloud-upload-outline"></i>
                                                    <p class="mb-1 font-weight-bold">Arraste o arquivo aqui ou clique para selecionar</p>
                                                    <small class="text-muted">Formatos aceitos: .m3u, .m3u8</small>
                                                </div>
                                                <input type="file" class="form-control mt-2" name="m3u_file" id="m3u_file" accept=".m3u,.m3u8,.txt" style="position:absolute;left:-10000px;width:1px;height:1px;opacity:0;">
                                                <small class="text-muted" id="fileName"></small>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label class="font-weight-bold">URL Remota M3U</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><i class="mdi mdi-link"></i></span>
                                                    </div>
                                                    <input type="url" class="form-control" name="m3u_url" id="m3u_url" placeholder="http://servidor.com/lista.m3u">
                                                </div>
                                                <small class="text-muted">Opcional. Use arquivo local, URL remota ou ambos; o arquivo local terá prioridade.</small>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label class="font-weight-bold">Modo avançado de separação</label>
                                                <select name="classification_mode" id="classification_mode" class="form-control">
                                                    <option value="auto" selected>Automático: canais, filmes, séries e episódios</option>
                                                    <option value="live">Forçar tudo como canais (Live TV)</option>
                                                    <option value="movie">Forçar tudo como filmes (VOD)</option>
                                                    <option value="series">Forçar tudo como séries/episódios</option>
                                                </select>
                                                <small class="text-muted">No modo automático, grupo, extensão e padrões S01E01/1x01 são usados para separar o conteúdo.</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-3" id="analysisPanel" style="display:none;">
                                <div class="col-12">
                                    <div class="alert alert-info mb-0">
                                        <h5><i class="mdi mdi-chart-box-outline"></i> Análise concluída</h5>
                                        <div id="analysisSummary"></div>
                                        <div class="table-responsive mt-3" style="max-height:320px;">
                                            <table class="table table-sm table-striped mb-0">
                                                <thead><tr><th>Categoria</th><th>Total</th><th>Live</th><th>Filmes</th><th>Episódios</th><th>Não classificados</th></tr></thead>
                                                <tbody id="analysisCategories"></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- BOTÃO DE SUBMISSÃO -->
                            <div class="row mt-3">
                                <div class="col-12 text-center">
                                    <button type="submit" name="submit_update" class="btn btn-import" id="btnSubmit">
                                        <i class="mdi mdi-magnify"></i> ANALISAR PLAYLIST
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4" id="diagnosticPanel" style="display:none;">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center flex-wrap">
                            <h4><i class="mdi mdi-pulse"></i> Diagnóstico real da importação</h4>
                            <span class="badge badge-info" id="diagStatus">Aguardando</span>
                        </div>
                        <div class="row mt-2" id="diagMetrics"></div>
                        <div class="progress mt-2" style="height:12px;"><div class="progress-bar progress-bar-striped progress-bar-animated" id="diagProgress" style="width:0%"></div></div>
                        <div class="mt-3 p-2" id="diagLogs" style="height:340px;overflow:auto;background:#111;color:#ddd;border-radius:6px;font-family:monospace;font-size:12px;"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- DASHBOARD DE ESTATÍSTICAS -->
        <div class="row mt-4">
            <div class="col-md-3">
                <div class="card card-stats live text-center p-3">
                    <div class="stat-number text-primary"><?= number_format($rCounts['live']) ?></div>
                    <div class="stat-label">Canais (Live TV)</div>
                    <small class="text-muted">m3u8, ts</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-stats movies text-center p-3">
                    <div class="stat-number text-success"><?= number_format($rCounts['movies']) ?></div>
                    <div class="stat-label">Filmes (VOD)</div>
                    <small class="text-muted">mp4, mkv, avi</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-stats series text-center p-3">
                    <div class="stat-number text-info"><?= number_format($rCounts['series']) ?></div>
                    <div class="stat-label">Séries</div>
                    <small class="text-muted">Auto-Temporadas</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-stats radio text-center p-3">
                    <div class="stat-number" style="color:#ab8ce4;"><?= count($rBouquets) ?></div>
                    <div class="stat-label">Buquês Ativos</div>
                    <small class="text-muted">Organização</small>
                </div>
            </div>
        </div>

        <!-- INFORMAÇÕES -->
        <div class="row mt-4">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="mdi mdi-information-outline"></i> Como Funciona a Importação Inteligente</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="d-flex">
                                    <div class="mr-3"><i class="mdi mdi-lightning-bolt text-primary" style="font-size:1.5rem;"></i></div>
                                    <div>
                                        <strong>Detecção Automática</strong>
                                        <p class="small text-muted mb-0">Identifica canais (m3u8/ts), filmes (mp4/mkv) e séries automaticamente pela extensão da URL.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex">
                                    <div class="mr-3"><i class="mdi mdi-duplicate text-success" style="font-size:1.5rem;"></i></div>
                                    <div>
                                        <strong>Anti-Duplicidade</strong>
                                        <p class="small text-muted mb-0">Verifica duplicidade por URL e por nome antes de inserir. Atualiza registros existentes.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex">
                                    <div class="mr-3"><i class="mdi mdi-television-classic text-info" style="font-size:1.5rem;"></i></div>
                                    <div>
                                        <strong>Séries Inteligentes</strong>
                                        <p class="small text-muted mb-0">Detecta padrões S01E01, 1x01, Season 1 Episode 1 e organiza temporadas automaticamente.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ($rSidebar) { echo "</div>"; } ?>
<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
        </div>
    </div>
</footer>
<!-- end Footer -->
<script src="assets/js/vendor.min.js"></script>
<script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
<script src="assets/libs/jquery-nice-select/jquery.nice-select.min.js"></script>
<script src="assets/libs/switchery/switchery.min.js"></script>
<script src="assets/libs/select2/select2.min.js"></script>
<script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
<script src="assets/js/app.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var uploadZone = document.getElementById('uploadZone');
        var fileInput = document.getElementById('m3u_file');
    if (fileInput) {
        fileInput.removeAttribute('disabled');
        fileInput.tabIndex = -1;
    }
    var fileName = document.getElementById('fileName');
    var form = document.getElementById('importForm');
    var btnSubmit = document.getElementById('btnSubmit');
    var tokenInput = document.getElementById('upload_token');
    var analyzed = false;
    var INITIAL_CHUNK_SIZE = 16 * 1024 * 1024;
        var MIN_CHUNK_SIZE = 512 * 1024;

    function token() {
        var bytes = new Uint8Array(16);
        if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
            window.crypto.getRandomValues(bytes);
        } else {
            for (var i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
        }
        return Array.from(bytes).map(function(b) { return b.toString(16).padStart(2, '0'); }).join('');
    }

    function humanSize(bytes) {
        var units = ['B', 'KB', 'MB', 'GB', 'TB'];
        var value = Number(bytes || 0), i = 0;
        while (value >= 1024 && i < units.length - 1) { value /= 1024; i++; }
        return value.toFixed(i === 0 ? 0 : 1) + ' ' + units[i];
    }

    function setButton(html, disabled) {
        btnSubmit.innerHTML = html;
        btnSubmit.disabled = !!disabled;
    }

    async function postData(data) {
        var response = await fetch('./m3u_update_nodup.php', { method: 'POST', body: data, credentials: 'same-origin' });
        var payload = null;
        try { payload = await response.json(); } catch (e) {
            var error = new Error(response.status === 413 ? 'O servidor rejeitou o bloco por tamanho.' : 'Resposta inválida do servidor. Verifique PHP/Nginx.');
            error.status = response.status;
            throw error;
        }
        if (!response.ok || !payload.ok) {
            var error = new Error(payload.error || 'Falha na operação.');
            error.status = response.status;
            throw error;
        }
        return payload;
    }

    async function uploadFile(file, uploadToken) {
        var chunkSize = INITIAL_CHUNK_SIZE;
        var offset = 0;
        var index = 0;
        while (offset < file.size) {
            var total = Math.ceil(file.size / chunkSize);
            var fd = new FormData();
            fd.append('ajax_action', 'upload_chunk');
            fd.append('upload_token', uploadToken);
            fd.append('chunk_index', String(index));
            fd.append('chunk_total', String(total));
            fd.append('file_size', String(file.size));
            fd.append('file_name', file.name);
            fd.append('chunk', file.slice(offset, Math.min(file.size, offset + chunkSize)), file.name + '.part');
            try {
                await postData(fd);
            } catch (err) {
                if ((err.status === 413 || /tamanho|413/i.test(err.message)) && index === 0 && chunkSize > MIN_CHUNK_SIZE) {
                    chunkSize = Math.max(MIN_CHUNK_SIZE, Math.floor(chunkSize / 2));
                    continue;
                }
                throw err;
            }
            offset += chunkSize;
            index++;
            var pct = Math.min(100, Math.round((offset / file.size) * 100));
            setButton('<i class="mdi mdi-loading mdi-spin"></i> Enviando ' + pct + '% — bloco ' + humanSize(chunkSize), true);
        }
    }

    async function fetchRemote(url, uploadToken) {
        var fd = new FormData();
        fd.append('ajax_action', 'fetch_remote');
        fd.append('upload_token', uploadToken);
        fd.append('m3u_url', url);
        setButton('<i class="mdi mdi-loading mdi-spin"></i> Baixando playlist...', true);
        await postData(fd);
    }

    async function analyze(uploadToken) {
        var fd = new FormData();
        fd.append('ajax_action', 'analyze');
        fd.append('upload_token', uploadToken);
        var mode = document.getElementById('classification_mode');
        if (mode) fd.append('classification_mode', mode.value);
        setButton('<i class="mdi mdi-loading mdi-spin"></i> Analisando estrutura...', true);
        var result = await postData(fd);
        renderAnalysis(result.analysis);
        analyzed = true;
        setButton('<i class="mdi mdi-shield-check"></i> IMPORTAR PLAYLIST ORGANIZADA', false);
    }

    function renderAnalysis(a) {
        document.getElementById('analysisPanel').style.display = 'flex';
        document.getElementById('analysisSummary').innerHTML =
            '<span class="badge badge-dark badge-count">Arquivo: ' + humanSize(a.file_size) + '</span> ' +
            '<span class="badge badge-primary badge-count">Total: ' + Number(a.total).toLocaleString('pt-BR') + '</span> ' +
            '<span class="badge badge-info badge-count">Live: ' + Number(a.live).toLocaleString('pt-BR') + '</span> ' +
            '<span class="badge badge-success badge-count">Filmes: ' + Number(a.movies).toLocaleString('pt-BR') + '</span> ' +
            '<span class="badge badge-warning badge-count">Episódios: ' + Number(a.series).toLocaleString('pt-BR') + '</span> ' +
            '<span class="badge badge-secondary badge-count">Séries: ' + Number(a.series_titles_count).toLocaleString('pt-BR') + '</span> ' +
            '<span class="badge badge-light badge-count">Temporadas: ' + Number(a.seasons_count).toLocaleString('pt-BR') + '</span> ' +
            '<span class="badge badge-danger badge-count">Duplicados internos: ' + Number(a.duplicates_in_file).toLocaleString('pt-BR') + '</span>';
        var tbody = document.getElementById('analysisCategories');
        tbody.innerHTML = '';
        (a.categories || []).slice(0, 250).forEach(function(c) {
            var tr = document.createElement('tr');
            [c.name, c.total, c.live, c.movies, c.series, c.unknown].forEach(function(v, idx) {
                var td = document.createElement('td');
                td.textContent = idx === 0 ? v : Number(v).toLocaleString('pt-BR');
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });
        document.getElementById('analysisPanel').scrollIntoView({behavior: 'smooth', block: 'center'});
    }

    if (uploadZone && fileInput) {
        uploadZone.addEventListener('click', function(e) { e.preventDefault(); fileInput.click(); });
        uploadZone.setAttribute('role', 'button');
        uploadZone.setAttribute('tabindex', '0');
        uploadZone.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } });
        ['dragenter', 'dragover'].forEach(function(evt) {
            uploadZone.addEventListener(evt, function(e) { e.preventDefault(); uploadZone.classList.add('dragover'); });
        });
        ['dragleave', 'drop'].forEach(function(evt) {
            uploadZone.addEventListener(evt, function(e) { e.preventDefault(); uploadZone.classList.remove('dragover'); });
        });
        uploadZone.addEventListener('drop', function(e) {
            if (e.dataTransfer.files.length) {
                var dropped = e.dataTransfer.files[0];
                try {
                    if (typeof DataTransfer !== 'undefined') { var dt = new DataTransfer(); dt.items.add(dropped); fileInput.files = dt.files; }
                } catch (dropError) {}
                fileName.textContent = 'Arquivo selecionado: ' + dropped.name + ' (' + humanSize(dropped.size) + ')';
                analyzed = false;
            }
        });
        fileInput.addEventListener('change', function() {
            if (this.files.length) {
                fileName.textContent = 'Arquivo selecionado: ' + this.files[0].name + ' (' + humanSize(this.files[0].size) + ')';
                uploadZone.classList.add('border-success');
            }
            analyzed = false;
        });
    }

    var diagnosticTimer = null;
    function esc(v) { var d=document.createElement('div'); d.textContent=String(v==null?'':v); return d.innerHTML; }
    function renderDiagnostic(d) {
        document.getElementById('diagnosticPanel').style.display = 'flex';
        document.getElementById('diagStatus').textContent = (d.status || 'executando') + ' — ' + (d.stage || '');
        var total = Number(d.channels_expected || d.channels_found || 0);
        var done = Number(d.channels_imported || 0) + Number(d.channels_updated || 0) + Number(d.channels_skipped || 0) + Number(d.errors || 0);
        var pct = total > 0 ? Math.min(100, Math.round(done * 100 / total)) : 0;
        document.getElementById('diagProgress').style.width = pct + '%';
        document.getElementById('diagMetrics').innerHTML = [
            ['Memória', humanSize(d.memory_current)], ['Pico', humanSize(d.memory_peak)], ['Categorias criadas', d.categories_created],
            ['Categorias reutilizadas', d.categories_reused], ['Inseridos', d.channels_imported], ['Atualizados', d.channels_updated],
            ['Ignorados', d.channels_skipped], ['Erros', d.errors], ['Avisos', d.warnings], ['SQL', d.sql_queries],
            ['Tempo', Number(d.elapsed_seconds || 0).toFixed(1) + 's'], ['Média/lote', Number(d.average_batch_seconds || 0).toFixed(2) + 's']
        ].map(function(x){return '<div class="col-6 col-md-3 col-xl-2 mb-2"><div class="border rounded p-2"><small>'+esc(x[0])+'</small><div><strong>'+esc(x[1])+'</strong></div></div></div>';}).join('');
        var icons={success:'✔',info:'ℹ',warning:'⚠',error:'✖'};
        document.getElementById('diagLogs').innerHTML=(d.logs||[]).map(function(l){
            return '<div class="mb-1">'+esc(icons[l.level]||'ℹ')+' ['+esc(l.time)+'] ['+esc(l.stage)+'] '+esc(l.message)+(l.file?' <span style="color:#999">('+esc(l.file)+':'+esc(l.line||'')+')</span>':'')+'</div>';
        }).join('');
        var box=document.getElementById('diagLogs'); box.scrollTop=box.scrollHeight;
    }
    async function pollDiagnostic(jobId) {
        clearInterval(diagnosticTimer);
        async function one() {
            try {
                var r=await fetch('./m3u_update_nodup.php?import_status='+encodeURIComponent(jobId),{credentials:'same-origin'});
                var p=await r.json(); if(p.ok) renderDiagnostic(p.diagnostic);
                if(p.ok && ['sucesso','concluído_com_avisos','falha'].indexOf(p.diagnostic.status)>=0) clearInterval(diagnosticTimer);
            } catch(e) {}
        }
        await one(); diagnosticTimer=setInterval(one,1000);
    }
    function buildImportPayload(action, jobId) {
        var fd = new FormData();
        fd.append('ajax_action', action);
        fd.append('upload_token', tokenInput.value);
        var server = form.querySelector('[name="servers"]');
        if (server) fd.append('servers', server.value);
        form.querySelectorAll('[name="bouquets[]"] option:checked').forEach(function(option) {
            fd.append('bouquets[]', option.value);
        });
        if (jobId) fd.append('job_id', jobId);
        var mode = document.getElementById('classification_mode');
        if (mode) fd.append('classification_mode', mode.value);
        return fd;
    }

    async function startRealImport() {
        var prepareFd = buildImportPayload('prepare_import');
        var prepared = await postData(prepareFd);
        await pollDiagnostic(prepared.job_id);
        var fd = buildImportPayload('start_import', prepared.job_id);
        var response = await fetch('./m3u_update_nodup.php', {method:'POST', body:fd, credentials:'same-origin'});
        var payload = null;
        try { payload = await response.json(); }
        catch (e) {
            var parseError = new Error(response.status === 413
                ? 'O servidor rejeitou a requisição de início da importação. O arquivo não deveria ser reenviado; atualize esta correção no servidor.'
                : 'Resposta inválida durante a importação. Consulte o diagnóstico e os logs do servidor.');
            parseError.status = response.status;
            throw parseError;
        }
        await new Promise(function(resolve){setTimeout(resolve,1200);});
        if(!response.ok || !payload.ok) throw new Error((payload.result&&payload.result.error)||payload.error||'Falha na importação.');
        return payload;
    }

    form.addEventListener('submit', async function(e) {
        if (analyzed) {
            e.preventDefault();
            setButton('<i class="mdi mdi-loading mdi-spin"></i> Importando e confirmando no banco...', true);
            try { await startRealImport(); setButton('<i class="mdi mdi-check"></i> IMPORTAÇÃO CONCLUÍDA', true); }
            catch(err) { setButton('<i class="mdi mdi-alert"></i> TENTAR NOVAMENTE', false); alert(err.message || String(err)); }
            return false;
        }
        e.preventDefault();
        try {
            var file = fileInput && fileInput.files.length ? fileInput.files[0] : null;
            var url = document.getElementById('m3u_url').value.trim();
            if (!file && !url) throw new Error('Selecione um arquivo M3U ou informe uma URL remota.');
            if (file && !/\.(m3u|m3u8|txt)$/i.test(file.name)) throw new Error('Formato não suportado. Use .m3u, .m3u8 ou .txt.');
            var uploadToken = token();
            tokenInput.value = uploadToken;
            if (file) await uploadFile(file, uploadToken); else await fetchRemote(url, uploadToken);
            await analyze(uploadToken);
        } catch (err) {
            analyzed = false;
            setButton('<i class="mdi mdi-magnify"></i> ANALISAR PLAYLIST', false);
            alert(err.message || String(err));
        }
        return false;
    });
});
</script>
</body>
</html>
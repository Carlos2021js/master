# CS PLAYER — Importadores M3U Ultra 4.0.7

Esta revisão preserva o banco e mantém cada importador em sua própria estrutura.

- Importador 1: lote padrão maior, streaming linha a linha e retry de locks 1205/1213.
- Importador 2: lotes 100–1000, padrão 500, savepoint por item e retry de locks.
- Importador 3: modo Turbo padrão, lotes 250–2000, padrão 1000, cache de prepared statements, conjuntos O(1) para buquês e sincronização de progresso reduzida.
- `streams_sys` continua sendo criado no formato nativo do banco, com `stream_status=0`, `to_analyze=0`, `on_demand=0`, pronto para o runtime do servidor.
- Nenhuma tabela, coluna, ID ou endpoint foi removido ou renomeado.

Para máxima velocidade no Importador 3, use Fonte direta + Turbo, lote 1000 ou 1500. Em VPS com MariaDB sob alta concorrência, lote 500 é mais conservador.

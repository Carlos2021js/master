<?php
/** CS PLAYER public M3U endpoint - port 80 compatibility wrapper. */
declare(strict_types=1);
$target = dirname(__DIR__) . '/admin/get.php';
if (!is_file($target)) $target = '/home/xtreamcodes/iptv_xtream_codes/admin/get.php';
if (!is_file($target)) { http_response_code(503); header('Content-Type: text/plain; charset=utf-8'); exit('CS PLAYER: endpoint M3U indisponível.'); }
require $target;

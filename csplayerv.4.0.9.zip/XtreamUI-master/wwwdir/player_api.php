<?php
/** CS PLAYER public Xtream API - port 80 compatibility wrapper. */
declare(strict_types=1);
$target = dirname(__DIR__) . '/admin/player_api.php';
if (!is_file($target)) $target = '/home/xtreamcodes/iptv_xtream_codes/admin/player_api.php';
if (!is_file($target)) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo '{"user_info":{"auth":0}}'; exit; }
require $target;

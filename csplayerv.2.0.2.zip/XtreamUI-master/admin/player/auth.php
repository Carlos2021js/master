<?php
require __DIR__ . '/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
$cfg = cs_player_load_config();
$username = trim((string)($_POST['username'] ?? ''));
$password = (string)($_POST['password'] ?? '');
if ($username === '' || $password === '') { $_SESSION['cs_player_error'] = 'Informe usuário e senha.'; header('Location: index.php'); exit; }
// O login usa exclusivamente os DNS manuais ativos cadastrados em Settings > Web Player.
// Não há sincronização automática com streaming_servers.
$dnsList = cs_player_session_dns_list($cfg, '', false);
if (!$dnsList) { cs_player_write_log('web_player_auth_blocked_no_dns', ['reason'=>'no_active_server'], 'error'); $_SESSION['cs_player_error'] = 'Não foi possível entrar agora. Tente novamente em instantes.'; header('Location: index.php'); exit; }
    $authenticated = cs_player_authenticate_dns($dnsList, $username, $password);
    if (is_array($authenticated) && isset($authenticated['row'], $authenticated['data'])) {
        $row = $authenticated['row'];
        $data = $authenticated['data'];
        session_regenerate_id(true);
        $_SESSION['cs_player_auth'] = true;
        $_SESSION['cs_player_username'] = (string)($authenticated['local_user']['username'] ?? $username);
        $_SESSION['cs_player_password'] = $password;
        $_SESSION['cs_player_dns_index'] = (string)$row['_index'];
        $_SESSION['cs_player_dns_name'] = (string)($row['name'] ?? 'Servidor');
        $_SESSION['cs_player_dns_url'] = (string)($row['url'] ?? '');
        $_SESSION['cs_player_api_endpoint'] = (string)($row['api_endpoint'] ?? 'player_api.php');
        $_SESSION['cs_player_local_api'] = !empty($authenticated['local_api']) || !empty($row['local_api']);
        $_SESSION['cs_player_provider_mode'] = (string)($authenticated['provider_mode'] ?? $row['provider_mode_selected'] ?? 'xtream');
        $_SESSION['cs_player_ip_mode_selected'] = (string)($row['ip_mode_selected'] ?? $row['ip_mode'] ?? $_SESSION['cs_player_json_ip_mode'] ?? 'auto');
        $_SESSION['cs_player_transport_dns_url'] = (string)($row['url'] ?? '');
        $_SESSION['cs_player_transport_engine'] = (string)($_SESSION['cs_player_provider_mode'] === 'json_xtream' ? 'json_compat' : 'advanced');
        unset($_SESSION['cs_player_manual_dns'], $_SESSION['cs_player_manual_only']);
        $_SESSION['cs_player_user_info'] = $data['user_info'] ?? [];
        if (!empty($authenticated['local_user']) && is_array($authenticated['local_user'])) {
            $token = cs_player_make_remember_token($authenticated['local_user'], 30);
            setcookie('cs_player_remember', $token, [
                'expires' => time() + 30 * 86400,
                'path' => dirname($_SERVER['SCRIPT_NAME'] ?? '/admin/player/') . '/',
                'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }
        header('Location: home.php'); exit;
    }

$diagnostics = is_array($authenticated['diagnostics'] ?? null) ? $authenticated['diagnostics'] : [];
$manualDnsCount = count(array_filter($dnsList, static fn($r) => (($r['source'] ?? '') === 'manual')));
cs_player_write_log('web_player_auth_failed', [
    'username_hash' => substr(hash('sha256', $username), 0, 12),
    'dns_count' => count($dnsList),
    'manual_dns_count' => $manualDnsCount,
    'dns_mode' => 'manual_only',
    'diagnostics' => $diagnostics,
], 'warning');
$codes = array_values(array_filter(array_map(static fn($item) => (int)($item['http_code'] ?? 0), $diagnostics)));
// Detalhes técnicos (HTTP 500/404, cURL, endpoint) ficam somente nos logs.
// A tela de login não expõe infraestrutura nem mensagens de diagnóstico.
$_SESSION['cs_player_error'] = 'Não foi possível entrar. Confira seu usuário, senha e se a assinatura está ativa.';
header('Location: index.php');

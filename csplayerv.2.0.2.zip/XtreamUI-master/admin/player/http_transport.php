<?php
/**
 * CS PLAYER - Transporte HTTP unificado para Web Player (PHP 7.4+)
 * Mantém DNS, família IP e telemetria consistentes entre login, catálogo e reprodução.
 */
if (!defined('CS_PLAYER_INTERNAL')) { http_response_code(403); exit; }

function cs_player_transport_ip_mode($requested = null) {
    $mode = strtolower(trim((string)($requested !== null ? $requested : ($_SESSION['cs_player_ip_mode_selected'] ?? $_SESSION['cs_player_json_ip_mode'] ?? 'auto'))));
    return in_array($mode, array('auto','ipv4','ipv6'), true) ? $mode : 'auto';
}

function cs_player_transport_attempt_modes($requested = null) {
    $mode = cs_player_transport_ip_mode($requested);
    if ($mode === 'ipv4') return array('ipv4');
    if ($mode === 'ipv6') return array('ipv6');
    // Em Auto, IPv4 primeiro porque diversos provedores IPTV publicam AAAA/CDN sem API funcional.
    return array('ipv4','auto');
}

function cs_player_transport_request($url, array $options = array()) {
    $timeout = max(3, min(60, (int)($options['timeout'] ?? 10)));
    $ua = (string)($options['user_agent'] ?? 'CSPlayer-Web/1.0');
    $accept = (string)($options['accept'] ?? 'application/json, text/plain, */*');
    $wantJson = !array_key_exists('json', $options) || !empty($options['json']);
    $requestedIp = $options['ip_mode'] ?? null;
    $attemptModes = cs_player_transport_attempt_modes($requestedIp);
    $attempts = array();

    if (!function_exists('curl_init')) {
        return array('ok'=>false,'http_code'=>0,'body'=>'','data'=>null,'curl_errno'=>-1,'curl_error'=>'cURL indisponível','remote_ip'=>'','effective_url'=>(string)$url,'time_ms'=>0,'ip_mode'=>'none','attempts'=>$attempts);
    }

    foreach ($attemptModes as $ipMode) {
        $ch = curl_init((string)$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, min(10, $timeout));
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: '.$accept, 'Connection: keep-alive', 'Cache-Control: no-cache'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        if (defined('CURLOPT_IPRESOLVE')) {
            if ($ipMode === 'ipv4' && defined('CURL_IPRESOLVE_V4')) curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
            elseif ($ipMode === 'ipv6' && defined('CURL_IPRESOLVE_V6')) curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V6);
        }
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno = (int)curl_errno($ch);
        $error = (string)curl_error($ch);
        $remoteIp = defined('CURLINFO_PRIMARY_IP') ? (string)curl_getinfo($ch, CURLINFO_PRIMARY_IP) : '';
        $effective = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $ms = (int)round(((float)curl_getinfo($ch, CURLINFO_TOTAL_TIME)) * 1000);
        $redirects = (int)curl_getinfo($ch, CURLINFO_REDIRECT_COUNT);
        curl_close($ch);
        $decoded = ($wantJson && is_string($body)) ? json_decode($body, true) : null;
        $ok = is_string($body) && $errno === 0 && $code >= 200 && $code < 400 && (!$wantJson || is_array($decoded));
        $attempts[] = array('ip_mode'=>$ipMode,'http_code'=>$code,'remote_ip'=>$remoteIp,'time_ms'=>$ms,'curl_errno'=>$errno,'response_bytes'=>is_string($body)?strlen($body):0);
        if ($ok) {
            $_SESSION['cs_player_ip_mode_selected'] = $ipMode;
            $_SESSION['cs_player_json_ip_mode'] = $ipMode;
            return array('ok'=>true,'http_code'=>$code,'body'=>$body,'data'=>is_array($decoded)?$decoded:null,'curl_errno'=>$errno,'curl_error'=>$error,'remote_ip'=>$remoteIp,'effective_url'=>$effective,'time_ms'=>$ms,'redirects'=>$redirects,'ip_mode'=>$ipMode,'attempts'=>$attempts);
        }
        // Se IPv4 chegou ao host mas a rota respondeu 401/403, não troque para uma família diferente.
        if ($ipMode === 'ipv4' && in_array($code, array(401,403), true)) break;
    }
    $last = end($attempts);
    return array('ok'=>false,'http_code'=>(int)($last['http_code']??0),'body'=>isset($body)&&is_string($body)?$body:'','data'=>isset($decoded)&&is_array($decoded)?$decoded:null,'curl_errno'=>(int)($last['curl_errno']??0),'curl_error'=>isset($error)?$error:'','remote_ip'=>(string)($last['remote_ip']??''),'effective_url'=>isset($effective)?$effective:(string)$url,'time_ms'=>(int)($last['time_ms']??0),'redirects'=>isset($redirects)?$redirects:0,'ip_mode'=>(string)($last['ip_mode']??cs_player_transport_ip_mode($requestedIp)),'attempts'=>$attempts);
}

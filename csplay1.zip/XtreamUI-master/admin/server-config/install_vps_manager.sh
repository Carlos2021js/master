#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Execute como root: sudo bash admin/server-config/install_vps_manager.sh'; exit 1; fi
BASE="$(cd "$(dirname "$0")" && pwd)"
install -o root -g root -m 0755 "$BASE/cs-player-adminctl" /usr/local/sbin/cs-player-adminctl
cat >/etc/sudoers.d/cs-player-adminctl <<'EOF'
# CS Player: somente o helper auditado pode ser executado pelo usuário web.
www-data ALL=(root) NOPASSWD: /usr/local/sbin/cs-player-adminctl *
EOF
chmod 0440 /etc/sudoers.d/cs-player-adminctl
visudo -cf /etc/sudoers.d/cs-player-adminctl
mkdir -p /var/log/cs-player
chown www-data:www-data /var/log/cs-player
chmod 0750 /var/log/cs-player
printf '\nInstalação concluída.\n- Helper: /usr/local/sbin/cs-player-adminctl\n- Sudoers: /etc/sudoers.d/cs-player-adminctl\n- Nenhuma senha root foi armazenada.\n'

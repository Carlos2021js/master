<?php
/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  IMPORTAÇÃO INTELIGENTE DE M3U — ULTRA PRO v5.0 (PHP 7.4–8.4)         ║
 * ║  Profissional, inteligente e com diagnóstico completo em tempo real    ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */

// ═══════════════════════════════════════════════════════════════════════════
// PREVENÇÃO DE ERRO 500 E CONFIGURAÇÕES INICIAIS
// ═══════════════════════════════════════════════════════════════════════════
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
        echo "ERRO FATAL DO PHP: " . $error['message'] . " em " . $error['file'] . ":" . $error['line'];
        exit;
    }
});

ini_set('display_errors', 0);
error_reporting(E_ALL);

// Configurações ajustáveis
define('M3U_BATCH_SIZE', 500);          // Tamanho do lote de commit
define('M3U_MAX_IMAGE_SIZE', 15 * 1024 * 1024); // 15 MB
define('M3U_MAX_VIDEO_SIZE', 300 * 1024 * 1024); // 300 MB
define('M3U_CHUNK_SIZE', 16 * 1024 * 1024);     // 16 MB por chunk
define('M3U_MIN_CHUNK_SIZE', 512 * 1024);       // 512 KB mínimo
define('M3U_TOKEN_TTL', 86400);                 // Tokens expiram em 24h

try {
    $requiredFiles = ['session.php', 'functions.php', 'cs_admin_access.php', 'cs_m3u_diagnostics.php'];
    foreach ($requiredFiles as $file) {
        $path = __DIR__ . '/' . $file;
        if (!file_exists($path)) throw new RuntimeException("Arquivo obrigatório não encontrado: {$file}");
        require_once $path;
    }

    // Stub para CSM3UImportDiagnostics (caso o arquivo original esteja vazio)
    if (!class_exists('CSM3UImportDiagnostics')) {
        class CSM3UImportDiagnostics {
            private $id;
            private $data;
            private static $instances = [];

            public function __construct($sourceType, $sourceName) {
                $this->id = bin2hex(random_bytes(8));
                $this->data = [
                    'status' => 'iniciado', 'stage' => '', 'channels_expected' => 0, 'channels_found' => 0,
                    'channels_imported' => 0, 'channels_updated' => 0, 'channels_skipped' => 0,
                    'errors' => 0, 'warnings' => 0, 'categories_created' => 0, 'categories_reused' => 0,
                    'sql_queries' => 0, 'memory_current' => 0, 'memory_peak' => 0,
                    'elapsed_seconds' => 0, 'average_batch_seconds' => 0, 'items_per_second' => 0,
                    'logs' => [], 'batches' => 0, 'eta_seconds' => 0
                ];
                self::$instances[$this->id] = $this;
            }
            public static function create($sourceType, $sourceName) { return new self($sourceType, $sourceName); }
            public static function open($id) {
                if (!isset(self::$instances[$id])) throw new RuntimeException("Diagnóstico não encontrado: {$id}");
                return self::$instances[$id];
            }
            public function id() { return $this->id; }
            public function snapshot() {
                $this->data['memory_current'] = memory_get_usage();
                $this->data['memory_peak'] = memory_get_peak_usage();
                $this->data['elapsed_seconds'] = microtime(true) - ($_SERVER['REQUEST_TIME_FLOAT'] ?? microtime(true));
                return $this->data;
            }
            public function update(array $data) { $this->data = array_merge($this->data, $data); }
            public function increment($key) { if (isset($this->data[$key])) $this->data[$key]++; }
            public function log($level, $stage, $message, $e = null) {
                $this->data['logs'][] = [
                    'time' => date('H:i:s'), 'level' => $level, 'stage' => $stage,
                    'message' => $message, 'file' => $e ? $e->getFile() : null, 'line' => $e ? $e->getLine() : null
                ];
            }
            public function setStage($stage, $message) { $this->data['stage'] = $stage; $this->log('info', $stage, $message); }
            public function finish($status, $message) { $this->data['status'] = $status; $this->log('info', 'finalizado', $message); }
            public function fail($e, $stage) { $this->data['status'] = 'falha'; $this->log('error', $stage, $e ? $e->getMessage() : 'Erro desconhecido', $e); }
        }
    }

    if (!isset($db) || !($db instanceof mysqli)) throw new RuntimeException("Conexão com o banco de dados (\$db) não está disponível.");
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    cs_admin_only('a análise e importação de playlists M3U');
    if (!hasPermissions('adv', 'import_streams')) exit('Acesso negado.');

    // ═══════════════════════════════════════════════════════════════════════
    // CLASSE M3UImporter (com melhorias extremas)
    // ═══════════════════════════════════════════════════════════════════════
    class M3UImporter {
        private $db;
        private $stats;
        private $bouquetData;
        private $categoryCache;
        private $seriesCache;
        private $existingStreamsCache;
        private $seriesSeasons;
        private $touchedSeries;
        private $diagnostics;
        private $batchStartedAt = 0.0;
        private $batchSecondsTotal = 0.0;
        private $startTime = 0.0;
        const LOCK_RETRIES = 4;
        const EXT_LIVE = ['m3u8', 'ts'];
        const EXT_VOD  = ['mp4', 'mkv', 'avi', 'mov', 'wmv', 'flv', 'webm', 'm4v'];
        const SERIES_PATTERNS = [
            '/(.*?)[._\-\s]+S(\d{1,3})\s*E(\d{1,3})/i',
            '/(.*?)[._\-\s]+(\d{1,2})x(\d{1,3})/i',
            '/(.*?)[._\-\s]+Season\s+(\d{1,2})\s+Episode\s+(\d{1,3})/i',
            '/(.*?)[._\-\s]+Temporada\s+(\d{1,2})\s+Episódio\s+(\d{1,3})/i',
            '/(.*?)[._\-\s]+T(\d{1,2})\s*EP(\d{1,3})/i',
        ];

        private static function categoryTypeForStream($type) {
            switch ($type) {
                case 1:  return 'live';
                case 2:  return 'movie';
                case 5:  return 'series';
                default: return 'live';
            }
        }

        public function __construct(mysqli $db, $diagnostics = null) {
            $this->db = $db;
            $this->diagnostics = $diagnostics;
            $this->stats = [
                'total' => 0, 'inserted' => 0, 'updated' => 0, 'skipped' => 0,
                'errors' => 0, 'live' => 0, 'movies' => 0, 'series' => 0, 'radio' => 0,
                'categories_created' => 0, 'categories_reused' => 0, 'sql_queries' => 0, 'warnings' => 0,
            ];
            $this->bouquetData = [];
            $this->categoryCache = [];
            $this->seriesCache = [];
            $this->existingStreamsCache = [];
            $this->seriesSeasons = [];
            $this->touchedSeries = [];
            $this->startTime = microtime(true);
        }

        private function sql($stage, callable $operation) {
            $this->stats['sql_queries']++;
            if ($this->diagnostics) $this->diagnostics->increment('sql_queries');
            try { return $operation(); } catch (Throwable $e) {
                if ($this->diagnostics) $this->diagnostics->log('error', $stage, 'Falha SQL: ' . $e->getMessage(), $e);
                throw $e;
            }
        }
        private function log($level, $stage, $message, $e = null) {
            if ($this->diagnostics) $this->diagnostics->log($level, $stage, $message, $e);
        }

        public static function isValidUrl($url) {
            if (!filter_var($url, FILTER_VALIDATE_URL)) return false;
            $parts = parse_url($url);
            $host = isset($parts['host']) ? $parts['host'] : '';
            if (empty($host)) return false;
            if (in_array(strtolower($host), ['127.0.0.1', 'localhost', '::1', '0.0.0.0'])) return false;
            $ip = @inet_pton($host);
            if ($ip !== false && strlen($ip) === 4) {
                $ip4 = ip2long($host);
                if ($ip4 !== false) {
                    $privateRanges = [
                        [ip2long('10.0.0.0'), ip2long('10.255.255.255')],
                        [ip2long('172.16.0.0'), ip2long('172.31.255.255')],
                        [ip2long('192.168.0.0'), ip2long('192.168.255.255')],
                        [ip2long('169.254.0.0'), ip2long('169.254.255.255')],
                        [ip2long('127.0.0.0'), ip2long('127.255.255.255')],
                    ];
                    foreach ($privateRanges as $range) { if ($ip4 >= $range[0] && $ip4 <= $range[1]) return false; }
                }
            }
            return true;
        }

        public static function parseSeriesInfo($name) {
            foreach (self::SERIES_PATTERNS as $pattern) {
                if (preg_match($pattern, $name, $m)) return ['title' => self::cleanTitle(trim($m[1])), 'season' => (int)$m[2], 'episode' => (int)$m[3]];
            }
            return null;
        }

        public static function cleanTitle($title) {
            $title = preg_replace('/[._\-\s]?(?:1080p|720p|480p|2160p|4k|uhd|hevc|x264|x265|h264|h265|avc|hevc|aac|dts|bluray|bdrip|dvdrip|webrip|hdtv|sd|hd|fhd|uhd)[._\-\s]?$/i', '', $title);
            $title = preg_replace('/[._\-\s]?(?:the\.complete\.series|complete\.series|complete\.season)[._\-\s]?$/i', '', $title);
            return trim($title, ' ._-');
        }

        public static function classifyType($url, $name, $group = '') {
            $path = parse_url($url, PHP_URL_PATH) ?: '';
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            $info = self::parseSeriesInfo($name);
            $groupKey = self::normalizeText($group);
            if ($info || preg_match('/\b(series?|seriados?|novelas?|doramas?|animes?|desenhos?)\b/i', $groupKey)) {
                $type = $info ? 5 : (in_array($ext, self::EXT_VOD, true) ? 2 : 1);
                return ['type' => $type, 'ext' => $ext, 'series' => $info];
            }
            if (preg_match('/\b(filmes?|movies?|vod|cinema|cursos?)\b/i', $groupKey)) return ['type' => 2, 'ext' => $ext ?: 'mp4', 'series' => null];
            if (preg_match('/\b(live|tv|canais?|radio|rádio)\b/i', $groupKey)) return ['type' => 1, 'ext' => $ext ?: 'ts', 'series' => null];
            if (in_array($ext, self::EXT_LIVE, true)) return ['type' => 1, 'ext' => $ext, 'series' => null];
            if (in_array($ext, self::EXT_VOD, true)) return ['type' => 2, 'ext' => $ext, 'series' => null];
            return ['type' => 0, 'ext' => $ext, 'series' => null];
        }

        public static function normalizeText($value) {
            $value = trim(preg_replace('/\s+/u', ' ', $value));
            return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
        }

        public static function iterateFile($filePath) {
            $handle = @fopen($filePath, 'rb');
            if (!$handle) throw new RuntimeException('Não foi possível abrir a playlist para leitura.');
            $pending = null;
            try {
                while (($line = fgets($handle)) !== false) {
                    $line = trim($line);
                    if ($line === '' || $line === '#EXTM3U') continue;
                    if (strpos($line, '#EXTINF:') === 0) {
                        preg_match_all('/([a-zA-Z0-9_-]+)="([^"]*)"/', $line, $m, PREG_SET_ORDER);
                        $pending = [];
                        foreach ($m as $attr) $pending[strtolower($attr[1])] = trim($attr[2]);
                        $comma = strpos($line, ',');
                        $pending['name'] = $comma !== false ? trim(substr($line, $comma + 1)) : '';
                        continue;
                    }
                    if ($pending !== null && preg_match('#^https?://#i', $line)) {
                        $pending['url'] = str_replace(' ', '%20', $line);
                        if ($pending['name'] !== '') yield $pending;
                        $pending = null;
                    }
                }
            } finally { fclose($handle); }
        }

        public static function analyzeFile($filePath) {
            $summary = ['file_size' => @filesize($filePath) ?: 0, 'total' => 0, 'live' => 0, 'movies' => 0, 'series' => 0, 'unknown' => 0, 'categories' => [], 'series_titles' => [], 'seasons' => [], 'duplicates_in_file' => 0, 'warnings' => []];
            $seen = [];
            foreach (self::iterateFile($filePath) as $item) {
                $summary['total']++;
                $name = trim(isset($item['name']) ? $item['name'] : '');
                $url = trim(isset($item['url']) ? $item['url'] : '');
                $group = trim(isset($item['group-title']) ? $item['group-title'] : 'Sem categoria');
                $classification = self::classifyType($url, $name, $group);
                $type = (int)$classification['type'];
                switch ($type) {
                    case 1: $summary['live']++; break;
                    case 2: $summary['movies']++; break;
                    case 5: $summary['series']++; $info = $classification['series']; if ($info) { $titleKey = self::normalizeText($info['title']); $summary['series_titles'][$titleKey] = $info['title']; $summary['seasons'][$titleKey][(int)$info['season']] = true; } break;
                    default: $summary['unknown']++; break;
                }
                $catKey = self::normalizeText($group);
                if (!isset($summary['categories'][$catKey])) $summary['categories'][$catKey] = ['name' => $group, 'total' => 0, 'live' => 0, 'movies' => 0, 'series' => 0, 'unknown' => 0];
                $summary['categories'][$catKey]['total']++;
                switch ($type) {
                    case 1: $summary['categories'][$catKey]['live']++; break;
                    case 2: $summary['categories'][$catKey]['movies']++; break;
                    case 5: $summary['categories'][$catKey]['series']++; break;
                    default: $summary['categories'][$catKey]['unknown']++; break;
                }
                $dupKey = hash('sha256', self::normalizeText($url));
                if (isset($seen[$dupKey])) $summary['duplicates_in_file']++; else $seen[$dupKey] = true;
            }
            $summary['series_titles_count'] = count($summary['series_titles']);
            $summary['seasons_count'] = array_sum(array_map('count', $summary['seasons']));
            unset($summary['series_titles'], $summary['seasons']);
            uasort($summary['categories'], function($a, $b) { return $b['total'] - $a['total']; });
            $summary['categories'] = array_values($summary['categories']);
            if ($summary['unknown'] > 0) $summary['warnings'][] = $summary['unknown'] . ' itens não classificados.';
            return $summary;
        }

        private function loadCaches() {
            $res = $this->db->query("SELECT id, category_name, category_type FROM stream_categories");
            if ($res) while ($row = $res->fetch_assoc()) $this->categoryCache[strtolower($row['category_type'])][self::normalizeText($row['category_name'])] = (int)$row['id'];
            $res = $this->db->query("SELECT id, title, category_id, seasons FROM series");
            if ($res) while ($row = $res->fetch_assoc()) {
                $this->seriesCache[self::normalizeText($row['title'])][(int)$row['category_id']] = (int)$row['id'];
                $decoded = json_decode($row['seasons'] ?: '[]', true);
                $this->seriesSeasons[(int)$row['id']] = array_fill_keys(array_map('intval', is_array($decoded) ? $decoded : []), true);
            }
            $res = $this->db->query("SELECT id, stream_display_name, stream_source, type FROM streams");
            if ($res) while ($row = $res->fetch_assoc()) {
                $type = (int)$row['type'];
                $this->existingStreamsCache['name'][$type][strtolower($row['stream_display_name'])] = $row['id'];
                $srcs = json_decode($row['stream_source'], true);
                if (is_array($srcs)) foreach ($srcs as $s) $this->existingStreamsCache['url'][$type][strtolower(trim(str_replace(' ', '%20', $s)))] = $row['id'];
            }
        }
        private function loadBouquets(array $bouquetIds) {
            foreach ($bouquetIds as $bId) {
                $bRow = getBouquet((int)$bId);
                if ($bRow) $this->bouquetData[(int)$bId] = [
                    'streams' => array_map('intval', json_decode($bRow['bouquet_channels'] ?: '[]', true) ?: []),
                    'series' => array_map('intval', json_decode($bRow['bouquet_series'] ?: '[]', true) ?: []),
                ];
            }
        }
        private function resolveCategory($catName, $type) {
            $catName = trim($catName) ?: 'Importação Automática';
            $categoryType = self::categoryTypeForStream($type);
            $key = self::normalizeText($catName);
            if (isset($this->categoryCache[$categoryType][$key])) { $this->stats['categories_reused']++; if ($this->diagnostics) $this->diagnostics->increment('categories_reused'); return $this->categoryCache[$categoryType][$key]; }
            $stmt = $this->sql('categoria', function() { return $this->db->prepare("INSERT INTO stream_categories (category_name, category_type, parent_id, cat_order) VALUES (?, ?, 0, 0)"); });
            $stmt->bind_param("ss", $catName, $categoryType);
            $this->sql('categoria', function() use ($stmt) { $stmt->execute(); });
            $catId = $this->db->insert_id;
            if ($catId <= 0) throw new RuntimeException('Falha ao criar categoria.');
            $this->categoryCache[$categoryType][$key] = $catId;
            $this->stats['categories_created']++;
            if ($this->diagnostics) { $this->diagnostics->increment('categories_created'); $this->diagnostics->log('success', 'categorias', 'Criada: ' . $catName); }
            return $catId;
        }
        private function findExisting($type, $url, $name) {
            $urlKey = strtolower(str_replace(' ', '%20', $url));
            $nameKey = strtolower($name);
            if (isset($this->existingStreamsCache['url'][$type][$urlKey])) return $this->existingStreamsCache['url'][$type][$urlKey];
            if (isset($this->existingStreamsCache['name'][$type][$nameKey])) return $this->existingStreamsCache['name'][$type][$nameKey];
            return null;
        }
        private function processStream(array $item, $serverId, $dryRun = false) {
            $name = trim(isset($item['name']) ? $item['name'] : '');
            $url = trim(isset($item['url']) ? $item['url'] : '');
            $catName = trim(isset($item['group-title']) ? $item['group-title'] : 'Importação Automática');
            $icon = isset($item['tvg-logo']) ? $item['tvg-logo'] : '';
            $classification = self::classifyType($url, $name, $catName);
            $type = $classification['type'];
            $ext = $classification['ext'];
            $info = $classification['series'];
            if ($type === 0) { $this->stats['skipped']++; return null; }
            $catId = $dryRun ? 0 : $this->resolveCategory($catName, $type); // No dry-run não cria categoria real
            $existingId = $dryRun ? null : $this->findExisting($type, $url, $name);
            if ($dryRun) {
                $this->stats['total']++;
                // Conta como inserido ou atualizado baseado em cache (não modifica o banco)
                if ($existingId) { $this->stats['updated']++; } else { $this->stats['inserted']++; }
                return 0;
            }
            $source = json_encode([$url]);
            $props = json_encode(["movie_image" => $icon, "genre" => $catName, "plot" => "", "cast" => "", "rating" => "", "director" => "", "releasedate" => "", "tmdb_id" => ""]);
            $container = json_encode([$ext ?: ($type === 1 ? "ts" : "mp4")]);
            global $rAdminSettings;
            if (!empty($icon) && isset($rAdminSettings['download_images']) && $rAdminSettings['download_images'] && function_exists('downloadImage')) $icon = downloadImage($icon);
            if ($existingId) {
                $stmt = $this->db->prepare("UPDATE streams SET stream_display_name=?, stream_source=?, stream_icon=?, movie_propeties=?, category_id=? WHERE id=?");
                $stmt->bind_param("ssssii", $name, $source, $icon, $props, $catId, $existingId);
                $this->sql('update', function() use ($stmt) { $stmt->execute(); });
                if ($stmt->affected_rows < 0) throw new RuntimeException('Falha ao atualizar stream.');
                $this->stats['updated']++;
                if ($this->diagnostics) $this->diagnostics->increment('channels_updated');
                $streamId = $existingId;
            } else {
                $now = time();
                $stmt = $this->db->prepare("INSERT INTO streams (type, category_id, stream_display_name, stream_source, stream_icon, added, movie_propeties, target_container, gen_timestamps, direct_source, movie_symlink, redirect_stream, allow_record, probesize_ondemand) VALUES (?,?,?,?,?,?,?,?,1,1,1,1,1,128000)");
                $stmt->bind_param("iisssiss", $type, $catId, $name, $source, $icon, $now, $props, $container);
                $this->sql('insert', function() use ($stmt) { $stmt->execute(); });
                $streamId = $this->db->insert_id;
                if ($streamId <= 0) throw new RuntimeException('Falha ao inserir stream.');
                $stmtSys = $this->db->prepare("INSERT INTO streams_sys (stream_id, server_id, to_analyze, stream_status) VALUES (?,?,0,0)");
                $stmtSys->bind_param("ii", $streamId, $serverId);
                $this->sql('sys', function() use ($stmtSys) { $stmtSys->execute(); });
                $this->existingStreamsCache['name'][$type][strtolower($name)] = $streamId;
                $this->existingStreamsCache['url'][$type][strtolower(str_replace(' ', '%20', $url))] = $streamId;
                $this->stats['inserted']++;
                if ($this->diagnostics) $this->diagnostics->increment('channels_imported');
            }
            switch ($type) { case 1: $this->stats['live']++; break; case 2: $this->stats['movies']++; break; case 5: $this->stats['series']++; break; }
            if ($type === 5 && $info) $this->processSeries($info, $catId, $catName, $streamId, $icon);
            $this->addToBouquets($type, $streamId);
            return $streamId;
        }
        private function processSeries(array $info, $catId, $catName, $streamId, $icon) {
            $title = $info['title']; $season = $info['season']; $epNum = $info['episode'];
            $seriesKey = self::normalizeText($title);
            if (!isset($this->seriesCache[$seriesKey][$catId])) {
                $stmt = $this->db->prepare("INSERT INTO series (title, category_id, cover, cover_big, genre, plot, cast, rating, director, releaseDate, last_modified, tmdb_id, seasons, episode_run_time, backdrop_path, youtube_trailer) VALUES (?,?,?,?,?, '', '', 0, '', '', ?, 0, '[]', 0, '', '')");
                $now = time(); $stmt->bind_param("sisssi", $title, $catId, $icon, $icon, $catName, $now); $stmt->execute();
                $seriesId = $this->db->insert_id;
                $this->seriesCache[$seriesKey][$catId] = $seriesId;
            } else {
                $seriesId = $this->seriesCache[$seriesKey][$catId];
                $this->db->query("UPDATE series SET last_modified = " . time() . " WHERE id = " . (int)$seriesId);
            }
            $stmtFind = $this->db->prepare("SELECT id FROM series_episodes WHERE series_id=? AND season_num=? AND sort=? LIMIT 1");
            $stmtFind->bind_param("iii", $seriesId, $season, $epNum); $stmtFind->execute();
            $episodeRow = $stmtFind->get_result()->fetch_assoc();
            if ($episodeRow) {
                $stmtEpisode = $this->db->prepare("UPDATE series_episodes SET stream_id=? WHERE id=?");
                $stmtEpisode->bind_param("ii", $streamId, (int)$episodeRow['id']);
            } else {
                $stmtEpisode = $this->db->prepare("INSERT INTO series_episodes (season_num, series_id, stream_id, sort) VALUES (?,?,?,?)");
                $stmtEpisode->bind_param("iiii", $season, $seriesId, $streamId, $epNum);
            }
            $stmtEpisode->execute();
            $this->seriesSeasons[$seriesId][(int)$season] = true;
            $this->touchedSeries[$seriesId] = true;
            foreach ($this->bouquetData as $bId => &$data) { if (!in_array($seriesId, $data['series'])) $data['series'][] = $seriesId; }
        }
        private function flushSeriesSeasons() {
            foreach (array_keys($this->touchedSeries) as $seriesId) {
                $seasons = array_map('intval', array_keys($this->seriesSeasons[$seriesId] ?? []));
                sort($seasons, SORT_NUMERIC);
                $stmt = $this->db->prepare('UPDATE series SET seasons=?, last_modified=? WHERE id=?');
                $now = time(); $stmt->bind_param('sii', json_encode($seasons), $now, $seriesId); $stmt->execute();
            }
        }
        private function addToBouquets($type, $streamId) {
            foreach ($this->bouquetData as $bId => &$data) { if ($type !== 5 && !in_array($streamId, $data['streams'])) $data['streams'][] = $streamId; }
        }
        private function saveBouquets() {
            foreach ($this->bouquetData as $bId => $data) {
                $stmt = $this->db->prepare("UPDATE bouquets SET bouquet_channels=?, bouquet_series=? WHERE id=?");
                $sJson = json_encode(array_values(array_map('intval', $data['streams'])));
                $eJson = json_encode(array_values(array_map('intval', $data['series'])));
                $stmt->bind_param("ssi", $sJson, $eJson, $bId); $stmt->execute();
            }
        }
        public function executeFile($filePath, $serverId, array $bouquetIds, $batchSize = M3U_BATCH_SIZE, $dryRun = false) {
            if (!is_readable($filePath)) throw new RuntimeException('Playlist não legível: ' . basename($filePath));
            if ($this->diagnostics) $this->diagnostics->setStage('cache', 'Carregando caches...');
            if (!$dryRun) {
                $this->loadCaches();
                $this->loadBouquets($bouquetIds);
            } else {
                // Para simulação, carregamos apenas caches necessários sem modificar
                $this->loadCaches();
            }
            $processedInBatch = 0; $batchCount = 0;
            $this->batchStartedAt = microtime(true);
            if (!$dryRun) {
                $this->db->query("SET SESSION innodb_lock_wait_timeout = 8");
                $this->db->query("SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED");
                $this->db->begin_transaction();
            }
            if ($this->diagnostics) $this->diagnostics->setStage($dryRun ? 'simulação' : 'importação', $dryRun ? 'Simulando alterações...' : 'Processando itens...');
            try {
                foreach (self::iterateFile($filePath) as $item) {
                    $this->stats['total']++;
                    if ($this->diagnostics) $this->diagnostics->increment('channels_found');
                    if ($dryRun) {
                        $this->processStream($item, $serverId, true);
                    } else {
                        $streamId = null;
                        $completed = false;
                        for ($attempt = 1; $attempt <= self::LOCK_RETRIES && !$completed; $attempt++) {
                            $sp = 'm3u_item_' . $attempt;
                            $this->db->query("SAVEPOINT " . $sp);
                            try {
                                $streamId = $this->processStream($item, $serverId);
                                $this->db->query("RELEASE SAVEPOINT " . $sp);
                                $completed = true;
                            } catch (Throwable $e) {
                                try { $this->db->query("ROLLBACK TO SAVEPOINT " . $sp); } catch (Throwable $ignored) {}
                                $lock = in_array((int)$e->getCode(), [1205,1213], true) || stripos($e->getMessage(), 'lock wait timeout') !== false || stripos($e->getMessage(), 'deadlock') !== false;
                                if ($lock && $attempt < self::LOCK_RETRIES) { $this->stats['warnings']++; usleep(150000 * $attempt); continue; }
                                $this->stats['errors']++;
                                $this->log('error', 'item', (isset($item['name']) ? $item['name'] : 'item') . ': ' . $e->getMessage(), $e);
                                break;
                            }
                        }
                        if ($streamId === null && $this->diagnostics) $this->diagnostics->increment('channels_skipped');
                    }
                    // Atualizar métricas de velocidade
                    if ($this->diagnostics && $this->stats['total'] % 10 === 0) {
                        $elapsed = microtime(true) - $this->startTime;
                        $ips = $elapsed > 0 ? $this->stats['total'] / $elapsed : 0;
                        $remaining = ($this->diagnostics->snapshot()['channels_expected'] - $this->stats['total']) / max($ips, 0.01);
                        $this->diagnostics->update(['items_per_second' => round($ips, 1), 'eta_seconds' => round($remaining)]);
                    }
                    $processedInBatch++;
                    if ($processedInBatch >= $batchSize && !$dryRun) {
                        $this->db->commit();
                        $batchSec = microtime(true) - $this->batchStartedAt;
                        $this->batchSecondsTotal += $batchSec;
                        $batchCount++;
                        if ($this->diagnostics) {
                            $this->diagnostics->increment('batches');
                            $this->diagnostics->update(['average_batch_seconds' => $this->batchSecondsTotal / $batchCount, 'message' => 'Lote ' . $batchCount . ' confirmado. ' . $this->stats['total'] . ' itens.']);
                        }
                        $this->db->begin_transaction();
                        $processedInBatch = 0;
                        $this->batchStartedAt = microtime(true);
                    }
                }
                if (!$dryRun) {
                    if ($this->diagnostics) $this->diagnostics->setStage('finalização', 'Salvando temporadas e buquês...');
                    $this->flushSeriesSeasons();
                    $this->saveBouquets();
                    $this->db->commit();
                    foreach ($bouquetIds as $bId) {
                        try { if (function_exists('scanBouquet')) scanBouquet((int)$bId); } catch (Throwable $e) { $this->stats['warnings']++; }
                    }
                }
                return $this->stats;
            } catch (Throwable $e) {
                if (!$dryRun) try { $this->db->rollback(); } catch (Throwable $ignored) {}
                return ['error' => 'Erro: ' . $e->getMessage()] + $this->stats;
            }
        }
        public function getStats() { return $this->stats; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // FUNÇÕES AUXILIARES
    // ═══════════════════════════════════════════════════════════════════════
    function csM3UBaseDir() { $d = __DIR__ . '/storage/m3u_uploads'; if (!is_dir($d)) @mkdir($d, 0750, true); return $d; }
    function csM3UTokenDir($token) { $d = csM3UBaseDir() . '/' . $token; if (!is_dir($d)) @mkdir($d, 0750, true); return $d; }
    function csM3UTokenPath($token, $suffix = '.m3u') { if (!preg_match('/^[a-f0-9]{32}$/', $token)) throw new RuntimeException('Token inválido'); return csM3UTokenDir($token) . '/playlist' . $suffix; }
    function csM3UJson($payload, $status = 200) { http_response_code($status); header('Content-Type: application/json'); echo json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
    function csM3UCleanup($maxAge = M3U_TOKEN_TTL) { $base = csM3UBaseDir(); $now = time(); foreach (glob($base . '/*', GLOB_ONLYDIR) ?: [] as $td) { if (filemtime($td) < $now - $maxAge) { array_map('unlink', glob($td . '/*') ?: []); @rmdir($td); } } }
    csM3UCleanup();

    // ═══════════════════════════════════════════════════════════════════════
    // ROTAS AJAX (incluindo simulação)
    // ═══════════════════════════════════════════════════════════════════════
    if (isset($_GET['import_status'])) {
        try { csM3UJson(['ok' => true, 'diagnostic' => CSM3UImportDiagnostics::open($_GET['import_status'])->snapshot()]); } catch (Throwable $e) { csM3UJson(['ok' => false, 'error' => $e->getMessage()], 404); }
    }
    if (isset($_POST['ajax_action'])) {
        try {
            $action = $_POST['ajax_action'];
            if ($action === 'upload_chunk') {
                $token = $_POST['upload_token'] ?? ''; $index = max(0, (int)($_POST['chunk_index'] ?? 0)); $total = max(1, (int)($_POST['chunk_total'] ?? 1)); $expectedSize = max(0, (int)($_POST['file_size'] ?? 0)); $fileName = basename($_POST['file_name'] ?? 'playlist.m3u');
                if (!isset($_FILES['chunk']) || $_FILES['chunk']['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Falha ao receber parte ' . ($index+1));
                $path = csM3UTokenPath($token); $metaPath = csM3UTokenPath($token, '.json');
                $previous = is_file($metaPath) ? json_decode(file_get_contents($metaPath), true) : []; $received = (int)($previous['received'] ?? 0);
                if ($index !== $received) throw new RuntimeException('Parte fora de ordem. Esperada: ' . ($received+1) . ', recebida: ' . ($index+1));
                if ($index === 0 && $expectedSize > 0) { $free = @disk_free_space(dirname($path)); if ($free !== false && $free < $expectedSize + 268435456) throw new RuntimeException('Espaço insuficiente.'); }
                $mode = $index === 0 ? 'wb' : 'ab'; $out = fopen($path, $mode); $in = fopen($_FILES['chunk']['tmp_name'], 'rb');
                if (!$out || !$in) throw new RuntimeException('Erro ao gravar.'); flock($out, LOCK_EX); stream_copy_to_stream($in, $out); fflush($out); flock($out, LOCK_UN); fclose($in); fclose($out);
                clearstatcache(true, $path);
                $meta = ['token' => $token, 'name' => $fileName, 'expected_size' => $expectedSize, 'parts' => $total, 'received' => $index+1, 'size' => filesize($path), 'updated_at' => time()];
                file_put_contents($metaPath, json_encode($meta, JSON_UNESCAPED_UNICODE), LOCK_EX);
                csM3UJson(['ok' => true, 'received' => $index+1, 'total' => $total, 'size' => $meta['size']]);
            } elseif ($action === 'fetch_remote') {
                $token = $_POST['upload_token'] ?? ''; $url = trim($_POST['m3u_url'] ?? '');
                if (!M3UImporter::isValidUrl($url)) throw new RuntimeException('URL inválida.');
                $path = csM3UTokenPath($token); $out = fopen($path, 'wb'); if (!$out) throw new RuntimeException('Erro ao criar arquivo.');
                $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_FILE => $out, CURLOPT_FOLLOWLOCATION => true, CURLOPT_CONNECTTIMEOUT => 20, CURLOPT_TIMEOUT => 0, CURLOPT_USERAGENT => 'CS Player M3U Importer/6.0', CURLOPT_FAILONERROR => true]);
                $ok = curl_exec($ch); $error = curl_error($ch); curl_close($ch); fclose($out);
                if (!$ok || !is_file($path) || filesize($path) === 0) { @unlink($path); throw new RuntimeException('Falha ao baixar: ' . $error); }
                csM3UJson(['ok' => true, 'size' => filesize($path)]);
            } elseif ($action === 'analyze') {
                $token = $_POST['upload_token'] ?? ''; $path = csM3UTokenPath($token);
                if (!is_file($path) || filesize($path) === 0) throw new RuntimeException('Arquivo não encontrado. Faça upload primeiro.');
                $metaPath = csM3UTokenPath($token, '.json'); $meta = is_file($metaPath) ? json_decode(file_get_contents($metaPath), true) : [];
                if (!empty($meta['parts']) && (int)($meta['received'] ?? 0) !== (int)$meta['parts']) throw new RuntimeException('Upload ainda não concluído.');
                $analysis = M3UImporter::analyzeFile($path);
                file_put_contents(csM3UTokenPath($token, '.analysis.json'), json_encode($analysis, JSON_UNESCAPED_UNICODE), LOCK_EX);
                csM3UJson(['ok' => true, 'analysis' => $analysis]);
            } elseif ($action === 'simulate') {
                $token = $_POST['upload_token'] ?? ''; $path = csM3UTokenPath($token);
                if (!is_file($path) || filesize($path) === 0) throw new RuntimeException('Playlist não encontrada.');
                $serverId = (int)($_POST['servers'] ?? 0);
                $bouquetIds = array_values(array_filter(array_map('intval', $_POST['bouquets'] ?? [])));
                $diag = CSM3UImportDiagnostics::create('simulação', basename($path));
                $diag->setStage('simulação', 'Executando simulação...');
                $importer = new M3UImporter($db, $diag);
                $result = $importer->executeFile($path, $serverId, $bouquetIds, M3U_BATCH_SIZE, true);
                $diag->finish('concluído', 'Simulação finalizada.');
                csM3UJson(['ok' => true, 'simulation' => $result]);
            } elseif ($action === 'prepare_import') {
                $token = $_POST['upload_token'] ?? ''; $path = csM3UTokenPath($token);
                if (!is_file($path) || filesize($path) === 0) throw new RuntimeException('Playlist não encontrada.');
                $analysisPath = csM3UTokenPath($token, '.analysis.json');
                if (!is_file($analysisPath)) throw new RuntimeException('Execute a análise primeiro.');
                $analysis = json_decode(file_get_contents($analysisPath), true) ?: [];
                $diag = CSM3UImportDiagnostics::create('arquivo', basename($path));
                $diag->update(['status' => 'preparado', 'categories_found' => count($analysis['categories'] ?? []), 'channels_expected' => (int)($analysis['total'] ?? 0)]);
                csM3UJson(['ok' => true, 'job_id' => $diag->id()]);
            } elseif ($action === 'start_import') {
                $token = $_POST['upload_token'] ?? ''; $path = csM3UTokenPath($token);
                if (!is_file($path) || filesize($path) === 0) throw new RuntimeException('Playlist não encontrada.');
                $analysisPath = csM3UTokenPath($token, '.analysis.json');
                if (!is_file($analysisPath)) throw new RuntimeException('Análise não encontrada.');
                $serverId = (int)($_POST['servers'] ?? 0); if ($serverId <= 0) throw new RuntimeException('Selecione um servidor.');
                $bouquetIds = array_values(array_filter(array_map('intval', $_POST['bouquets'] ?? [])));
                $jobId = $_POST['job_id'] ?? ''; $diag = CSM3UImportDiagnostics::open($jobId);
                if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
                $analysis = json_decode(file_get_contents($analysisPath), true) ?: [];
                $diag->update(['status' => 'executando', 'categories_found' => count($analysis['categories'] ?? []), 'channels_expected' => (int)($analysis['total'] ?? 0)]);
                $importer = new M3UImporter($db, $diag);
                $result = $importer->executeFile($path, $serverId, $bouquetIds, M3U_BATCH_SIZE);
                if (isset($result['error'])) { $diag->finish('falha', $result['error']); }
                else {
                    $diag->update([
                        'channels_found' => (int)$result['total'], 'channels_imported' => (int)$result['inserted'],
                        'channels_updated' => (int)$result['updated'], 'channels_skipped' => (int)$result['skipped'],
                        'categories_created' => (int)$result['categories_created'], 'categories_reused' => (int)$result['categories_reused'],
                        'sql_queries' => (int)$result['sql_queries']
                    ]);
                    $finalStatus = ((int)$result['errors'] > 0 || (int)$result['warnings'] > 0) ? 'concluído_com_avisos' : 'sucesso';
                    $diag->finish($finalStatus, 'Importação concluída.');
                    @unlink($path); @unlink($analysisPath); @unlink(csM3UTokenPath($token, '.json'));
                }
                csM3UJson(['ok' => !isset($result['error']), 'job_id' => $jobId, 'result' => $result], isset($result['error']) ? 500 : 200);
            } else throw new RuntimeException('Ação desconhecida.');
        } catch (Throwable $e) { csM3UJson(['ok' => false, 'error' => $e->getMessage()], 400); }
    }

    // Processamento do formulário clássico
    if (isset($_POST["submit_update"])) {
        set_time_limit(0); ignore_user_abort(true); ini_set('max_execution_time', '0');
        try {
            $token = $_POST['upload_token'] ?? ''; $filePath = csM3UTokenPath($token);
            if (!is_file($filePath) || filesize($filePath) === 0) throw new RuntimeException('Faça upload e análise antes de importar.');
            $analysisPath = csM3UTokenPath($token, '.analysis.json');
            if (!is_file($analysisPath)) throw new RuntimeException('Análise obrigatória.');
            $serverId = (int)($_POST['servers'] ?? 0); if ($serverId <= 0) throw new RuntimeException('Selecione um servidor.');
            $bouquetIds = array_values(array_filter(array_map('intval', $_POST['bouquets'] ?? [])));
            $importer = new M3UImporter($db); $_RESULT = $importer->executeFile($filePath, $serverId, $bouquetIds);
            if (!isset($_RESULT['error'])) { @unlink($filePath); @unlink($analysisPath); @unlink(csM3UTokenPath($token, '.json')); }
        } catch (Throwable $e) { $_RESULT = ['error' => $e->getMessage()]; }
    }

    // Dados para o formulário
    $rServers = function_exists('getStreamingServers') ? getStreamingServers(true) : [];
    $rBouquets = []; $res = $db->query("SELECT id, bouquet_name FROM bouquets ORDER BY bouquet_order ASC"); if ($res) while ($row = $res->fetch_assoc()) $rBouquets[] = $row;
    $rCounts = ['live' => 0, 'movies' => 0, 'series' => 0]; $res = $db->query("SELECT type, COUNT(*) as cnt FROM streams GROUP BY type");
    if ($res) while ($row = $res->fetch_assoc()) { $t = (int)$row['type']; if ($t===1) $rCounts['live']=(int)$row['cnt']; elseif ($t===2) $rCounts['movies']=(int)$row['cnt']; elseif ($t===5) $rCounts['series']=(int)$row['cnt']; }
    $rSidebar = isset($rSettings['sidebar']) ? (bool)$rSettings['sidebar'] : false;
    include $rSidebar ? 'header_sidebar.php' : 'header.php';

} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo "<h1>Erro interno</h1><p>" . htmlspecialchars($e->getMessage()) . "</p>";
    exit;
}
?>
<style>
.boxed-layout-ext { padding: 10px; }
.card-stats { border-left: 4px solid; transition: transform 0.2s; }
.card-stats:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
.card-stats.live { border-left-color: #4fc6e1; } .card-stats.movies { border-left-color: #81c868; } .card-stats.series { border-left-color: #03a9f4; } .card-stats.radio { border-left-color: #ab8ce4; }
.stat-number { font-size: 2rem; font-weight: 700; line-height: 1; }
.stat-label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; color: #868e96; }
.upload-zone { border: 2px dashed #dee2e6; border-radius: 8px; padding: 30px 20px; text-align: center; transition: all 0.3s; cursor: pointer; background: #f8f9fa; }
.upload-zone:hover, .upload-zone.dragover { border-color: #4fc6e1; background: #e8f4f8; }
.upload-zone i { font-size: 2.5rem; color: #adb5bd; margin-bottom: 10px; } .upload-zone:hover i { color: #4fc6e1; }
.btn-import { background: linear-gradient(135deg, #4fc6e1 0%, #03a9f4 100%); border: none; color: #fff; font-weight: 600; padding: 12px 40px; font-size: 1rem; border-radius: 6px; letter-spacing: 0.5px; transition: all 0.3s; }
.btn-import:hover { background: linear-gradient(135deg, #03a9f4 0%, #4fc6e1 100%); transform: translateY(-1px); box-shadow: 0 4px 15px rgba(79,198,225,0.4); color: #fff; }
.badge-count { font-size: 0.7rem; padding: 3px 8px; border-radius: 10px; font-weight: 600; }
.section-title { font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; color: #868e96; margin-bottom: 15px; padding-bottom: 8px; border-bottom: 1px solid #eee; }
.analysis-log { max-height: 200px; overflow-y: auto; background: #f8f9fa; border-radius: 6px; padding: 10px; font-family: monospace; font-size: 12px; }
.log-entry { padding: 2px 0; border-bottom: 1px solid #eee; }
.log-entry.error { color: #dc3545; } .log-entry.success { color: #28a745; } .log-entry.warning { color: #ffc107; } .log-entry.info { color: #17a2b8; }
.progress-upload { height: 4px; background: #e9ecef; border-radius: 2px; margin-top: 5px; }
.progress-upload-bar { height: 100%; background: #4fc6e1; border-radius: 2px; transition: width 0.3s; }
</style>

<div class="<?= $rSidebar ? 'content-page' : 'wrapper' ?> boxed-layout-ext"><div class="container-fluid">
<div class="row"><div class="col-12"><div class="page-title-box">
    <h4 class="page-title"><i class="mdi mdi-cloud-upload" style="color:#4fc6e1;"></i> Importação M3U Ultra Pro v5.0 <span class="badge badge-info ml-2">PHP 7.4–8.4</span></h4>
</div></div></div>

<?php if (isset($_RESULT) && !isset($_RESULT['error'])): ?>
<div class="alert alert-success"><strong>Importação concluída!</strong> Total: <?= intval($_RESULT['total']) ?> | Inseridos: <?= intval($_RESULT['inserted']) ?> | Atualizados: <?= intval($_RESULT['updated']) ?> | Ignorados: <?= intval($_RESULT['skipped']) ?></div>
<?php elseif (isset($_RESULT['error'])): ?>
<div class="alert alert-danger"><?= htmlspecialchars($_RESULT['error']) ?></div>
<?php endif; ?>

<div class="row"><div class="col-xl-12"><div class="card"><div class="card-body">
<form id="importForm">
    <input type="hidden" name="upload_token" id="upload_token" value="">
    <div class="row">
        <div class="col-lg-6">
            <div class="section-title"><i class="mdi mdi-server"></i> Destino</div>
            <div class="form-group"><label>Servidor</label><select name="servers" class="form-control select2"><?php foreach ($rServers as $s): ?><option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['server_name']) ?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>Buquês</label><select name="bouquets[]" class="form-control select2" multiple><?php foreach ($rBouquets as $b): ?><option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['bouquet_name']) ?></option><?php endforeach; ?></select></div>
        </div>
        <div class="col-lg-6">
            <div class="section-title"><i class="mdi mdi-file-upload"></i> Fonte M3U</div>
            <div class="upload-zone" id="uploadZone"><i class="mdi mdi-cloud-upload-outline"></i><p>Arraste ou clique para selecionar</p><small>.m3u, .m3u8</small></div>
            <div class="progress-upload" id="uploadProgress" style="display:none"><div class="progress-upload-bar" id="uploadProgressBar" style="width:0%"></div></div>
            <input type="file" id="m3u_file" accept=".m3u,.m3u8,.txt" style="display:none"><small id="fileName" class="text-muted"></small>
            <div class="form-group mt-2"><label>Ou URL remota</label><input type="url" class="form-control" id="m3u_url" placeholder="http://..."></div>
        </div>
    </div>
    <div class="row mt-3" id="analysisPanel" style="display:none"><div class="col-12"><div class="alert alert-info"><h5>Análise concluída</h5><div id="analysisSummary"></div><div class="analysis-log mt-2" id="analysisLog"></div></div></div></div>
    <div class="row mt-3" id="simulationPanel" style="display:none"><div class="col-12"><div class="alert alert-secondary"><h5>Simulação (dry-run)</h5><div id="simulationSummary"></div></div></div></div>
    <div class="text-center mt-3">
        <button type="submit" class="btn btn-import" id="btnSubmit"><i class="mdi mdi-magnify"></i> ANALISAR PLAYLIST</button>
        <button type="button" class="btn btn-outline-info ml-2" id="btnSimulate" style="display:none" onclick="runSimulation()"><i class="mdi mdi-test-tube"></i> SIMULAR IMPORTAÇÃO</button>
    </div>
</form>
</div></div></div></div>

<div class="row mt-4" id="diagnosticPanel" style="display:none"><div class="col-12"><div class="card"><div class="card-body">
    <div class="d-flex justify-content-between"><h4><i class="mdi mdi-pulse"></i> Diagnóstico</h4><span class="badge badge-info" id="diagStatus">Aguardando</span></div>
    <div class="row mt-2" id="diagMetrics"></div>
    <div class="progress mt-2"><div class="progress-bar progress-bar-striped progress-bar-animated" id="diagProgress" style="width:0%"></div></div>
    <div class="mt-3 p-2" id="diagLogs" style="height:300px;overflow:auto;background:#111;color:#ddd;border-radius:6px;font-family:monospace;font-size:12px;"></div>
</div></div></div></div>

<div class="row mt-4">
    <div class="col-md-3"><div class="card card-stats live text-center p-3"><div class="stat-number text-primary"><?= number_format($rCounts['live']) ?></div><div class="stat-label">Canais Live</div></div></div>
    <div class="col-md-3"><div class="card card-stats movies text-center p-3"><div class="stat-number text-success"><?= number_format($rCounts['movies']) ?></div><div class="stat-label">Filmes</div></div></div>
    <div class="col-md-3"><div class="card card-stats series text-center p-3"><div class="stat-number text-info"><?= number_format($rCounts['series']) ?></div><div class="stat-label">Séries</div></div></div>
    <div class="col-md-3"><div class="card card-stats radio text-center p-3"><div class="stat-number" style="color:#ab8ce4;"><?= count($rBouquets) ?></div><div class="stat-label">Buquês</div></div></div>
</div>
</div></div>

<script src="assets/js/vendor.min.js"></script>
<script src="assets/libs/select2/select2.min.js"></script>
<script src="assets/js/app.min.js"></script>
<script>
$(function(){
    $('.select2').select2({width:'100%'});
    var uploadZone=document.getElementById('uploadZone'), fileInput=document.getElementById('m3u_file'), fileName=document.getElementById('fileName'),
        btnSubmit=document.getElementById('btnSubmit'), btnSimulate=document.getElementById('btnSimulate'),
        tokenInput=document.getElementById('upload_token'), analyzed=false, uploadTokenGlobal='',
        CHUNK=16*1024*1024, MIN_CHUNK=512*1024, uploadProgress=document.getElementById('uploadProgress'),
        uploadProgressBar=document.getElementById('uploadProgressBar');
    function token(){ return Array.from(window.crypto.getRandomValues(new Uint8Array(16))).map(b=>b.toString(16).padStart(2,'0')).join(''); }
    function humanSize(b){ var u=['B','KB','MB','GB','TB'],v=Number(b||0),i=0; while(v>=1024&&i<u.length-1){v/=1024;i++;} return v.toFixed(i===0?0:1)+' '+u[i]; }
    function setButton(h,d,btn){ btn=btn||btnSubmit; btn.innerHTML=h; btn.disabled=!!d; }
    async function post(data){ var r=await fetch('./m3u_update_nodup.php',{method:'POST',body:data,credentials:'same-origin'}); var p=null; try{p=await r.json();}catch(e){throw new Error(r.status===413?'Servidor rejeitou bloco.':'Resposta inválida.');} if(!r.ok||!p.ok) throw new Error(p.error||'Falha.'); return p; }
    async function uploadFile(file,tok){
        var chunkSize=CHUNK,offset=0,idx=0; uploadProgress.style.display='block'; uploadProgressBar.style.width='0%';
        while(offset<file.size){
            var total=Math.ceil(file.size/chunkSize),fd=new FormData();
            fd.append('ajax_action','upload_chunk'); fd.append('upload_token',tok); fd.append('chunk_index',String(idx));
            fd.append('chunk_total',String(total)); fd.append('file_size',String(file.size)); fd.append('file_name',file.name);
            fd.append('chunk',file.slice(offset,Math.min(file.size,offset+chunkSize)),file.name+'.part');
            try{await post(fd);}catch(e){if((e.message.includes('413')||e.message.includes('tamanho'))&&idx===0&&chunkSize>MIN_CHUNK){chunkSize=Math.max(MIN_CHUNK,Math.floor(chunkSize/2));continue;} throw e;}
            offset+=chunkSize; idx++;
            var pct=Math.min(100,Math.round(offset/file.size*100));
            uploadProgressBar.style.width=pct+'%'; setButton('<i class="mdi mdi-loading mdi-spin"></i> Enviando '+pct+'%',true);
        }
        uploadProgress.style.display='none';
    }
    async function fetchRemote(url,tok){ var fd=new FormData(); fd.append('ajax_action','fetch_remote'); fd.append('upload_token',tok); fd.append('m3u_url',url); setButton('<i class="mdi mdi-loading mdi-spin"></i> Baixando...',true); await post(fd); }
    async function analyze(tok){ var fd=new FormData(); fd.append('ajax_action','analyze'); fd.append('upload_token',tok); setButton('<i class="mdi mdi-loading mdi-spin"></i> Analisando...',true); var r=await post(fd); renderAnalysis(r.analysis); analyzed=true; setButton('<i class="mdi mdi-shield-check"></i> IMPORTAR',false); btnSimulate.style.display='inline-block'; }
    function renderAnalysis(a){
        document.getElementById('analysisPanel').style.display='flex';
        document.getElementById('analysisSummary').innerHTML=
            '<span class="badge badge-dark badge-count">'+humanSize(a.file_size)+'</span> '+
            '<span class="badge badge-primary badge-count">Total: '+Number(a.total).toLocaleString('pt-BR')+'</span> '+
            '<span class="badge badge-info badge-count">Live: '+Number(a.live).toLocaleString('pt-BR')+'</span> '+
            '<span class="badge badge-success badge-count">Filmes: '+Number(a.movies).toLocaleString('pt-BR')+'</span> '+
            '<span class="badge badge-warning badge-count">Episódios: '+Number(a.series).toLocaleString('pt-BR')+'</span> '+
            '<span class="badge badge-secondary badge-count">Séries: '+Number(a.series_titles_count).toLocaleString('pt-BR')+'</span> '+
            '<span class="badge badge-light badge-count">Temporadas: '+Number(a.seasons_count).toLocaleString('pt-BR')+'</span> '+
            '<span class="badge badge-danger badge-count">Duplicados: '+Number(a.duplicates_in_file).toLocaleString('pt-BR')+'</span>';
        var log=document.getElementById('analysisLog'), html='<strong>Log de análise:</strong><br>';
        (a.warnings||[]).forEach(function(w){ html+='<div class="log-entry warning">⚠ '+w+'</div>'; });
        html+='<div class="log-entry info">ℹ '+(a.total||0)+' itens encontrados.</div>';
        html+='<div class="log-entry success">✔ Análise concluída com sucesso.</div>';
        log.innerHTML=html;
        document.getElementById('analysisPanel').scrollIntoView({behavior:'smooth',block:'center'});
    }
    async function runSimulation(){
        if(!uploadTokenGlobal) return alert('Faça upload primeiro.');
        setButton('<i class="mdi mdi-loading mdi-spin"></i> Simulando...',true,btnSimulate);
        var fd=new FormData(); fd.append('ajax_action','simulate'); fd.append('upload_token',uploadTokenGlobal);
        fd.append('servers',document.querySelector('[name="servers"]').value);
        document.querySelectorAll('[name="bouquets[]"] option:checked').forEach(function(o){ fd.append('bouquets[]',o.value); });
        try{
            var r=await post(fd);
            document.getElementById('simulationPanel').style.display='flex';
            document.getElementById('simulationSummary').innerHTML='<strong>Resultado da simulação:</strong> '+
                'Total: '+r.simulation.total+' | Inseridos: '+r.simulation.inserted+' | Atualizados: '+r.simulation.updated+' | Ignorados: '+r.simulation.skipped+
                ' | Erros: '+r.simulation.errors;
            setButton('<i class="mdi mdi-test-tube"></i> SIMULAR IMPORTAÇÃO',false,btnSimulate);
        }catch(e){ alert(e.message); setButton('<i class="mdi mdi-test-tube"></i> SIMULAR IMPORTAÇÃO',false,btnSimulate); }
    }
    uploadZone.addEventListener('click',function(){ fileInput.click(); });
    ['dragenter','dragover'].forEach(function(e){ uploadZone.addEventListener(e,function(ev){ ev.preventDefault(); uploadZone.classList.add('dragover'); }); });
    ['dragleave','drop'].forEach(function(e){ uploadZone.addEventListener(e,function(ev){ ev.preventDefault(); uploadZone.classList.remove('dragover'); }); });
    uploadZone.addEventListener('drop',function(e){ if(e.dataTransfer.files.length){ var dt=new DataTransfer(); dt.items.add(e.dataTransfer.files[0]); fileInput.files=dt.files; fileName.textContent='Arquivo: '+e.dataTransfer.files[0].name+' ('+humanSize(e.dataTransfer.files[0].size)+')'; analyzed=false; } });
    fileInput.addEventListener('change',function(){ if(this.files.length) fileName.textContent='Arquivo: '+this.files[0].name+' ('+humanSize(this.files[0].size)+')'; analyzed=false; });

    var diagTimer=null;
    function esc(v){ var d=document.createElement('div'); d.textContent=String(v==null?'':v); return d.innerHTML; }
    function renderDiagnostic(d){
        document.getElementById('diagnosticPanel').style.display='flex';
        document.getElementById('diagStatus').textContent=(d.status||'executando')+' — '+(d.stage||'');
        var total=Number(d.channels_expected||d.channels_found||0), done=Number(d.channels_imported||0)+Number(d.channels_updated||0)+Number(d.channels_skipped||0)+Number(d.errors||0), pct=total>0?Math.min(100,Math.round(done*100/total)):0;
        document.getElementById('diagProgress').style.width=pct+'%';
        var metrics=[
            ['Memória',humanSize(d.memory_current)],['Pico',humanSize(d.memory_peak)],['Categorias criadas',d.categories_created],
            ['Categorias reutilizadas',d.categories_reused],['Inseridos',d.channels_imported],['Atualizados',d.channels_updated],
            ['Ignorados',d.channels_skipped],['Erros',d.errors],['Avisos',d.warnings],['SQL',d.sql_queries],
            ['Velocidade',(d.items_per_second||0)+' it/s'],['Tempo',Number(d.elapsed_seconds||0).toFixed(1)+'s'],['Média/lote',Number(d.average_batch_seconds||0).toFixed(2)+'s']
        ];
        if(d.eta_seconds>0) metrics.push(['ETA',Math.ceil(d.eta_seconds)+'s']);
        document.getElementById('diagMetrics').innerHTML=metrics.map(function(x){return '<div class="col-6 col-md-3 col-xl-2 mb-2"><div class="border rounded p-2"><small>'+esc(x[0])+'</small><div><strong>'+esc(x[1])+'</strong></div></div></div>';}).join('');
        var icons={success:'✔',info:'ℹ',warning:'⚠',error:'✖'};
        document.getElementById('diagLogs').innerHTML=(d.logs||[]).map(function(l){ return '<div>'+esc(icons[l.level]||'ℹ')+' ['+esc(l.time)+'] ['+esc(l.stage)+'] '+esc(l.message)+(l.file?' <span style="color:#999">('+esc(l.file)+':'+esc(l.line||'')+')</span>':'')+'</div>'; }).join('');
        var box=document.getElementById('diagLogs'); box.scrollTop=box.scrollHeight;
    }
    async function pollDiagnostic(jobId){ clearInterval(diagTimer); async function one(){ try{ var r=await fetch('./m3u_update_nodup.php?import_status='+encodeURIComponent(jobId),{credentials:'same-origin'}); var p=await r.json(); if(p.ok) renderDiagnostic(p.diagnostic); if(p.ok&&['sucesso','concluído_com_avisos','falha'].indexOf(p.diagnostic.status)>=0) clearInterval(diagTimer); }catch(e){} } await one(); diagTimer=setInterval(one,1000); }
    async function startRealImport(){
        var fd=new FormData(); fd.append('ajax_action','prepare_import'); fd.append('upload_token',tokenInput.value);
        var p=await post(fd); await pollDiagnostic(p.job_id);
        fd=new FormData(); fd.append('ajax_action','start_import'); fd.append('upload_token',tokenInput.value); fd.append('job_id',p.job_id);
        fd.append('servers',document.querySelector('[name="servers"]').value);
        document.querySelectorAll('[name="bouquets[]"] option:checked').forEach(function(o){ fd.append('bouquets[]',o.value); });
        var resp=await fetch('./m3u_update_nodup.php',{method:'POST',body:fd,credentials:'same-origin'});
        var payload=await resp.json();
        await new Promise(function(r){setTimeout(r,1200);});
        if(!resp.ok||!payload.ok) throw new Error((payload.result&&payload.result.error)||payload.error||'Falha na importação.');
        return payload;
    }

    document.getElementById('importForm').addEventListener('submit',async function(e){
        e.preventDefault();
        if(analyzed){
            setButton('<i class="mdi mdi-loading mdi-spin"></i> Importando...',true);
            try{ await startRealImport(); setButton('<i class="mdi mdi-check"></i> CONCLUÍDO',true); }
            catch(err){ setButton('<i class="mdi mdi-alert"></i> TENTAR NOVAMENTE',false); alert(err.message); }
            return;
        }
        try{
            var file=fileInput.files.length?fileInput.files[0]:null, url=document.getElementById('m3u_url').value.trim();
            if(!file&&!url) throw new Error('Selecione um arquivo ou URL.');
            if(file&&!/\.(m3u|m3u8|txt)$/i.test(file.name)) throw new Error('Formato inválido.');
            uploadTokenGlobal = token(); tokenInput.value=uploadTokenGlobal;
            if(file) await uploadFile(file,uploadTokenGlobal); else await fetchRemote(url,uploadTokenGlobal);
            await analyze(uploadTokenGlobal);
        }catch(err){ analyzed=false; setButton('<i class="mdi mdi-magnify"></i> ANALISAR',false); alert(err.message); }
    });
});
</script>
</body></html>
<?php
include 'session.php'; include 'functions.php';
if ((int)($rPermissions['is_admin'] ?? 0) !== 1 || !hasPermissions('adv','settings')) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'Acesso restrito ao administrador.'], JSON_UNESCAPED_UNICODE);
    exit;
}
require_once dirname(__DIR__) . '/player/bootstrap.php';
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
function out($a,$s=200){http_response_code($s);echo json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
if($_SERVER['REQUEST_METHOD']==='GET'){
  $cfg=cs_player_load_config();
  if(($_GET['action']??'')==='test'){
    $url=cs_player_normalize_dns((string)($_GET['url']??'')); if(!$url)out(['ok'=>false,'message'=>'DNS inválido'],400);
    $start=microtime(true); $test=cs_player_http_json($url.'/player_api.php',4); $ms=(int)((microtime(true)-$start)*1000);
    out(['ok'=>$test!==null,'latency_ms'=>$ms,'message'=>$test!==null?'DNS respondeu':'Sem resposta JSON do player_api.php']);
  }
  out(['ok'=>true,'config'=>$cfg,'player_url'=>'../player/']);
}
if($_SERVER['REQUEST_METHOD']!=='POST')out(['ok'=>false],405);
$raw=json_decode((string)file_get_contents('php://input'),true); if(!is_array($raw))out(['ok'=>false,'message'=>'JSON inválido'],400);
$cfg=cs_player_default_config();
foreach(['enabled','smart_login','dns_failover','pip_enabled','autoplay_next','remember_position'] as $k)$cfg[$k]=!empty($raw[$k]);
foreach(['brand','login_title','login_subtitle','home_title'] as $k)$cfg[$k]=mb_substr(trim((string)($raw[$k]??$cfg[$k])),0,160);
$cfg['hls_retries']=max(1,min(10,(int)($raw['hls_retries']??4)));$cfg['stall_timeout']=max(5,min(60,(int)($raw['stall_timeout']??12)));$cfg['request_timeout']=max(3,min(30,(int)($raw['request_timeout']??8)));
$cfg['dns']=[]; foreach(($raw['dns']??[]) as $i=>$row){if(!is_array($row))continue;$url=cs_player_normalize_dns((string)($row['url']??''));if(!$url)continue;$cfg['dns'][]=['id'=>(string)($row['id']??('dns_'.($i+1))),'name'=>mb_substr(trim((string)($row['name']??('DNS '.($i+1)))),0,80),'url'=>$url,'enabled'=>!empty($row['enabled']),'priority'=>max(1,min(999,(int)($row['priority']??($i+1))))];}
if(!cs_player_save_config($cfg))out(['ok'=>false,'message'=>'Não foi possível salvar player/storage/config.json'],500);out(['ok'=>true,'message'=>'Configurações do Web Player salvas.','config'=>$cfg]);

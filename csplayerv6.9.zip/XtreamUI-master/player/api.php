<?php
require __DIR__ . '/bootstrap.php';
if (empty($_SESSION['cs_player_auth'])) cs_player_json(['ok'=>false,'message'=>'Sessão expirada'],401);
$cfg = cs_player_load_config();
$dnsRow = cs_player_session_dns($cfg);
if (!$dnsRow) cs_player_json(['ok'=>false,'message'=>'DNS indisponível'],503);
$dns = $dnsRow['url']; $u=(string)$_SESSION['cs_player_username']; $p=(string)$_SESSION['cs_player_password'];
$action=(string)($_GET['action']??'home');
if ($action==='home') {
    $liveCats=cs_player_api_call($dns,$u,$p,'get_live_categories')??[];
    $vodCats=cs_player_api_call($dns,$u,$p,'get_vod_categories')??[];
    $seriesCats=cs_player_api_call($dns,$u,$p,'get_series_categories')??[];
    $live=cs_player_api_call($dns,$u,$p,'get_live_streams')??[];
    $vod=cs_player_api_call($dns,$u,$p,'get_vod_streams')??[];
    $series=cs_player_api_call($dns,$u,$p,'get_series')??[];
    cs_player_json(['ok'=>true,'server'=>['name'=>$dnsRow['name']??'Servidor'],'user'=>$_SESSION['cs_player_user_info']??[], 'categories'=>['live'=>$liveCats,'movies'=>$vodCats,'series'=>$seriesCats], 'content'=>['live'=>array_slice($live,0,120),'movies'=>array_slice($vod,0,120),'series'=>array_slice($series,0,120)], 'features'=>['pip'=>(bool)$cfg['pip_enabled'],'failover'=>(bool)$cfg['dns_failover'],'stall_timeout'=>(int)$cfg['stall_timeout'],'retries'=>(int)$cfg['hls_retries']]]);
}
if ($action==='series_info') {
    $id=(int)($_GET['id']??0); if(!$id) cs_player_json(['ok'=>false,'message'=>'Série inválida'],400);
    $data=cs_player_api_call($dns,$u,$p,'get_series_info',['series_id'=>$id]); cs_player_json(['ok'=>(bool)$data,'data'=>$data]);
}
if ($action==='category') {
    $type=(string)($_GET['type']??'live'); $cat=(string)($_GET['category_id']??'');
    $map=['live'=>'get_live_streams','movies'=>'get_vod_streams','series'=>'get_series']; if(!isset($map[$type])) cs_player_json(['ok'=>false],400);
    $extra=$cat!==''?['category_id'=>$cat]:[]; $data=cs_player_api_call($dns,$u,$p,$map[$type],$extra)??[]; cs_player_json(['ok'=>true,'data'=>$data]);
}
if ($action==='failover') {
    if (empty($cfg['dns_failover'])) cs_player_json(['ok'=>false,'message'=>'Failover desativado']);
    $active=cs_player_active_dns($cfg); $current=(int)($_SESSION['cs_player_dns_index']??-1); $start=0;
    foreach($active as $i=>$row){ if((int)$row['_index']===$current){$start=$i+1;break;} }
    for($step=0;$step<count($active);$step++){
        $row=$active[($start+$step)%count($active)]; if((int)$row['_index']===$current) continue;
        $data=cs_player_api_call($row['url'],$u,$p);
        if(cs_player_is_authenticated_response($data)){$_SESSION['cs_player_dns_index']=(int)$row['_index'];$_SESSION['cs_player_dns_name']=$row['name']??'Servidor';cs_player_json(['ok'=>true,'server'=>$_SESSION['cs_player_dns_name']]);}
    }
    cs_player_json(['ok'=>false,'message'=>'Nenhum DNS alternativo respondeu']);
}
cs_player_json(['ok'=>false,'message'=>'Ação inválida'],400);

<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('CSPLAYER_WEB');
    session_start();
}

define('CS_PLAYER_ROOT', __DIR__);
if (!defined('CS_PLAYER_INTERNAL')) { define('CS_PLAYER_INTERNAL', true); }
define('CS_PLAYER_CONFIG_FILE', CS_PLAYER_ROOT . '/storage/config.php');
define('CS_PLAYER_LEGACY_CONFIG_FILE', CS_PLAYER_ROOT . '/storage/config.json');

function cs_player_default_config(): array {
    return [
        'enabled' => true,
        'brand' => 'CS Player',
        'login_title' => 'CS Player',
        'login_subtitle' => 'Entre com sua assinatura para continuar',
        'home_title' => 'Início',
        'smart_login' => true,
        'dns_failover' => true,
        'pip_enabled' => true,
        'autoplay_next' => false,
        'remember_position' => true,
        'hls_retries' => 4,
        'stall_timeout' => 12,
        'request_timeout' => 8,
        'dns' => [],
    ];
}

function cs_player_load_config(): array {
    $default = cs_player_default_config();
    $data = null;

    if (is_file(CS_PLAYER_CONFIG_FILE)) {
        $loaded = include CS_PLAYER_CONFIG_FILE;
        if (is_array($loaded)) {
            $data = $loaded;
        }
    } elseif (is_file(CS_PLAYER_LEGACY_CONFIG_FILE)) {
        $raw = file_get_contents(CS_PLAYER_LEGACY_CONFIG_FILE);
        $legacy = json_decode((string)$raw, true);
        if (is_array($legacy)) {
            $data = $legacy;
            // Migração transparente: preserva a configuração existente sem banco de dados.
            if (cs_player_save_config($legacy)) {
                @unlink(CS_PLAYER_LEGACY_CONFIG_FILE);
            }
        }
    }

    if (!is_array($data)) {
        return $default;
    }
    $cfg = array_replace($default, $data);
    $cfg['dns'] = is_array($cfg['dns'] ?? null) ? array_values($cfg['dns']) : [];
    return $cfg;
}

function cs_player_save_config(array $config): bool {
    $dir = dirname(CS_PLAYER_CONFIG_FILE);
    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
        return false;
    }
    $tmp = CS_PLAYER_CONFIG_FILE . '.tmp';
    $php = "<?php\nif (!defined('CS_PLAYER_INTERNAL')) { http_response_code(404); exit; }\nreturn " . var_export($config, true) . ";\n";
    if (file_put_contents($tmp, $php, LOCK_EX) === false) {
        return false;
    }
    @chmod($tmp, 0640);
    if (!rename($tmp, CS_PLAYER_CONFIG_FILE)) {
        @unlink($tmp);
        return false;
    }
    @chmod(CS_PLAYER_CONFIG_FILE, 0640);
    return true;
}

function cs_player_normalize_dns(string $url): string {
    $url = trim($url);
    if ($url === '') return '';
    if (!preg_match('~^https?://~i', $url)) $url = 'http://' . $url;
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) return '';
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    if (!in_array($scheme, ['http','https'], true)) return '';
    $host = $parts['host'];
    $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
    $path = isset($parts['path']) ? rtrim($parts['path'], '/') : '';
    return $scheme . '://' . $host . $port . $path;
}

function cs_player_active_dns(array $cfg): array {
    $rows = [];
    foreach (($cfg['dns'] ?? []) as $idx => $row) {
        if (!is_array($row) || empty($row['enabled'])) continue;
        $url = cs_player_normalize_dns((string)($row['url'] ?? ''));
        if ($url === '') continue;
        $row['url'] = $url;
        $row['_index'] = $idx;
        $rows[] = $row;
    }
    usort($rows, static fn($a,$b) => (int)($a['priority'] ?? 100) <=> (int)($b['priority'] ?? 100));
    return $rows;
}

function cs_player_http_json(string $url, int $timeout = 8): ?array {
    if (!function_exists('curl_init')) return null;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_USERAGENT => 'CSPlayer-Web/1.0',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if (!is_string($body) || $code < 200 || $code >= 400) return null;
    $data = json_decode($body, true);
    return is_array($data) ? $data : null;
}

function cs_player_api_call(string $dns, string $username, string $password, string $action = '', array $extra = []): ?array {
    $params = array_merge(['username' => $username, 'password' => $password], $extra);
    if ($action !== '') $params['action'] = $action;
    $cfg = cs_player_load_config();
    $timeout = max(3, min(30, (int)($cfg['request_timeout'] ?? 8)));
    return cs_player_http_json(rtrim($dns, '/') . '/player_api.php?' . http_build_query($params), $timeout);
}

function cs_player_is_authenticated_response(?array $data): bool {
    if (!$data || !isset($data['user_info']) || !is_array($data['user_info'])) return false;
    $ui = $data['user_info'];
    if (isset($ui['auth']) && (int)$ui['auth'] !== 1) return false;
    if (isset($ui['status']) && !in_array(strtolower((string)$ui['status']), ['active','1'], true)) return false;
    return !empty($ui['username']) || isset($ui['auth']);
}

function cs_player_require_login(): void {
    if (empty($_SESSION['cs_player_auth']) || empty($_SESSION['cs_player_username']) || !isset($_SESSION['cs_player_dns_index'])) {
        header('Location: index.php');
        exit;
    }
}

function cs_player_json(array $payload, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function cs_player_session_dns(array $cfg, ?int $requested = null): ?array {
    $active = cs_player_active_dns($cfg);
    if (!$active) return null;
    $index = $requested ?? (int)($_SESSION['cs_player_dns_index'] ?? -1);
    foreach ($active as $row) {
        if ((int)$row['_index'] === $index) return $row;
    }
    return $active[0];
}

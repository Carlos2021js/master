#!/usr/bin/env bash
set -Eeuo pipefail

# CS PLAYER — Atualizador remoto seguro via Dropbox/GitHub
# Mantém a estrutura técnica XtreamUI-master exigida pelo instalador.
# Não altera o banco de dados.

TARGET="/home/xtreamcodes/iptv_xtream_codes"
PHPXC="$TARGET/php/bin/php"
TMPROOT="/tmp/cs-player-update"
BACKUPROOT="$TARGET/admin/backups/remote-updates"
URL="${1:-}"

log(){ printf '[CS PLAYER] %s\n' "$*"; }
fail(){ printf '[CS PLAYER][ERRO] %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Execute como root."
[ -n "$URL" ] || fail "Uso: $0 URL_HTTPS_DO_ZIP (Dropbox ou GitHub)"
case "$URL" in
  https://www.dropbox.com/*|https://dropbox.com/*|https://dl.dropboxusercontent.com/*|https://github.com/*|https://raw.githubusercontent.com/*) ;;
  *) fail "Por segurança, informe uma URL HTTPS do Dropbox ou GitHub." ;;
esac

command -v unzip >/dev/null 2>&1 || fail "unzip não está instalado."
if command -v curl >/dev/null 2>&1; then
  FETCH=(curl -fL --connect-timeout 15 --max-time 300 -A "CS-PLAYER-Updater/6.6.4" -o)
elif command -v wget >/dev/null 2>&1; then
  FETCH=(wget -q --timeout=30 -O)
else
  fail "curl ou wget é necessário."
fi

rm -rf "$TMPROOT"
mkdir -p "$TMPROOT" "$BACKUPROOT"
ZIP="$TMPROOT/update.zip"
EXTRACT="$TMPROOT/extract"
mkdir -p "$EXTRACT"

log "Baixando atualização..."
if [ "${FETCH[0]}" = "curl" ]; then
  "${FETCH[@]}" "$ZIP" "$URL" || fail "Falha ao baixar ZIP."
else
  "${FETCH[@]}" "$ZIP" "$URL" || fail "Falha ao baixar ZIP."
fi

unzip -tq "$ZIP" >/dev/null || fail "ZIP inválido ou corrompido."
unzip -q "$ZIP" -d "$EXTRACT"

ROOT="$EXTRACT/XtreamUI-master"
[ -d "$ROOT" ] || fail "O ZIP precisa conter a pasta raiz XtreamUI-master/."
[ -f "$ROOT/admin/settings.php" ] || fail "Pacote incompleto: admin/settings.php ausente."
[ -f "$ROOT/admin/player/bootstrap.php" ] || fail "Pacote incompleto: Web Player ausente."

log "Validando PHP antes da atualização..."
LINTER=""
if [ -x "$PHPXC" ]; then LINTER="$PHPXC"; elif command -v php >/dev/null 2>&1; then LINTER="$(command -v php)"; fi
if [ -n "$LINTER" ]; then
  FAILED=0
  while IFS= read -r -d '' f; do
    if ! "$LINTER" -l "$f" >/dev/null 2>&1; then
      echo "ERRO PHP: ${f#$ROOT/}" >&2
      "$LINTER" -l "$f" >&2 || true
      FAILED=1
    fi
  done < <(find "$ROOT/admin" -type f -name '*.php' -print0)
  [ "$FAILED" -eq 0 ] || fail "Atualização cancelada: pacote contém erro PHP para o runtime do CS PLAYER."
  log "PHP validado com $($LINTER -r 'echo PHP_VERSION;' 2>/dev/null || true)."
else
  log "Aviso: nenhum PHP CLI localizado; continuando sem lint."
fi

STAMP="$(date +%Y-%m-%d_%H-%M-%S)"
BACKUP="$BACKUPROOT/$STAMP"
mkdir -p "$BACKUP"

log "Criando backup dos arquivos administrativos atuais..."
[ -d "$TARGET/admin" ] && tar -czf "$BACKUP/admin.tar.gz" -C "$TARGET" admin 2>/dev/null || true
[ -f "$TARGET/CS_PLAYER_RELEASE.txt" ] && cp -a "$TARGET/CS_PLAYER_RELEASE.txt" "$BACKUP/" || true

# Arquivos persistentes que não devem ser substituídos por atualização.
PERSIST="$TMPROOT/persist"
mkdir -p "$PERSIST"
[ -f "$TARGET/config" ] && cp -a "$TARGET/config" "$PERSIST/main-config" || true
for f in \
  "$TARGET/admin/logs/cs-player/web-player-config.php" \
  "$TARGET/admin/logs/cs-player/web-player-config.php.bak" \
  "$TARGET/admin/logs/cs-player/dns-health.json"; do
  if [ -f "$f" ]; then
    mkdir -p "$PERSIST/$(dirname "${f#$TARGET/}")"
    cp -a "$f" "$PERSIST/${f#$TARGET/}"
  fi
done

log "Aplicando arquivos da nova versão..."
cp -a "$ROOT"/. "$TARGET"/

# Restaura dados persistentes caso o pacote trouxesse versões vazias.
[ -f "$PERSIST/main-config" ] && cp -a "$PERSIST/main-config" "$TARGET/config" || true
if [ -d "$PERSIST/admin" ]; then cp -a "$PERSIST/admin"/. "$TARGET/admin"/; fi

chown -R xtreamcodes:xtreamcodes "$TARGET" 2>/dev/null || true

log "Executando pós-validação..."
if [ -x "$PHPXC" ] && [ -f "$TARGET/admin/player/check_install.php" ]; then
  "$PHPXC" "$TARGET/admin/player/check_install.php" || fail "Pós-validação falhou. Backup disponível em $BACKUP"
fi

rm -rf "$TMPROOT"
log "Atualização concluída."
log "Backup: $BACKUP"
log "Banco de dados não foi alterado."

# CS PLAYER v6.3.8 — Player estilo YouTube

- Player de vídeo redesenhado com controles customizados inspirados na organização do YouTube.
- Barra de progresso inferior, play/pause central, tempo, volume, PiP, Cast, configurações de velocidade e tela cheia.
- Botão manual Reconectar removido.
- Reconexão automática mantida e aprimorada com atraso progressivo, recuperação silenciosa e failover automático.
- Controles responsivos para smartphone e desktop.
- Banco de dados inalterado.
